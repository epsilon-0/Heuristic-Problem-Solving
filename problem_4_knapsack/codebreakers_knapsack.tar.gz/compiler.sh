#!/bin/bash

g++ Knapsack.cpp BNBTree.cpp -o solver

