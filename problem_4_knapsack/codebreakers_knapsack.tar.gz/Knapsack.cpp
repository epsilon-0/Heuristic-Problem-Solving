#include<iostream>
#include<vector>
#include<algorithm>
#include<ctime>

#include "knapsack.h"
#include "quadknap.h"
#include "BNBTree.h"

using namespace std;

int TYPE;

vector< int > value, weight;
int capacity;
vector< int > knapsacks;
vector< vector< int > > gain;
vector< int > pi1;

int get_input(){
  int sz, index, val, wt, knaps;
  cin >> TYPE;
  if ( TYPE == 1 ){
    cin >> sz;
    cin >> capacity;
    value.resize(sz); weight.resize(sz);
    for ( int i = 0; i < sz; i++ ){
      cin >> index >> val >> wt;
      index--;
      value[index] = val;
      weight[index] = wt;
    }
  }
  else if ( TYPE == 2 ){
    cin >> sz >> knaps;
    for ( int i = 0; i < knaps; i++ ){
      cin >> capacity;
      knapsacks.push_back(capacity);
    }
    value.resize(sz); weight.resize(sz);
    for ( int i = 0; i < sz; i++ ){
      cin >> index >> val >> wt;
      index--;
      value[index] = val;
      weight[index] = wt;
    }
  }
  else if ( TYPE == 3 ){
    cin >> sz;
    cin >> capacity;
    for ( int i = 0; i < sz; i++ ){
      cin >> wt;
      weight.push_back(wt);
    }
    gain.resize(sz);
    for ( int i = 0; i < sz; i++ ){
      gain[i].resize(sz);
    }
    for ( int i = 0; i < sz; i++ ){
      cin >> val;
      gain[i][i] = val;
      value.push_back( val );
    }
    for ( int i = 0; i < sz - 1; i++ ){
      for ( int j = i+1; j < sz; j++ ){
	cin >> val;
	gain[i][j] = val;
	gain[j][i] = val;
      }
    }
  }
}

bool comp ( int i, int j){
  return value[i]*weight[j] > value[j]*weight[i];
}

vector< int > solve(vector< int > value, vector< int > weight, int capacity){

  // sort the numbers by increasing order of pi/wi
  vector< int > ind;
  for ( int i = 0; i < value.size(); i++ ){
    ind.push_back(i);
  }
  sort( ind.begin(), ind.end(), comp );

  vector< int > newv, neww;
  for ( int i = 0; i < value.size(); i++ ){
    newv.push_back(value[ind[i]]);
    neww.push_back(weight[ind[i]]);
  }

  // find critical item
  int tot = 0;
  int crit = 0;
  while ( tot < capacity && crit < newv.size()){
    tot += neww[crit];
    crit++;
  }

  int newcapacity = capacity;
  vector< int > answer;
  int pos = 0;
  while ( pos < crit/3 ){
    answer.push_back(pos);
    newcapacity -= neww[pos];
    pos++;
  }

  vector< int > tempv, tempw;
  while ( pos < (crit+2*(value.size()-1))/3 ){
    tempv.push_back(newv[pos]);
    tempw.push_back(neww[pos]);
    pos++;
  }

  Knapsack core(tempv, tempw, newcapacity, true);

  vector< int > coreanswer = core.getWitness();

  int already = answer.size();

  for ( int i = 0; i < coreanswer.size(); i++ ){
    answer.push_back(already+coreanswer[i]);
  }

  vector< int > sln;
  for ( int i = 0; i < answer.size(); i++ ){
    sln.push_back(ind[answer[i]]);
  }
  
  sort( sln.begin(), sln.end() );
  
  return sln;
}

bool qcomp( int i, int j ){
  return pi1[i] > pi1[j];
}

vector< int > qsolve(){
  srand(time(NULL));
  pi1.clear();
  for ( int i = 0; i < weight.size(); i++ ){
    pi1.push_back( accumulate( gain[i].begin(), gain[i].end(), 0 ) );
  }

  vector< int > ind;
  for ( int i = 0; i < weight.size(); i++ ){
    ind.push_back(i);
  }

  sort(ind.begin(), ind.end(), qcomp);

  vector< int > newweight(weight.size(), 0);
  vector< vector< int > > newgain(weight.size());
  vector< int > best_solution, current_solution;
  int curr_best = 0, curr;

  clock_t start = clock();
  int cn = 0;
  while(true){
    if ( (clock() - start) / (double) CLOCKS_PER_SEC > 160 ){
      break;
    }
    if ( cn > 0 ){
      random_shuffle(ind.begin(),ind.end());
    }
    cn++;
    for ( int i = 0; i < weight.size(); i++ ){
      newweight[i] = weight[ind[i]];
      newgain[i].resize(weight.size());
    }
  
    for ( int i = 0; i < newweight.size(); i++ ){
      for ( int j = 0; j < newweight.size(); j++ ){
	newgain[i][j] = gain[ind[i]][ind[j]];
      }
    }

    Quadknap qt(newweight, newgain, capacity);
    curr = qt.getSolution();
    if ( curr > curr_best ){
      curr_best = curr;
      current_solution = qt.getWitness();
      best_solution.clear();
      for ( int i = 0; i < current_solution.size(); i++ ){
	best_solution.push_back(ind[current_solution[i]]);
      }
    }
    //    cout << curr_best << endl;
  }
  return best_solution;
}

int main(){
  get_input();
  if ( TYPE == 1 ){
    vector< int > answer = solve(value, weight, capacity);
    for ( int i = 0; i < answer.size(); i++ ){
      cout << answer[i] + 1 << endl;
    }
  }
  if ( TYPE == 2 ){
    BnbTree bnbTree = BnbTree(value, weight, knapsacks);
    bnbTree.solve();
    vector<vector<int> > witness = bnbTree.getWitness(); 
    for (int i = 0; i < witness.size(); i++) {
      for (int j = 0; j < witness[i].size(); j++) {
	cout << witness[i][j] + 1 << " " << i + 1 << endl;
      }
    }
  }
  if ( TYPE == 3 ){
    vector< int > answer = qsolve();
    for ( int i = 0; i < answer.size(); i++ ){
      cout << answer[i] + 1 << endl;
    }
  }
}
