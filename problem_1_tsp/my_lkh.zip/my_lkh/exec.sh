#!/bin/bash

./LKSolver < $1 > $2


