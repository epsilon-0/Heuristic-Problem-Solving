for i in range(100):
  printf("%d %d %d",i,i,i)
