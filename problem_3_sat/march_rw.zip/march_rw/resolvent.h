int resolvent_look();
