#!/bin/bash

./WalkSat <$1 >$2
