#! /bin/bash

g++ WalkSat.cpp -o WalkSat
