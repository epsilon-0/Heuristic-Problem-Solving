#!/bin/sh
export MROOT=<full_path>
echo $MROOT
cd simp
gmake clean
gmake rs
cp minisat_static ../lr_gl_shr
