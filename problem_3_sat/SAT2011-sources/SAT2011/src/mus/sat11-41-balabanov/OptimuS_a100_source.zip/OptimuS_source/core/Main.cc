/*****************************************************************************************[Main.cc]
Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
Copyright (c) 2007-2010, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#include <errno.h>

#include <signal.h>
#include <zlib.h>

#include "utils/System.h"
#include "utils/ParseUtils.h"
#include "utils/Options.h"
#include "core/Dimacs.h"
#include "core/Solver.h"

using namespace Minisat;

//=================================================================================================
typedef struct myvariable_ myvariable;
typedef struct myclause_ myclause;

struct myclause_
	{
	int answer;		//answer=1 - can be removed; answer=2 - can't be removed!!
	int current_size;
	vec<int> literals;
	vec<int> lit_answers;
	};

struct myvariable_
	{
	int name;
	int pos_size; //current sizes;
	int neg_size;
	vec<int> positive;
	vec<int> pos_index;
 	vec<int> negative;
	vec<int> neg_index;
	};
//=============================================
int distance(myclause *clause1, myclause *clause2){
	int i,j;
	int dist=0;
	for (i=0;i<=(*clause1).literals.size()-1;i++) 
		{
		for (j=0;j<=(*clause2).literals.size()-1;j++)
			{
			if ( abs((*clause1).literals[i])==abs((*clause2).literals[j]) ) 
				{
				if (((*clause1).literals[i]==-(*clause2).literals[j]))
					{dist++; if (dist>=2) {return dist;}}
				break;
				} 
			}
		}
return dist;
}
//=============================================
int resolution(myclause *clause1, myclause *clause2, vec<int> *resolvent,int pivot_index1,int pivot_index2) {

int answer=1;
int local_index1=0;
int local_index2=0;
(*resolvent).clear(); 

while ((local_index1<(*clause1).literals.size())&&(local_index2<(*clause2).literals.size()))
	{
	if ((local_index1!=pivot_index1)&&(local_index2!=pivot_index2))
		{
		if (abs((*clause1).literals[local_index1])>abs((*clause2).literals[local_index2])) 
			{(*resolvent).push((*clause2).literals[local_index2]);local_index2++;}
		else if (abs((*clause1).literals[local_index1])<abs((*clause2).literals[local_index2])) 
			{(*resolvent).push((*clause1).literals[local_index1]);local_index1++;}
		else if (abs((*clause1).literals[local_index1])==abs((*clause2).literals[local_index2])) 
			{
			if ((*clause1).literals[local_index1]!=(*clause2).literals[local_index2]) {return 0;}
			else {(*resolvent).push((*clause1).literals[local_index1]);local_index1++;local_index2++;}
			}
		}
	else if ((local_index1==pivot_index1)&&(local_index2!=pivot_index2))
		{local_index1++;}
	else if ((local_index1!=pivot_index1)&&(local_index2==pivot_index2))
		{local_index2++;}
	else if ((local_index1==pivot_index1)&&(local_index2==pivot_index2))
		{local_index1++;local_index2++;}
	}

if (local_index1<(*clause1).literals.size())
	{for (int i=local_index1;i<=(*clause1).literals.size()-1;i++) 
		{if (i!=pivot_index1) {(*resolvent).push((*clause1).literals[i]);}}}

else if (local_index2<(*clause2).literals.size())
	{for (int i=local_index2;i<=(*clause2).literals.size()-1;i++) 
		{if (i!=pivot_index2) {(*resolvent).push((*clause2).literals[i]);}}}

return answer;
}
//=============================================
int subsumes(vec<int> *clause1, myclause *clause2){
int answer=1; //answer 1: clause1 subsumes clause2, and so clause2 can be removed;
int inside=0;
int pos=-1;
if ((*clause1).size() > (*clause2).literals.size()) {return 0;}

for (int i=0;i<=(*clause1).size()-1;i++)
	{
	inside=0;
	for (int j=pos+1;j<=(*clause2).literals.size()-1;j++)
		{if ((*clause1)[i]==(*clause2).literals[j]) {inside=1;pos=j;break;}}

	if (inside==0) {return 0;}
	}

return answer;
}
//=============================================
int subsumes3(myclause *clause1, myclause *clause2, myclause *clause3,int pivot_name){
int answer=1; //answer 1: clause1 and clause2 subsume clause3, and so clause3 can be removed;
int inside=0;

for (int i=0;i<=(*clause1).literals.size()-1;i++)
	{
	inside=0;
	if (abs((*clause1).literals[i])!=pivot_name) 
		{
		for (int j=0;j<=(*clause3).literals.size()-1;j++)
			{if ((*clause1).literals[i]==(*clause3).literals[j]) {inside=1;break;}}
		if (inside==0) {return 0;}
		}
	}

for (int i=0;i<=(*clause2).literals.size()-1;i++)
	{
	inside=0;
	if (abs((*clause2).literals[i])!=pivot_name)
		{
		for (int j=0;j<=(*clause3).literals.size()-1;j++)
			{if ((*clause2).literals[i]==(*clause3).literals[j]) {inside=1;break;}}
		if (inside==0) {return 0;}
		}
	}

return answer;
}
//=============================================
void subsumption(vec<myclause> *circuit, vec<myvariable> *entries, int *counter){

int res_answer=0;
int subsumes_answer=0;
int current_var=0;
vec<int> resolvent;
resolvent.clear();

for (int i=0;i<=(*entries).size()-1;i++)
	{
	for (int j=0;j<=(*entries)[i].positive.size()-1;j++)
		{
		if ((*circuit)[(*entries)[i].positive[j]].answer!=1)
			{
			for (int k=0;k<=(*entries)[i].negative.size()-1;k++)
				{
				if ((*circuit)[(*entries)[i].negative[k]].answer!=1)
					{
					res_answer=resolution(&((*circuit)[(*entries)[i].positive[j]]),&((*circuit)[(*entries)[i].negative[k]]),&resolvent,(*entries)[i].pos_index[j],(*entries)[i].neg_index[k]);
	
					if (res_answer==1) 
						{
						if (resolvent.size()>0)
							{
							current_var=resolvent[0];
							if (current_var>0)
								{
								for (int l=0;l<=(*entries)[abs(current_var)-1].positive.size()-1;l++)
									{
	if (((*entries)[abs(current_var)-1].positive[l]!=(*entries)[i].positive[j])&&((*entries)[abs(current_var)-1].positive[l]!=(*entries)[i].negative[k])){	
									subsumes_answer=subsumes(&resolvent,&((*circuit)[(*entries)[abs(current_var)-1].positive[l]]));
									if ((subsumes_answer==1)&&((*circuit)[(*entries)[abs(current_var)-1].positive[l]].answer!=1))
										{(*circuit)[(*entries)[abs(current_var)-1].positive[l]].answer=1;(*counter)++;}}
									}
								}
							else if (current_var<0)
								{
								for (int l=0;l<=(*entries)[abs(current_var)-1].negative.size()-1;l++)
									{	
	if (((*entries)[abs(current_var)-1].negative[l]!=(*entries)[i].positive[j])&&((*entries)[abs(current_var)-1].negative[l]!=(*entries)[i].negative[k])){
									subsumes_answer=subsumes(&resolvent,&((*circuit)[(*entries)[abs(current_var)-1].negative[l]]));
									if ((subsumes_answer==1)&&((*circuit)[(*entries)[abs(current_var)-1].negative[l]].answer!=1))
										{(*circuit)[(*entries)[abs(current_var)-1].negative[l]].answer=1;(*counter)++;}}
									}
								}
							}
						}
					}
				}
			}
		}
	}
return;
}
//=============================================
void order_elimination(vec<myclause> *circuit,vec<myvariable> *entries,vec<int> *elimination_indexes){

vec<int> freq_pos;
vec<int> freq_neg;
vec<int> checked;
int max_pos=0;
int max_neg=0;
int max_pos_index=-1;
int max_neg_index=-1;
int counter=0;

for (int i=0;i<=(*circuit).size()-1;i++) {checked.push(-1);}
(*elimination_indexes).clear();

for (int i=0;i<=(*entries).size()-1;i++) 
	{
	freq_pos.push((*entries)[i].positive.size()+(*entries)[i].negative.size());
	//freq_neg.push((*entries)[i].negative.size());
	}

for (int i=0;i<=freq_pos.size()-1;i++)
	{
	max_pos=(*circuit).size();
	max_neg=0;
	max_pos_index=-1;
	max_neg_index=-1;
	for (int j=0;j<=freq_pos.size()-1;j++)
		{
		if (freq_pos[j]<max_pos) {max_pos=freq_pos[j];max_pos_index=j;}
		//if (freq_neg[j]>max_neg) {max_neg=freq_neg[j];max_neg_index=j;} 
		}

	if (max_pos_index!=-1){
		freq_pos[max_pos_index]=(*circuit).size();
		for (int j=0;j<=(*entries)[max_pos_index].positive.size()-1;j++)
			{if (checked[(*entries)[max_pos_index].positive[j]]==-1) 
				{(*elimination_indexes).push((*entries)[max_pos_index].positive[j]);checked[(*entries)[max_pos_index].positive[j]]=1;counter++;}}
		if (counter>checked.size()) {break;}//}
 // if (max_neg_index!=-1){
		//freq_neg[max_neg_index]=-1;
		max_neg=max_pos;max_neg_index=max_pos_index;
		for (int j=0;j<=(*entries)[max_neg_index].negative.size()-1;j++)
			{if (checked[(*entries)[max_neg_index].negative[j]]==-1) 
				{(*elimination_indexes).push((*entries)[max_neg_index].negative[j]);checked[(*entries)[max_neg_index].negative[j]]=1;counter++;}}
		if (counter>checked.size()) {break;}}
	}

return;
}
//=============================================
int clause_value(myclause *clause1,vec<lbool> *model,int index_var_excluded){
int answer=0;

for (int i=0;i<=(*clause1).literals.size()-1;i++)
	{
	if (abs((*clause1).literals[i])-1!=index_var_excluded)
		{
		if (((*clause1).literals[i]>0)&&((*model)[abs((*clause1).literals[i])-1]!=l_False)) {answer=1;return answer;}	
		if (((*clause1).literals[i]<0)&&((*model)[abs((*clause1).literals[i])-1]!=l_True)) {answer=1;return answer;}
		}
	}

return answer;
}
//=============================================
void analyze_sat(vec<myclause> *circuit, vec<myvariable> *entries, int index, vec<lbool> *model, int *counter){

int clause_index=0;
int success_index=0;
int clause_answer=0;
int overall_answer=0;
vec<int> new_sat;
vec<int> new_sat_models;
new_sat.clear();
new_sat_models.clear();

for (int i=0;i<=(*circuit)[index].literals.size()-1;i++)
	{
	overall_answer=0;
	//---------------
	if ((*circuit)[index].literals[i]>0)
		{
		for (int j=0;j<=(*entries)[(*circuit)[index].literals[i]-1].negative.size()-1;j++)
			{
			clause_index=(*entries)[(*circuit)[index].literals[i]-1].negative[j];

			if ((*circuit)[clause_index].answer!=1)
				{
				clause_answer=clause_value(&((*circuit)[clause_index]),model,(*circuit)[index].literals[i]-1);
				if (clause_answer==0) {overall_answer++;success_index=clause_index;if (overall_answer>1) {break;}}
				}
			}
		if ((overall_answer<=1)&&((*circuit)[success_index].answer!=2)) 
			{(*circuit)[success_index].answer=2;
			new_sat.push(success_index);(*counter)++;
			new_sat_models.push((*circuit)[index].literals[i]-1);}
		}
	//---------------
	else if ((*circuit)[index].literals[i]<0)
		{
		for (int j=0;j<=(*entries)[-(*circuit)[index].literals[i]-1].positive.size()-1;j++)
			{
			clause_index=(*entries)[-(*circuit)[index].literals[i]-1].positive[j];

			if ((*circuit)[clause_index].answer!=1)
				{
				clause_answer=clause_value(&((*circuit)[clause_index]),model,-(*circuit)[index].literals[i]-1);
				if (clause_answer==0) {overall_answer++;success_index=clause_index;if (overall_answer>1) {break;}}
				}
			}
		if ((overall_answer<=1)&&((*circuit)[success_index].answer!=2)) 
			{(*circuit)[success_index].answer=2;
			new_sat.push(success_index);(*counter)++;
			new_sat_models.push(-(*circuit)[index].literals[i]-1);}
		}
	//---------------
	}

if (new_sat.size()==0) {return;}
else 
	{
	for (int i=0;i<=new_sat.size()-1;i++)
		{
		if ((*model)[new_sat_models[i]]==l_True) {(*model)[new_sat_models[i]]=l_False;}
		else if ((*model)[new_sat_models[i]]==l_False) {(*model)[new_sat_models[i]]=l_True;}

		analyze_sat(circuit,entries,new_sat[i],model,counter);

		if ((*model)[new_sat_models[i]]==l_True) {(*model)[new_sat_models[i]]=l_False;}
		else if ((*model)[new_sat_models[i]]==l_False) {(*model)[new_sat_models[i]]=l_True;}
		}
	}

return; 
}
//=============================================
int sign(int number){
int sign1=1;
if (number<0) {sign1=-1;}
else if (number==0) {sign1=0;}
return sign1;
}
//=============================================
void chain_preprocessing(vec<myclause> *circuit,vec<myvariable> *entries, int *counter){

vec<int> chain_array;
int current_literal;
int found_chain=0;
int chain_start_index=0;
int chain_end_index=0;
int exit_loop=1;
int chain_pos=0;
int chain_neg=0;
double start,newtime1;

start=cpuTime();
for (int i=0;i<=(*entries).size()-1;i++)
	{
	newtime1=cpuTime();
	if (newtime1-start > 100.0) {return;}
	chain_pos=0;chain_neg=0;
	//--------------------------------------------------------------
	chain_array.clear();
	for (int j=0;j<=(*entries).size()-1;j++) {chain_array.push(0);}
	//-------------
	for (int j=0;j<=(*entries)[i].positive.size()-1;j++)
		{
		found_chain=0;
		if (((*circuit)[(*entries)[i].positive[j]].answer!=1)&&((*circuit)[(*entries)[i].positive[j]].literals.size()==2))
			{
			if (abs((*circuit)[(*entries)[i].positive[j]].literals[0])!=i+1) {current_literal=(*circuit)[(*entries)[i].positive[j]].literals[0];}
			else {current_literal=(*circuit)[(*entries)[i].positive[j]].literals[1];}
			
			if (chain_array[abs(current_literal)-1]==0)
				{chain_array[abs(current_literal)-1]=(j+1)*sign(current_literal);}
			else if ((sign(chain_array[abs(current_literal)-1])!=sign(current_literal))&&(abs(chain_array[abs(current_literal)-1])-1!=j))
				{
				found_chain=1;
				chain_start_index=abs(chain_array[abs(current_literal)-1])-1;
				chain_end_index=j;
				break;
				}
			}
		}
	//--------------
	exit_loop=1;
	while ((found_chain!=1)&&(exit_loop!=0))
		{
		exit_loop=0;
		for (int j=0;j<=chain_array.size()-1;j++)
			{
			//--------------
			if (chain_array[j]<0)
				{
				for (int k=0;k<=(*entries)[j].positive.size()-1;k++)
					{
					found_chain=0;
					if (((*circuit)[(*entries)[j].positive[k]].answer!=1)&&((*circuit)[(*entries)[j].positive[k]].literals.size()==2))
						{
						if (abs((*circuit)[(*entries)[j].positive[k]].literals[0])!=j+1) {current_literal=(*circuit)[(*entries)[j].positive[k]].literals[0];}
						else {current_literal=(*circuit)[(*entries)[j].positive[k]].literals[1];}

						if (chain_array[abs(current_literal)-1]==0)
							{chain_array[abs(current_literal)-1]=(abs(chain_array[j]))*sign(current_literal);exit_loop=1;}
						else if ((sign(chain_array[abs(current_literal)-1])!=sign(current_literal))&&(abs(chain_array[abs(current_literal)-1])!=abs(chain_array[j])))
							{
							found_chain=1;
							chain_start_index=abs(chain_array[abs(current_literal)-1])-1;
							chain_end_index=abs(chain_array[j])-1;
							break;
							}
						}
					if (found_chain==1) {break;}
					}
				}
			//-------------
			else if (chain_array[j]>0)
				{
				for (int k=0;k<=(*entries)[j].negative.size()-1;k++)
					{
					found_chain=0;
					if (((*circuit)[(*entries)[j].negative[k]].answer!=1)&&((*circuit)[(*entries)[j].negative[k]].literals.size()==2))
						{
						if (abs((*circuit)[(*entries)[j].negative[k]].literals[0])!=j+1) {current_literal=(*circuit)[(*entries)[j].negative[k]].literals[0];}
						else {current_literal=(*circuit)[(*entries)[j].negative[k]].literals[1];}
					
						if (chain_array[abs(current_literal)-1]==0)
							{chain_array[abs(current_literal)-1]=(abs(chain_array[j]))*sign(current_literal);exit_loop=1;}
						else if ((sign(chain_array[abs(current_literal)-1])!=sign(current_literal))&&(abs(chain_array[abs(current_literal)-1])!=abs(chain_array[j])))
							{
							found_chain=1;
							chain_start_index=abs(chain_array[abs(current_literal)-1])-1;
							chain_end_index=abs(chain_array[j])-1;
							break;
							}
						}
					if (found_chain==1) {break;}
					}
				}
			//-------------
			if (found_chain==1) {break;}
			}
		}
	//--------------
	if (found_chain==1) 
		{
		chain_pos=1;
		for (int j=0;j<=(*entries)[i].positive.size()-1;j++)
			{
			if ((j!=chain_start_index)&&(j!=chain_end_index)&&((*circuit)[(*entries)[i].positive[j]].answer!=1))
				{(*circuit)[(*entries)[i].positive[j]].answer=1;(*counter)++;}
			}
		}
	//------------------------------------------------------------------------
	//------------------------------------------------------------------------
	chain_array.clear();
	for (int j=0;j<=(*entries).size()-1;j++) {chain_array.push(0);}
	//-------------
	for (int j=0;j<=(*entries)[i].negative.size()-1;j++)
		{
		found_chain=0;
		if (((*circuit)[(*entries)[i].negative[j]].answer!=1)&&((*circuit)[(*entries)[i].negative[j]].literals.size()==2))
			{
			if (abs((*circuit)[(*entries)[i].negative[j]].literals[0])!=i+1) {current_literal=(*circuit)[(*entries)[i].negative[j]].literals[0];}
			else {current_literal=(*circuit)[(*entries)[i].negative[j]].literals[1];}
		
			if (chain_array[abs(current_literal)-1]==0)
				{chain_array[abs(current_literal)-1]=(j+1)*sign(current_literal);}
			else if ((sign(chain_array[abs(current_literal)-1])!=sign(current_literal))&&(abs(chain_array[abs(current_literal)-1])-1!=j))
				{
				found_chain=1;
				chain_start_index=abs(chain_array[abs(current_literal)-1])-1;
				chain_end_index=j;
				break;
				}
			}
		}
	//--------------
	exit_loop=1;
	while ((found_chain!=1)&&(exit_loop!=0))
		{
		exit_loop=0;
		for (int j=0;j<=chain_array.size()-1;j++)
			{
			//--------------
			if (chain_array[j]<0)
				{
				for (int k=0;k<=(*entries)[j].positive.size()-1;k++)
					{
					found_chain=0;
					if (((*circuit)[(*entries)[j].positive[k]].answer!=1)&&((*circuit)[(*entries)[j].positive[k]].literals.size()==2))
						{
						if (abs((*circuit)[(*entries)[j].positive[k]].literals[0])!=j+1) {current_literal=(*circuit)[(*entries)[j].positive[k]].literals[0];}
						else {current_literal=(*circuit)[(*entries)[j].positive[k]].literals[1];}
			
						if (chain_array[abs(current_literal)-1]==0)
							{chain_array[abs(current_literal)-1]=(abs(chain_array[j]))*sign(current_literal);exit_loop=1;}
						else if ((sign(chain_array[abs(current_literal)-1])!=sign(current_literal))&&(abs(chain_array[abs(current_literal)-1])!=abs(chain_array[j])))
							{
							found_chain=1;
							chain_start_index=abs(chain_array[abs(current_literal)-1])-1;
							chain_end_index=abs(chain_array[j])-1;
							break;
							}
						}
					if (found_chain==1) {break;}
					}
				}
			//-------------
			else if (chain_array[j]>0)
				{
				for (int k=0;k<=(*entries)[j].negative.size()-1;k++)
					{
					found_chain=0;
					if (((*circuit)[(*entries)[j].negative[k]].answer!=1)&&((*circuit)[(*entries)[j].negative[k]].literals.size()==2))
						{
						if (abs((*circuit)[(*entries)[j].negative[k]].literals[0])!=j+1) {current_literal=(*circuit)[(*entries)[j].negative[k]].literals[0];}
						else {current_literal=(*circuit)[(*entries)[j].negative[k]].literals[1];}
			
						if (chain_array[abs(current_literal)-1]==0)
							{chain_array[abs(current_literal)-1]=(abs(chain_array[j]))*sign(current_literal);exit_loop=1;}
						else if ((sign(chain_array[abs(current_literal)-1])!=sign(current_literal))&&(abs(chain_array[abs(current_literal)-1])!=abs(chain_array[j])))
							{
							found_chain=1;
							chain_start_index=abs(chain_array[abs(current_literal)-1])-1;
							chain_end_index=abs(chain_array[j])-1;
							break;
							}
						}
					if (found_chain==1) {break;}
					}
				}
			//-------------
			if (found_chain==1) {break;}
			}
		}
	//--------------
	if (found_chain==1) 
		{
		chain_neg=1;
		for (int j=0;j<=(*entries)[i].negative.size()-1;j++)
			{
			if ((j!=chain_start_index)&&(j!=chain_end_index)&&((*circuit)[(*entries)[i].negative[j]].answer!=1))
				{(*circuit)[(*entries)[i].negative[j]].answer=1;(*counter)++;}
			}
		}
	}
return;
}
//=============================================
int unit_propagation(vec< myclause > *circuit, vec< myvariable > *entries, int *counter, vec<int> *unit_q){

	int unit_literal;
	int i,j;
	int index;
	int index_inside;
	int counter_new=0;

	i=0;
	while (i<(*unit_q).size())
		{
		j=0; 
		while ((*circuit)[(*unit_q)[i]].lit_answers[j]==1) {j++;}
		unit_literal=(*circuit)[(*unit_q)[i]].literals[j];

		if (unit_literal>0)
			{
			if ((*entries)[abs(unit_literal)-1].positive.size()>0)
				{
				for (j=0;j<=(*entries)[abs(unit_literal)-1].positive.size()-1;j++)
					{
					index=(*entries)[abs(unit_literal)-1].positive[j];
					if ((index!=(*unit_q)[i])&&((*circuit)[index].answer!=1))
						{(*circuit)[index].answer=1;(*entries)[abs(unit_literal)-1].pos_size--;counter_new++;}
					}
				}
			if ((*entries)[abs(unit_literal)-1].negative.size()>0)
				{
				for (j=0;j<=(*entries)[abs(unit_literal)-1].negative.size()-1;j++)
					{
					index=(*entries)[abs(unit_literal)-1].negative[j];
					index_inside=(*entries)[abs(unit_literal)-1].neg_index[j];

					if ((index!=(*unit_q)[i])&&((*circuit)[index].answer!=1)&&((*circuit)[index].lit_answers[index_inside]!=1))
						{
						(*circuit)[index].lit_answers[index_inside]=1;
						(*circuit)[index].current_size--;
		
						if ((*circuit)[index].current_size==0) {return 1;}
						if ((*circuit)[index].current_size==1) {(*unit_q).push(index);}
						}
					}
				}
			}
		else 
			{
			if ((*entries)[abs(unit_literal)-1].negative.size()>0)
				{
				for (j=0;j<=(*entries)[abs(unit_literal)-1].negative.size()-1;j++)
					{
					index=(*entries)[abs(unit_literal)-1].negative[j];
					if ((index!=(*unit_q)[i])&&((*circuit)[index].answer!=1))
						{(*circuit)[index].answer=1;(*entries)[abs(unit_literal)-1].neg_size--;counter_new++;}
					}
				}
			
			if ((*entries)[abs(unit_literal)-1].positive.size()>0)
				{
				for (j=0;j<=(*entries)[abs(unit_literal)-1].positive.size()-1;j++)
					{
					index=(*entries)[abs(unit_literal)-1].positive[j];
					index_inside=(*entries)[abs(unit_literal)-1].pos_index[j];

					if ((index!=(*unit_q)[i])&&((*circuit)[index].answer!=1)&&((*circuit)[index].lit_answers[index_inside]!=1))
						{
						(*circuit)[index].lit_answers[index_inside]=1;
						(*circuit)[index].current_size--;
		
						if ((*circuit)[index].current_size==0) {return 1;}
						if ((*circuit)[index].current_size==1) {(*unit_q).push(index);}
						}
					}
				}
			}
		i++;
		}
*counter=counter_new;
return 0;
}
//==================================================
void remove_clauses(int num_vars, vec<myclause> *circuit, vec<myvariable> *entries, int *counter_pass, vec<int> *remove_dummy){
//----variables declaration---

	int i,j,k;
	myclause clause1,clause2;
	vec<int> positive,negative;
	vec<int> answers;
	vec<int> answers_pos_neg;
	vec<int> entries_names;
	myvariable var1;
	int counter=0;
	double start,newtime1;
	double time_constant=30.0;

//-----finish declaration----

start=cpuTime();
//-----------------------------------------------------------
counter=1;
int counter_new=0;
while ((counter!=0)&&((*circuit).size()!=0))
	{
	counter=0;
	answers.clear();
	//------------------------------------------------------------
	for (i=0;i<=(*entries).size()-1;i++)
		{
		(*entries)[i].positive.copyTo(positive);
		(*entries)[i].negative.copyTo(negative);
		
		answers_pos_neg.clear();
		for (j=1;j<=positive.size()+negative.size();j++) {answers_pos_neg.push(0);}
		
		if (((*entries)[i].pos_size!=0)&&((*entries)[i].neg_size!=0))
			{
			for (j=0;j<=positive.size()-1;j++)
				{
				clause1.answer=(*circuit)[positive[j]].answer;
				clause1.current_size=(*circuit)[positive[j]].current_size;
				(*circuit)[positive[j]].literals.copyTo(clause1.literals);
				(*circuit)[positive[j]].lit_answers.copyTo(clause1.lit_answers);

				if ((clause1.answer<1))
					{
					for (k=0;k<=negative.size()-1;k++)
						{
						clause2.answer=(*circuit)[negative[k]].answer;
						clause2.current_size=(*circuit)[negative[k]].current_size;
						(*circuit)[negative[k]].literals.copyTo(clause2.literals);
						(*circuit)[negative[k]].lit_answers.copyTo(clause2.lit_answers);

						if ((clause2.answer!=1))
							{
							if (distance(&clause1,&clause2)==1) 
								{
								answers_pos_neg[j]=1;
								answers_pos_neg[positive.size()+k]=1;
								break;
								}
							}
						}
					}
				}

			for (k=0;k<=negative.size()-1;k++)
				{
				clause1.answer=(*circuit)[negative[k]].answer;
				clause1.current_size=(*circuit)[negative[k]].current_size;
				(*circuit)[negative[k]].literals.copyTo(clause1.literals);
				(*circuit)[negative[k]].lit_answers.copyTo(clause1.lit_answers);
				if ((clause1.answer<1)&&(answers_pos_neg[positive.size()+k]!=1))
					{
					for (j=0;j<=positive.size()-1;j++)
						{
						clause2.answer=(*circuit)[positive[j]].answer;
						clause2.current_size=(*circuit)[positive[j]].current_size;
						(*circuit)[positive[j]].literals.copyTo(clause2.literals);
						(*circuit)[positive[j]].lit_answers.copyTo(clause2.lit_answers);
						if ((clause2.answer!=1))
							{
							if (distance(&clause1,&clause2)==1) 
								{
								answers_pos_neg[positive.size()+k]=1;
								break;
								}
							}
						}
					}
				}
		
			for (j=0;j<=positive.size()-1;j++) 
				{
				if ((answers_pos_neg[j]==0))
					{
					if ((*circuit)[positive[j]].answer<1)
						{(*circuit)[positive[j]].answer=1;(*remove_dummy).push(positive[j]);(*entries)[i].pos_size--;counter++;}
					}
				}
			for (j=0;j<=negative.size()-1;j++) 
				{
				if ((answers_pos_neg[j+positive.size()]==0))
					{
					if ((*circuit)[negative[j]].answer<1)
						{(*circuit)[negative[j]].answer=1;(*remove_dummy).push(negative[j]);(*entries)[i].neg_size--;counter++;}
					}
				}
			}

		else if (((*entries)[i].pos_size!=0)&&((*entries)[i].neg_size==0))
			{
			for (j=0;j<=positive.size()-1;j++) 
				{
				if ((*circuit)[positive[j]].answer<1)
					{(*circuit)[positive[j]].answer=1;(*remove_dummy).push(positive[j]);(*entries)[i].pos_size--;counter++;}
				}
			}
		else if (((*entries)[i].pos_size==0)&&((*entries)[i].neg_size!=0))
			{
			for (j=0;j<=negative.size()-1;j++) 
				{
				if ((*circuit)[negative[j]].answer<1)
					{(*circuit)[negative[j]].answer=1;(*remove_dummy).push(negative[j]);(*entries)[i].neg_size--;counter++;}
				}
			}
		}	

	newtime1=cpuTime();
	counter_new=counter_new+counter;
	if (newtime1-start > time_constant) {break;}
	if (counter==0) {break;}
	}

(*counter_pass)=(*counter_pass)+counter_new;
return;
}
//========================================================
int find_next(vec<myclause> *circuit,vec<myvariable> *entries,int index,int *current_min,vec<int> *elimination_indexes){

int current_lit;

if (index>=0)
	{
	for (int j=0;j<=(*circuit)[index].literals.size()-1;j++) 
		{
		current_lit=(*circuit)[index].literals[j];
		if (current_lit>0) 
			{
			for (int k=0;k<=(*entries)[abs(current_lit)-1].negative.size()-1;k++)
				{
				if ((*entries)[abs(current_lit)-1].negative[k]>(*current_min))
				{if ((*circuit)[(*entries)[abs(current_lit)-1].negative[k]].answer==0) 
					{(*elimination_indexes).push((*entries)[abs(current_lit)-1].negative[k]);return 1;}}
				}
			}
		else if (current_lit<0) 
			{
			for (int k=0;k<=(*entries)[abs(current_lit)-1].positive.size()-1;k++)
				{
				if ((*entries)[abs(current_lit)-1].positive[k]>(*current_min))
				{if ((*circuit)[(*entries)[abs(current_lit)-1].positive[k]].answer==0) 
					{(*elimination_indexes).push((*entries)[abs(current_lit)-1].positive[k]);return 1;}}
				}
			}
		}
	}
//-------------ordering from the beginning----------
/*
for (int j=(*current_min)+1;j<=(*circuit).size()-1;j++)
	{if ((*circuit)[j].answer==0) {(*elimination_indexes).push(j);(*current_min)=j;return 1;}}
*/
//-------------ordering using var frequencies----------
/*
int max_cl=-1;
int max_cl_index=-1;
int max_max=(*circuit).size()*(*entries).size();
for (int i=0;i<=(*circuit).size()-1;i++)
	{
	max_cl=0;
	if ((*circuit)[i].answer==0)
		{
		for (int j=0;j<=(*circuit)[i].literals.size()-1;j++)
			{
			if ((*circuit)[i].literals[j]>0) {max_cl+=(*entries)[abs((*circuit)[i].literals[j])-1].negative.size();}
			else if ((*circuit)[i].literals[j]<0) {max_cl+=(*entries)[abs((*circuit)[i].literals[j])-1].positive.size();}
			}
		if (max_cl<max_max) {max_max=max_cl;max_cl_index=i;}
		}
	}
if (max_cl_index>-1) {(*elimination_indexes).push(max_cl_index);return 1;}
*/
//-------------ordering using clause sizes----------
int ind1=-1;
int ind3=-1;
int ind4=-1;
int ind5=-1;
int ind2=-1;
for (int i=0;i<=(*circuit).size()-1;i++)
	{
	if ((*circuit)[i].answer==0){
	if ((*circuit)[i].literals.size()>=6) {(*elimination_indexes).push(i);return 1;}
	else if (((*circuit)[i].literals.size()==1)&&(ind1<0)) {ind1=i;}
	else if (((*circuit)[i].literals.size()==3)&&(ind3<0)) {ind3=i;}
	else if (((*circuit)[i].literals.size()==4)&&(ind4<0)) {ind4=i;}
	else if (((*circuit)[i].literals.size()==5)&&(ind5<0)) {ind5=i;}
	else if (((*circuit)[i].literals.size()==2)&&(ind2<0)) {ind2=i;}}
	}

if (ind5>-1) {(*elimination_indexes).push(ind5);return 1;}
else if (ind4>-1) {(*elimination_indexes).push(ind4);return 1;}
else if (ind3>-1) {(*elimination_indexes).push(ind3);return 1;}
else if (ind2>-1) {(*elimination_indexes).push(ind2);return 1;}
else if (ind1>-1) {(*elimination_indexes).push(ind1);return 1;}
//----------------------------------------------------
return -1;
}
//========================================================
//===================================================================================================

void printStats(Solver& solver){}

static Solver* solver;

static void SIGINT_exit(int signum) {
    printf("\n"); printf("c *** INTERRUPTED ***\n");
		printf("s UNKNOWN\n");
    _exit(1); }

//=================================================================================================
// Main:

int main(int argc, char** argv)
{
    try {
        setUsageHelp("c USAGE: %s [options] <input-file> <result-output-file>\n\n  where input may be either in plain or gzipped DIMACS.\n");
        
#if defined(__linux__)
        fpu_control_t oldcw, newcw;
        _FPU_GETCW(oldcw); newcw = (oldcw & ~_FPU_EXTENDED) | _FPU_DOUBLE; _FPU_SETCW(newcw);
#endif
        // Extra options:
        //
        IntOption    verb   ("MAIN", "verb",   "Verbosity level (0=silent, 1=some, 2=more).", 1, IntRange(0, 2));
        IntOption    cpu_lim("MAIN", "cpu-lim","Limit on CPU time allowed in seconds.\n", INT32_MAX, IntRange(0, INT32_MAX));
        IntOption    mem_lim("MAIN", "mem-lim","Limit on memory usage in megabytes.\n", INT32_MAX, IntRange(0, INT32_MAX));
        
		char *argv_copy[6];
		int argc_copy=6;

		argv_copy[0]=argv[0];
		argv_copy[1]=argv[1];
		argv_copy[2]=(char*)"-no-luby";
		argv_copy[3]=(char*)"-rinc=1.5";
		argv_copy[4]=(char*)"-phase-saving=0";
		argv_copy[5]=(char*)"-rnd-freq=0.02";
		//argv_copy[6]=(char*)"-rnd-seed=100.55";

    parseOptions(argc_copy, argv_copy, true);
		verb=0;
    Solver S;
    S.verbosity = verb;  
    solver = &S;

        // Use signal handlers that forcibly quit until the solver will be able to respond to
        // interrupts:
        signal(SIGINT, SIGINT_exit);
        signal(SIGXCPU,SIGINT_exit);

        // Set limit on CPU-time:
        if (cpu_lim != INT32_MAX){
            rlimit rl;
            getrlimit(RLIMIT_CPU, &rl);
            if (rl.rlim_max == RLIM_INFINITY || (rlim_t)cpu_lim < rl.rlim_max){
                rl.rlim_cur = cpu_lim;
                if (setrlimit(RLIMIT_CPU, &rl) == -1){}
                   // printf("WARNING! Could not set resource limit: CPU-time.\n");
            } }

        // Set limit on virtual memory:
        if (mem_lim != INT32_MAX){
            rlim_t new_mem_lim = (rlim_t)mem_lim * 1024*1024;
            rlimit rl;
            getrlimit(RLIMIT_AS, &rl);
            if (rl.rlim_max == RLIM_INFINITY || new_mem_lim < rl.rlim_max){
                rl.rlim_cur = new_mem_lim;
                if (setrlimit(RLIMIT_AS, &rl) == -1){}
                   // printf("WARNING! Could not set resource limit: Virtual memory.\n");
            } }
        
        gzFile in = (argc == 1) ? gzdopen(0, "rb") : gzopen(argv[1], "rb");
        if (in == NULL)
            printf("c ERROR! Could not open file: %s\n", argc == 1 ? "<stdin>" : argv[1]), exit(1);
       
        parse_DIMACS(in, S);
        gzclose(in);

//========== reading file for the preprocessing and further elimination =============

	//-------numbers---------
	int num_clauses,num_vars;
	int name;
	int counter=0;
	int answer=0;
	int lit_index,sort_index;
	int total_lits=0;
	int clause_counter=0;
	int num_removed=0;
	//int chain=0;
	//int subsump=0;
	int unit=0;
	int BCE=0;
	int sat_saved=0;
	int sat_checked=0;
	int unsat_checked=0;
	int skip=-1;
	int currently_removed=-1;
	int round=1;
	int currently_removed_limit=100;
	int time_limit_const=2;
	int current_min=-1;
	int br;

	//----vecs of ints------
	vec<int> positive,negative;
	vec<int> unit_q;
	//vec<int> temp;
	vec<int> model;
	vec<int> elimination_indexes;
	vec<int> remove_dummy;

	//------other types------
	vec<Lit> dummy;
	vec<myclause> circuit;
	vec<myvariable> entries;
	myvariable var1;
	myclause clause1,clause2;
	lbool ret;
	
	//----file and char-----
	FILE * input_file;
	char str [1000];
	char ch;
	char * file_name;

	//----time variables----
	double start,newtime,newtime1;
	start=cpuTime();	

//================ reading ======================

	file_name=argv[1];
	input_file=fopen(argv[1],"r");
	printf("c - Reading the instance.. ");
	answer=fscanf(input_file,"%c",&ch); 
	while (ch=='c') {answer=fscanf(input_file,"%[^\n]",str); answer=fscanf(input_file,"%c",&ch); answer=fscanf(input_file,"%c",&ch);}
	answer=fscanf(input_file,"%s",str);
	answer=fscanf(input_file,"%d %d",&num_vars,&num_clauses);

	for (int i=1;i<=num_vars;i++)
		{
		entries.push();
		entries.last().positive.clear();
		entries.last().negative.clear();
		entries.last().name=i;
		entries.last().pos_size=0;
		entries.last().neg_size=0;
		model.push(0);
		}
//----
	for (int i=0;i<=num_clauses-1;i++)
		{
		circuit.push();
		circuit.last().literals.clear();
		circuit.last().lit_answers.clear();
		circuit.last().answer=0;

		name=1;
		lit_index=0;
		sort_index=0;
		while (name!=0)
			{
			answer=fscanf(input_file,"%d",&name);
			if (name==0) {break;}
			total_lits++;
			//-------sorting--------
			/*if (circuit.last().literals.size()==0) {sort_index=0;circuit.last().literals.push(name);}
			else 
				{
				temp.clear();
				for (sort_index=0;sort_index<=circuit.last().literals.size()-1;sort_index++)
					{
					if (abs(name)>=abs(circuit.last().literals[sort_index])) {temp.push(circuit.last().literals[sort_index]);}
					else if (abs(name)<abs(circuit.last().literals[sort_index])) {temp.push(name);temp.push(circuit.last().literals[sort_index]);break;}
					if (sort_index==circuit.last().literals.size()-1) {temp.push(name);sort_index++;break;}
					}
					
				if (sort_index<circuit.last().literals.size()-1)
					{
					for (int j=sort_index+1;j<=circuit.last().literals.size()-1;j++)
						{temp.push(circuit.last().literals[j]);}
					}
				temp.copyTo(circuit.last().literals);
				}*/
			circuit.last().literals.push(name);
			//---------------------
			circuit.last().lit_answers.push(0);

			if (name==abs(name)) 
				{
				entries[abs(name)-1].positive.push(i);
				entries[abs(name)-1].pos_index.push(lit_index);
				entries[abs(name)-1].pos_size++;
				}
			if (name==-abs(name)) 
				{
				entries[abs(name)-1].negative.push(i);
				entries[abs(name)-1].neg_index.push(lit_index);
				entries[abs(name)-1].neg_size++;
				}
			lit_index++;
			}
		if (lit_index==1) {unit_q.push(clause_counter);}
		circuit.last().current_size=lit_index;
		clause_counter++;
    elimination_indexes.push(i);		//comment it for x100 version;
		}
	fclose(input_file);
	newtime=cpuTime();
	printf("OK! Totally clauses: %8d; Vars: %8d; Time: %4.2f\n",num_clauses,num_vars,newtime-start);

//============== preprocessing ===================

/*
	newtime=cpuTime();
	printf("c - Chain preprocessing..  ");
	chain_preprocessing(&circuit,&entries,&chain);
	num_removed=num_removed+chain;
	newtime1=cpuTime();
	printf("OK! Removed clauses: %8d;                 Time: %4.2f\n",chain,newtime1-newtime);
*/

	newtime=cpuTime();
	printf("c - Unit propagation..     ");
	answer=unit_propagation(&circuit,&entries,&unit,&unit_q);
	num_removed=num_removed+unit;
	newtime1=cpuTime();
	printf("OK! Removed clauses: %8d;                 Time: %4.2f\n",unit,newtime1-newtime);
/*
	newtime=cpuTime();
	printf("c - Subsumption..          ");
	subsumption(&circuit,&entries,&subsump);
	num_removed=num_removed+subsump;
	newtime1=cpuTime();
	printf("OK! Removed clauses: %8d;                 Time: %4.2f\n",subsump,newtime1-newtime);
*/
	newtime=cpuTime();
	printf("c - Delete by resolution.. ");	
	remove_dummy.clear();
	remove_clauses(num_vars,&circuit,&entries,&BCE,&remove_dummy);
	num_removed=num_removed+BCE;
	newtime1=cpuTime();
	printf("OK! Removed clauses: %8d;                 Time: %4.2f\n",BCE,newtime1-newtime);
/*
	newtime=cpuTime();
	printf("c - Ordering elimination.. ");
	order_elimination(&circuit,&entries,&elimination_indexes);
	newtime1=cpuTime();
	printf("OK!                                            Time: %4.2f\n",newtime1-newtime);
*/
//-----------------------------------------------------------------------------

//====================== solving part ===============================

//-------tunning parameters------
	currently_removed_limit=100;
	time_limit_const=5;
//-------------------------------
	for (int i=0;i<=num_clauses-1;i++) 
		{
		if (circuit[i].answer==1) {dummy.push(mkLit(num_vars+i,true));}
		else {dummy.push(mkLit(num_vars+i,false));}
		}
//============ solving original ===============
	printf("c   - Solving the original instance..\n");
	S.time_limit=2*time_limit_const;
	if (!S.simplify()){}
	ret = S.solveLimited(dummy);
	if (ret == l_True) 
		{
		printf("c     - NOT OK - SAT!! Terminating..\n");printf("s SATISFIABLE\n");
		printf("v "); 
		for (int i = 0; i < num_vars; i++)
        	{if (S.model[i] != l_Undef) {printf("%s%s%d", (i==0)?"":" ", (S.model[i]==l_True)?"":"-", i+1);}}
        printf(" 0\n");
		exit(10);
		}
	else if (ret == l_False) {printf("c     - OK - UNSAT! Continue to clause elimination..\n");}
	else {printf("c     - yet UNKNOWN! Continue to clause elimination..\n");}
//============ clause elimination ==============
	skip=-1;
	currently_removed=0;
	round=1;
	counter=0;
	//--------initial clause to eliminate---------
	//if (find_next(&circuit,&entries,-1,&current_min,&elimination_indexes)==-1) {skip=0;}	//uncoment for x100 version
	//---------------------------------------------
	while (skip!=0)
		{
		S.time_limit=time_limit_const*round;	
		if (skip==-1) {printf("c   - round: %4d;   Skips in previous round: %4d\n",round,0);}
		else {printf("c   - round: %4d;   Skips in previous round: %4d\n",round,skip);}
		skip=0;
		current_min=-1;
		br=0;
		for (int i=0;i<=num_clauses-1;i++)
			{
			if (i>=elimination_indexes.size()) {break;}
			remove_dummy.clear();
				 if ((i+1) == ((int)   num_clauses/100+1))  {printf("c     - clauses done:  1%%; among them skipped: %4.2f%%;\n",(double)skip*100/(i+1));}
			else if ((i+1) == ((int)   num_clauses/10 +1))  {printf("c     - clauses done: 10%%; among them skipped: %4.2f%%;\n",(double)skip*100/(i+1));}
			else if ((i+1) == ((int)2* num_clauses/10 +1))  {printf("c     - clauses done: 20%%; among them skipped: %4.2f%%;\n",(double)skip*100/(i+1));}
			else if ((i+1) == ((int)3* num_clauses/10 +1))  {printf("c     - clauses done: 30%%; among them skipped: %4.2f%%;\n",(double)skip*100/(i+1));}
			else if ((i+1) == ((int)4* num_clauses/10 +1))  {printf("c     - clauses done: 40%%; among them skipped: %4.2f%%;\n",(double)skip*100/(i+1));}
			else if ((i+1) == ((int)5* num_clauses/10 +1))  {printf("c     - clauses done: 50%%; among them skipped: %4.2f%%;\n",(double)skip*100/(i+1));}
			else if ((i+1) == ((int)6* num_clauses/10 +1))  {printf("c     - clauses done: 60%%; among them skipped: %4.2f%%;\n",(double)skip*100/(i+1));}
			else if ((i+1) == ((int)7* num_clauses/10 +1))  {printf("c     - clauses done: 70%%; among them skipped: %4.2f%%;\n",(double)skip*100/(i+1));}
			else if ((i+1) == ((int)8* num_clauses/10 +1))  {printf("c     - clauses done: 80%%; among them skipped: %4.2f%%;\n",(double)skip*100/(i+1));}
			else if ((i+1) == ((int)9* num_clauses/10 +1))  {printf("c     - clauses done: 90%%; among them skipped: %4.2f%%;\n",(double)skip*100/(i+1));}
			else if ((i+1) == ((int)99*num_clauses/100+1))  {printf("c     - clauses done: 99%%; among them skipped: %4.2f%%;\n",(double)skip*100/(i+1));}
	
			if (circuit[elimination_indexes[i]].answer<=0)
				{
				//-------------------
				dummy[elimination_indexes[i]]=mkLit(num_vars+elimination_indexes[i],true);
				for (int j=0;j<=circuit[elimination_indexes[i]].literals.size()-1;j++) 
					{
					if (circuit[elimination_indexes[i]].literals[j]<0) {dummy.push(mkLit(abs(circuit[elimination_indexes[i]].literals[j])-1,false));}
					else {dummy.push(mkLit(abs(circuit[elimination_indexes[i]].literals[j])-1,true));}
					}
				//-------------------
				ret = S.solveLimited(dummy);
				//-------------------
				if (ret == l_True) 
					{
					dummy[elimination_indexes[i]]=mkLit(num_vars+elimination_indexes[i],false);circuit[elimination_indexes[i]].answer=2;sat_checked++;
					//analyze_sat(&circuit,&entries,elimination_indexes[i],&(S.model),&sat_saved); //uncomment for p100,x100 version;
					//if (round==1) {if (find_next(&circuit,&entries,elimination_indexes[i],&current_min,&elimination_indexes)==-1) {br=1;}}  //uncomment for x100 version;
					}
				else if (ret == l_False) 
					{
					circuit[elimination_indexes[i]].answer=1;currently_removed++;unsat_checked++;
					//if (round==1) {if (find_next(&circuit,&entries,elimination_indexes[i],&current_min,&elimination_indexes)==-1) {br=1;}}  //uncomment for x100 version;
					}
				else 
					{
					circuit[elimination_indexes[i]].answer=-1;dummy[elimination_indexes[i]]=mkLit(num_vars+elimination_indexes[i],false);skip++;
					//if (round==1) {if (find_next(&circuit,&entries,-1,&current_min,&elimination_indexes)==-1) {br=1;}}  //uncomment for x100 version;
					}
				for (int j=0;j<=circuit[elimination_indexes[i]].literals.size()-1;j++) {dummy.pop();}
				if (br==1) {break;}
				//-------------------
				if (currently_removed>currently_removed_limit)
					{
					currently_removed=0;
					remove_clauses(num_vars,&circuit,&entries,&BCE,&remove_dummy);
					num_removed=num_removed+BCE;
					if (remove_dummy.size()>0)
						{for (int j=0;j<=remove_dummy.size()-1;j++) {dummy[remove_dummy[j]]=mkLit(num_vars+remove_dummy[j],true);}}
					}
				//-------------------
				}
			//else {if (round==1) {if (find_next(&circuit,&entries,-1,&current_min,&elimination_indexes)==-1) {break;}}}		//uncomment for x100 version;
			}
		if (skip==0) {break;}
		round++;
		}		
//========================= output in a file ========================
/*
		FILE * output_file;
		strcat(file_name,".MUS.cnf");
		output_file = fopen (file_name,"w");		
		fprintf(output_file,"p cnf %d %d\n",num_vars,sat_checked+sat_saved);

		for (int i=0;i<=circuit.size()-1;i++) 
			{
			if (circuit[i].answer!=1)
				{
				for (int j=0;j<=circuit[i].literals.size()-1;j++)
					{fprintf(output_file,"%d ",circuit[i].literals[j]);}
				fprintf(output_file,"0\n");
				}
			}
		fclose(output_file);
*/
//==================================================================
		newtime=cpuTime();
		printf("c - Finish! Unsat core size: %d / %d; Time: %4.2f s\n",sat_saved+sat_checked,num_clauses,newtime-start);
		printf("c - ---------------------------------------------------------------------------\n");
		printf("c - Statistics: |    unit   |    BCE    | sat-saved | sat-check | unsat-check |\n");
		printf("c -             | %7d   | %7d   | %7d   | %7d   | %7d     |\n",unit,BCE,sat_saved,sat_checked,unsat_checked);
		printf("c - ---------------------------------------------------------------------------\n");
//====================== output for sat competition ================
		
		printf("s UNSATISFIABLE\n");
		printf("v ");
		for (int i=0;i<=circuit.size()-1;i++) 
			{if (circuit[i].answer!=1) {printf("%d ",i+1);}}
		printf("0\n");
	
//==================================================================		
#ifdef NDEBUG
        exit(20);
#else
        return 20;
#endif
    } catch (OutOfMemoryException&){
        printf("s UNKNOWN\n");
        exit(0);
    }
}
