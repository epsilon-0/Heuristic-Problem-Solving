#ifndef MINIMAL_CORE_H
#define MINIMAL_CORE_H

#include "simp/SimpSolver.h"
#include "mtl/Map.h"
#include "mtl/Set.h"

namespace Minisat 
{

class CMinimalCore
{
public:
    CMinimalCore(SimpSolver& solver);

    lbool Solve(bool preprocess);

    inline SimpSolver& GetSolver() { return m_Solver; }

    inline int GetIcFromVar(int nVar) { return nVar - m_nFirstVar; }

    inline void SetStartVar(int var) { m_nFirstVar = var; }

    inline int GetIcNumber() { return m_nICSize; }

private:
    void PrintData(int unknownSize, int mucSize, int iter, bool last = false);

    SimpSolver& m_Solver;
    int m_nICSize;
    int m_nFirstVar;

};

}

#endif
