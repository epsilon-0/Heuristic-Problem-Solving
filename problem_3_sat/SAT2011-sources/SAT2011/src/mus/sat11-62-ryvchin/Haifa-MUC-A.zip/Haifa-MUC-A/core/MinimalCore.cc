#include "core/MinimalCore.h"
#include "utils/ParseUtils.h"
#include "mtl/Sort.h"
#include "mtl/Set.h"
#include "utils/System.h"


#include <stdio.h>
#include <assert.h>

namespace Minisat
{

static IntOption     remove_order("MinimalCore", "remove-order", "0 - regular low, 1 - regular high, 2 - the highest, 3 - the lowest\n", 1, IntRange(0,3));

CMinimalCore::CMinimalCore(SimpSolver& solver): 
      m_Solver(solver)
      , m_nICSize(0)
      , m_nFirstVar(0)
{}

void CMinimalCore::PrintData(int unknownSize, int mucSize, int iter, bool last)
{
    printf("c %siter %d time %g not-muc %d unknown %d muc %d\n", 
        last ? "final " : "", 
        iter + 1, 
        cpuTime(),
        m_nICSize - mucSize - unknownSize, 
        unknownSize, 
        mucSize);
}

lbool CMinimalCore::Solve(bool preprocess)
{
    Set<int> setUnknown;
    vec<int> vecNotInMuc;
    Set<int> setMuc;
    int nIcForRemove = -1;
    lbool res = l_Undef;
    vec<int> vecOrder;
    m_nICSize = m_Solver.nVars() - m_nFirstVar;

    m_Solver.assumptions.clear();
//    m_Solver.m_nFirstVar = m_nFirstVar;
    for (Var i = m_nFirstVar; i < m_Solver.nVars(); ++i)
    {
        m_Solver.assumptions.push(mkLit(i, true));
        m_Solver.setFrozen(i, true);
    }

    // run preprocessing
    double before_time = cpuTime();
    m_Solver.eliminate(preprocess);
    double simplified_time = cpuTime();
    if (m_Solver.verbosity > 0)
    {
        printf("c |  Simplification time:  %12.2f s                                       |\n", simplified_time - before_time);
        printf("c |                                                                             |\n"); 
    }

    int nIteration = 0;
    for ( ;true; ++nIteration)
    {
        res = m_Solver.solveAssump();
        if (res == l_False)
        {
            setUnknown.clear();
            for (int nLitId = 0; nLitId < m_Solver.conflict.size(); ++nLitId)
            {
                int nIc = var(m_Solver.conflict[nLitId]);
                if (!setMuc.has(nIc))
                    setUnknown.insert(nIc);
            }

            if (setUnknown.elems() == 0)
            {
                break;
            }
        }
        else if (res == l_True)
        {
            if (nIteration == 0)
            {
                // the problem is sat
                return res;
            }
            
            setMuc.insert(nIcForRemove);
            if (setUnknown.elems() == 0)
            {
                res = l_False;
                break;
            }
        }
        else
        {
            if (nIteration == 0)
                for (int nInd = 0; nInd < m_nICSize; ++nInd)
                {
                    setUnknown.insert(nInd + m_nFirstVar);
                }
            break;
        }

        PrintData(setUnknown.elems(), setMuc.elems(), nIteration);

        if (remove_order == 0)
            nIcForRemove = setUnknown.getAnyRemovalFromLow();
        else if (remove_order == 1)
            nIcForRemove = setUnknown.getAnyRemovalFromHigh();
        else 
        {
            vecOrder.clear();
            setUnknown.copyTo(vecOrder);
            sort(vecOrder);
            if (remove_order == 2)
            {
                nIcForRemove = vecOrder.last();
            }
            else
            {
                nIcForRemove = vecOrder[0];
            }
            setUnknown.remove(nIcForRemove);
        }

        m_Solver.assumptions.clear();
        assert(m_Solver.decisionLevel() == 0);
        for (Var i = m_nFirstVar; i < m_Solver.nVars(); ++i)
        {
            if (!setUnknown.has(i) && !setMuc.has(i))
            {
                if (i != nIcForRemove)
                {
                    m_Solver.enqueue(mkLit(i, false));
                }
                else
                {
                    m_Solver.assumptions.push(mkLit(i, false));
                }
            }
            else if (setMuc.has(i))
            {
                m_Solver.enqueue(mkLit(i, true));
            }
            else
            {
                m_Solver.assumptions.push(mkLit(i, true));
            }
        }

    }

    PrintData(setUnknown.elems(), setMuc.elems(), nIteration, true);

    vec<int> vecUnknown;
    vec<int> vecMuc;
    setUnknown.copyTo(vecUnknown);
    setMuc.copyTo(vecMuc);
    sort(vecUnknown);
    sort(vecMuc);

    printf("v ");
    for (int nInd = 0; nInd < vecUnknown.size(); ++nInd)
    {
        printf("%d ", vecUnknown[nInd] - m_nFirstVar + 1) ;
    }

    for (int nInd = 0; nInd < vecMuc.size(); ++nInd)
    {
        printf("%d ", vecMuc[nInd] - m_nFirstVar + 1);
    }
    printf("0\n");

    return res;
}

}
