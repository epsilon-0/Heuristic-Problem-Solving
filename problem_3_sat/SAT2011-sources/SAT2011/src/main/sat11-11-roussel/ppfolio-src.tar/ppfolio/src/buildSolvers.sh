#!/bin/sh
ROOT=`pwd`

mkdir bin


rm -rf clasp-1.3.6
tar xzf clasp-1.3.6-source.tar.gz
cd clasp-1.3.6
./configure.sh
cd build/release
make
cp bin/clasp $ROOT/bin

cd $ROOT
rm -rf cryptominisat-2.7.1
tar xzf cryptominisat-2.7.1.tar.gz
cd cryptominisat-2.7.1
./configure
make
cp cryptominisat $ROOT/bin

cd $ROOT
rm -rf lingeling-276-6264d55-100731
tar xzf lingeling-276-6264d55-100731.tar.gz 
cd lingeling-276-6264d55-100731
./configure
make
cp lingeling plingeling $ROOT/bin

cd $ROOT
rm -rf march_hi
unzip -x march_hi.zip
cd march_hi
sed -i -e 's/-static//' Makefile
make
cp march_hi $ROOT/bin

cd $ROOT
rm -rf TNM
tar xf TNM.tar
cd TNM
sed -i -e 's/-static//' Makefile
make
cp TNM $ROOT/bin

#
