#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "cdcl.h"
#include "vec.h"
#include "analyseRL.h"
#include "heap.h"
    
extern infoVar *infoAtom;
extern unsigned int numclause;
extern unsigned int numatom;
extern BIGINT nbPropagation;
extern int nbConf;
extern binaryStruct *binClause;
extern int nbRemoveRedByBin;
extern int nbRemoveRed;
extern int whenLearnt;
extern int hammingDistance;
extern unsigned int * numOccurenceLearnt;


unsigned int *partial_assign;
int *posChoice;
unsigned int **reason;
unsigned int *nivOp;
int *level;

int decisionLevel;
int tail;
int qhead;

unsigned char *seen;
unsigned char *isAssign;

int allocVarWatcheClause;
vector *watched;

int allocateMemoryClause;


unsigned int *vTemp;
int indVtmp;
int *pTmp;
int indPtmp;

int MYFLAG = 0;
unsigned int *permDiff;


#include <stdint.h>

/**
   This function initialize one struct dpll
   In entry :
       - h, heuristic to choice variable
   In exit :
       - s, the dpll structure
   Return : this function return 0 if CNF is false, otherwise not 0
 */
void initDPLL()
{
  int i;
  
  /* initialize variable */
  nivOp = (unsigned int *) calloc(numatom + 1, sizeof(unsigned int));
  posChoice = (int *) calloc(numatom + 1, sizeof(int));
  isAssign = (unsigned char *) calloc(numatom+1, sizeof(unsigned char));
  seen = (unsigned char *) calloc(numatom + 1, sizeof(unsigned char));

  level = (int *) malloc(sizeof(int)*(numatom+1));  
  pTmp = (int *) malloc(sizeof(int)*(numatom+1)); /* tableau temporaire (litredundant) */
  partial_assign = (unsigned int *) malloc(sizeof(unsigned int) * (numatom + 1));
  vTemp = (unsigned int *) malloc(sizeof(unsigned int)*(numatom+1)); /* utilisé dans propagate */
  permDiff = (unsigned int *) calloc(numatom+1, sizeof(unsigned int)); /* utilisé pour le lbd */

  for(i = 0; i< (numatom + 1); level[i++] = -1);

  watched = (vector *) malloc(sizeof(vector)*(2*(numatom+1)));
  reason = (unsigned int **) malloc(sizeof(unsigned int *)*(numatom+1));

  decisionLevel = 0;
  posChoice[0] = 0;

  for(i = 0 ; i<2 * (numatom + 1) ; i++) initVector(&(watched)[i]);  
  tail = 0;
  qhead = 0;
}  
/**
   This function initialize one struct dpll
   In exit :
       - s, the dpll structure
 */
void reinitDPLL()
{
  int i, var;

  for(i = posChoice[0] ; i<tail ; i++ )
    {
      var = ABS(partial_assign[i]);
      isAssign[var] = NOT_ASS;
      level[var] = -1;
      addHeap(var);
    }
    
  decisionLevel = 0;
  tail = posChoice[0];
  qhead = tail;
}/* reinit */



/**
   Attach a clause, verbotten add clause false
   In entry :
       - cl, indice clause
   In exit :
       - s, struct of type dpll
   Return : this function return 0 if the clause attaching and else the litteral propagate
 */
void attachClause(unsigned int *cl)
{  
  add(&watched[cl[1]], cl);
  if(*cl > 1) add(&watched[cl[2]], cl);
  if(getLBD(cl[*cl + 1])) setIsAttachedTrue(cl[*cl + 1]);
}/* attachClause */

/**
   Detach clause
   In entry :
        - cl, a detached clause
   In exit :
        - s, the struct dpll
 */
void detachClause(unsigned int *cl)
{
  delete(&(watched[cl[1]]), cl);
  if(*cl > 1) delete(&(watched[cl[2]]), cl);
  if(cl[*cl + 1]) setIsAttachedFalse(cl[*cl + 1]);
}/* detachClause */



int nbClauseAppriseInGraph = 0;
extern int numclauseLearnt;
extern unsigned int ** clauseLearnt;

void debugOcc()
{
  int i, j;  
  unsigned int *cl;
  unsigned int litT = 0, litF = 0;
  
  for( i = 0 ; i<numclauseLearnt ; i++)
    {
      cl = clauseLearnt[i];
      
      cl[*cl + 1] = 0;
      for(j = 1 ; j<=*cl ; j++)
	{
	  if(1 & (infoAtom[ABS(cl[j])].currentAssign ^ cl[j]))
	    {
	      cl[*cl + 1]++;
	      litT++;
	    }else litF++;
	}
    }
}




/**
   Add one litteral on the propagation list
   In entry :
        - l, the literal
	- cl, the clause
   In exit :
        - s, structure dpll
 */
void uncheckedEnqueue(unsigned int l, unsigned int *cl)
{  
  isAssign[ABS(l)] = (SIGN(l)) ? ASS_FALSE : ASS_TRUE;
  infoAtom[ABS(l)].view = 1;
  level[ABS(l)] = decisionLevel;
  reason[ABS(l)] = cl;
  partial_assign[tail++] = l;
  if(cl && cl[*cl + 1]) setIsUsedTrue(cl[*cl + 1]);
}/* uncheckedEnqueue */


/**
   Propagate all enqueud facts. If a conflit arises, the conflicting clause is returned,
   otherwise NULL.

   In exit :
      - s, the dpll structure
      
   Post-condition : 
      - the propagation queue is empty, even if there was a conflict.
*/
unsigned int *propagate()
{
  unsigned int *confl = NULL;
  unsigned int first, assIs;
  unsigned int *c, var, *pc, *ec;
  unsigned int **i, **j, **end;  
  
  
  while (qhead < tail)
    {
      var = NEG(partial_assign[qhead]);
      qhead++;      
      
      nbPropagation++;
      
      for(pc = binClause[var].tabBin, ec = &pc[binClause[var].nbBin] ; pc != ec ; pc++)
	{	  
	  first = *pc;
          assIs = isAssign[ABS(first)];
          
          if(LIT_TRUE(first, assIs)) continue;
          if(LIT_FALSE(first, assIs))
            {
              binClause[var].res[1] = first;
              confl = binClause[var].res;
              qhead = tail;
              return confl;
            }        
          uncheckedEnqueue(first, binClause[var].res);
	}
      
      for(i = j = watched[var].tab, end = &(watched[var].tab[watched[var].nbElt]); i != end ; )
	{
	  c = *(i++);
	  
 	  /* the first variable is'nt propagate */
 	  if(c[1] == var){c[1] = c[2]; c[2] = var;}
	  
	  first = c[1];
          assIs = isAssign[ABS(first)];
	  // If 0th watch is true, then clause is already satisfied.
	  if(LIT_TRUE(first, assIs)) *(j++) = c;
	  else
	    {	      
	      // Look for new watch:
	      for (pc = &c[3], ec = &c[*c + 1] ; pc != ec ; pc++)
		{
		  if(!(LIT_FALSE(*pc, isAssign[ABS(*pc)])))
		    {		      
		      c[2] = *pc; *pc = var;
		      add(&(watched[c[2]]), c);
		      goto FoundWatch; 
		    }
		}
	      
	      // Did not find watch -- clause is unit under assignment:
	      *(j++) = c;

	      if(LIT_FALSE(first, assIs))
		{
		  confl = c;
		  qhead = tail;
		  // Copy the remaining watches:
		  while (i != end) *(j++) = *(i++);
		}else
		{
		  assert(assIs == NOT_ASS);  
		  uncheckedEnqueue(first, c);
		}
	    }
	FoundWatch:;		
	}
      watched[var].nbElt = j - watched[var].tab;
    }

  return confl;
}// propagate

/**
 * affiche la clause cl
 */
void afficheClause(unsigned int *cl)
{
  int i;
  int var;

  printf("size = %d  : ", *cl);
  for(i = 1 ; i <= *cl ; i++)
    {
      var = cl[i];
      printf("(%d,%d) ", LIT(var), level[ABS(var)]);
    }
  printf("\n");
}// afficheClause


/**
 * Allows to know if the literal is redundant.
 * @param lit, the literal for the test
 * @return 1 if the literal is redundant otherwise 0.
 */
int litRedundant(int lit)
{
  int i;
  int posInit = indVtmp;
  unsigned int *cl;

  indPtmp = 0;
  pTmp[indPtmp++] = lit;
  
  while(indPtmp > 0)
    {
      --indPtmp;
      cl = reason[ABS(pTmp[indPtmp])];
      assert(cl);
      
      for( i = 2 ; i <= *cl ; i++) /* on peut commencer à 2 car seen[cl[i]] >= 2 */
	{
	  lit = cl[i];
	  
	  if((seen[ABS(lit)] < 2) && level[ABS(lit)] > 0)
	    {
	      if(reason[ABS(lit)] && nivOp[level[ABS(lit)]])
		{
		  seen[ABS(lit)] = 2;
		  pTmp[indPtmp++] = lit;
		  vTemp[indVtmp++] = lit;
		}
	      else
		{
		  for( i = posInit ; i< indVtmp ; i++) seen[ABS(vTemp[i])] = 0;
		  indVtmp = posInit;
		  return 0;
		}
	    }
	}
    }
  
  return 1;
}/* litRedundant */


/**
    Permet de savoir si la clause apprise est self subsumé par une clause binaire
 */
int litRedundantBin(unsigned int lit)
{
  unsigned int* tab, *end;

  tab = binClause[NEG(lit)].tabBin;
  for( end = &tab[binClause[NEG(lit)].nbBin] ; tab != end ; tab++)    
    if((seen[ABS(*tab)] == 3) && LIT_FALSE(*tab, isAssign[ABS(*tab)])) return 1;    
  return 0;
}/* litRedundantBin */


extern int testFalseLeartn;
/**
 *   Description:
 *     Analyze conflict and produce a reason clause.
 *  
 *  Pre-conditions:
 *     * 'cl' is assumed to conflicting clause
 *     
 *  
 *  Post-conditions:
 *     * the first litteral to clause returned is the asserting clause
 *  
 *  Effect:
 *     Will undo part of the trail, up to but not beyond the assumption of the current decision level
 */
unsigned int *analyseConflict(unsigned int *cl)
{  
  int i, j, sz, pathC = 0, p = 0, tmp, saveT = tail;
  unsigned int *c, *pc, lbd = 0;

  indVtmp = 0;
  c = cl;

  do{
    assert(c);
    sz = *c;
    
    seen[ABS(p)] = 0; // we saw
    
    for(i = (p) ? 2 : 1 ; i <= sz ; i++ )
      {
	tmp = c[i];	
	
	if(!seen[ABS(tmp)] && (level[ABS(tmp)] > 0))
	  {
	    increase(ABS(tmp));
	    if(level[ABS(tmp)] == decisionLevel)
              {
                seen[ABS(tmp)] = 1;
                pathC++;              
              }
	    else
              {
                vTemp[indVtmp++] = tmp;
                nivOp[level[ABS(tmp)]]++;
                seen[ABS(tmp)] = 2;  
              }
	  }
      }
    
    for(p = partial_assign[--tail] ; !seen[ABS(p)] ; p = partial_assign[--tail]);
      
    assert(tail >= posChoice[decisionLevel - 1]);
    c = reason[ABS(p)];
    pathC--;
  }while(pathC > 0);  
  
  /* Simplify conflict clause: */
  j = sz = indVtmp;
  seen[ABS(p)] = 3; // assertive literal is viewed
  
  for( i = 0 ; i<sz ; i++)
    {
      tmp = vTemp[i];
      assert(tmp != p);
      if(nivOp[level[ABS(tmp)]] <= 1) seen[ABS(tmp)] = 3;
      else 
	{
	  if(!reason[ABS(tmp)] || !litRedundant(tmp))
	    seen[ABS(tmp)] = 3;	    
	  else
	    {
	      nivOp[level[ABS(tmp)]]--;
	      j--;
	      nbRemoveRed++;
	    }
	}
    }

#if RESBIN
  /* use binary clause */
  for( i = 0 ; i<sz ; i++)
    {
      tmp = vTemp[i];
      if(seen[ABS(tmp)] != 3) continue;        
      if(litRedundantBin(tmp))
	{
	  seen[ABS(tmp)] = 2;
	  j--;
	  nbRemoveRedByBin++;
	}
    }
#endif

  /* conflict simplication finished */
  /* create clause: */
  sz = j;
  /* c[0] = sz size of clause */
  /* c[1] assertive literal */
  /* c[sz + 1] infoVar */
  c = (unsigned int *) calloc(sz + 3, sizeof(unsigned int));
  tmp = 0;
  MYFLAG++;
  for(j = 0, pc = &c[2] ; j<indVtmp ; j++)
    {
      if(seen[ABS(vTemp[j])] == 3) 
        {
          if(!tmp || level[ABS(c[tmp])] < level[ABS(vTemp[j])]) tmp = pc - c; // search the max level
          if(permDiff[level[ABS(vTemp[j])]] != MYFLAG) 
            {
              permDiff[level[ABS(vTemp[j])]] = MYFLAG;
              lbd++;
            }
          *(pc++) = vTemp[j];
        }    
      seen[ABS(vTemp[j])] = nivOp[level[ABS(vTemp[j])]] = 0;  
    }
  
  if(tmp){j = c[tmp]; c[tmp] = c[2]; c[2] = j;} // assert level c[2] = max_level
   
  for(i = saveT - 1 ; i >= posChoice[decisionLevel - 1] ; i--)
    {      
      tmp = ABS(partial_assign[i]);     
      addHeap(tmp);
      level[tmp] = -1;
      isAssign[tmp] = NOT_ASS;    
    }

  seen[ABS(p)] = 0;
  tail = posChoice[decisionLevel - 1];
  c[1] = NEG(p); /* litteral assertive */
  *c = sz + 1;
  indVtmp = 0;

  if(!sz){c[2] = 1; return c;}

  if(lbd > 20) lbd = 21U;
  setLBD(c[sz + 2], lbd);
  setAcceptTrue(c[sz + 2]);
  return c;
}/* analyseConflict */


/**
 * Permet de remonter dans l'arbre jusqu'au niveau lev
 * @param lev, le niveau où on veut être dans l'arbre.   
 */
void cancelUntil(int lev)
{
  int var;

  if(decisionLevel > lev)
    {      
      for(tail-- ; (tail >= posChoice[lev]); tail--)
	{
	  var = ABS(partial_assign[tail]);
          infoAtom[var].currentAssign = partial_assign[tail] & 1;
	  addHeap(var);
	  isAssign[var] = NOT_ASS;
	  assert(level[var] >= lev);	  
	  level[var] = -1;
	}
      tail++;
      qhead = tail;
      decisionLevel = lev;
    }else qhead = tail;
} /* cancelUntil */


/**
 * Backjumping processus
 * @param s, the structure dpll
 * @return the backjumping level
 */
int backjumping(unsigned int *conf)
{
  int lev;

  if(*conf == 1)    
    lev = 0;
  else lev = level[ABS(conf[2])];

  cancelUntil(lev);
  decisionLevel = lev;
  return lev;
}/* backjumping */



/**
 * This function fallow to push a new variable 
 * @param v, new variable
 */
void pushNewVariable(unsigned int v)
{
  posChoice[decisionLevel] = qhead;
  decisionLevel++;
  assert(decisionLevel < numatom);
  assert(isAssign[ABS(v)] == NOT_ASS);  
  uncheckedEnqueue(v, NULL);  
}/* pushNewVariable */


