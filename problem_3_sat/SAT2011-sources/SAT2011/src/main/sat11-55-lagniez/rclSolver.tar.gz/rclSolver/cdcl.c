#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <assert.h>
#include <math.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <limits.h>
#include <stdint.h>

#include <sys/times.h>
#include <sys/time.h>
#include <sys/types.h>

#include "vec.h"
#include "cdcl.h"
#include "analyseRL.h"
#include "heap.h"

/************************************/
/* Compilation flags                */
/************************************/

#define LUBY 1
#define TIRETS 83
#define INIT_LUBY 100


/* No longer using constant CLK_TCK - it is deprecated! */
/* Instead: */
long ticks_per_second;

/**************************************/
/* CDCL variable                      */
/**************************************/

extern int *posChoice;
extern unsigned int **reason;
extern int *partial_assign;
extern unsigned char *isAssign;
extern int decisionLevel;
extern int tail;
extern int *level;
extern int *vTemp;
extern int indVtmp;
extern vector *watched;


/************************************/
/* Main data structures             */
/************************************/

unsigned int numatom = 0;
unsigned int numclause = 0;
int numliterals;

int nbRemoveRed = 0;
int nbRemoveRedByBin = 0;
int nbRemoveInit = 0;
int nbRemoveLearnt = 0;

int hammingDistance = 0;
int whenLearnt = 2;

unsigned int ** clause = NULL;		/* clauses to be satisfied */
				/* indexed as clause[clause_num][literal_num] */
infoVar *infoAtom;		        /* value of each atom */

int resultat = OUT;
int nbClauseAdd = 0;
int nbClauseDer = 0;
int nbConflitDer = 0;
int maxAtom = 100000;
int nbClauseBin = 0;

int nbConf = 0;
int nbCleaning = 0;
double bornconf = 100;

double cla_inc = 1.0, clause_decay = 1 / 0.999;
double *weightVar = NULL;

int numtry = 0;			/* total attempts at solutions */

/* Randomization */
unsigned int seed;  /* Sometimes defined as an unsigned long int */

struct timeval tv;
struct timezone tzp;

/* Statistics */

double expertime;
double totalTime=0;

int nbPush = 0;


/* Learnt clause */
int numclauseLearnt = 0;
unsigned int ** clauseLearnt = NULL;
int INCREASE_LIMIT_REDUCE = 100;
int MAX_NB_USE = 7;

/* binary clause */
binaryStruct *binClause;

/************************************/
/* Forward declarations             */
/************************************/

void parse_parameters(int argc,char *argv[]);
double elapsed_seconds(void);
void initprob(void); 
void handle_interrupt(int sig);
long super(int i);
void print_statistics_header(void);
void showInter();
void showFinal();
void removeClauseDB(int cl);
void cleaningDB();
void solve(int nbConflict);

double sizeLearnt;

int nbPC =0;
int nbCf = 0;
BIGINT nbPropagation = 0;

int var1 = 0;
int stat;
int *tabDistrib;

int nbCauseBeforeReduce;


/***************************************************************************************/
/* Memory used     *********************************************************************/
/***************************************************************************************/

int memReadStat(int field)
{
  char    name[256];
  pid_t pid = getpid();
  int     value = 0;
  sprintf(name, "/proc/%d/statm", pid);
  FILE*   in = fopen(name, "rb");
  if (in == NULL) return 0;
  for (; field >= 0; field--)
    assert(fscanf(in, "%d", &value));
  fclose(in);
  return value;
}

uint64_t memUsed() 
{
  return (uint64_t)memReadStat(0) * (uint64_t)getpagesize();
}

/*****************************************************************************************/
/* Main           ************************************************************************/
/*****************************************************************************************/

#define NBCLAUSEREDUCE 1000
#define NBADDREDUCE 100

int main(int argc,char *argv[])
{
  ticks_per_second = sysconf(_SC_CLK_TCK);
  gettimeofday(&tv,&tzp);
  seed = (unsigned int)((( tv.tv_sec & 0177 ) * 1000000) + tv.tv_usec);
  parse_parameters(argc, argv);
  srandom(seed);
  initprob();
  
  print_statistics_header();

  signal(SIGINT, handle_interrupt);
  signal(SIGTERM, handle_interrupt);
  signal(SIGALRM, handle_interrupt);

  (void) elapsed_seconds();
  
  nbClauseDer = numclause;

  sizeLearnt = NBCLAUSEREDUCE;
  
  hammingDistance = 0;  // deviation
  while(1)
    {
      numtry++;
      solve((int) bornconf);      
#if LUBY == 0
      bornconf *= 1.5;
#else
      bornconf = super(numtry) * INIT_LUBY;
#endif
    }
  termineProg(OUT,"UNKNOWN");
  return 0;
}/* main */

/**
 * Parse parameters
 */
void parse_parameters(int argc,char *argv[])
{
  int i;
  
  for (i=1;i < argc;i++)
    {
      if (strcmp(argv[i],"-stat") == 0) stat = 1;
    }
}/* parse_parameters */

/**
   Luby
 */
long super(int i)
{
    long power;
    int k;

    if (i<=0){
      fprintf(stderr, "bad argument super(%d)\n", i);
      exit(1);
    }
    /* let 2^k be the least power of 2 >= (i+1) */
    k = 1;
    power = 2;
    while (power < (i+1)){
      k += 1;
      power *= 2;
    }
    if (power == (i+1)) return (power/2);
    return (super(i - (power/2) + 1));
}/* super */

/**
   Handle interrupt
*/
void handle_interrupt(int sig)
{
  showFinal();
  exit(0);
}/* handle_interrupt */

/**
   Compare integer
 */
static int cmpInt(const void *p1, const void *p2)
{
  int a = *(int*)p1;
  int b = *(int*)p2;
  if(a<0) a = -a;
  if(b<0) b = -b;
  return a - b;
}//cmpInt




/**
   Init prob : parse problem
*/
void initprob(void)
{
  int i;
  int j = 0;
  unsigned int stp1;
  unsigned int stp2;
  int lastc;
  int nextc;
  int storeptr[MAXLENGTH];
  int lit;
  int tau;
  int sz;
  
  while ((lastc = getchar()) == 'c' || lastc == '\n')
    {
      while ((nextc = getchar()) != EOF && nextc != '\n');
    }
  ungetc(lastc,stdin);
  if (scanf("p cnf %i %i",&numatom, &numclause) != 2)
    {
      fprintf(stderr,"c initprob 1 : Bad input file\n");
      exit(-1);
    }

  numclause += 10;
  maxAtom = numatom + 2;
  while (getchar()!='\n');

  /* initMyVariable */
  if(!(infoAtom = (infoVar *) calloc(maxAtom + 1, sizeof(infoVar)))){perror("infoAtom"); exit(1);}  
  for(i = 0 ; i< maxAtom + 1 ; infoAtom[i++].currentAssign = 1);
  initDPLL();
  
  /* on prépare pour les clauses binaires */
  binClause = (binaryStruct *) malloc(sizeof(binaryStruct) * ((maxAtom + 1) * 2));
  for( i = 0 ; i < (2 * (maxAtom + 1)) ; i++)
    {
      binClause[i].res[0] = 2;
      binClause[i].res[1] = 0;  /* une valeur au pif qui sera utilisé pour l'analyse de conflit */
      binClause[i].res[2] = i;  /* le littéral qui sera la raison de la propagation */
      binClause[i].res[3] = 0; /* permet de dire que la clause n'est pas une clause apprise */
      binClause[i].nbBin = 0;   /* le nombre de 'clause binaire' associé */
      binClause[i].tabBin = NULL;
    }

  numliterals = 0;
  for(i = 0 ; i < numclause ; i++)
    {
      sz = -1;
      tau = 0;
      do
        {
          sz++;
	  j = scanf("%d", &lit);          
          
          if(j != 1)
	    {
	      lit = 0;
	      
	      if(j == EOF)
		{
		  numclause = i + 1;
		  if(!(sz))
		    {
		      numclause--;
		      goto end_loop;
		    }
		}
	    }
          
          /* show lit exist to clause[i] or it's a tauto */
	  if(lit)
	    {
	      for(j=0 ; j<sz ; j++) if((storeptr[j] == lit) || (storeptr[j] == -lit)) break;
	      if(j < sz)
		{
		  if(storeptr[j] == lit)
		    {
		      sz--;
		      continue;
		    }/*redundancy*/
		  else tau = 1;/*tautologie*/
		}
	    }
          
          if(lit != 0)
            {
              storeptr[sz] = lit; /* clause[i][size[i]] = j; */
              numliterals++;
            }
        }
      while(lit != 0);
      if(!sz)
        {
          printf("s UNSATISFIABLE\n");
          exit(20);
        }
      
      if(tau)
        {
          numclause--;
          i--;
        }
      else
        {
	  if(sz == 1)
	    {
	      stp1 = (storeptr[0] > 0) ? storeptr[0]<<1 :  (-storeptr[0]<<1) + 1;
	      if(LIT_FALSE(stp1, isAssign[ABS(stp1)])) termineProg(UNS, "UNSAT");
	      if(!(isAssign[ABS(stp1)] != NOT_ASS)) uncheckedEnqueue(stp1, NULL);
	      numclause--;
	      i--;
	    }else if(sz == 2)
	    {
	      stp1 = (storeptr[0] > 0) ? storeptr[0]<<1 :  (-storeptr[0]<<1) + 1;
	      stp2 = (storeptr[1] > 0) ? storeptr[1]<<1 :  (-storeptr[1]<<1) + 1;
              
	      nbClauseBin++;
	      
	      binClause[stp1].tabBin = (unsigned int * ) realloc(binClause[stp1].tabBin, sizeof(unsigned int) * (binClause[stp1].nbBin + 1));
	      binClause[stp1].tabBin[binClause[stp1].nbBin++] = stp2;
	      
	      binClause[stp2].tabBin = (unsigned int * ) realloc(binClause[stp2].tabBin, sizeof(unsigned int) * (binClause[stp2].nbBin + 1));
	      binClause[stp2].tabBin[binClause[stp2].nbBin++] = stp1;
	      
	      numclause--;
	      i--;
	    }else
	    {
	      if(!(clause = (unsigned int **) realloc(clause, sizeof(unsigned int *) * (i + 1)))){perror("clause"); exit(1);}
	      if(!(clause[i] = (unsigned int *) malloc(sizeof(unsigned int)*(sz + 2))))
		{
		  perror("size");
		  exit(1);
		}	  
	      qsort(storeptr, sz, sizeof(int), cmpInt);
	      for(j = 1 ; j <= sz ; j++)
		{
		  if(storeptr[j -1] > 0)
		      clause[i][j] = storeptr[j - 1]<<1;
		  else clause[i][j] = ((-storeptr[j - 1])<<1) + 1;
		}
	      *clause[i] = sz;
	      clause[i][sz + 1] = 0; // pour dire que ce n'est pas une clause apprise	      
	      attachClause(clause[i]);
	    }
	}
    }
      
 end_loop:  

  if(propagate()) termineProg(UNS, "UNSAT");
  posChoice[0] = tail;

  initHeap();
  for(i = 1 ; i <= numatom ;i++) addHeap(i);
}/* initprob */


/**
   elapsed seconds
 */
double elapsed_seconds(void) 
{ 
   double answer;   
   answer = (double) clock() / CLOCKS_PER_SEC - totalTime;
   totalTime = (double) clock() / CLOCKS_PER_SEC;
   return answer; 
}/* elapsed_seconds */


/**********************************************************************************/
/**********************************************************************************/
/**********************************************************************************/

/**
   Print statistics header
 */
void print_statistics_header(void)
{
  int i;
  fprintf(stderr, "c \nc seed = %i, numatom = %i, numclause = %i, numliterals = %i\nc ",
          seed, numatom,numclause,numliterals);

  for(i = 0 ; i< TIRETS ; fprintf(stderr, "-"), i++); fprintf(stderr, "\n");
  fprintf(stderr, "c | %4s | %7s | %7s | %8s | %9s | %7s | %9s | %7s |\nc ",
	  "try", "tps", "#impl", "#learnt", "#conf", "#clean", "#propa", "#deci");
  for(i = 0 ; i< TIRETS ; fprintf(stderr, "-"), i++); fprintf(stderr, "\n");
}/* print_statistics_header */


/**
   Fonction permettant d'afficher les informations intermédiaire
 */
void showInter()
{
  double temps = elapsed_seconds();
  int i;

  fprintf(stderr, "c | %4d | %7.1lf | %7d | %8d | %9d | %7d | %9lld | %7d |\n",
	  numtry, temps, posChoice[0], numclauseLearnt, nbCf, nbCleaning, nbPropagation, nbPC);
  if(stat)
    {
      fprintf(stderr, "nb cleaning = %d\n", nbCleaning);
      fprintf(stderr, "nb conflit = %d\n",nbCf);
      fprintf(stderr, "nb decision = %d\n",nbPC);
      fprintf(stderr, "Distribution : ");
      for( i = 0 ; tabDistrib[i] ; i++)
	{
	  fprintf(stderr, "%.4lf %%\t", (((double) tabDistrib[i]) / var1) * 100);
	  if(i && (!(i%10))) fprintf(stderr,"\n");
	}
      i--;
      if(i%10)
	fprintf(stderr, "\n");
      fprintf(stderr, "--------------------------------------------------------\n");
    }
}/* showInter */

/**
   Fonction permettant de savoir le temps passé depuis le début du programme
   Retourne :
      - le temps passé depuis le début du programme
 */
double tps_ecouler()
{
   double answer;
   answer = (double) clock() / CLOCKS_PER_SEC;
   return answer; 
}//tps_ecouler


/**
   Fonction permettant d'afficher les r<E9>sultats du test
 */
void showFinal()
{
  int i;


  showInter();
  fprintf(stderr, "c ");
  for(i = 0 ; i< TIRETS ; fprintf(stderr, "="), i++); fprintf(stderr, "\n");
  fprintf(stderr, "c times = %lf\n",tps_ecouler());  
  fprintf(stderr, "c restart = %d\n",numtry);
  fprintf(stderr, "c conflit = %d\n",nbCf);
  fprintf(stderr, "c decision = %d\n",nbPC);
  fprintf(stderr, "c cleaningDB = %d\n",nbCleaning);
  fprintf(stderr, "c clause binaire = %d\n",nbClauseBin);
  fprintf(stderr, "c propagation = %lld \t (%lf (prop/sec))\n",nbPropagation, nbPropagation / tps_ecouler());
  fprintf(stderr, "c literal removed by litRedundant = %d\n",nbRemoveRed);
  fprintf(stderr, "c literal removed by litRedundantBin = %d\n",nbRemoveRedByBin);
  fprintf(stderr, "c init clause removed by simplify = %d\n",nbRemoveInit);
  fprintf(stderr, "c learnt clause removed by simplify = %d\n",nbRemoveLearnt);
  uint64_t mem_used = memUsed();
  if(mem_used != 0) fprintf(stderr,"c Memory used           : %.2f MB\n", mem_used / 1048576.0);

  switch(resultat)
    {
    case SAT :
      {
        printf("s SATISFIABLE\n");
        printf("v ");
        for(i = 1 ; i<(numatom + 1); i++)
          if(infoAtom[i].currentAssign) printf("%d ", -i); else printf("%d ",i);
        printf("0\n");
        exit(10);
        break;
      }
    case UNS :
      {
        printf("s UNSATISFIABLE\n");
        exit(20);
        break;
      }
    case OUT : 
      {
        printf("UNKNOWN\n");
      }
    }  
}//showFinal


/**
   Fonction permettant de gérer la terminaison du programme
   En entrée : 
      - res, dans quel état le programme c'est terminé
      - comment, une chaine de caractère décrivant l'état de sorti
 */
void termineProg(int res,char *comment)
{
  resultat = res;
  kill(getpid(),SIGTERM);
}/* termineProg */


/**
   Realloc memory variable
 */
void realloue()
{

  if(!(clauseLearnt = (unsigned int **) realloc(clauseLearnt, sizeof(unsigned int *)*(((numclauseLearnt/MAXCLAUSEBLOC)+1)*MAXCLAUSEBLOC))))
    {
      perror("clause\n");
      exit(1);
    }
}/* realloue */


/**
   Add new clause of data base
   In entry :
       - c, one table (malloc)       
   Return : This function return 0 if the new clause is added, otherwise >0

 */
int addClauseDB(unsigned int *c)
{

  nbClauseAdd++;

  if(*c == 2)
    {       
      nbClauseBin++;
      
      binClause[c[1]].tabBin = (unsigned int *) realloc(binClause[c[1]].tabBin, sizeof(unsigned int) * (binClause[c[1]].nbBin + 1));
      binClause[c[1]].tabBin[binClause[c[1]].nbBin++] = c[2];
      
      binClause[c[2]].tabBin = (unsigned int *) realloc(binClause[c[2]].tabBin, sizeof(unsigned int) * (binClause[c[2]].nbBin + 1));
      binClause[c[2]].tabBin[binClause[c[2]].nbBin++] = c[1];
    }else
    {
      if(!(numclauseLearnt % MAXCLAUSEBLOC)) realloue();      
      clauseLearnt[numclauseLearnt] = c;
      attachClause(c);
      ++numclauseLearnt;
    }

  return 1;
}/* addClauseDB */


/**
   Remove clause learnt
   In entry :
        - cl, index of the clause to remove
 */
void removeClauseInit(unsigned int *cl)
{
  detachClause(cl);
  free(cl);
}/* removeClause */

/**
   Remove clause learnt
   In entry :
        - cl, index of the clause to remove
 */
void removeClause(unsigned int *cl)
{
  detachClause(cl);
  free(cl);
}/* removeClause */


int locked(unsigned int * cl){ return (reason[ABS(cl[1])] == cl) && (LIT_TRUE(cl[1], isAssign[ABS(cl[1])])) && (level[ABS(cl[1])]);}
int trueClause(unsigned int *cl){ return (LIT_TRUE(cl[1], isAssign[ABS(cl[1])])) && (!level[ABS(cl[1])]); }

/**
 *  Refresh data base
 */
void cleaningDB()
{  
  static double minDeviation = 1;
  int backJumpInRed = decisionLevel;
  unsigned int *cl, *lTmp;
  int tmp, i, j, nTmp, cpt, maxLevel, nbFree, posMaxLev, jump = 0;

  tmp = 0;
  hammingDistance = 0;
  for( i = 1, cpt = 0 ; i <= numatom ; infoAtom[i].numFlip = 0, infoAtom[i++].view = 0) 
    {
      if(infoAtom[i].lastAssign != infoAtom[i].currentAssign) hammingDistance++;
      if(infoAtom[i].view) cpt++; 
      infoAtom[i].lastAssign = infoAtom[i].currentAssign;
    }
  double deviation = (double) hammingDistance / (double) cpt;  
  if(deviation < minDeviation) minDeviation = deviation;
  if(minDeviation < 0.1) minDeviation = 0.1;
  hammingDistance = 0;
  
  for (i = 0 ; i < numclauseLearnt ; i++)
    {
      cl = clauseLearnt[i];
      lTmp = &cl[*cl + 1];
      
      if (!getAccept(*lTmp) && *cl > 2 && !locked(cl) && getLBD(*lTmp) && getLBD(*lTmp) <= 20)
        {
          cpt = maxLevel = nbFree = posMaxLev = 0;
          nTmp = (*cl * minDeviation) + 2;
          for(j = 1 ; (j <= *cl) && (cpt <= (nTmp + 1)) ; j++)
            {
              if(infoAtom[ABS(cl[j])].currentAssign == (cl[j] & 1)) cpt++;
              if(!getIsAttached(*lTmp))
                {
                  if(nbFree < 2 && !LIT_FALSE(cl[j], isAssign[ABS(cl[j])]))
                    {                      
                      // two literals different to l_False at the beginning
                      tmp = cl[j], cl[j] = cl[nbFree + 1], cl[++nbFree] = tmp; // ICI
                    }else if(maxLevel < level[ABS(cl[j])])
                    {
                      maxLevel = level[ABS(cl[j])];
                      posMaxLev = j;
                    }
                }
            }
          
          if(cpt <= nTmp) setAcceptTrue(*lTmp); else setAcceptFalse(*lTmp);
          
          if(!getIsAttached(*lTmp) && nbFree < 2)
            {
              tmp = cl[posMaxLev],  cl[posMaxLev] = cl[nbFree + 1], cl[nbFree + 1] = tmp;
              setIsUsedTrue(*lTmp);
              
              if(!nbFree) // conflict clause
                {
                  // search the backjump level
                  maxLevel = 0;
                  for( j = 2 ; j <= *cl ; j++ )
                    if(maxLevel < level[ABS(cl[j])])
                      {
                        maxLevel = level[ABS(cl[j])];
                        posMaxLev = j; 
                      }
                  tmp = cl[posMaxLev], cl[posMaxLev] = cl[1], cl[1] = tmp;
                }
              if(backJumpInRed > maxLevel) backJumpInRed = maxLevel;
              jump = 1;
            }
        }else if(getLBD(*lTmp) > 20 && !getIsUsed(*lTmp)) setAcceptFalse(*lTmp); else setAcceptTrue(*lTmp);
    }


  if(jump) cancelUntil(backJumpInRed ? backJumpInRed - 1 : 0); // free level
  cpt = 0;
  
  // Don't delete binary or locked clauses.
  for (i = j = 0 ; i < numclauseLearnt ; i++)
    {
      cl = clauseLearnt[i];      
      lTmp = &cl[*cl + 1];
      if(*cl <= 2 || locked(cl)) goto saveClause;    
      
      if(!getIsUsed(*lTmp)) setNbUse(*lTmp, getNbUse(*lTmp) - 1); else setNbUse(*lTmp, MAX_NB_USE);
      setIsUsedFalse(*lTmp);
      
      if(!getAccept(*lTmp) || !getNbUse(*lTmp))
        {          
          if(getIsAttached(*lTmp)) detachClause(cl);
          
          if(!getNbUse(*lTmp) || getLBD(*lTmp) > 20) // delete clause
            {
              free(cl);
              continue;
            }
        }
      else
        {
          if(!getIsAttached(*lTmp))
            {
              setNbUse(*lTmp, MAX_NB_USE);
              attachClause(cl);
            }
        }
    saveClause:
      if(getIsAttached(*lTmp)) cpt++;
      clauseLearnt[j++] = clauseLearnt[i];
    }
  numclauseLearnt = j;
}/* cleaningDB */

/**
 * Permet de savoir si une clause est satisfaite.
 * @param cl, la clause que l'on souhaite vérifier.
 * @return 1 si la clause est satisfaite et 0 sinon.
 */
int satisfied(unsigned int *cl)
{
  unsigned int *i, *end;
  for( i = &cl[1], end = &i[*cl] ; i != end ; i++)    
    if(LIT_TRUE(*i, isAssign[ABS((*i))])) return 1;  
  return 0;
}// satisfied


/**
 * Delete satisfied clauses.
 */
void simplify()
{  
  unsigned int i, j, k, *tab;
  if(decisionLevel != 0) return;
  
  // init clauses
  for( j = i = 0 ; i<numclause ; i++)
    {
      if(satisfied(clause[i]))
	{
	  nbRemoveInit++;
	  removeClauseInit(clause[i]);
	}
      else clause[j++] = clause[i];	
    }
  numclause = j;  
  
  // learnt clauses
  for( j = i = 0 ; i<numclauseLearnt ; i++)
    {
      if(satisfied(clauseLearnt[i]))
        {         
          nbRemoveLearnt++;
          if(getIsAttached(clauseLearnt[i][*clauseLearnt[i] + 1])) detachClause(clauseLearnt[i]);           
          free(clauseLearnt[i]);
        }
      else clauseLearnt[j++] = clauseLearnt[i];	
    }
 numclauseLearnt = j;

 // binary clauses 
 for( i = 1 ; i <= numatom ; i++)
   {     
     if((binClause[i<<1].nbBin || binClause[(i<<1) | 1].nbBin) && !LIT_UNDEF(isAssign[i]))
       {
         binClause[i<<1].nbBin = 0;
         binClause[(i<<1) | 1].nbBin = 0;
         free(binClause[i<<1].tabBin);
         free(binClause[(i<<1) | 1].tabBin);         
       }else
       {
         tab = binClause[i<<1].tabBin; 
         for(j = k = 0 ; j < binClause[i<<1].nbBin ; j++)
           if(LIT_UNDEF(isAssign[ABS(tab[j])])) tab[k++] = tab[j];           
         binClause[i<<1].nbBin = k;

         tab = binClause[(i<<1) | 1].tabBin; 
         for(j = k = 0 ; j < binClause[(i<<1) | 1].nbBin ; j++)
           if(LIT_UNDEF(isAssign[ABS(tab[j])])) tab[k++] = tab[j];
         binClause[(i<<1) | 1].nbBin = k;
       }
   }
 
}/* simplify */


/**
 * This function allows to choice the next decision.
 * @return the next decision variable.
 */
unsigned int pickBranchLit()
{
  unsigned var;
  int i;
  do
    {
      var = nextOrderHeap();
    }
  while(isAssign[var] != NOT_ASS && var);
  
  assert((isAssign[var] == NOT_ASS) || !var);
  
  if(!var)
    {
      for( i = 1 ; i<=numatom; i++) assert(isAssign[i]);
      for(i = 0 ; i<tail ; i++)             
	{
	  var = partial_assign[i];
	  infoAtom[ABS(var)].currentAssign = var & 1;
	}
      termineProg(SAT,"ASSIGNMENTS FOUND");
    }

  return (var<<1) | infoAtom[var].currentAssign;
}/* pickBranchLit */

int aSimplify = 0;

/**
   CDCL with nbConflict
 */
void solve(int nbConflict)
{
  static int controlReduce = INIT_LIMIT_REDUCE;
  static int posReduce = INIT_LIMIT_REDUCE;

  unsigned int *clConf, var;
  unsigned int *cl;
  nbConf = 0;

  if(aSimplify){simplify(); aSimplify = 0;}

  while(1)
    {          
      cl = propagate();
    classicalBacktrack:
      if (cl != NULL)
	{
	  // CONFLICT
          nbConflict--;
          nbConf++;
	  nbCf++;
          controlReduce--;
	  
	  if(decisionLevel == 0) termineProg(UNS,"UNSATISFIABLE");
	  
          clConf = analyseConflict(cl);
          decrease();
          backjumping(clConf);

	  if(*clConf > 2)
	    {    
	      addClauseDB(clConf);	 	  
	      uncheckedEnqueue(clConf[1], clConf);
	      cla_inc *= clause_decay;
	    }else if(*clConf == 2)
	    {
	      addClauseDB(clConf);
	      uncheckedEnqueue(clConf[1], binClause[clConf[2]].res);
	      free(clConf);	      
	    }else
	    {
	      aSimplify = 1;
	      uncheckedEnqueue(clConf[1], NULL);
	      free(clConf);
	    }
	  
	  cl = propagate();
	  if(cl) goto classicalBacktrack;	    
	}else
	{
	  // NO CONFLICT
	  if (nbConflict <= 0)
	    {	    
	      cancelUntil(0);
	      return; 
	    }
	  
	  if(controlReduce < 0)
	    {
              controlReduce = (posReduce += INCREASE_LIMIT_REDUCE);              
              if(!(++nbCleaning & 63))
                {
                  if(MAX_NB_USE < 15) MAX_NB_USE--;
                }
	      cleaningDB();
              showInter();
	    }
	  
	  var = pickBranchLit();
	  nbPC++;	
	  pushNewVariable(var);
	}
    }
}//solve

