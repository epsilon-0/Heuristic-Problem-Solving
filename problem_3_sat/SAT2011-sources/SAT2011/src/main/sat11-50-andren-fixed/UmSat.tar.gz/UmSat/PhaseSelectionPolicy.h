/*
 *  PhaseSelectionPolicy.h
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-12.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _PHASESELECTIONPOLICY_H__
#define _PHASESELECTIONPOLICY_H__ 1

#include "Policies.h"
#include "Listeners.h"

class VariableSelectionPolicy {
public:
	virtual bool done() { return true; }
	virtual Variable select() { return 0; }
};

class PhaseSelectionPolicy : public LiteralSelectionPolicy, public Listeners {
public:
	enum Phase { True, False, Saved, NotSaved };
	PhaseSelectionPolicy(size_t numberOfVarialbes, VariableSelectionPolicy &variable, Phase phase = Saved) :
	_variable(variable),
	_phases(numberOfVarialbes),
	_method(phase)
	{
		//std::cout << "Phase selection policy: " << _method << std::endl;
	}
	virtual bool done() { return _variable.done(); }
	virtual Literal select() {
		Variable var = _variable.select();
		if(_method == True) return Literal(var);
		if(_method == False) return Literal(-var);
		Literal lit = _phases[var] ? Literal(var) : Literal(-var);
		if(_method == NotSaved) lit = lit.opposite();
		return lit;
	}
	
	virtual void onAssert(Literal lit) {
		_phases[lit.absVariable()] = lit.variable() > 0;
	}
private:
	Phase _method;
	VariableSelectionPolicy &_variable;
	std::vector<bool> _phases;
};

#endif
