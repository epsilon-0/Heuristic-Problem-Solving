/*
 *  Clauses.cpp
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-11.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "Clauses.h"
#include <iterator>

std::ostream &operator<<(std::ostream& s, LearntClause2 const & c) {
	s << "<" << c._w0.variable() << ", " << c._w1.variable() << "> ";
	std::copy(c._literals.begin(), c._literals.end(), std::ostream_iterator<Literal>(s, " "));
	return s;
}

Constraint::Result LearntClause2::simplify(Trail &trail, ConstraintManager &cm) {
	std::vector<Literal>::iterator lp(_literals.begin()), end(_literals.end());
	while (lp != end) {
		if(trail.contains(*lp)) return Constraint::skip; // Already satisfied.
		if(trail.contains(lp->opposite())) { // Already falsified literal.
			--end;
			std::swap(*lp,*end);
		} else {
			++lp;
		}
	}
	_literals.erase(end, _literals.end());
	if(_literals.size() == 0) return Constraint::conflict; // All literals already falsified.
	if(_literals.size() == 1) { // Propagate.
	  if(trail.contains(_literals.at(0).opposite())) return Constraint::conflict;
		trail.enqueueUnitLiteral(_literals.at(0));
		/*
		Constraint *conflict(0);
		while (trail.hasUnitLiteral() && conflict == 0) {
			Literal lit = trail.assertNextUnitLiteral();
			conflict = cm.notify(lit);
		}
		return conflict ? Constraint::conflict : Constraint::skip;
		*/
		return Constraint::skip;
	}
	_w0 = _literals.at(0);
	_w1 = _literals.at(1);
	return Constraint::keep;
}

bool LearntClause2::satisfied(Trail const &T) {
  std::vector<Literal>::const_iterator lit = std::find_if(_literals.begin(), _literals.end(), Trail::Contains(T));
  return lit != _literals.end();
}
