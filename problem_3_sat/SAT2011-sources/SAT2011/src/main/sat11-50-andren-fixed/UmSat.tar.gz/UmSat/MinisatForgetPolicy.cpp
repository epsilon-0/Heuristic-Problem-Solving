/*
 *  MinisatForgetPolicy.cpp
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-12.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "MinisatForgetPolicy.h"

#include <iostream>
#include <iterator>

struct Activity : public std::unary_function<LearntClause2 const *, double> {
	double operator()(LearntClause2 const * c) {
		return c->activity();
	}
};

struct RemoveP : public std::unary_function<LearntClause2 const *, bool> {
  RemoveP(double activity, ReasonManager const & reasons) : _activity(activity), _reasons(reasons) {}
  bool operator()(LearntClause2 const * c) {
    if(c->size() <= 4) return true; // keep: Small clause.
    if(c->isReason(_reasons)) return true; // keep: Reason
    if(c->activity() > _activity) return true; // keep: High activity
    return false; // forget rest...
  }
  const double _activity;
  ReasonManager const &_reasons;
};

ConstraintManager::iterator MinisatForgetPolicy::select(ConstraintManager::iterator begin, ConstraintManager::iterator end) {
  size_t dist = std::distance(begin, end);
  std::vector<double> pnt;
  pnt.reserve(dist);
  std::transform(begin,end,back_inserter(pnt),Activity());
  std::sort(pnt.begin(), pnt.end());
  
  dist = ((double)dist * (1.0 - _percentToForget));
  double point = pnt.at(dist);
  ConstraintManager::iterator mid = std::partition(begin, end, RemoveP(point, _reasons));
  if(std::distance(mid, end) < 5) _numberOfClausesForNextForget = (size_t)(_numberOfClausesForNextForget * _forgetIncrement);
  return mid;
}

void MinisatForgetPolicy::rescale() {
  ConstraintManager::iterator i = _watches.begin();
  for(;i != _watches.end(); ++i) {
    (*i)->activity() /= _max_activity;
  }
  _bumpAmount /= _max_activity;
}

void MinisatForgetPolicy::onConflict(Constraint *con) {
  LearntClause2 *c = dynamic_cast<LearntClause2 *>(con);
  if(c && c->isLearnt()) {
    c->activity() += _bumpAmount;
    if(c->activity() > _max_activity) {
      rescale();
    }
  }
  _bumpAmount *= _decayFactor;
}
