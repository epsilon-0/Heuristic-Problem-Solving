/*
 *  reader.h
 *  UmSAT
 *
 *  Created by Daniel Andrén on 2010-04-21.
 *  Copyright 2010 Umeå univeritet. All rights reserved.
 *
 */

#ifndef _READER_H__
#define _READER_H__ 1

#include <boost/tokenizer.hpp>
#include <vector>
#include <string>
#include <iostream>

typedef std::vector<int> PreClause;
typedef std::vector<PreClause> PreProblem;

class TypeProblemPair {
public:
	TypeProblemPair() {}
	std::string const &type() const { return _type; }
	std::string &type() { return _type; }
	size_t const size() const { return _preProblem.size(); }
	PreProblem::const_iterator begin() const { return _preProblem.begin(); }
	PreProblem::const_iterator end() const { return _preProblem.end(); }
	void push_back(PreClause clause) { _preProblem.push_back(clause); }
private:
	std::string _type;
	PreProblem _preProblem;
};

class Reader {
public:
	Reader(std::istream &instream) :
	_instream(instream)
	{ }
	
	TypeProblemPair read() {
		lineNo = 0;
		_instream.unsetf(std::ios::skipws);
		return doRead();
	}
	
private:
	typedef boost::tokenizer<boost::char_separator<char>, std::istream_iterator<char> > tokenizer;

	PreClause read_vector(tokenizer::const_iterator &toki, tokenizer::const_iterator end);

	TypeProblemPair doRead(void);
	std::istream &_instream;
	size_t lineNo;
};

#endif