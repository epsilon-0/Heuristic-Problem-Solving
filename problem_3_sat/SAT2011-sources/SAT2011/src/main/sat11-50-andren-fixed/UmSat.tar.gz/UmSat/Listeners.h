/*
 *  Listeners.h
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-07.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _LISTENERS_H__
#define _LISTENERS_H__

#include "Literal.h"

class Constraint;

class Listeners {
public:
	typedef std::vector<Listeners*> const_iterator;
	virtual void init() {}
	virtual void onExplain(Literal, Reason const &) {}
	virtual void onBacktrack(Literal) {}
	virtual void onAssert(Literal) {}
	virtual void onDecide(Literal) {}
	virtual void onConflict(Constraint *) {}
	virtual void onPropagation(Constraint *, Literal) {}
	virtual void onLearn(Constraint *) {}
	virtual void onRestart() {}
	virtual void onForget() {}
	virtual void onForgetConstraint(Constraint *) {}
	
	virtual ~Listeners() {}
};
#endif
