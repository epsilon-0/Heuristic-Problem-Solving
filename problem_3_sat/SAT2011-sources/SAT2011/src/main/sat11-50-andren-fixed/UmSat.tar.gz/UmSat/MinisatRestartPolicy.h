/*
 *  MinisatResatartPolicy.h
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-12.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _MINISATRESTARTPOLICT_H__
#define _MINISATRESTARTPOLICT_H__

#include "Policies.h"
#include "Listeners.h"

class MinisatRestartPolicy: public RestartPolicy, public Listeners {
 public:
 MinisatRestartPolicy() : _numberOfConflicts(0), _numberOfConflictsBeforeNextRestart(100), _factor(1.2) {}
 public: // Restart policy
  virtual bool restart() { return _numberOfConflicts > _numberOfConflictsBeforeNextRestart; }
 public: // Listener
  virtual void onRestart() {
    _numberOfConflicts = 0;
    _numberOfConflictsBeforeNextRestart = (size_t)(_factor * _numberOfConflictsBeforeNextRestart);
  }
  virtual void onConflict(Constraint *) { ++_numberOfConflicts; }
 private:
  size_t _numberOfConflicts;
  size_t _numberOfConflictsBeforeNextRestart;
  double _factor;
};

#endif
