/*
 *  MinisatForgetPolicy.h
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-12.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _MINISATFORGETPOLICY_H__
#define _MINISATFORGETPOLICY_H__

#include "Listeners.h"
#include "Policies.h"
#include "Clauses.h"
class PropagationReason;

class MinisatForgetPolicy : public Listeners, public ForgetPolicy {
public:
	MinisatForgetPolicy(ConstraintManager & watches, ReasonManager & reasons, double percentToForget = 0.5, double forgetIncrement = 1.1, double percentClausesForFirstForget = 1.0/3.0) :
	_percentClausesForFirstForget(percentClausesForFirstForget),
	_forgetIncrement(forgetIncrement),
	_percentToForget(percentToForget),
	_bumpAmount(1.0),
	_decayFactor(1.0/0.999),
	_max_activity(1000.0),
	_numberOfClausesForNextForget(watches.numberOfInitialConstraints()*_percentClausesForFirstForget),
	_watches(watches),
	_reasons(reasons)
	{}
	
public:
	virtual bool forget() {
	  return _watches.numberOfLearntConstraints() > _numberOfClausesForNextForget;
	}
	virtual ConstraintManager::iterator select(ConstraintManager::iterator begin, ConstraintManager::iterator end);
public:
	virtual void onRestart() {
	  _numberOfClausesForNextForget = (size_t)(_numberOfClausesForNextForget * _forgetIncrement);
	}
	virtual void onConflict(Constraint *con);
 private:
	void rescale();
	
	const double _percentClausesForFirstForget;
	const double _forgetIncrement;
	const double _percentToForget;
	double _bumpAmount;
	const double _decayFactor;
	const double _max_activity;
	size_t _numberOfClausesForNextForget;
	ConstraintManager &_watches;
	ReasonManager &_reasons;
};

#endif
