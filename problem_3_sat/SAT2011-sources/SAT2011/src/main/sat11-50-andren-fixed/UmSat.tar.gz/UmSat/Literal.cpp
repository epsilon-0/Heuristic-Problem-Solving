/*
 *  Literal.cpp
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-21.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "Literal.h"
#include <iostream>

std::ostream& operator<<(std::ostream& s, const Literal& l) {
	return s << l.variable();
}

std::ostream& operator<<(std::ostream& s, const Reason& r) {
  for(Reason::const_iterator l(r.begin()); l != r.end(); ++l) {
    s << *l << " ";
  }
  return s;
}
