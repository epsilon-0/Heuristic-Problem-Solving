/*
 *  Solve.h
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-07.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _SOLVE_H__
#define _SOLVE_H__

class Constraint;
class ConstraintManager;
class LiteralSelectionPolicy;
class RestartPolicy;
class ForgetPolicy;
class StopPolicy;
class Listeners;
class Literal;
class LearntClause;
class ReasonManager;

#include "Trail.h"
#include "Conflict.h"
#include <vector>
#include <algorithm>

class Solve {
public:
	Solve(Trail &, ConstraintManager &, ReasonManager &);
	enum Answer { UNSAT, SAT, UNKNOWN };
	Answer solve();
	void addListener(Listeners *listener) { _listeners.push_back(listener); }
	void removeListener(Listeners *listener) {
		_listeners.erase(std::find(_listeners.begin(), _listeners.end(), listener));
	}
	LiteralSelectionPolicy *setLiteralSelectionPolicy(LiteralSelectionPolicy *pol) {
		LiteralSelectionPolicy *old = _literalSelectionPolicy;
		_literalSelectionPolicy = pol;
		return old;
	}
	RestartPolicy *setRestartPolicy(RestartPolicy *pol) {
		RestartPolicy *old = _restartPolicy;
		_restartPolicy = pol;
		return old;
	}
	ForgetPolicy *setForgetPolicy(ForgetPolicy *pol) {
		ForgetPolicy *old = _forgetPolicy;
		_forgetPolicy = pol;
		return old;
	}
	StopPolicy *setStopPolicy(StopPolicy *pol) {
		StopPolicy *old = _stopPolicy;
		_stopPolicy = pol;
		return old;
	}

private:
	void applyExhaustiveUnitPropagation();
	void applyConflictHandling();
	void applyDecide();
	bool applyUnitPropagation();
	void applyRestart();
	void applyForget();

	void assertLiteral(Literal, bool);
	void applyBackjump(LearntClause2 *);
	
	void backtrackToLevel(size_t);
	void backtrack();
	
	bool isConflict() const { return _conflict != 0; }

	void checkSymmetry();
	
	Answer _sat_flag;
	Trail &_trail;
	ConstraintManager &_watches;
	ReasonManager &_reasons;
	Conflict _conflictHandler;
	Constraint *_conflict;
	LiteralSelectionPolicy *_literalSelectionPolicy;
	RestartPolicy *_restartPolicy;
	ForgetPolicy *_forgetPolicy;
	StopPolicy *_stopPolicy;
	
	std::vector<Listeners *> _listeners;
};

#endif
