/*
 *  Policies.h
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _POLICIES_H__
#define _POLICIES_H__ 1

#include "Literal.h"
#include "ConstraintManager.h"

class LiteralSelectionPolicy {
public:
	virtual bool done() { return false; }
	virtual Literal select() { return Literal(0); }
};

class RestartPolicy {
public:
	virtual bool restart() { return false; }
};

class ForgetPolicy {
public:
	virtual bool forget() { return false; }
	virtual ConstraintManager::iterator select(ConstraintManager::iterator, ConstraintManager::iterator end) { return end; }
};

class StopPolicy {
public:
	virtual bool stop() { return false; }
};
#endif
