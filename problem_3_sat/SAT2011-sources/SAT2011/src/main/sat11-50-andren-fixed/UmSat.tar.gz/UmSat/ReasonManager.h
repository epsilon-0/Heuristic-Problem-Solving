/*
 *  ReasonManager.h
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-31.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _REASONMANAGER_H__
#define _REASONMANAGER_H__

#include "Literal.h"
#include <map>

#include <iostream>

#ifndef NDEBUG
#define DEBUG 0
#endif

class Constraint;

class ReasonManager {
public:
	void resize(size_t numVars) { _reasons.resize(2*(numVars+1), 0); }
	void setReason(Literal lit, Constraint *cons) {
#if DEBUG >= 10
		std::cerr << "Reason for " << lit << " is ";
		if(cons) std::cerr << cons;
		else std::cerr << "None";
		std::cerr << std::endl;
#endif
		_reasons[lit.index()] = cons; 
	}
	Constraint *getReason(Literal lit) const { return _reasons[lit.index()]; }
private:
	std::vector<Constraint*> _reasons;
};

#endif
