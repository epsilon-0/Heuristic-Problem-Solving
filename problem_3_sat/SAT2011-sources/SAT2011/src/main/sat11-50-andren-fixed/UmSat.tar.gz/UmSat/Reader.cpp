/*
 *  reader.cpp
 *  UmSAT
 *
 *  Created by Daniel Andrén on 2010-04-21.
 *  Copyright 2010 Umeå univeritet. All rights reserved.
 *
 */

#include <boost/tokenizer.hpp>
#include <boost/lexical_cast.hpp>
#include <iostream>
#include "Reader.h"

typedef boost::tokenizer<boost::char_separator<char>, std::istream_iterator<char> > tokenizer;

PreClause Reader::read_vector(tokenizer::const_iterator &toki, tokenizer::const_iterator end) {
	PreClause constraint;
	while(toki != end) {
		if(*toki == "\n") { ++lineNo; ++toki; continue; }
		int var = boost::lexical_cast<int>(*toki++);
		if(var == 0) return constraint;
		constraint.push_back(var);
	}
	return constraint;
}

static void skip_to(std::string str, tokenizer::const_iterator &toki, tokenizer::const_iterator end) {
	while(toki != end && *toki != str) {
		++toki;
	}
	if(toki != end && *toki == str) ++toki;
}

TypeProblemPair Reader::doRead() {
	boost::char_separator<char> sep(" \t","\n");
	tokenizer tokens(_instream, std::istream_iterator<char> (),sep);
	
	TypeProblemPair constraints;
	tokenizer::const_iterator toki = tokens.begin();
	while(toki != tokens.end()) {
		if(*toki == "\n") { ++lineNo; ++toki; continue; }
		if(*toki == "p") {
			++toki; // skip "p"
			if(toki != tokens.end())
				constraints.type() = *toki;
			skip_to("\n", toki, tokens.end());
			++lineNo;
			continue;
		}
		if(*toki == "c") {
			skip_to("\n", toki, tokens.end()); 
			++lineNo;
			continue;
		}
		try {
			PreClause constraint = read_vector(toki, tokens.end());
			constraints.push_back(constraint);
		} catch(boost::bad_lexical_cast &) {
			std::cerr << lineNo << ":Bad cast! '" << *toki << "'" << std::endl;
			skip_to("0", toki, tokens.end());
		}
	}
	return constraints;
}
