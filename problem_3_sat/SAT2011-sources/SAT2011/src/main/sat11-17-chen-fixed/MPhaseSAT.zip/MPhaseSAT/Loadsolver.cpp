// Copyright (c) 2010, Jingchao Chen, Donghua University,China.  All rights reserved.

#include <stdio.h>
#include <ctype.h>
#include "constants.h"
#include "precosatXOR.h"

int  pre_height;
extern int numatom;

extern int *StackLit;
extern int *fixedvar;
extern int originClauses;
extern int *AMOvar;
extern int ClsVarRate;
extern bool localfind;
extern bool crypto_Gss;

bool glueSolveType;
extern bool on_the_fly;

using namespace PrecoSat;

extern Stack<int> *BinCls; // binary clauses 
extern int *key_lit;
extern int RealNumVars;              // the real number of atoms
int sortkey(int *keyvar,int *VarWeight);
extern int *unit;
extern int *candidate;

bool parity (unsigned x)
{ bool res = false; while (x) res = !res, x &= x-1; 
    return res; 
}
int newVars(int **clsLit, int numXor)
{
    int nVar=numatom;
    int i;

    for (i = 0; i < numXor; i++){
  		int xor_size=clsLit[i+1]-clsLit[i];
		if(xor_size<=4) continue;
		nVar+=(xor_size/2)-1;
     }
	if(nVar!=numatom){
		fixedvar=(int *)realloc(fixedvar, sizeof(int)*(nVar+1));
		for(i=numatom+1; i<=nVar; i++) fixedvar[i]=0;
		if(AMOvar){
	         AMOvar=(int *)realloc(AMOvar, sizeof(int)*(nVar+1));
			 for(i=numatom+1; i<=nVar; i++) AMOvar[i]=0;
		}
	}
	return nVar;
}
int loadclause(Solver *solver, intpp & clsLit,int & numCls, int & numXor,bool binClause)
{  int i;
   solver->candidateVar=candidate;
   if(binClause){
	   for(i=2; i<2*numatom+2; i++){
		  int last=BinCls[i];
		  if(fixedvar[i/2]) continue;
		  for(int j=0; j<last; j++){  // A V B (A<B) ?
		     int other=BinCls[i][j];
			 if(i>=other) continue; 
		     if(fixedvar[other/2]) continue;
		 	 solver->add_lit2(i);
		     solver->add_lit2(other);
		     solver->import(); // add a CNF
		  }
	   }
   }
  
   int *litbuf=(int *) malloc( sizeof(int) *(200));
//CNF clause   
    int endClsNo=numXor+numCls;	
    int CNFlen,j;
    for(i=numXor; i<endClsNo; i++){
		if(binClause){
			  if(clsLit[i+1]-clsLit[i]==2) continue;
		}
		int cls_size=clsLit[i+1]-clsLit[i];
	    if(cls_size>200) litbuf=(int *)realloc(litbuf, sizeof(int)*cls_size);
		CNFlen=0;
		for(j=0; j<cls_size; j++){
             int lit=clsLit[i][j];
			 int vv=ABS(lit);
			 if(fixedvar[vv]==0)  litbuf[CNFlen++]=lit;
			 else if(fixedvar[vv]==lit) goto nextCNF;
		 }
    	 for(j=0; j<CNFlen; j++){// var -> 2*var   -var-> 2*var+1
			 int lit=litbuf[j];
			 solver->add_lit2(lit2posLit(lit));
		 }
		 solver->import(); // add a CNF
nextCNF:   ;   
	}
//XOR clause
    int nVar=numatom+1;
  	for (i = 0; i < numXor; i++){
  		unsigned int j;
		int value,xorlen,xor_size=clsLit[i+1]-clsLit[i];
        if(xor_size>200) litbuf=(int *)realloc(litbuf, sizeof(int)*xor_size);
		xorlen=value=0;
	  	for(j=0; j<(unsigned)xor_size; j++){
             int lit=clsLit[i][j];
             int vv=ABS(lit);
			 if(fixedvar[vv]==0)  litbuf[xorlen++]=lit;
			 else if(fixedvar[vv]==lit) value=value^1;
		}	 
        if(xorlen==0){
			if(value) continue;
        	free(litbuf);
			return UNSAT;
		}
		if(value) litbuf[0]=-litbuf[0]; 
		int size;
		int xbuf[10];
		for(int pos=0; pos<xorlen; pos+=size){
	     	if(xorlen<=4) size=xorlen;
			else{
				if(pos+3>=xorlen) size=xorlen-pos;
			    else size=2;
			}
			int xs;
			for(xs=0;xs<size; xs++) xbuf[xs]=litbuf[pos+xs];
			if(pos) {
				xbuf[xs++]=nVar;
            	nVar++;
			}
			if(size!=xorlen-pos) xbuf[xs++]=-nVar;
			unsigned pow2=1<<xs;
	//		printf("\n pow2=%d ",pow2);
//			for(j=0; j<xs; j++) printf("%d ", xbuf[j]);
			for(j=0; j<pow2; j++){ // XOR -> CNF
		   	   if(parity(j)) continue;
           	   unsigned bits=j;
       		   for(int k=0; k<xs; k++) {
				    int lit=xbuf[k];
					if(bits & 1) lit=-lit;
	                solver->add_lit2(lit2posLit(lit));
					bits=bits>>1;
			   }
		       solver->import(); // add a CNF
			}
		}
	}
	free(litbuf);
	return UNKNOWN;
}

extern int *mapvar;

int assignSolution(Solver *solver, int result, int *solution, bool map)
{
     if (result > 0) {
         //if (!solver->satisfied()) { //bug ???
         //    printf ("c ERROR\n");
         //    abort ();
		 //}
		 //printf("c SATISFIABLE ????\n");
	     for (int i = 1; i <= numatom; i++) {
			 int lit=(solver->val2 (2 * i) < 0) ? -i : i;
			 if(!map){
				   if(solution[i]==0) solution[i]=lit;
			 }
			 else{
				 int var=mapvar[i-1];
				 if(lit<0) solution[var]=-var;
				 else solution[var]=var;
			 }
	   }
       delete solver;
       return SAT;
  } 
  delete solver;
  if (result < 0) return UNSAT;
  return UNKNOWN;
}

int Loadbigsolver(int decision_limit,int ** & clsLit, int numCls, bool vmap)
{ 
	printf("c A large instance  \n");
	Solver *solver=new Solver(numatom);
//optimal option
    solver->set ("order", 3);
    solver->set ("maxlimit", 100000);
    solver->fxopts();
    solver->maxDepth=0;
	
	if(AMOvar){
	     free(AMOvar);
	     AMOvar=0;
	}

	int newn=0;
    int *base=clsLit[0];
	int total=clsLit[numCls]-clsLit[0];
	for(int i=numCls; i>0; i--){
	    int size=clsLit[i]-clsLit[i-1];
	   	int *pv=base+(clsLit[i-1]-clsLit[0]);
		for(int j=0; j<size; j++){
			int lit=*(pv+j);
			solver->add_lit2(lit2posLit(lit));
		}
    	solver->import(); // add a CNF
		int nowSize=clsLit[i]-clsLit[0];
		if(nowSize<total-10000 && i>10) {
			base=(int *)realloc(base, sizeof(int)*nowSize);
	        total=nowSize;
		}
		newn++;
	}
	free(base);
	free(clsLit);
    clsLit=0;
   	int res = solver->solve(decision_limit);
    return assignSolution(solver, res,unit,vmap);
}

extern char *FileName;

int Loadsolver_end(intpp & clsLit, int & numCls, int & numXor,int *RankVar)
{   int i;
    bool change_IUP_to_JWHS=false;
repeat:
    int nVar=newVars(clsLit,numXor);
	Solver *solver=new Solver(nVar);
//optimal option
	solver->set ("order", 3);
	int limit=(numCls/5)*2;
    if(numXor>0){
		if(limit<10000) limit=10000;  //SHA 
	}
	else if(limit<30000) limit=30000; 
    solver->set ("maxlimit", limit);
  
	solver->fxopts();
	solver->RankVar=RankVar;
	solver->maxDepth=11; 
  
	int rc=loadclause(solver, clsLit, numCls, numXor,true);
    if(rc==UNSAT){
	      delete solver;
  	      return UNSAT;
	}
	if(change_IUP_to_JWHS){
          change_IUP_to_JWHS=false;
		  solver->phase_type=JWHS; 
		  if(originClauses==210223)  solver->randpick=true;
		  goto	ptype;
	}
    solver->phase_type=HALF_IUP;
    if(numXor){
		if(numXor>2000){
			if(numXor>numatom/14) solver->phase_type=JWHS; 
			if(numXor>numCls/12) {
				if(numatom<15000) {
					solver->phase_type=IUP; 
				    change_IUP_to_JWHS=true;
					if(originClauses==210223) {
						solver->randpick=true; 
					}
		        }
				else solver->phase_type=JWHS; 
			}
		}
		else {
			if(numXor<1000 && numCls>300000) solver->phase_type=JWHS; 
        }
		if(glueSolveType) {
			solver->phase_type=IUP; 
			solver->sub_phase=true;
		}
		if(numXor<700 && numXor/2<solver->stats.clauses.bin && ClsVarRate<8){
	       	 solver->halfphaseLearning=true;
             solver->phase_type=JWHS;
		}
   	}
	else{
		  if(ClsVarRate<6 && solver->stats.clauses.irr/15>numatom){
		        if((solver->stats.clauses.irr/3)*2<solver->stats.clauses.bin) solver->phase_type=JWHS;
		   }
		  if(ClsVarRate>100 && numatom<1500){ 
	        	solver->halfphaseLearning=true;
                solver->phase_type=JWHS;
		  }
		  if(solver->stats.clauses.irr<(solver->stats.clauses.bin/9)*10 && ClsVarRate>55){ 
	        	solver->halfphaseLearning=true;
                solver->phase_type=JWHS;
		  }
          if(solver->stats.clauses.irr>900000 && numatom<80000 && ClsVarRate<6){
	             solver->phase_type=JWHS;
		  }
	}
ptype:
	printf("c solve by multiple heuristics \n");
//	switch(solver->phase_type){
//	  case JWHS: 	printf("c phase_type=JWHS \n"); break;
//	  case IUP: 	printf("c phase_type=IUP \n"); break;
//	  case HALF_IUP: printf("c phase_type=HALF_IUP \n");
//	}

	if(!change_IUP_to_JWHS){
		for (i= 2; i<2*numatom+2; i++) BinCls[i].release(); //bug (mem);
        free(BinCls);
        BinCls=0;
	}
    int res =0;
	int cand2[2]={0};
    solver->candidateVar=cand2;
    int decision_limit;
 
	int bins=solver->stats.clauses.bin;
	solver->BinAddLimit=bins+bins/3;
	if(solver->BinAddLimit<800000) solver->BinAddLimit=800000;
 	if(originClauses>3000000) goto nopre;
 
	for(i=0; i<1 && res==0; i++){
          int candp=0;
          while(res==0){
		  if(candidate[candp]==0) break;
          solver->candidateVar=candidate+candp;
		  solver->undo(0);
    	  solver->Initialize();
          if(candp || i) decision_limit=20000;
		  else 	decision_limit=200000;
		  res=solver->solve(decision_limit);
		  while(candidate[candp]) candp++;
		  candp++;
	   }
	}
nopre:
    if(res==0){
	      if(change_IUP_to_JWHS) decision_limit=1500000;
		  else  decision_limit=0x7fffffff;
		  solver->candidateVar=cand2;
		  solver->undo(0);
          solver->Initialize();
		  res=solver->solve(decision_limit);
  		  if(res==0) {
              delete solver;
              if(change_IUP_to_JWHS) goto repeat;
			  return UNKNOWN;
		  }
	}
    return assignSolution(solver, res,fixedvar,false);
}

int Loadsolver(int decision_limit,int **clsLit, int numCls, int numXor,int unit_sp,int *RankVar,bool loadbin)
{ 
    int nVar=newVars(clsLit,numXor);
	Solver *solver=new Solver(nVar);
//optimal option
    solver->set ("order", 3);
	int limit=(numCls/5)*2;
	if(limit<30000) limit=30000; 
    solver->set ("maxlimit", limit);
  
  	solver->fxopts();
    solver->RankVar=RankVar;
	if(decision_limit<=5000) solver->phase_type=JWHS;
    else solver->phase_type=IUP;
    
    solver->sub_phase=true;
	if(crypto_Gss) solver->phase_type=JWHS;
//unit clause;
	for(int i=0; i<unit_sp; i++){
		  int lit=StackLit[i]; 
		  solver->add_lit2(lit2posLit(lit)); 
		  solver->add_lit2(0);
	}
    int rc=loadclause(solver, clsLit, numCls, numXor,loadbin);
  	if(rc==UNSAT){
		 delete solver;
  	     return UNSAT;
	}
	if(solver->stats.clauses.irr>110000 && originClauses<90000){ 
			solver->phase_type=JWHS;
    }
    int cand2[2]={0};
    solver->maxDepth=0; 
    solver->candidateVar=cand2;
   	int	res = solver->solve(decision_limit);
    return assignSolution(solver, res,fixedvar,false);
}

int preLoadsolver(intpp & clsLit, int & numCls)
{ 
    int decision_limit,numXor;
	bool re_solve=false;
retry:
	Solver *solver=new Solver(numatom);
//optimal option
	solver->set ("order", 3);
	int maxnum=numCls/3;
	if(maxnum<30000) maxnum=30000;
    solver->set ("maxlimit", maxnum);
  
	solver->set("block", 0); // false block
    if(re_solve) solver->set ("block", 1); // true block
	solver->fxopts();
	solver->RankVar=0;
	solver->maxDepth=0;
	
	printf("c phase 1 \n");

	bool binClause=false;
	numXor=0;
	int rc=loadclause(solver, clsLit, numCls, numXor,binClause);
    if(rc==UNSAT){
		 delete solver;
  	     return UNSAT;
	}
    int res =0;
	int cand2[2]={0};
    solver->candidateVar=cand2;
    solver->Initialize();
    if(numCls>50000 && numCls<220000 && (numatom<40000 || originClauses==210223)){
		solver->randpick=true; 
    }
    solver->extendLimit=numCls>100000;
	if(solver->extendLimit) decision_limit=600000; //1200000;
	else decision_limit=200000;	

	int bins=solver->stats.clauses.bin;
	solver->BinAddLimit=bins+bins/3;
	if(solver->BinAddLimit<800000) solver->BinAddLimit=800000;
    else{  
        if(bins>(numCls/5)*3 && numatom>numCls/4){
			  solver->extendLimit=false;
              solver->BinAddLimit=700000;
	          decision_limit=50000;
		}
		else{
			if(bins<1000000 && numCls>1200000) solver->BinAddLimit=(bins/10)*4; 
			if(bins>800000){
				decision_limit=(bins/5)*4;
			}
		}
	}
    if(bins>1500000){
		if(numatom<numCls/20) {
			solver->BinAddLimit=bins+bins/5;
			decision_limit=bins;
   		}
	}
	if(ClsVarRate>21 && ClsVarRate<28 && numatom<12000)	decision_limit=2000000;	
   	if(numCls<18000) solver->phase_type=IUP;
	if(re_solve){
		decision_limit=0x7fffffff;
		solver->extendLimit=false;
    }
	res=solver->solve(decision_limit);
//out:
	pre_height=0;
 	if(res==0){
		solver->undo(0);
		solver->extendLimit=false;
		if(solver->stats.decisions)	pre_height=(int)(solver->stats.sumheight/(double)solver->stats.decisions);
//      printf("c height=%d \n", pre_height);
//		getchar();
		if(!re_solve){
			if(pre_height>2000 || (pre_height>95 && pre_height<180 && ClsVarRate<3 && solver->remvars()<8000)) {
			    delete solver;
		     	re_solve=true;
			    goto retry;
			}
		}
	   	bool continue_solve=false;
		if(pre_height>390 && solver->remvars()<80000){
			if(numCls>1000000) continue_solve=true; 
		}
//	    printf("c numCls=%d \n",numCls);
		if(pre_height<17 && numatom<800 && numatom>600 && ClsVarRate==12) continue_solve=true; 
		if(((numCls>10000 && numCls<18000) || (numCls<10000 && originClauses>12000)) && pre_height ){ 
			if(numatom >2500 && pre_height<29 && solver->remvars()<2000) continue_solve=true; 
			if(pre_height<17 && numatom >1000) continue_solve=true; 
	//	    printf("c continue_solve=%d \n",continue_solve);
		}
		if(continue_solve){
			    solver->set ("block", 1); // true block
				decision_limit=0x7fffffff;
			    localfind=false;
		        if(pre_height>380 && numatom<27000 && ClsVarRate<15) localfind=true;
				if(solver->agility >1900000 && pre_height<17 && originClauses<70000) solver->hybridpolicy=true;
				res=solver->solve(decision_limit);
		}
		if(res==0){
			bool xorcopy=false;
		    int *elimCls;
		    solver->OutputClause(clsLit, numCls, numXor,fixedvar,(int *)0, elimCls,xorcopy);
    	    glueSolveType=false;
	        if(bins>400000 && bins>numCls/2){
			    if(numatom/20 > solver->remvars()) glueSolveType=true;
			}
		    delete solver;
		    return UNKNOWN;
		}
	}
    return assignSolution(solver, res,fixedvar,false);
}

int Loadsolver(intpp & clsLit, int & numCls, int & numXor,int *RankVar)
{ 
    int i,decision_limit;
 
	int nVar=newVars(clsLit,numXor);
	Solver *solver=new Solver(nVar);
//optimal option
	solver->set ("order", 3);
	int limit=(numCls/5)*2;
	if(limit<30000) limit=30000; 
    solver->set ("maxlimit", limit);
    
	if(localfind) printf("c local search on \n");
	else printf("c local search off \n");

	solver->fxopts();
	solver->RankVar=RankVar;
	solver->maxDepth=0;
	
	int rc=loadclause(solver, clsLit, numCls, numXor,true);
    if(rc==UNSAT){
		 delete solver;
  	     return UNSAT;
	}
//unit clause;
    for(i=1; i<=numatom; i++){
          if(fixedvar[i]==0) continue; 
		  solver->add_lit2(lit2posLit(fixedvar[i])); 
		  solver->add_lit2(0);
	}  
    int res =0;
	int cand2[2]={0};
    solver->candidateVar=cand2;
    solver->Initialize();
  
	if(on_the_fly && originClauses<1000){
    	solver->phase_type=JWHS;
		goto no_pre;
	}
 	if(numatom<1000) solver->phase_type=JWHS;
	else solver->phase_type=IUP;
	decision_limit=30000;
    res=solver->solve(decision_limit);

	if(ClsVarRate>5000) solver->phase_type=JWHS; 
    else solver->phase_type=IUP;

	if(res==0){
		cand2[0]=0;
        solver->candidateVar=cand2;
        solver->Initialize();
	    decision_limit=30000;//50000;
        res=solver->solve(decision_limit);
	}
	if(localfind) goto no_pre;

	solver->maxDepth=1;
    for(i=0; i<1 && res==0; i++){
       int candp=0;
       while(res==0){
		  if(candidate[candp]==0) break;
          solver->candidateVar=candidate+candp;
		  solver->undo(0);
		  solver->Initialize();
          if(candp || i) decision_limit=10000;    //2000, 10000;
		  else 	decision_limit=5000;
		  res=solver->solve(decision_limit);
		  while(candidate[candp]) candp++;
		  candp++;
	   }
	}
    if(res==0){
       	cand2[0]=0;
     	if(numatom<5000 && numCls<20000) decision_limit=30000;
		else decision_limit=100000;
	  	solver->candidateVar=cand2;
        solver->Initialize();
	    res=solver->solve(decision_limit);
	}
no_pre:
    if(res==0){
	    solver->maxDepth=0; 
	    cand2[0]=0;
   		int height;
   	  	if(solver->stats.decisions) height=(int)(solver->stats.sumheight/(double)solver->stats.decisions);
        else height=0;
       // if(height<14 || ((originClauses>1000 && height<29) && !on_the_fly)){
	    if(height<14 || ((originClauses>1000 && originClauses<30000 && height<24) && !on_the_fly)){
			solver->hybridpolicy=true; 
  		}
		if(height<20 && originClauses<6000) {
			solver->hybridpolicy=true;
			if(on_the_fly && height<9) { 
		     	solver->phase_type=JWHS;
				solver->hybridpolicy=false; 
			}
		}
		if(height<13 && solver->stats.clauses.irr>30000) {
			if(solver->agility < 2500000 ){
				solver->hybridpolicy=false; 
		    	solver->phase_type=IUP;
			}
		}
		if(solver->agility <2000000) {
			solver->hybridpolicy=false;
		   	solver->phase_type=JWHS;
			if(originClauses<23000) solver->phase_type=IUP;
	    }
		if(solver->agility > 3500000 && height<21) solver->hybridpolicy=true; 
		
		printf("c height=%d age=%d \n",height,solver->agility/100000);

		if(localfind){
			if(height<33 && numatom<1000 && solver->agility >2500000) solver->hybridpolicy=true;
		}
		if(originClauses<600 && height<30) solver->hybridpolicy=true;
    	if(originClauses<10000 && height<16 && numatom<2500 && solver->agility >1700000) solver->hybridpolicy=true;
	    if(height<8 && originClauses<2000 && numatom<500 && on_the_fly) solver->hybridpolicy=false; 
	    if(ClsVarRate>100 && numatom<200 && height<13) solver->hybridpolicy=false;
	   	res=0;
		if(solver->hybridpolicy && !localfind){
			if(numatom<340 && originClauses<3000){
		     	decision_limit=1000000;
	    	    solver->Initialize();
				solver->hybridpolicy=false;
   		        res = solver->solve(decision_limit);
				solver->hybridpolicy=true;
			}
		}
		if(res==0){
       		decision_limit=0x7fffffff;
		    solver->Initialize();
   	        solver->subsolve=true;
		    res = solver->solve(decision_limit);
		}
	}
//out:    
	if(res==0){
       	delete solver;
       	return UNKNOWN;
	}
    return assignSolution(solver, res,fixedvar,false);
}
