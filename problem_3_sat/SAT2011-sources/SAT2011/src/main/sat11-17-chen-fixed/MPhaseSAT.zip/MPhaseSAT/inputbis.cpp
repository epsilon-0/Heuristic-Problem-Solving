#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>
#include "Multiflip.h"

extern int numatom;     // var #
extern int numClauses;  // clause #
extern my_type *clause_state;

extern int **sat;
extern int **Clit;
extern my_type *var_state;

extern int MY_CLAUSE_STACK_fill_pointer;
extern int *neg_nb;
extern int *pos_nb;
extern int **neg_in;
extern int **pos_in;
extern my_type *var_value;

void allocMem();
void readSATProblem(char *CNFfile, bool readlarge);
void set_clauses()
{
   sat=Clit;
   allocMem();
   for (int i=0; i<numClauses; i++) clause_state[i] = ACTIVE;
   return;
}

void build_structure()
{
  int i, j, var, lit;

  for (i=0; i<=numatom; i++) neg_nb[i] =pos_nb[i] = 0;
  for (i=0; i<numClauses; i++) {
      int len=sat[i+1]-sat[i];
	  for(j=0; j<len; j++) {
	       var=sat[i][j]; 
		   if (var<0) neg_nb[-var]++;    //negative literal
		   else  pos_nb[var]++;    	   //positive literal
	  }
  }
  for (i=1; i<=numatom; i++) { 
      neg_in[i] = (int *)malloc((neg_nb[i]+1) * sizeof(int));
      pos_in[i] = (int *)malloc((pos_nb[i]+1) * sizeof(int));
      neg_in[i][neg_nb[i]]=pos_in[i][pos_nb[i]]=NOnum;
      neg_nb[i] = pos_nb[i] = 0;
      var_value[i]=0;
	  var_state[i] = ACTIVE;
 
  }   
  for (i=0; i<numClauses; i++) {
    int len = sat[i+1]-sat[i];
    for(j=0; j<len; j++) {
      lit=sat[i][j];
	  if (lit>0) pos_in[lit][pos_nb[lit]++] = i;
      else	neg_in[-lit][neg_nb[-lit]++] = i;
    }
  }
}
