#ifndef MULTIFLIP_DEFINED 
#define MULTIFLIP_DEFINED 

typedef signed int my_type;
typedef unsigned int my_unsigned_type;

#define OLD_CLAUSE_REDUNDANT -77
#define NEW_CLAUSE_REDUNDANT -7

#define WORD_LENGTH 100 
#define TRUE 1
#define FALSE 0

#define SATISFIABLE 2
#define UNSATISFIABLE -1

#define NOnum -1

#define NEGATIVE 0
#define POSITIVE 1
#define PASSIVE 0
#define ACTIVE 1

#define walk_satisfiable() (MY_CLAUSE_STACK_fill_pointer == 0)

//#define ABS(x) ((x)>0 ? (x):(-x))

#define pop(stack) stack[--stack ## _fill_pointer]
#define push(item, stack) stack[stack ## _fill_pointer++] = item


#endif
