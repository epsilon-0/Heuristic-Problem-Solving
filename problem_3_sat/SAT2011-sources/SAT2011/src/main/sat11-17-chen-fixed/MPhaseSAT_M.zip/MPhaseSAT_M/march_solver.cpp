
//#define ADD_CONFLICT
//#define BACKJUMP

//#define LOCAL_AUTARKY

#define COMPENSATION_RESOLVENTS
#define SAT_INCREASE	1000
#define CONTINUE	1
#define FINISHED	0

#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <time.h>

#include "march_common.h"
#include "march_extvar.h"

int previousCount;
int prev_local_count;
int march_solve_rec();
void backtrack();
void MainDead( int *__rstackp );
int DPLL_propagate_binary_equivalence( const int bieq );
inline int DPLL_update_datastructures( const int nrval );
void remove_satisfied_implications( const int nrval );
int DPLL_add_binary_implications( int lit1, int lit2 );
void restore_implication_arrays   ( const int nrval );

void init_direction();
int init_new_record();
void mark_complement_of_literals( int clsidx );
int count_clashing_literals( int clsidx, int mark );
int is_subsumed( const int clsidx1, const int clsidx2 );
void print_components( const int nrofcomponents );
void remove_blocked_clauses( );
void check_blocking_literal( int nrval );

int fix_recorded_literals( int record_index );
void record_node( const int record_index, int branch_literal, const int skip_left, const int skip_right );
void check_forced_array_capacity();
void set_recorded_literals( int record_index );
void get_recorded_literals( int **_forced_literal_array, int *_forced_literals );

void get_forced_literals( int **_forced_literal_array, int *_forced_literals );
int  get_signedBranchVariable( );

void init_lookahead();
void dispose_lookahead();
int lookahead();

void init_freevars();
void dispose_freevars();
void reduce_freevars( int nrval );

void ConstructPreselectedSet( );
int ConstructCandidatesSet( );
int PreselectAll( );

int count_edges( const int graph_flag );
void fixDependedEquivalences();
int dependantsExists(); 
void fixEq( int nr, int pos, int value );

void free_big_clauses_datastructures();
void allocateVc( int ***__Vc, int ***__VcLUT );
void freeVc( int **__Vc, int **__VcLUT );
void rebuild_BinaryImp( );
void free_BinaryImp( );

void init_preselection( );
void dispose_preselection( );

int verifySolution();
int checkSolution();

#define IS_REDUCED_TIMP( __a, __b )	((timeAssignments[__a] < NARY_MAX) && (timeAssignments[__b] == (NARY_MAX+1)) )

#ifdef DISTRIBUTION
  #define LEFT_CHILD	 records[record_index].child[branch_literal > 0]
  #define RIGHT_CHILD	 records[record_index].child[branch_literal < 0]
#endif

int *tmpEqImpSize;

int *TernaryImpTable, *TernaryImpLast;
int current_bImp_stamp, *bImp_stamps;

int *newbistack, *newbistackp, newbistackSize;
int *substack,   *substackp,   substackSize;

int analyze_autarky();

int nrofforced;

int *autarky_level;

void reset_doublelook_pointers();
int DL_treelook( int nrval );

//unsigned long long solution_bin = 0;
uint64 solution_bin = 0;
unsigned int solution_bits = 63;

#ifdef DISTRIBUTION
float first_time;
int skip_flag = 0, first_depth = 20;
#endif
#ifdef SUBTREE_SIZE
int path_length;
#endif
#ifdef PLOT
int plotCount = 0;
#endif
#ifdef CUT_OFF
int last_SAT_bin = -1;
#endif
#ifdef BACKJUMP
int backjump_literal = 0;
#endif

int currentNodeNumber = 1, UNSATflag = 0;

#define STAMP_IMPLICATIONS( _nrval ) \
{ \
    bImp = BIMP_START(_nrval); \
    current_bImp_stamp++; \
    bImp_stamps[ _nrval ] = current_bImp_stamp; \
    for (i = BIMP_ELEMENTS; --i; ) \
	bImp_stamps[ *(bImp++) ] = current_bImp_stamp; \
}

inline void push_stack_blocks( )
{ 
	PUSH( r, STACK_BLOCK ); 
	PUSH( imp, STACK_BLOCK ); 
        PUSH( bieq, STACK_BLOCK ); 
        PUSH( subsume, STACK_BLOCK ); 
	current_node_stamp++;
}

#ifdef PROGRESS_BAR
#define NODE_START( ) \
{ \
	push_stack_blocks( ); \
	pb_descend( ); \
}
#define NODE_END( ) \
{ \
	backtrack(); \
	pb_climb(); \
}
#else
#define NODE_START( ) \
{ \
	push_stack_blocks( ); \
}
#define NODE_END( ) \
{ \
	backtrack(); \
}
#endif \

unsigned int current_record;
struct record *records;

extern int *StackLit;
extern int **Clit;
extern int *key_lit;
extern int numClauses;
int Loadsolver(int decision_limit,int **clsLit, int numCls, int numXor,int usp,int *RankVar,bool loadbin,int * & solution);
extern int *subsolution;
extern int main_SAT,main_UNSAT;
/*
int DPLL_solver(int * & localsolution)
{
	int i,up;
	printf("c CDCL \n");
    up=0;
	for( i = 1; i <= original_nrofvars; i++ ){
		if(IS_FIXED(i)){
			if(FIXED_ON_COMPLEMENT(i)) StackLit[up]=-i;
			else StackLit[up]=i;
			//printf("%d ",StackLit[up]);
			up++;
		}
	}
    int rc=Loadsolver(100000, Clit, numClauses, 0, up, key_lit, false, localsolution);
	return rc;
}
*/
extern int local_find_tries, local_find_steps; 
extern bool localfind;
void  getlocalsolution(int *solution);
int Local_search(int &tries,int & steps);
extern bool goodsolution;
inline int recursive_solve( ) 
{ 
	int _result = 0;

	PUSH( r, STACK_BLOCK ); 

    if(localfind && depth==10){
		  static int local_cnt=0;
       	  if(nodeCount-prev_local_count>4000){
			  if(local_cnt<50 || (original_nrofvars<600 && local_cnt<100)){
			     local_cnt++;
		         int rc=Local_search(local_find_tries,local_find_steps);
		         if(rc==main_SAT){
				   getlocalsolution(subsolution);
			       goodsolution=true;
				   return SAT;
				 }
			  }
		  }
		  prev_local_count=nodeCount;
	}
	/*
	if(depth==10 && nodeCount>6000){
		//printf("\n previous=%d nodeCount=%d =%d ", previousCount, nodeCount,nodeCount-previousCount);
		static int DPLL_cnt=0;
		if(nodeCount-previousCount>16000 && DPLL_cnt<10){
		   previousCount=0;
		   bool save=localfind;
           localfind=false;
		   int rc=DPLL_solver(subsolution);
	       localfind=save;
           if(rc==main_SAT){
		        goodsolution=true;
			    return SAT;
		   }
  	       if(rc==main_UNSAT) return UNSAT;
		   DPLL_cnt++;
		   previousCount=nodeCount+120000;
		}
		else previousCount=nodeCount;
    } 
	else if(depth==10) previousCount=nodeCount;
    */
	depth++; 
	_result = march_solve_rec(); 
	depth--;
	return _result;
}

#define UPDATE_BIN( ) \
{\
    if( (unsigned)depth <= solution_bits ) solution_bin ^= (uint64) 1 << (solution_bits - depth); \
}

/*
	----------------------------------------------------
	------------[ initializing and freeing ]------------
	----------------------------------------------------
*/
void clearTernaryImpReduction( )
{
	int i;
	for( i = 1; i <= nrofvars; i++ )
	{
	    TernaryImpReduction[  i ] = 0;
	    TernaryImpReduction[ -i ] = 0;
	}
}

inline void fill_ternary_implication_arrays( )
{
	int i, j, lit;

        for( i = 0; i < nrofclauses; i++ )
	    if( Clength[ i ] == 3 )
	    {
                for( j = 0; j < 3; j++ )
                {
                   lit = Cv[i][j];
                   TernaryImp[lit][ tmpTernaryImpSize[lit]++ ] = Cv[i][(j+1)%3 ];
                   TernaryImp[lit][ tmpTernaryImpSize[lit]++ ] = Cv[i][(j+2)%3 ];
                }
	    }

        for( i = -nrofvars; i <= nrofvars; i++ )
	    TernaryImpSize[ i ] = tmpTernaryImpSize[ i ] / 2;	    
}

int initSolver()
{
	int i, j, _tmp;

	/* initialise global counters */

	current_node_stamp = 1;
	lookDead 	   = 0;
	mainDead 	   = 0;
	/* allocate recursion stack */
	/* tree is max. nrofvars deep and we thus have max. nrofvars STACK_BLOCKS
		 -> 2 * nrofvars should be enough for everyone :)
	*/
	INIT_ARRAY( r       , 3 * nrofvars + 1   );

	INIT_ARRAY( imp     , INITIAL_ARRAY_SIZE );
	INIT_ARRAY( subsume , INITIAL_ARRAY_SIZE );
	INIT_ARRAY( bieq    , INITIAL_ARRAY_SIZE );
	INIT_ARRAY( newbi   , INITIAL_ARRAY_SIZE );
	INIT_ARRAY( sub     , INITIAL_ARRAY_SIZE );

	MALLOC_OFFSET( bImp_satisfied, int, nrofvars, 2 );
	MALLOC_OFFSET( bImp_start,     int, nrofvars, 2 );
	MALLOC_OFFSET( bImp_stamps,    int, nrofvars, 0 );
	MALLOC_OFFSET( node_stamps, tstamp, nrofvars, 0 );

	init_lookahead();
	init_preselection();
#ifdef DISTRIBUTION
	init_direction();
#endif
	tmpTernaryImpSize = (int* ) malloc( sizeof(int ) * ( 2*nrofvars+1 ) );
#ifdef TERNARYLOOK
        TernaryImp 	  = (int**) malloc( sizeof(int*) * ( 2*nrofvars+1 ) );
        TernaryImpSize 	  = (int* ) malloc( sizeof(int ) * ( 2*nrofvars+1 ) );

        for( i = 0; i <= 2 * nrofvars; i++ )
	{
	    tmpTernaryImpSize[ i ] = 0;
	    TernaryImpSize   [ i ] = 0;
	}

	for( i = 0; i < nrofclauses; i++ )
	    if( Clength[ i ] == 3 )
		for( j = 0; j < 3; j++ )
		    TernaryImpSize[ Cv[ i ][ j ] + nrofvars ]++;

        for( i = 0; i <= 2 * nrofvars; i++ )
	    TernaryImp[ i ] = (int*) malloc(sizeof(int)*(4*TernaryImpSize[i]+4));

        tmpTernaryImpSize 	+= nrofvars;
        TernaryImp 		+= nrofvars;
	TernaryImpSize 		+= nrofvars;

	fill_ternary_implication_arrays();

        for( i = -nrofvars; i <= nrofvars; i++ )
//	    tmpTernaryImpSize[ i ] = 2 * tmpTernaryImpSize[ i ] + 2;	
	    tmpTernaryImpSize[ i ] = 4 * TernaryImpSize[ i ] + 2;	

//	branch_on_dummies_from_long_clauses();

	while( AddTernaryResolvents() );

        for( i = -nrofvars; i <= nrofvars; i++ )
	    free( TernaryImp[ i ] );

	FREE_OFFSET( TernaryImp     );
	FREE_OFFSET( TernaryImpSize );
#else
        tmpTernaryImpSize 	+= nrofvars;
#endif

// initialise global datastructures 

#ifdef GLOBAL_AUTARKY
	MALLOC_OFFSET( TernaryImpReduction, int, nrofvars, 0 );

	if( kSAT_flag )
	{
	    int _nrofliterals = 0;

	    for( i = 0; i < nrofbigclauses; ++i )
		_nrofliterals += clause_length[ i ];

	    clause_reduction = (int*)  malloc( sizeof(int ) * nrofbigclauses );
	    clause_red_depth = (int*)  malloc( sizeof(int ) * nrofbigclauses );
	    big_global_table = (int*)  malloc( sizeof(int ) * _nrofliterals );
	    clause_SAT_flag  = (int*)  malloc( sizeof(int ) * nrofbigclauses );

	    MALLOC_OFFSET( big_to_binary, int*, nrofvars, NULL );
	    MALLOC_OFFSET( btb_size,      int , nrofvars,    0 );

	    for( i = 0; i < nrofbigclauses; ++i )
	    {
		clause_reduction[ i ] =  0;
		clause_red_depth[ i ] =  nrofvars;
		clause_SAT_flag [ i ] =  0;
	    }

	    int tmp = 0;
            for( i = 1; i <= nrofvars; i++ )
            {
                big_to_binary[  i ] = (int*) &big_global_table[ tmp ];
                tmp += big_occ[  i ];

                big_to_binary[ -i ] = (int*) &big_global_table[ tmp ];
                tmp += big_occ[ -i ];

            }
	    assert( tmp == _nrofliterals );
	}
#endif
        TernaryImp 	= (int**) malloc( sizeof(int*) * ( 2*nrofvars+1 ) );
        TernaryImpSize 	= (int* ) malloc( sizeof(int ) * ( 2*nrofvars+1 ) );
        TernaryImpLast 	= (int* ) malloc( sizeof(int ) * ( 2*nrofvars+1 ) );
        TernaryImpTable	= (int* ) malloc( sizeof(int ) * ( 6*nrofclauses+1 ) );

	TernaryImp	       += nrofvars;
	TernaryImpSize	       += nrofvars;
	TernaryImpLast	       += nrofvars;

	if( simplify_formula() == UNSAT ) return UNSAT;

	for( i = -nrofvars; i <= nrofvars; i++ )
	{
	    tmpTernaryImpSize[ i ] = 0;
	    TernaryImpSize   [ i ] = 0;
	    bImp_satisfied   [ i ] = 2;	//waarom staat dit hier?
	}

	for( i = 0; i < nrofclauses; i++ )
	    if( Clength[ i ] == 3 )
		for( j = 0; j < 3; j++ )
		    TernaryImpSize[ Cv[ i ][ j ] ]++;

	_tmp = 0;
        for( i = -nrofvars; i <= nrofvars; i++ )
        {
	    TernaryImp[ i ]     = TernaryImpTable + 2 * _tmp;
            _tmp               += TernaryImpSize[ i ];
	    TernaryImpLast[ i ] = TernaryImpSize[ i ];
        }

	fill_ternary_implication_arrays();

	rebuild_BinaryImp();

	init_freevars();

	for( i = 0; i < nrofceq ; i++ )
	    assert( CeqSizes[ i ] != 1 );
#ifdef EQ
	for( i = 0; i < nrofceq ; i++ )	
	    if( CeqSizes[ i ] == 2 )
            	DPLL_propagate_binary_equivalence( i );
#endif

	autarky_level = (int*) malloc( sizeof(int) * (nrofvars+1) );
	tmpEqImpSize  = (int*) malloc( sizeof(int) * (nrofvars+1) );

#ifdef CUT_OFF
	solution_bits = CUT_OFF - 1;
#endif

	push_stack_blocks();
	return 1;
}

void disposeSolver()
{
	if( kSAT_flag ) free_big_clauses_datastructures();

        free_BinaryImp();

        dispose_lookahead();
        dispose_preselection();
        dispose_freevars();

        FREE_OFFSET( TernaryImp        );
        FREE_OFFSET( TernaryImpSize    );
        FREE_OFFSET( tmpTernaryImpSize );
        FREE_OFFSET( bImp_stamps       );
        FREE_OFFSET( bImp_satisfied    );
        FREE_OFFSET( node_stamps       );

        FREE( impstack );
        FREE( rstack );
}

int propagate_forced_literals()
{
	int _freevars = freevars;

	if( IFIUP( 0, FIX_FORCED_LITERALS ) == UNSAT )
	    return UNSAT;

	nrofforced = _freevars - freevars;
	percentage_forced = 100.0 * nrofforced / (double) _freevars;
	return SAT;
}

#ifdef DISTRIBUTION // naar distribution.c
int distribution_branching()
{
	int _result;

	target_rights  = 0;
	current_rights = 0;
	current_record = 0;
    previousCount  = 0;
    prev_local_count=0;

	first_time = (float) clock();
	do
	{
	    assert( target_rights <= jump_depth );
#ifdef SUBTREE_SIZE
	    path_length = 1;
#endif
	    _result = march_solve_rec();
	    if( _result != UNSAT ) return _result;
#ifndef CUT_OFF
	    pb_reset();
#endif
 		target_rights++;
	    current_record = 1;
	} while( records[1].UNSAT_flag == 0 );
	return UNSAT;
}
#endif

#ifdef DISTRIBUTION
int skip_node( )
{
	if( depth < jump_depth )
	    if( (target_rights < current_rights) || 
		(target_rights >= (current_rights + jump_depth - depth)) ) return 1;
	return 0;
}
#endif

int march_solve_rec()
{
	int branch_literal = 0, _result, _percentage_forced;
	int skip_left = 0, skip_right = 0, top_flag = 0;

#ifdef DISTRIBUTION
	int record_index = current_record;
	top_flag = TOP_OF_TREE;
	if( fix_recorded_literals(record_index) == UNSAT ) return UNSAT;
	if( record_index == 0 ) record_index = init_new_record( );
#endif

#ifdef SUBTREE_SIZE
	path_length++;
#endif
#ifdef CUT_OFF
	if( depth <= CUT_OFF ) last_SAT_bin = -1;
    if( solution_bin == last_SAT_bin )
	{
#ifdef DISTRIBUTION
	    records[ record_index ].UNSAT_flag = 1;
#endif
            return UNSAT;
	}
#endif

#ifdef DISTRIBUTION
	branch_literal = records[record_index].branch_literal;
	if( branch_literal != 0 ) dist_acc_flag = 1;
	else
#endif
 	do
	{
	    nodeCount++;
        int ret=ConstructCandidatesSet();
 	    if( ret == 0 )
	    { 
	        if( depth > 0 )
	        {
		         if( checkSolution() == SAT ) return verifySolution();
	        }
	    	if( PreselectAll() == 0 )  return verifySolution();
	    }
	    else ConstructPreselectedSet();
	    if( lookahead() == UNSAT )
	    {
	    	lookDead++;
	    	return UNSAT;
	    }

	    if( propagate_forced_literals() == UNSAT ) return UNSAT;

	    branch_literal = get_signedBranchVariable();
	} while( (percentage_forced > 50.0) || (branch_literal == 0) );
#ifdef PLOT
	if( plotCount++ >= 10000 )  return UNSAT;
	printf("\t%i\t%.3f\t%i\n", plotCount, sum_plot / count_plot, depth );
#endif
	_percentage_forced = (int)percentage_forced;

#ifdef PARALLEL
	if( depth < para_depth )
	    if( para_bin & (1 << (para_depth - depth - 1) ) ) branch_literal *= -1;
#endif
	//printf("branch_literal = %i at depth %i\n", branch_literal, depth );
#ifdef GLOBAL_AUTARKY
	if( depth == 0 )
	{
	    int i;
	    for( i = 1; i <= nrofvars; i++ )
	    {
	    	TernaryImpReduction[  i ] = 0;
		    TernaryImpReduction[ -i ] = 0;
			if( kSAT_flag )
			{
		        btb_size[  i ] = 0;
		        btb_size[ -i ] = 0;
			}
	    }
	    if( kSAT_flag )
		   for( i = 0; i < nrofbigclauses; ++i ) clause_reduction[ i ] = 0;
	}
#endif
	NODE_START();
#ifdef BLOCK_PRESELECT
	set_block_stamps( branch_literal );
#endif
	autarky_level[ depth + 1 ] = FALSE;
#ifdef DISTRIBUTION
	if( top_flag )
	{	
	    branch_literal *= -1;
	    current_rights++;
	    UPDATE_BIN();
	}
	skip_left = skip_node();
#endif
	if( (skip_left==0) && IFIUP( branch_literal, FIX_BRANCH_VARIABLE ) )
	{
#ifdef DISTRIBUTION
	    current_record = LEFT_CHILD;
#endif
	    _result = recursive_solve();
#ifdef DISTRIBUTION
	    LEFT_CHILD = current_record;
#endif
	    if( _result == SAT || _result == UNKNOWN ) return _result;
	}
	else {
//leftend:
#ifdef DISTRIBUTION
		if( (LEFT_CHILD != 0)  && records[ LEFT_CHILD ].UNSAT_flag == 0 )
		{
		    records[ LEFT_CHILD ].UNSAT_flag = 1; 
//		    printf("c left child %i UNSAT by parent!\n", LEFT_CHILD );
		}
#endif
	    PUSH( r, STACK_BLOCK );
	}
	NODE_END();

#ifdef BACKJUMP
	if( backjump_literal != 0 )
	  if( timeAssignments[ backjump_literal ] >= NARY_MAX )
	  {
		return UNSAT;
	  }
	backjump_literal = 0;
#endif

#ifdef DISTRIBUTION
	if( top_flag )
	{
	    current_rights--;
	    UPDATE_BIN();
	}
#endif
	if( autarky_level[ depth + 1 ] == TRUE )
	{
	    //printf("c autarky backtrack at depth %i\n", depth);
	    return UNSAT;
	}
	percentage_forced = _percentage_forced;

#ifdef PARALLEL
	if( depth < para_depth ) goto parallel_skip_node;
#endif

#ifdef GLOBAL_AUTARKY
	if( depth == 0 )
	  if( kSAT_flag )
	  {
	    int i;
	    for( i = 1; i <= nrofvars; ++i )
	    {
		assert( TernaryImpReduction[  i ] == 0 );
		assert( TernaryImpReduction[ -i ] == 0 );

		assert( btb_size[  i ] == 0 );
		assert( btb_size[ -i ] == 0 );
	    }

	    for( i = 0; i < nrofbigclauses; ++i )
	    {
		clause_red_depth[ i ] = nrofvars;
		clause_SAT_flag[ i ]  = 0;
	    }
	  }

	  if( kSAT_flag )
	  {
	    int i;
	    for( i = 1; i <= nrofvars; ++i )
	    {
		assert( TernaryImpReduction[  i ] >= 0 );
		assert( TernaryImpReduction[ -i ] >= 0 );

		assert( btb_size[  i ] >= 0 );
		assert( btb_size[ -i ] >= 0 );
	    }
	  }

#endif
	NODE_START();
#ifdef BLOCK_PRESELECT
	set_block_stamps( branch_literal );
#endif
        if( top_flag == 0 )
	{
#ifdef DISTRIBUTION
	    current_rights++;
#endif
	    UPDATE_BIN();
	}
#ifdef DISTRIBUTION
	skip_right = skip_node();
#endif
	if( (skip_right == 0) && IFIUP( -branch_literal, FIX_BRANCH_VARIABLE ) )
	{
#ifdef DISTRIBUTION
	    current_record = RIGHT_CHILD;
#endif
	    _result = recursive_solve();
#ifdef DISTRIBUTION
	    RIGHT_CHILD = current_record;
#endif
	    if( _result == SAT || _result == UNKNOWN ) return _result;
	}
	else {
//rightend:
#ifdef DISTRIBUTION
		if( (RIGHT_CHILD != 0) && records[ RIGHT_CHILD ].UNSAT_flag == 0 )
		{
		    records[ RIGHT_CHILD ].UNSAT_flag = 1; 
//		    printf("c right child %i UNSAT by parent!\n", RIGHT_CHILD );
		}
#endif
		PUSH( r, STACK_BLOCK );
	}
	NODE_END();

	if( top_flag == 0 )
	{	
#ifdef DISTRIBUTION
	    current_rights--;
#endif
	    UPDATE_BIN();
	}

#ifdef PARALLEL
	parallel_skip_node:;
#endif
//	printf("ended node %i at depth %i\n", nodeCount, depth );

#ifdef SUBTREE_SIZE
	if( (skip_flag == 0) && (jump_depth == 0)  && (current_rights == 0) )
	{
	    int subtree = path_length - depth;

//	    float cost = nodeCount * (CLOCKS_PER_SEC /  ((float)(clock() + 10 - first_time)));
//	    printf("c nodes per second = %.3f at level %i\n", cost, depth );

//	    if( jump_depth >= 30 ) jump_depth = 999;
	    if( jump_depth >= 28 ) jump_depth = 999; //bug

	    if( subtree >     SUBTREE_SIZE )
	    {
	        jump_depth = depth;

	        while( subtree > 2*SUBTREE_SIZE )
	        {
		         jump_depth++; 
		         subtree = subtree / 2;
	        }

	     //   if( jump_depth >= 20 ) jump_depth = 999;
           if( jump_depth >= 18 ) jump_depth = 999; //bug

	        skip_flag = 1;
	    }
	}
#endif
#ifdef DISTRIBUTION
	record_node( record_index, branch_literal, skip_left, skip_right );

	current_record = record_index;
#endif

#ifdef BACKJUMP
	if( kSAT_flag )
	{
	    int *_rstackp = rstackp, nrval;
	
	    while( --_rstackp > rstack )
	    {
		nrval = *_rstackp;
		if( (TernaryImpReduction[ nrval ] + TernaryImpReduction[ -nrval ]) != 0 )
		{
		    backjump_literal = nrval;
		    break;
		}
	    }
	}
#endif
	return UNSAT;
}

int IFIUP( const int nrval, const int forced_or_branch_flag )
{
	int i, *_forced_literal_array, _forced_literals, *local_fixstackp;

	local_fixstackp = rstackp;
	end_fixstackp   = rstackp;

	currentTimeStamp = BARY_MAX;
	
	current_bImp_stamp = 1;

	for( i = nrofvars; i >= 1;  i-- )
	{
	    bImp_stamps[  i ] = 0;
	    bImp_stamps[ -i ] = 0;
	}
	if( forced_or_branch_flag == FIX_FORCED_LITERALS )
	{
	   get_forced_literals( &_forced_literal_array, &_forced_literals );
	   for( i = 0; i < _forced_literals; i++ )
	      	if( look_fix_binary_implications(*(_forced_literal_array++)) == UNSAT ) 
			{  MainDead( local_fixstackp ); 
			   return UNSAT; 
			}
	}
#ifdef DISTRIBUTION
	else if( forced_or_branch_flag == FIX_RECORDED_LITERALS )
	{
	   get_recorded_literals( &_forced_literal_array, &_forced_literals );
	   for( i = 0; i < _forced_literals; i++ )
	      	if( look_fix_binary_implications(*(_forced_literal_array++)) == UNSAT ) 
			{   MainDead( local_fixstackp );
			    return UNSAT; 
			}
	}
#endif
	else
	{
	   int rc=look_fix_binary_implications( nrval );
       if( rc == UNSAT ) 	
    	 { MainDead( local_fixstackp ); 
		    return UNSAT; 
		}
	}
	while( local_fixstackp < end_fixstackp )
		if( DPLL_update_datastructures(*(local_fixstackp++)) == UNSAT ) 	
		{ MainDead( local_fixstackp ); //bug ???
		    return UNSAT; 
		}

	rstackp = end_fixstackp;
	return SAT;
}

inline void reduce_big_occurences( const int clause_index, const int nrval )
{
#ifdef HIDIFF
	HiRemoveClause( clause_index );
#endif
#ifdef NO_TRANSLATOR
	int *clauseSet, index;
	int *literals = clause_list[ clause_index ], lit;
	while( *literals != LAST_LITERAL )
	{
	    lit =  *(literals++);
	    if( lit != nrval )
	    {
	        clauseSet = clause_set[ lit ];
	        index = 0; //wellicht niet nodig
	        while( 1 )
	    	{
		    if( *(clauseSet++) == clause_index )
		    {
		        clauseSet[ -1 ] = clause_set[ lit ][ big_occ[ lit ] - 1 ];
		        clause_set[ lit ][ big_occ[ lit ] - 1 ] = LAST_CLAUSE;
		        break;
		    }
		    index++;
		}
	    }
	    big_occ[ lit ]--;
	}
#endif
}

inline int DPLL_update_datastructures( const int nrval )
{
	int i, *bImp;
#ifdef EQ
	int nr, ceqidx;
	nr = NR( nrval );
    PUSH( sub, STACK_BLOCK );
#endif

	FIX( nrval, NARY_MAX );

	unitResolveCount++;
	reduce_freevars( nrval );

    bImp = BIMP_START(-nrval);
    for( i = BIMP_ELEMENTS; --i; ) bImp_satisfied[ -(*(bImp++)) ]++;

	// Update eager datastructures
	if( kSAT_flag == 0 )
	{
#ifdef GLOBAL_AUTARKY
	    int lit1, lit2;

        int *tImp = TernaryImp[ nrval ] + 2 * TernaryImpSize[ nrval ];
        for( i = TernaryImpLast[ nrval ] - TernaryImpSize[ nrval ]; i--; )
         {
	    	lit1 = *(tImp++);
	    	lit2 = *(tImp++);

	    	if( IS_REDUCED_TIMP( lit1, lit2 ) )
		    TernaryImpReduction[ lit1 ]--;
	    	else if( IS_REDUCED_TIMP( lit2, lit1 ) )
                    TernaryImpReduction[ lit2 ]--;
            }
#endif
	    remove_satisfied_implications(  nrval );
	    remove_satisfied_implications( -nrval );

#ifdef GLOBAL_AUTARKY
            tImp = TernaryImp[ -nrval ];
            for( i = tmpTernaryImpSize[ -nrval ]; i--; )
	    {
	        TernaryImpReduction[ *(tImp++) ]++;
	        TernaryImpReduction[ *(tImp++) ]++;
	    }
#endif
	}
	else
	{
	  int *clauseSet, clause_index; 

	  // REMOVE SATISFIED CLAUSES
	  clauseSet = clause_set[ nrval ];
	  while( *clauseSet != LAST_CLAUSE )
	  {
	    clause_index = *(clauseSet++);

	    // if clause is not satisfied
	    if( clause_length[ clause_index ] < SAT_INCREASE - 2 )	
	    {
#ifdef GLOBAL_AUTARKY
		// if clause is already been reduced
		if( clause_reduction[ clause_index ] > 0 )
		{
                int *literals = clause_list[ clause_index ];
                while( *literals != LAST_LITERAL )	TernaryImpReduction[ *(literals++) ]--;
		}
		clause_SAT_flag[ clause_index ] = 1;
#endif
		reduce_big_occurences( clause_index, nrval );
	    }
	    clause_length[ clause_index ] += SAT_INCREASE;
	  }
#ifdef GLOBAL_AUTARKY
	  for( i = 0; i < btb_size[ nrval ]; ++i )
	  {
	    // decrease literal reduction
            int *literals = clause_list[ big_to_binary[ nrval ][ i ] ], flag = 0;
            while( *literals != LAST_LITERAL )
            {
		if( timeAssignments[ *(literals++) ] == NARY_MAX )
		{
		    if( flag == 1 ) { flag = 0; break; }
		    flag = 1;
		}
            }

	    if( flag == 1 )
	    {
		clause_SAT_flag[  big_to_binary[ nrval ][ i ] ] = 1;
		literals = clause_list[ big_to_binary[ nrval ][ i ] ];
	    	while( *literals != LAST_LITERAL )
	            TernaryImpReduction[ *(literals++) ]--;
	    }
	  }
#endif
	}
	

#ifdef GLOBAL_AUTARKY
#ifdef EQ	
	tmpEqImpSize[ nr ] = Veq[ nr ][ 0 ];
	for( i = 1; i < Veq[ nr ][0]; i++ )
        {
	    int j;
            ceqidx = Veq[ nr ][i];
            for( j = 0; j < CeqSizes[ ceqidx ]; j++ )
                TernaryImpReduction[ Ceq[ceqidx][j] ]++;
        }
#endif
#endif
	if( kSAT_flag )
	{
	  int UNSAT_flag, *clauseSet, clause_index;
	  int first_lit, *literals, lit;

	  // REMOVE UNSATISFIED LITERALS
	  UNSAT_flag = 0;
	  clauseSet = clause_set[ -nrval ];
	  while( *clauseSet != LAST_CLAUSE )
	  {
	    clause_index = *(clauseSet++);
#ifdef GLOBAL_AUTARKY
	    // if clause is for the first time reduced
	    if( clause_reduction[ clause_index ] == 0 )
	    {
                int *literals = clause_list[ clause_index ];
                while( *literals != LAST_LITERAL ) TernaryImpReduction[ *(literals++) ]++;
		        clause_red_depth[ clause_index ] = depth;
	    }
	    clause_reduction[ clause_index ]++;
#endif
	    clause_length[ clause_index ]--;
#ifdef HIDIFF
	    HiRemoveLiteral( clause_index, nrval );
#endif
            if(  clause_length[ clause_index ] == 2 )
            {
#ifdef GLOBAL_AUTARKY
                literals = clause_list[ clause_index ];
                while( *literals != LAST_LITERAL )
                {
                    lit = *(literals)++;
		            if( timeAssignments[ lit ] < NARY_MAX ) big_to_binary[ lit ][ btb_size[ lit ]++ ] = clause_index;
		}
#endif
		reduce_big_occurences( clause_index, -nrval );
		clause_length[ clause_index ] = SAT_INCREASE;

	        if( UNSAT_flag == 0 )
	        {
                    first_lit = 0;
                    literals = clause_list[ clause_index ];
                    while( *literals != LAST_LITERAL )
                    {
                        lit = *(literals)++;
                        if( IS_NOT_FIXED( lit ) )
                        {
                            if( first_lit == 0 ) first_lit = lit;
                            else
			    {
				UNSAT_flag = !DPLL_add_binary_implications( first_lit, lit ); 
				goto next_clause;
			    }
                        }
                        else if( !FIXED_ON_COMPLEMENT(lit) ) goto next_clause;
                    }

                    if( first_lit != 0 )  UNSAT_flag = !look_fix_binary_implications( first_lit );
                    else                  UNSAT_flag = 1;
                }
                next_clause:;
	    }
	  }

	  if( UNSAT_flag ) return UNSAT;
	}

	if( kSAT_flag == 0 )
	{
	       int *tImp = TernaryImp[ -nrval ];
		   for( i = tmpTernaryImpSize[ -nrval ] - 1; i >= 0; i-- ){
              // if( DPLL_add_binary_implications( *(tImp++), *(tImp++) ) == UNSAT ){ //bug ????
			   if( DPLL_add_binary_implications( *tImp, *(tImp+1) ) == UNSAT ){
					return UNSAT;
				}
                tImp+=2;
		   }
	}

#ifdef EQ
        while( Veq[ nr ][ 0 ] > 1 )
        {
            ceqidx = Veq[ nr ][ 1 ];

            fixEq( nr, 1, SGN(nrval));
            PUSH( sub, nrval );

            if( CeqSizes[ ceqidx ] == 2 )
			{
				if ( DPLL_propagate_binary_equivalence( ceqidx ) == UNSAT ){
					return UNSAT;
				}
	    }
	    else if( CeqSizes[ ceqidx ] == 1 )
            {
			   if( look_fix_binary_implications(Ceq[ceqidx][0]*CeqValues[ceqidx]) == UNSAT ){
				return UNSAT;
			   }
            }
        }

        while( newbistackp != newbistack )
        {
            POP( newbi, ceqidx );
            if( CeqSizes[ ceqidx ] == 2 )
				if ( DPLL_propagate_binary_equivalence( ceqidx ) == UNSAT ){
	                return UNSAT;
				}
        }
#endif
	return SAT;
}

inline void swap_ternary_implications( const int nrval, const int lit1, const int lit2 )
{
	int i, last, *tImp = TernaryImp[ nrval ];

	last = --TernaryImpSize[ nrval ];
	for( i = last - 1; i >= 0; i-- )
	    if( (tImp[ 2*i ] == lit1) && (tImp[ 2*i + 1 ] == lit2) )
	    {
	    	tImp[ 2*i     ] = tImp[ 2*last     ]; tImp[ 2*last     ] = lit1; 
		tImp[ 2*i + 1 ] = tImp[ 2*last + 1 ]; tImp[ 2*last + 1 ] = lit2; 
		return;
	    }
}

void remove_satisfied_implications( const int nrval )
{
        int i, lit1, lit2, *tImp = TernaryImp[ nrval ];

        for( i = TernaryImpSize[ nrval ] - 1; i >= 0; i-- )
        {
            lit1 = *(tImp++);
            lit2 = *(tImp++);
	    
	    swap_ternary_implications( lit1, lit2, nrval );
	    swap_ternary_implications( lit2, nrval, lit1 );
        }

        tmpTernaryImpSize[ nrval ] = TernaryImpSize[ nrval ];
        TernaryImpSize   [ nrval ] = 0;
}

int DPLL_propagate_binary_equivalence( const int bieq )
{
        int i, j, ceqsubst;
        int lit1, lit2;
        int value;

        lit1 = Ceq[ bieq ][ 0 ];
        lit2 = Ceq[ bieq ][ 1 ];
        value = CeqValues[ bieq ];

        for( i = 1; i < Veq[ lit1 ][ 0 ]; i++ )
        {
            ceqsubst = Veq[ lit1 ][ i ];
            for( j = 1; j < Veq[ lit2 ][ 0 ]; j++ )
            {
            	if( (ceqsubst == Veq[ lit2 ][ j ]) )
                {
                    fixEq( lit1, i, 1);
                    PUSH( sub, lit1 );

                    fixEq( lit2, j, value);
                    PUSH( sub, lit2 * value );

                    if( CeqSizes[ ceqsubst ] == 0 )
                       	if (CeqValues[ ceqsubst ] == -1 )
                            return UNSAT;

                    if( CeqSizes[ ceqsubst ] == 1 )
                      	if( !look_fix_binary_implications(Ceq[ceqsubst][0] * CeqValues[ceqsubst]) )
                    	    return UNSAT;
	
                    if( CeqSizes[ ceqsubst ] == 2 )
                     	PUSH( newbi, ceqsubst );

		    i--;
                    break;
                }
            }
        }

        if( (DPLL_add_binary_implications( lit1, -lit2 * value ) && 
	     DPLL_add_binary_implications( -lit1, lit2 * value )) == UNSAT ) return UNSAT;

        return SAT;
}

inline int DPLL_add_compensation_resolvents( const int lit1, const int lit2 )
{
	int i, lit, *bImp = BIMP_START(lit2);

    	CHECK_NODE_STAMP( -lit1 );
	CHECK_BIMP_UPPERBOUND( -lit1, BinaryImp[ lit2 ][ 0 ] );

	for (i = BIMP_ELEMENTS; --i; )
	{
	    lit = *(bImp++); 
	    if( IS_FIXED(lit) ) continue;

	    if( bImp_stamps[ -lit ] == current_bImp_stamp )	
		return look_fix_binary_implications( lit1 );
#ifdef COMPENSATION_RESOLVENTS
	    if( bImp_stamps[ lit ] != current_bImp_stamp )
	    {
		CHECK_NODE_STAMP( -lit );
	      	CHECK_BIMP_BOUND  ( -lit );
		ADD_BINARY_IMPLICATIONS( lit, lit1 );
	    }
#endif
    	}
	return UNKNOWN;
}

int DPLL_add_binary_implications( int lit1, int lit2 )
{
	int i, *bImp;

	if( IS_FIXED(lit1) )
	{
	    if( !FIXED_ON_COMPLEMENT(lit1) ) return SAT;
		else if( IS_FIXED(lit2) ){	
		    int look_rc=FIXED_ON_COMPLEMENT(lit2);
		    return !look_rc;
		}
		else {
			int look_rc=look_fix_binary_implications(lit2);
		    return look_rc;
        }
	}
	else if( IS_FIXED(lit2) )
	{
	    if( !FIXED_ON_COMPLEMENT(lit2) ) return SAT;
		else {
			int look_rc=look_fix_binary_implications(lit1);
		    return look_rc;
       	}
	}
	
#ifdef BIEQ
	while( (VeqDepends[ NR(lit1) ] != INDEPENDENT) && 
	    (VeqDepends[ NR(lit1) ] != EQUIVALENT) )
		lit1 = VeqDepends[ NR(lit1) ] * SGN(lit1);

	while( (VeqDepends[ NR(lit2) ] != INDEPENDENT) && 
	    (VeqDepends[ NR(lit2) ] != EQUIVALENT) ) lit2 = VeqDepends[ NR(lit2) ] * SGN(lit2);
	if( lit1 == -lit2 ) return SAT;
	if( lit1 ==  lit2 ) {
		int look_rc=look_fix_binary_implications(lit1);
		return look_rc;
	}
#endif

	STAMP_IMPLICATIONS( -lit1 );
	if( bImp_stamps[ -lit2 ] == current_bImp_stamp )
	    return look_fix_binary_implications( lit1 );
	if( bImp_stamps[lit2] != current_bImp_stamp )
	{
	    int _result;

	    bImp_stamps[ BinaryImp[-lit1][ BinaryImp[-lit1][0] - 1] ] = current_bImp_stamp;

	    _result = DPLL_add_compensation_resolvents( lit1, lit2 );
		if( _result != UNKNOWN ) {
			return _result;
		}
	 
	    STAMP_IMPLICATIONS( -lit2 ); 
		if( bImp_stamps[ -lit1 ] == current_bImp_stamp ){
	    	int look_rc=look_fix_binary_implications( lit2 );
		    return look_rc;
        }
	    _result = DPLL_add_compensation_resolvents( lit2, lit1 );
		if( _result != UNKNOWN ){
			return _result;
		}

	    ADD_BINARY_IMPLICATIONS( lit1, lit2 );
	}
	return SAT;
}

int autarky_stamp( const int nrval )
{
	int i, *tImp, lit1, lit2, flag = 0;

	tImp = TernaryImp[ -nrval ];
	for( i = tmpTernaryImpSize[ -nrval ]; i--; )
	{
	    lit1 = *(tImp++);
	    lit2 = *(tImp++);
		
	    if( IS_NOT_FIXED(lit1) && IS_NOT_FIXED(lit2) )
	    {
		flag = 1;
		if( VeqDepends[ NR(lit1) ] == DUMMY )
		    autarky_stamp( lit1 );
		else
		    TernaryImpReduction[ lit1 ]++;

		if( VeqDepends[ NR(lit2) ] == DUMMY )
		    autarky_stamp( lit2 );
		else
		TernaryImpReduction[ lit2 ]++;
	    }
	}
	return flag;
}

int analyze_autarky( )
{
#ifdef LOOKAHEAD_ON_DUMMIES
	int *tImp, lit1, lit2;
#endif
	int i, j, nrval, twice;
	int new_bImp_flag, _depth, *_rstackp;

	if( depth == 0 ) return 0;

        for( i = 1; i <= nrofvars; i++ )
        {
            TernaryImpReduction[  i ] = 0;
            TernaryImpReduction[ -i ] = 0;
        }

	new_bImp_flag = 0;
	_rstackp      = rstackp;
	for( _depth = depth; _depth > 0; _depth-- )
	{
//	  if( autarky_level[ _depth ] == TRUE )
//	  {
//		while( *(_rstackp--) == STACK_BLOCK );
//	 	continue;
//	  }

	  for( twice = 1 ; twice <= 2; twice++ )	    
	    while( *(--_rstackp) != STACK_BLOCK )
	    {
		nrval = *(_rstackp);
#ifndef LOOKAHEAD_ON_DUMMIES
		if( autarky_stamp( nrval ) == 1 )
		    new_bImp_flag = 1;
#else
		tImp = TernaryImp[ -nrval ];
		for( i = tmpTernaryImpSize[ -nrval ]; i--; )
		{
		    lit1 = *(tImp++);
		    lit2 = *(tImp++);
		
		    if( IS_NOT_FIXED(lit1) && IS_NOT_FIXED(lit2) )
		    {
			new_bImp_flag = 1;
			TernaryImpReduction[ lit1 ]++;
			TernaryImpReduction[ lit2 ]++;
		    }
		}
#endif
	        for( j = 1; j < tmpEqImpSize[NR(nrval)]; j++ )
	        {
	            int ceqsubst = Veq[NR(nrval)][j];
	    	    for( i = 0; Ceq[ceqsubst][i] != NR(nrval); i++ )
		    {
			new_bImp_flag = 1;
	   	        TernaryImpReduction[ Ceq[ceqsubst][i] ]++;
		    }
	        }
	    }
	  if( new_bImp_flag == 1 ) break;
	  autarky_level[ _depth ] = TRUE;
	}
	return _depth;
}

void backtrack()
{
	int nrval, varnr, size;

	while( !( *( rstackp - 1 ) == STACK_BLOCK ) )
	{   POP_BACKTRACK_RECURSION_STACK }
	
	POP_RECURSION_STACK_TO_DEV_NULL

	while( !( *( subsumestackp - 1 ) == STACK_BLOCK ) )
	{	
	    POP( subsume, nrval );

	    TernaryImpSize[ TernaryImp[nrval][ 2*TernaryImpSize[nrval]   ] ]++;
	    TernaryImpSize[ TernaryImp[nrval][ 2*TernaryImpSize[nrval]+1 ] ]++;
	    TernaryImpSize[ nrval ]++;
	}
	subsumestackp--;

	while( !( *( rstackp - 1 ) == STACK_BLOCK ) )
	{   POP_BACKTRACK_RECURSION_STACK }
	POP_RECURSION_STACK_TO_DEV_NULL

        while( !( *( bieqstackp - 1 ) == STACK_BLOCK ) )
        {
	    POP( bieq, varnr );
            VeqDepends[ varnr ] = INDEPENDENT;         
        }
        bieqstackp--;

	while( !( *( impstackp - 1 ) == STACK_BLOCK ) )
	{
	    POP( imp, size );
	    POP( imp, nrval );
	    BinaryImp[ nrval ][ 0 ] = size;
	}
	impstackp--;
}

void MainDead( int *local_fixstackp )
{
	int nrval;
	mainDead++;

        while( end_fixstackp > local_fixstackp )
        {
	    nrval = *(--end_fixstackp);
	    UNFIX( nrval ); 
	}
	rstackp = end_fixstackp;
}

inline void restore_big_occurences( const int clause_index, const int nrval )
{
#ifdef HIDIFF
	HiAddClause( clause_index );
#endif
#ifdef NO_TRANSLATOR
	int *literals = clause_list[ clause_index ], lit;
	while( *literals != LAST_LITERAL )
	{
	    lit = *(literals++);
	    if( lit != nrval ) clause_set[ lit ][ big_occ[ lit ] ] = clause_index;
	    big_occ[ lit ]++;
	}
#endif
}

void restore_implication_arrays( const int nrval )
{
	int i, *bImp;
#ifdef GLOBAL_AUTARKY
	int lit1, lit2;
#endif
#ifdef EQ
	int ceqsubst, var;
	while( !( *( substackp - 1 ) == STACK_BLOCK ) )
	{
	    POP( sub, var );
	    ceqsubst = Veq[ NR(var) ][ Veq[ NR(var) ][ 0 ]++ ];
	    CeqValues[ ceqsubst ] *= SGN(var);
	    CeqSizes[ ceqsubst ]++; 
        }
        substackp--;
#ifdef GLOBAL_AUTARKY
	for( i = 1; i < Veq[NR(nrval)][0]; i++ )
	{
	    int j;
	    ceqsubst = Veq[NR(nrval)][i];
	    for( j = 0; j < CeqSizes[ceqsubst]; j++ ) TernaryImpReduction[ Ceq[ceqsubst][j] ]--;
	}
#endif
#endif
	if( kSAT_flag )
	{
	  int clause_index, *clauseSet;
	  clauseSet = clause_set[ nrval ];
	  while( *clauseSet != LAST_CLAUSE )
	  {
	    clause_index = *(clauseSet++);
	    clause_length[ clause_index ] -= SAT_INCREASE;

	    if( clause_length[ clause_index ] < SAT_INCREASE - 2 )
	    {
		restore_big_occurences( clause_index, nrval );
#ifdef GLOBAL_AUTARKY
		clause_SAT_flag[ clause_index ] = 0;
		if( clause_reduction[ clause_index ] > 0 )
		{
                    int *literals = clause_list[ clause_index ];
                    while( *literals != LAST_LITERAL )
			TernaryImpReduction[ *(literals++) ]++;
		}
#endif
	    }
	  }
#ifdef GLOBAL_AUTARKY
	  for( i = 0; i < btb_size[ nrval ]; ++i )
	  {
	    // decrease literal reduction
            int *literals = clause_list[ big_to_binary[ nrval ][ i ] ], flag = 0;
            while( *literals != LAST_LITERAL )
            {
		if( timeAssignments[ *(literals++) ] == NARY_MAX )
		{
		    if( flag == 1 ) { flag = 0; break; }
		    flag = 1;
		}
            }

	    if( flag == 1 )
	    {
		clause_SAT_flag[ big_to_binary[ nrval ][ i ] ] = 0;
		literals = clause_list[ big_to_binary[ nrval ][ i ] ];
            	while( *literals != LAST_LITERAL )
	            TernaryImpReduction[ *(literals++) ]++;
	    }
	  }
#endif
          clauseSet = clause_set[ -nrval ];
	  while( *clauseSet != LAST_CLAUSE )
          {
            clause_index = *(clauseSet++);
	    if( clause_length[ clause_index ] == SAT_INCREASE )
	    {
		restore_big_occurences( clause_index, -nrval );
		clause_length[ clause_index ] = 2;
#ifdef GLOBAL_AUTARKY
                int *literals = clause_list[ clause_index ];
                while( *literals != LAST_LITERAL )
                {
                    int lit = *(literals)++;
                    if( timeAssignments[ lit ] < NARY_MAX )
			btb_size[ lit ]--;
		}
#endif
	    }

#ifdef GLOBAL_AUTARKY
            clause_reduction[ clause_index ]--;

	    // if clause is restored to original length
	    if( clause_reduction[ clause_index ] == 0 )
	    {
		// decreasee literal reduction array
                int *literals = clause_list[ clause_index ];
                while( *literals != LAST_LITERAL )
		    TernaryImpReduction[ *(literals++) ]--;
		
		clause_red_depth[ clause_index ] = nrofvars;
	    }
#endif
#ifdef HIDIFF
	    HiAddLiteral( clause_index, nrval );
#endif
            clause_length[ clause_index ]++;
          }
	}

	/* restore all literals that were removed due to fixing of nrval */
	if( kSAT_flag == 0 )
	{
	    int *tImp = TernaryImp[ -nrval ];
	    for( i = TernaryImpSize[ -nrval ] = tmpTernaryImpSize[ -nrval ]; i--; )
	    {
	    	TernaryImpSize[ *(tImp++) ]++;
	    	TernaryImpSize[ *(tImp++) ]++;
	    }
#ifdef GLOBAL_AUTARKY
	    tImp = TernaryImp[ -nrval ];
            for( i = tmpTernaryImpSize[ -nrval ]; i--; )
	    {
	    	TernaryImpReduction[ *(tImp++) ]--;
	    	TernaryImpReduction[ *(tImp++) ]--;
	    }
#endif
	/* restore all clauses that were removed due to fixing of nrval */
	    tImp = TernaryImp[ nrval ];
	    for( i = TernaryImpSize[ nrval ] = tmpTernaryImpSize[ nrval ]; i--; )
	    {
	    	TernaryImpSize[ *(tImp++) ]++;
	    	TernaryImpSize[ *(tImp++) ]++;
	    }
#ifdef GLOBAL_AUTARKY
	    tImp = TernaryImp[ nrval ] + 2 * TernaryImpSize[ nrval ];
	    for( i = TernaryImpLast[ nrval ] - TernaryImpSize[ nrval ]; i--; )
	    {
		lit1 = *(tImp++);
		lit2 = *(tImp++);

	    	if( IS_REDUCED_TIMP( lit1, lit2 ) )
                    TernaryImpReduction[ lit1 ]++;
		else if( IS_REDUCED_TIMP( lit2, lit1 ) )
                    TernaryImpReduction[ lit2 ]++;
            }
#endif
	}

        bImp = BIMP_START(-nrval);
        for( i = BIMP_ELEMENTS; --i; )
            bImp_satisfied[ -(*(bImp++)) ]--;

	freevars++;
	
	UNFIX( nrval ); 
}

int checkSolution( )
{
	int i, *sizes;

//	printf("c checking solution %i\n", nodeCount );
	if( kSAT_flag ) sizes = big_occ;
	else 		sizes = TernaryImpSize;

	for ( i = 1; i <= original_nrofvars; i++ )
	    if( IS_NOT_FIXED( i ) )
	    {
	        if( sizes[  i ] > 0 ) { return UNSAT; }
	        if( sizes[ -i ] > 0 ) { return UNSAT; }
	        if( BinaryImp[  i ][ 0 ] > bImp_satisfied[  i ] ){ return UNSAT; }
	        if( BinaryImp[ -i ][ 0 ] > bImp_satisfied[ -i ] ){ return UNSAT; }
	    }

	return SAT;
}

int verifySolution()
{
	int i, j, satisfied;
/*
	int dollars;
#ifndef CUT_OFF
//	unsigned long long mask = 0xffffffffffffffffLLU;
	uint64 mask = 0xffffffffffffffff;
	dollars = solution_bits - depth;
	if( dollars < 1 ) dollars = 1;

	printf("\nc |" );
	for( i = solution_bits; i >= dollars; i-- )
	{
#ifdef DISTRIBUTION
	    if( solution_bits - i == (unsigned)jump_depth ) printf(".");
#endif
	    if( ((solution_bin & mask) >> i) > 0 ) printf("1");
	    else printf("0");
	    mask = mask >> 1;
	}

	for( i = solution_bits - depth; i >= 2; i-- ) printf("$");
	printf("|\n");
#else
      printf("s %i\n", solution_bin + 1);
      fflush( stdout );
	  last_SAT_bin = solution_bin;

        return UNSAT;
#endif
*/
#ifdef DISTRIBUTION 
//	printf("c direction branchin :: current_rights = %i\n", current_rights );
#endif
	do
	{ fixDependedEquivalences(); }
	while( dependantsExists() );

	/* check all 3-clauses */

	for( i = 0; i < nrofclauses; i++ )
	{
	    satisfied = 0;
	    if( Clength[ i ] == 0 ) continue;

	    for( j = 0; j < Clength[ i ]; j++ )
		if( timeAssignments[ Cv[ i ][ j ] ] == VARMAX ) satisfied = 1;

  	    if( !satisfied )
	    {
	 	  //printf("\nc clause %i: ", i);
		for( j = 0; j < Clength[ i ]; j++ )
	  	    //printf("%i [%i] ", Cv[i][j], IS_FIXED(Cv[i][j]) );
	    	printf("c not satisfied yet\n");	
	    	return UNKNOWN;
	    }
	}

#ifdef EQ
        for( i = 0; i < nrofceq; i++ )
        {
      	    int value = CeqValues[ i ];
            for( j = 0; j < CeqSizes[ i ]; j++ )
            	value *= EQSGN( Ceq[ i ][ j ] );
            if( value == -1 )
            {
                printf("c eq-clause %i is not satisfied yet\n", i);
            	return UNKNOWN;
            }
        }
#endif
	return SAT;
}

//------------------------------------ block begin --------------------------------------------------
#define	OCCURENCE_GRAPH		1
#define CONFLICT_GRAPH		2
#define	RESOLUTION_GRAPH	3
#define SUBSUMPTION_GRAPH	4

#define INITIAL_ORDER		nrofclauses
#define INITIAL_LOW		nrofclauses
#define INITIAL_PARENT		-1

#define PRINT_COMPONENTS
//#define REMOVE_BLOCKED_BINARIES

#define PRINT_EDGES

int *candidates, nrofcandidates;
int *MarkArray;
int **literal_occ, **literal_lut;
int binary_blocked = 0, nary_blocked = 0; 
int removed_blocked_clauses = 0;	
int *clause_order_stamp, *clause_order_array, *clause_parent, *clause_low;
int current_order;

int *graph_subsume, graph_subsume_stamp = 0;

void allocate_local_datastructures( );
void free_local_datastructures( );
int depth_first_graph_rec( const int clsidx, const int parent, const int graph_flag );
void determine_clause_low( const int clsidx, const int graph_flag );
/*
void print_graph_data( )
{
	int i;

	clause_order_stamp = (int*) malloc( sizeof(int) * nrofclauses );
	clause_order_array = (int*) malloc( sizeof(int) * nrofclauses );
	clause_parent      = (int*) malloc( sizeof(int) * nrofclauses );
	clause_low         = (int*) malloc( sizeof(int) * nrofclauses );

	allocate_local_datastructures();

	graph_subsume = (int*) malloc( sizeof(int) * (2*nrofvars + 1) );
	for( i = 0; i <= 2*nrofvars; i++ ) 
	    graph_subsume[ i ] = 0;
	
	graph_subsume += nrofvars;

	printf("p edge %i %i \n", nrofclauses, count_edges( SUBSUMPTION_GRAPH ) );

	graph_subsume -= nrofvars;
	free( graph_subsume );

	free_local_datastructures();

	free( clause_order_stamp );
	free( clause_order_array );
	free( clause_parent );
	free( clause_low );
}

int count_edges( const int graph_flag )
{
    int i, j, lit, clsidx, clschk, nrofedges = 0;

    if( graph_flag <= CONFLICT_GRAPH )
	for( i = 0; i < nrofclauses; i++ )
	    clause_parent[ i ] = -1;	

    for( clsidx = 0; clsidx < nrofclauses; clsidx++ )
    {
	assert( Clength[ clsidx ] > 0 );

	if( graph_flag >= RESOLUTION_GRAPH )
	    mark_complement_of_literals( clsidx );
	else if( graph_flag == OCCURENCE_GRAPH )
	    clause_parent[ clsidx ] = clsidx;
	
	for( i = 0; i < Clength[ clsidx ]; i++ )
	{
	    lit = -Cv[ clsidx ][ i ];
	    for( j = 1; j <= literal_occ[ lit ][ 0 ]; j++ )
	    {
		clschk = literal_occ[ lit ][ j ];
		if( graph_flag <= CONFLICT_GRAPH )
		{
		    if( clause_parent[ clschk ] != clsidx )
		    {	clause_parent[ clschk ] = clsidx;
#ifdef PRINT_EDGES
		        if( clschk < clsidx )
			    printf("e %i %i\n", clschk + 1, clsidx + 1 );
#endif
			nrofedges++; 		    	    }
		}
		else if( count_clashing_literals( clschk, clsidx ) == 1 )
		{
		    if( graph_flag == SUBSUMPTION_GRAPH )
			if( is_subsumed( clschk, clsidx ) )
			    continue;
#ifdef PRINT_EDGES
		    if( clschk < clsidx )
			printf("e %i %i\n", clschk + 1, clsidx + 1 );
#endif
		    nrofedges++;
		}
	    }
	    if( graph_flag == OCCURENCE_GRAPH )
	    {
	    	for( j = 1; j <= literal_occ[ -lit ][ 0 ]; j++ )
	    	{
		    clschk = literal_occ[ -lit ][ j ];
		    if( clause_parent[ clschk ] != clsidx )
		    {	clause_parent[ clschk ] = clsidx;
#ifdef PRINT_EDGES
		        if( clschk < clsidx )
			    printf("e %i %i\n", clschk + 1, clsidx + 1 );
#endif
			nrofedges++;				}
		}
	    }
	}
    }
    assert( (nrofedges % 2) == 0);
    return nrofedges / 2;
}

int count_components( const int graph_flag )
{
	int i, tmp, nrofcomponents = 0;	

	current_order = 0;

	for( i = 0; i < nrofclauses; i++ )
	{
	    clause_order_stamp[ i ] = INITIAL_ORDER;
	    clause_low        [ i ] = INITIAL_LOW;
	}

	for( i = 0; i < nrofclauses; i++ )
	{
	    if( clause_order_stamp[ i ] == INITIAL_ORDER )
	    {
		nrofcomponents++;
		if( depth_first_graph_rec( i, INITIAL_PARENT, graph_flag ) >= 2 )
	     	    printf("c found ARTICULATION clause %i\n", i);
	    }
	}

	for( i = nrofclauses - 1; i >= 0; i-- )
	{
	     tmp = clause_order_array[ i ];
	     determine_clause_low( tmp, graph_flag );
	     if( (clause_low[ tmp ] != 0) &&
	         (clause_low[ tmp ] == clause_order_stamp[ clause_parent[ tmp ] ]) && 
		 (clause_parent[ clause_parent[ tmp ] ] != INITIAL_PARENT) )
	     	    printf("c found ARTICULATION clause %i\n", clause_parent[ tmp ] );
	}

	printf("c number of components = %i\n", nrofcomponents );

	print_components( nrofcomponents );

	return nrofcomponents;
}

int depth_first_graph_rec( const int clsidx, const int parent, const int graph_flag )
{
	int i, j, lit, clschk, counter = 0;

	clause_order_array[ current_order ] = clsidx;
	clause_order_stamp[ clsidx ] = current_order;
	clause_parent     [ clsidx ] = parent; 
	clause_low        [ clsidx ] = current_order;
	current_order++;

	mark_complement_of_literals( clsidx );

	for( i = 0; i < Clength[ clsidx ]; i++ )
	{
	    lit = -Cv[ clsidx ][ i ];
	    for( j = 1; j <= literal_occ[ lit ][ 0 ]; j++ )
	    {
		clschk = literal_occ[ lit ][ j ];
		if( clause_order_stamp[ clschk ] == INITIAL_ORDER )
		{
		    if( graph_flag <= CONFLICT_GRAPH )
		    {
			counter++;
			depth_first_graph_rec( clschk, clsidx, graph_flag );
		    }
		    else if( count_clashing_literals( clschk, clsidx ) == 1 )
		    {
			if( graph_flag == SUBSUMPTION_GRAPH )
			    if( is_subsumed( clschk, clsidx ) ) continue;

			counter++;
			depth_first_graph_rec( clschk, clsidx, graph_flag );
			mark_complement_of_literals( clsidx );
		    }
		}
	    }
	}
	return counter;
}

void determine_clause_low( const int clsidx, const int graph_flag )
{
	int i, j, lit, clschk;

	mark_complement_of_literals( clsidx );
	
	for( i = 0; i < Clength[ clsidx ]; i++ )
	{
	    lit = -Cv[ clsidx ][ i ];
	    for( j = 1; j <= literal_occ[ lit ][ 0 ]; j++ )
	    {
		clschk = literal_occ[ lit ][ j ];
		if( clause_low[ clsidx ] > clause_low[ clschk ] )
		{
		    if( graph_flag >= RESOLUTION_GRAPH )
		    {
			if( count_clashing_literals( clschk, clsidx ) > 1 )
			    continue;			

			if( graph_flag == SUBSUMPTION_GRAPH )
			    if( is_subsumed( clschk, clsidx ) )
			        continue;
		    }
		    clause_low[ clsidx ] = clause_low[ clschk ];
		}
	    }
	}
}

void mark_complement_of_literals( int clsidx )
{
	int i;

	for( i = 0; i < Clength[ clsidx ]; i++ )
	    MarkArray[ -Cv[ clsidx ][ i ] ] = clsidx;
}

int count_clashing_literals( int clsidx, int mark )
{
	int i, counter = 0;

	for( i = 0; i < Clength[ clsidx ]; i++ )
	    if( MarkArray[ Cv[ clsidx ][ i ] ] == mark )
		counter++;

	assert( counter > 0 );
	
	return counter;
}

inline int check_subsumed( const int clsidx )
{
	int i, j, h, subsumed, current;

	for( i = 0; i < Clength[ clsidx ]; i++ )
	    for( j = 1; j <= literal_occ[ Cv[ clsidx ][ i ] ][ 0 ]; j++ )
	    {
	    	subsumed = 1;
		current = literal_occ[ Cv[ clsidx ][ i ] ][ j ];
	    	for( h = 0; h < Clength[ current ]; h++ )
		    if( graph_subsume[ Cv[current][h] ] != graph_subsume_stamp )
		    {
		    	subsumed = 0;
		    	break;
		    } 
	    	if( subsumed ) return 1;
	    }
	return 0;
}

int is_subsumed( const int clsidx1, const int clsidx2 )
{
	int i;

	graph_subsume_stamp++;

	for( i = 0; i < Clength[ clsidx1 ]; i++ )
	    graph_subsume[ Cv[ clsidx1 ][ i ] ] = graph_subsume_stamp;

	for( i = 0; i < Clength[ clsidx2 ]; i++ )
	    if( graph_subsume[ -Cv[ clsidx2 ][ i ] ] == graph_subsume_stamp )
	    	graph_subsume[ -Cv[ clsidx2 ][ i ] ] = 0; 
	    else
	    	graph_subsume[ Cv[ clsidx2 ][ i ] ] = graph_subsume_stamp; 

	if( check_subsumed( clsidx1 ) == 1 ) 
	    return 1;
	return check_subsumed( clsidx2 );
}

void add_blocked_binaries( )
{
	int i, j, idx = 0, *resolution_counter, *resolution_index, nrofadditions = 0;

	MALLOC_OFFSET( resolution_counter, int, nrofvars,  0 );
	MALLOC_OFFSET( resolution_index  , int, nrofvars, -1 );

	for( idx = 0; idx < nrofclauses; idx++ )
	    for( j = 0; j < Clength[ idx ] ; j++ )
	    {
		resolution_counter[ Cv[ idx ][ j ] ]++;
		resolution_index  [ Cv[ idx ][ j ] ] = idx;
	    }

	for( i = -nrofvars; i <= nrofvars; i++ )
	{
	    if( resolution_counter[ i ] == 1 )
	    {
		idx = resolution_index[ i ];
		for( j = 0; j < Clength[ idx ]; j++ )
		    if( Cv[ idx ][ j ] != i )
		    {
			resolution_counter[ -Cv[ idx ][ j ] ]++;
			resolution_index  [ -Cv[ idx ][ j ] ] = idx;
			resolution_counter[ -i ]++;
			resolution_index  [ -i ] = idx;
			nrofadditions++;
		    }
	    }
	}

	printf("c nrofadditions = %i\n", nrofadditions ); 

	Cv      = (int**) realloc( Cv,      sizeof(int*) *  ( nrofclauses + nrofadditions ) );
	Clength = (int* ) realloc( Clength, sizeof(int ) *  ( nrofclauses + nrofadditions ) );


	for( i = -nrofvars; i <= nrofvars; i++ )
	{
	    if( resolution_counter[ i ] == 1 )
	    {
		idx = resolution_index[ i ];
		for( j = 0; j < Clength[ idx ]; j++ )
		    if( Cv[ idx ][ j ] != i )
		    {
			Cv     [ nrofclauses ] = (int*)malloc( sizeof(int) * 2);
			Clength[ nrofclauses ] = 2;
			Cv [ nrofclauses][ 0 ] = -i;
			Cv [ nrofclauses][ 1 ] = -Cv[ idx ][ j ];
			nrofclauses++;
		    }
	    }
	}

	FREE_OFFSET( resolution_counter );
	FREE_OFFSET( resolution_index   );
}

void iteratively_remove_blocked_clauses( )
{
	int _removed_blocked_clauses;

	do
	{
	    _removed_blocked_clauses = removed_blocked_clauses;
	    remove_blocked_clauses( );
	    compactCNF( );
	    printf("c found and removed %i (2:%i; n:%i) blocked clauses (+ %i)\n", removed_blocked_clauses, 
		binary_blocked, nary_blocked, removed_blocked_clauses - _removed_blocked_clauses );
	}
	while( removed_blocked_clauses > _removed_blocked_clauses );
}
void remove_blocked_clauses( )
{
	int i;

	candidates = (int*) malloc( sizeof(int) * nrofclauses );
	nrofcandidates = 0;

	allocate_local_datastructures();

	for( i = 1; i <= nrofvars; i++ )
	{
	    check_blocking_literal(  i );
	    check_blocking_literal( -i );
	}

	free_local_datastructures();

	free( candidates );
}

void check_blocking_literal( int nrval )
{
	int i, j;

	nrofcandidates = 0;
	for( i = 1; i <= literal_occ[ nrval ][ 0 ]; i++ )
	    if( Clength[ literal_occ[ nrval ][ i ] ] > 0 )
		candidates[ nrofcandidates++ ] = literal_occ[ nrval ][ i ];

	for( i = 1; i <= literal_occ[ -nrval ][ 0 ]; i++ )
	{
	    if( Clength[ literal_occ[ -nrval ][ i ] ] == 0 ) continue;

	    mark_complement_of_literals( literal_occ[ -nrval ][ i ] );

	    for( j = 0; j < nrofcandidates; j++ )
		if( count_clashing_literals( candidates[j], literal_occ[-nrval][i] ) == 1 )
		    candidates[ j-- ] = candidates[ --nrofcandidates ];

	    if( nrofcandidates == 0 ) break;
	}

	for( j = 0; j < nrofcandidates; j++ )
	{
	    if( Clength[ candidates[ j ] ] == 2 ) 
#ifdef REMOVE_BLOCKED_BINARIES			  
		binary_blocked++;
#else						
		continue;
#endif
	    else	nary_blocked++;

	    removed_blocked_clauses++;
    	    //printf("clause %i is blocked due to literal %i\n", candidates[ j ], nrval);
	    Clength[ candidates[ j ] ] = 0; 
	}
}

void print_components( const int nrofcomponents )
{
	int i, offset = 0, counter;
#ifdef PRINT_COMPONENTS
	int j, current;
#endif
        for( i = 1; i <= nrofcomponents; i++ )
	{
	    counter = 0;
	    do
	    {
#ifdef PRINT_COMPONENTS
		current = clause_order_array[ counter + offset ];
		for( j = 0; j < Clength[ current ]; j++ )
		    printf("%i ", Cv[ current ][ j ] );
		printf("0\n");
#endif
		counter++;
	    }
	    while( (counter + offset < nrofclauses) && (clause_parent[ clause_order_array[ counter + offset ] ] != INITIAL_PARENT) );

	    offset += counter;
	    printf("c component %i has %i clauses\n", i, counter); 
	}
}
void allocate_local_datastructures( )
{
	int i;

	MarkArray = (int*) malloc( sizeof(int) * (2*nrofvars + 1) );
	for( i = 0; i <= (2*nrofvars); i++ )
		MarkArray[ i ] = -1;

	MarkArray += nrofvars;	

	allocateVc( &literal_occ, &literal_lut );
	literal_occ += nrofvars;
}

void free_local_datastructures( )
{
	literal_occ -= nrofvars;
	freeVc( literal_occ, literal_lut );

	MarkArray -= nrofvars;
	free( MarkArray );
}
*/
void compute_sign_balance( )
{
	int i, j, active = 0, *_occurence; 
	double sign_bias = 0, pos, neg;

	_occurence = (int*) malloc( sizeof(int) * (2*nrofvars+1) );
	_occurence += nrofvars;

	for( i = 1; i <= nrofvars; i++ )
	{
	    _occurence[  i ] = 0;
	    _occurence[ -i ] = 0;
	}

	for( i = 0 ; i < nrofclauses; i++ )
	    for( j = 0; j < Clength[ i ]; j++ )
		_occurence[ Cv[i][j] ]++;

	for( i = 0; i <= nrofvars; i++ )
	{
	    pos = (double) _occurence[  i ];
	    neg = (double) _occurence[ -i ];

	    if( (pos > 0) && (neg > 0) )
	    {
		active++;
		sign_bias +=  (pos / neg) + (neg / pos);
	    }
	}

	sign_bias = (sign_bias / active) - 2;

	printf("c stat :: sign balance is biased by %.3f\n", sign_bias );

	_occurence -= nrofvars;	
	free( _occurence );
}
//------------------------------------------------block end --------------------------
//------------------------------------------------model filter begin --------------------------
#define FILTERS 	10
//#define MIN_EQ_SIZE	10
#define MAX_EQ_SIZE	9

int *model_constraint;
int *constraint_stamp;

void add_model_constraint()
{
	int i, lit, eq_size = 0;

#ifdef MIN_EQ_SIZE
	do
	{
	    eq_size = 0;

	    for( i = 1; i <= original_nrofvars; i++ )
		if( rand() % 2 )
		    model_constraint[ eq_size++ ] = i;
		
	}
	while( eq_size < MIN_EQ_SIZE );
#endif
#ifdef MAX_EQ_SIZE
	for( i = 1; i <= MAX_EQ_SIZE; i++ )
	{
	    do
	    {
		lit = rand() % original_nrofvars + 1;
	    }
	    while( IS_FORCED(lit) || constraint_stamp[ lit ] == nrofceq );
	
	    constraint_stamp[ lit ] = nrofceq;
	    model_constraint[ eq_size++ ] = lit;
	}
#endif

        Ceq      [ nrofceq ] = (int*) malloc( sizeof( int ) * eq_size );
        CeqSizes [ nrofceq ] = eq_size;
        CeqValues[ nrofceq ] = (rand() % 2) * 2  - 1;

	for( i = 0; i < eq_size; i++ )
	{
	    Ceq[ nrofceq ][ i ] = model_constraint[ i ];

//	    printf("%i ", model_constraint[ i ] );

            CHECK_VEQ_BOUND( model_constraint[ i ] );
            Veq[ model_constraint[ i ] ][ Veq[ model_constraint[ i ] ][ 0 ]++ ] = nrofceq;
            VeqLUT[ model_constraint[ i ] ][ VeqLUT[ model_constraint[ i ] ][ 0 ]++ ] = i;
	}

//	printf(" = %i\n", CeqValues[ nrofceq ] );

	eq_found[ eq_size ]++;

	nrofceq++;
}

void add_model_constraints()
{
#ifdef MODEL_FILTER
	int i;

	srand( (unsigned)time( NULL ) );

	model_constraint = (int*) malloc( sizeof(int) * nrofvars + 1 );
	constraint_stamp = (int*) malloc( sizeof(int) * nrofvars + 1 );

	for( i = 1; i <= nrofvars; i++ )
	    constraint_stamp[ i ] = -1;

	for( i = 1; i <= FILTERS; i++ )
	    add_model_constraint();

	free( model_constraint );
	free( constraint_stamp );
#endif
}
//------------------------------------------------model filter end --------------------------
//------------------------------------------------distribute begin --------------------------
#define INITIAL_FORCED_ARRAY_SIZE	20
#define INITIAL_RECORD_ARRAY_SIZE	20

#define JUMP_DEPTH			999

#ifdef DISTRIBUTION
int *recorded_literal_array, recorded_literals;
unsigned int record_array_size, recorded_nodes;
int *forced_array, forced_array_size, forced_elements;
int bin_mask = 0, current_bin = 0;

void fill_distribution_bins();

void init_direction()
{
	current_record  = 0;
	recorded_nodes  = 0;
	forced_elements = 0;
	jump_depth      = JUMP_DEPTH;
#ifdef SUBTREE_SIZE
	jump_depth 	= 0;
#endif
#ifdef CUT_OFF
	jump_depth 	= CUT_OFF;
#endif
	forced_array_size = INITIAL_ARRAY_SIZE;
	forced_array = (int*) malloc( sizeof(int) * forced_array_size );

	record_array_size = INITIAL_RECORD_ARRAY_SIZE;
	records = (struct record*) malloc( sizeof(struct record) * record_array_size );

	records[0].branch_literal = 0;
	records[0].forced_offset  = 0;
	records[0].nrofforced     = 0;
	records[0].child[0]       = 0;
	records[0].child[1]       = 0;
	records[0].UNSAT_flag     = 0;
#ifdef CUT_OFF
	fill_distribution_bins();
#endif
}

int init_new_record()
{
	if( (depth > jump_depth) && (jump_depth > 0) ) return 0;

	recorded_nodes++;
	current_record = recorded_nodes;

	if( record_array_size <= recorded_nodes )
	{
	    //record_array_size += (unsigned int)(0.5 * record_array_size);
	 	int delta=(record_array_size/2); 
		if(delta>200000) delta=200000;
		record_array_size += delta; // bug
		records = (struct record*) realloc( records, sizeof(struct record) * record_array_size );
	}

	records[ recorded_nodes ].branch_literal = 0;
	records[ recorded_nodes ].forced_offset  = 0;
	records[ recorded_nodes ].nrofforced     = 0;
	records[ recorded_nodes ].child[0]       = 0;
	records[ recorded_nodes ].child[1]       = 0;
	records[ recorded_nodes ].UNSAT_flag     = 1;

	return recorded_nodes;
}

int fix_recorded_literals( int record_index )
{
	if( record_index == 0 ) 		 return SAT;
	if( records[ record_index ].UNSAT_flag ) return UNSAT;

	records[ record_index ].UNSAT_flag = 1;

        set_recorded_literals( record_index );
        if( IFIUP( 0, FIX_RECORDED_LITERALS ) == UNSAT )
            return UNSAT;

	return SAT;
}

void record_node( const int record_index, int record_literal, const int skip_left, const int skip_right )
{
        if( (depth < jump_depth) )	// || jump_depth == 0??
        {
            if( (skip_left == 0) && (records[ record_index ].child[ record_literal > 0 ] == 0) )
	    {
		int tmp =  init_new_record();
                records[ record_index ].child[ record_literal > 0 ] = tmp;
	    }

            if( (skip_right == 0) && (records[ record_index ].child[ record_literal < 0 ] == 0) )
	    {
		int tmp =  init_new_record();
                records[ record_index ].child[ record_literal < 0 ] = tmp;
	    }

            struct record *node = &records[ record_index ];
	    node->UNSAT_flag = records[ node->child[0] ].UNSAT_flag &
			       records[ node->child[1] ].UNSAT_flag;
        }
	else records[ record_index ].UNSAT_flag = (depth == jump_depth);

        if( (record_index > 0) &&
            ((depth < jump_depth)) &&  // || jump_depth == 0?
            (records[ record_index ].branch_literal == 0) &&
            (records[ record_index ].UNSAT_flag     == 0) )
	{
	    int *_rstackp = rstackp;
	    struct record *node  = &records[ record_index ];

	    if( TOP_OF_TREE ) record_literal *= -1;

	    node->branch_literal = record_literal;
	    node->forced_offset  = forced_elements;

	    check_forced_array_capacity();

	    while( *(--_rstackp) != STACK_BLOCK )
	    {	forced_array[ forced_elements++ ] = *(_rstackp);    }

	    node->nrofforced = forced_elements - node->forced_offset;
	}
}

void check_forced_array_capacity()
{
	if( forced_elements + freevars > forced_array_size )
	{
	    forced_array_size *= 2;
	    forced_array_size += freevars;
	    forced_array = (int*) realloc( forced_array, sizeof(int) * forced_array_size );
	}
}

void set_recorded_literals( int record_index )
{
	recorded_literal_array = &forced_array[records[record_index].forced_offset];
	recorded_literals = records[record_index].nrofforced;
}

void get_recorded_literals( int **_forced_literal_array, int *_forced_literals )
{
        *_forced_literal_array = recorded_literal_array;
        *_forced_literals      = recorded_literals;
}

#ifdef CUT_OFF
/*************************
	 the procedure fill distribution_bin create a mapping 
	 for a fixed JUMP DEPTH given a explicit jumping strategy
*************************/
int current_rights = 0;

void fill_distribution_bins_rec()
{
	if( depth == CUT_OFF )
	{
	    if( current_rights == target_rights )
		bins[ bin_mask ] = current_bin++;
	    return;
	}

	depth++;
#ifdef OPPOSITE_DIRECTION
	bin_mask ^= 1 << (CUT_OFF - depth);
	current_rights++;
#endif
	fill_distribution_bins_rec();
#ifdef OPPOSITE_DIRECTION
	bin_mask ^= 1 << (CUT_OFF - depth);
	current_rights--;
#endif
#ifndef OPPOSITE_DIRECTION
	bin_mask ^= 1 << (CUT_OFF - depth);
	current_rights++;
#endif
	fill_distribution_bins_rec();
#ifndef OPPOSITE_DIRECTION
	bin_mask ^= 1 << (CUT_OFF - depth);
	current_rights--;
#endif
	depth--;	
}
void fill_distribution_bins()
{
        target_rights  = 0;
        current_rights = 0;

	bins = (int*) malloc( sizeof(int) * (1<<CUT_OFF) );

        do
        {
	    fill_distribution_bins_rec();	    
            target_rights++;
        }
        while( target_rights <= CUT_OFF );
}
#endif

#endif
//------------------------------------------------distribution end --------------------------



