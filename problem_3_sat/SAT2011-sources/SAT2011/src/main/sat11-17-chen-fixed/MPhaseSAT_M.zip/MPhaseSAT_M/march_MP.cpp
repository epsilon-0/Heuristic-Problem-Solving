#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "march.h"
#include "march_common.h"
#include "march_var.h"

int equivalence_reasoning();
void init_equivalence();
int initSolver();
void disposeSolver();
int distribution_branching();

void compute_sign_balance( );
void initFormula();
int parseCNF( FILE* in );
void disposeFormula();

int check_kSAT();
void TransformFormula();

int resolvent_look();
/*
void handleUNSAT()
{
	printf( "c main():: nodeCount: %i\n", nodeCount );
	printf( "c main():: time=%f\n", ((float)(clock()))/CLOCKS_PER_SEC );
   	printf( "s UNSATISFIABLE\n" );
	disposeFormula();
	exit( EXIT_CODE_UNSAT);
}
*/

void getSolution( const int orignrofvars, int *solution )
{
	int i;
	for( i = 1; i <= orignrofvars; i++ ){
		if(timeAssignments[ i ] ==  VARMAX) solution[i]=i;
		else if( timeAssignments[ i ] == (VARMAX + 1) ) solution[i]=-i;
	}
}

extern int local_find_tries, local_find_steps; 
//extern bool localfind;
void  getlocalsolution(int *solution);
int Local_search(int &tries,int & steps);
bool goodsolution;
extern int main_SAT;
		
//0: unkown, 1:SAT, -1: UNSAT
int mix_march_solve(int *Solution)
{
	int result,exitcode;
	result   = UNKNOWN;
	int unsatcode=-1;
	int satcode=1;
    int unkown=0;
	goodsolution=false;
   // float starttime=((float)(clock()))/CLOCKS_PER_SEC;

	printf( "c switch to march \n");

   	initFormula();
	init_equivalence();

	if( simplify_formula() == UNSAT )
	{
		disposeFormula();
		return unsatcode;
	}
//    printf( "c preprocessing phase I completed:: there are now %i free variables and %i clauses.\n", freevars, nrofclauses );
	compute_sign_balance();
	if( equivalence_reasoning() == UNSAT )	return unsatcode; //handleUNSAT();

	kSAT_flag = check_kSAT();

//	if( kSAT_flag )	printf("c using k-SAT heuristics (size based diff)\n");
//	else		printf("c using 3-SAT heuristics (occurence based diff)\n");

#ifndef TERNARYLOOK
	if( resolvent_look() == UNSAT ) return unsatcode; //handleUNSAT();
#endif
	TransformFormula();
    //printf( "c clause / variable ratio: ( %i / %i ) = %.2f\n", nrofclauses, nrofvars, (double) nrofclauses / nrofvars );

	depth                 = 0;   
    nodeCount             = 0;
    lookAheadCount        = 0;
    unitResolveCount      = 0;
	necessary_assignments = 0;

	if( initSolver() )
	{
#ifdef PROGRESS_BAR
		pb_init( 6 );
#endif
		result = distribution_branching();
//#ifdef PROGRESS_BAR
//		pb_dispose();
//#endif
	}
	else
	{
	//	printf( "c main():: conflict caused by unary equivalence clause found.\n" );
		result = UNSAT;
	}
/*
    printf( "c main():: nodeCount: %i\n", nodeCount );
	printf( "c main():: dead ends in main: %i\n", mainDead );
    printf( "c main():: lookAheadCount: %i\n", lookAheadCount );
    printf( "c main():: unitResolveCount: %i\n", unitResolveCount );
	printf( "c main():: necessary_assignments: %i\n", necessary_assignments );
	printf( "c main():: bin_sat: %i, bin_unsat %i\n", bin_sat, bin_unsat );
#ifdef DOUBLELOOK
	printf( "c main():: doublelook: #: %d, succes #: %d\n", (int) doublelook_count, (int) (doublelook_count - doublelook_failed) );
	printf( "c main():: doublelook: overall %.3f of all possible doublelooks executed\n", 
		100.0 * dl_actual_counter / (double) dl_possibility_counter );
 	printf( "c main():: doublelook: succesrate: %.3f, average DL_trigger: %.3f\n", 100.0 - 
		(100.0 * doublelook_failed / doublelook_count), DL_trigger_sum / doublelook_count );
#endif
*/
    //printf( "c time=%f\n", ((float)(clock()))/CLOCKS_PER_SEC-starttime);
	switch( result )
	{
	    case SAT:
	    	if(!goodsolution) getSolution(original_nrofvars, Solution);
		    exitcode = satcode;
		    break;
	    case UNSAT: exitcode = unsatcode; break;
	    default: exitcode = unkown; 
    }

	disposeSolver();
	disposeFormula();
    return exitcode;
}
