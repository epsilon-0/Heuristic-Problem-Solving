#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

#include "march_common.h"
#include "march_extvar.h"

void allocate_big_clauses_datastructures();

int check_kSAT();
void TransformFormula();
void transformTo3SAT();
void lessRedundantTransformation();
void initialiseBinaryImp();
void compensateTransformation();
void branch_on_dummies_from_long_clauses();
void resize_BinaryImp();

#define VARLRT( __a )   ( __a + nrofLRTvars )

#define MAXPAIR         1

/*
	The procedures in this file translate the formula in Cv in such
	a way that the maximum clause length after translation is three.
	The resulted formula is placed in Cv.
*/

int check_kSAT()
{
	int i;

	for( i = 0; i < nrofclauses; i++ )
	    if( Clength[ i ] > 3 )
		return 1;
	
	return 0;
}

void TransformFormula()
{
	if( kSAT_flag )		allocate_big_clauses_datastructures();
	else
	{
	    lessRedundantTransformation();
	    transformTo3SAT();
	    compensateTransformation();
	}
}

void transformTo3SAT()
{
	int 	i, j, **_Cv, *_dummy, *_Clength;
	int 	b, e, delta, clen, max_clen, cp, min_unsat_counter;
	delta = 0;
	max_clen = 0;
	min_unsat_counter = 0;

	for( i = 0; i < nrofclauses; i++ )
	{
	    if( Clength[ i ] > max_clen )
		max_clen = Clength[ i ];

#ifdef MIN_UNSAT_TRANSLATION
	    if( Clength[ i ] >= 8 ) 
	    {
		min_unsat_counter += Clength[ i ];
		continue;
	    }
#endif
	    if( Clength[ i ] > 3 )
		delta += Clength[ i ] - 3;
	}

	printf( "c transformTo3SAT():: you gave me %i variables and %i clauses.\n", nrofvars, nrofclauses );
	printf( "c transformTo3SAT():: by the way, the maximal clause length before transformation was %i.\n", max_clen );

#ifdef CHAINPLUS
	printf( "c transformTo3SAT():: CHAINPLUS defined.\n" );
	printf( "c transformTo3SAT():: I will add %i variables and %i clauses!\n", delta, delta * 3 + min_unsat_counter );
	_Cv = (int**) malloc( sizeof( int* ) * ( nrofclauses + ( delta * 3 ) + min_unsat_counter) );
	_Clength = (int*) malloc( sizeof( int ) * ( nrofclauses + ( delta * 3 ) + min_unsat_counter ) );
#else
	printf( "c transformTo3SAT():: I will add %i variables and %i clauses!\n", delta, delta + min_unsat_counter );
	_Cv = (int**) malloc( sizeof( int* ) * ( nrofclauses + delta + min_unsat_counter ) );
	_Clength = (int*) malloc( sizeof( int ) * ( nrofclauses + delta + min_unsat_counter) );
#endif

	/* dummy array needed for transformation. */
	_dummy = (int*) malloc( sizeof( int ) * max_clen * 2 );
	
	cp = 0;
	for( i = 0; i < nrofclauses; i++ )
	{
	    clen = Clength[ i ];

	    /* eliminate 0-clauses from formula!! */
	    /* 1-clauses shouldn't be there! */
	    if( (clen == 0) || (clen == 1) )
	    {
		continue;
	    }
	    else if( (clen == 2) || (clen == 3) )
	    {
		_Cv     [ cp ] = Cv     [ i ];
		_Clength[ cp ] = clen;
		cp++;
	    }
	    else
	    {
		/* copy clause to _dummy */
		for( j = 0; j < clen; j++ ) _dummy[ j ] = Cv[ i ][ j ];

#ifdef MIN_UNSAT_TRANSLATION
		if( clen >= 8 )
		{
		    int first_dummy = ++nrofvars;

		    printf("translating clause: ");
		    for( j =0; j < clen; j++ ) printf("%i ", Cv[ i ][ j ]);
		    printf("\n");

		    for( j = 0; j < (clen-1)/2 ; j++ )
		    {
			nrofvars++;

			printf("adding cluase: %i %i %i\n", _dummy[ 2*j] , nrofvars - 1, -nrofvars );
			printf("adding cluase: %i %i %i\n", _dummy[ 2*j + 1] , -nrofvars + 1, nrofvars );

			_Cv[ cp ] = (int*) malloc( sizeof( int ) * 3 );
			_Cv[ cp ][ 0 ] = _dummy[ 2*j ];
			_Cv[ cp ][ 1 ] = nrofvars - 1;
			_Cv[ cp ][ 2 ] = -nrofvars;
			_Clength[ cp ] = 3;
			cp++;

			_Cv[ cp ] = (int*) malloc( sizeof( int ) * 3 );
			_Cv[ cp ][ 0 ] = _dummy[ 2*j + 1 ];
			_Cv[ cp ][ 1 ] = -nrofvars + 1;
			_Cv[ cp ][ 2 ] = nrofvars;
			_Clength[ cp ] = 3;
			cp++;

		    }

		    if( (clen %2) == 0 )
			printf("adding cluase: %i %i %i\n", _dummy[ clen - 2] , -first_dummy, -nrofvars );
		    else
			printf("adding cluase: %i %i %i\n", _dummy[ clen - 1] , -first_dummy, -nrofvars );


		    _Cv[ cp ] = (int*) malloc( sizeof( int ) * 3 );
		    if( (clen % 2) == 0 )
			_Cv[ cp ][ 0 ] = _dummy[ clen - 2 ];
		    else
			_Cv[ cp ][ 0 ] = _dummy[ clen - 1 ];
		    _Cv[ cp ][ 1 ] = -first_dummy;
		    _Cv[ cp ][ 2 ] = -nrofvars;
		    _Clength[ cp ] = 3;
		    cp++;

		    printf("adding cluase: %i %i %i\n", _dummy[ clen - 1] , first_dummy, nrofvars );

		    _Cv[ cp ] = (int*) malloc( sizeof( int ) * 3 );
		    _Cv[ cp ][ 0 ] = _dummy[ clen - 1 ];
		    _Cv[ cp ][ 1 ] = first_dummy;
		    _Cv[ cp ][ 2 ] = nrofvars;
		    _Clength[ cp ] = 3;
		    cp++;

		    continue;
	        }
#endif
			b = 0;
			e = clen;
			while( b < (e - 3) )
			{	
				_Cv[ cp ] = (int*) malloc( sizeof( int ) * 3 );
				_Cv[ cp ][ 0 ] = _dummy[ b ];
				_Cv[ cp ][ 1 ] = _dummy[ b + 1 ];
				_Cv[ cp ][ 2 ] = -( ++nrofvars );
				_Clength[ cp ] = 3;
				cp++;
				
#ifdef CHAINPLUS
				/*
					A v B v ~X, but also:
					X v ~A and X v ~B
				*/

				_Cv[ cp ] = (int*) malloc( sizeof( int ) * 2 );
				_Cv[ cp ][ 0 ] = -_dummy[ b ];
				_Cv[ cp ][ 1 ] = nrofvars;
				_Clength[ cp ] = 2;
				cp++;

				_Cv[ cp ] = (int*) malloc( sizeof( int ) * 2 );
				_Cv[ cp ][ 0 ] = -_dummy[ b + 1 ];
				_Cv[ cp ][ 1 ] = nrofvars;
				_Clength[ cp ] = 2;
				cp++;
#endif				
				b += 2;
				_dummy[ e++ ] = nrofvars;
			}
	
			_Cv[ cp ] = (int*) malloc( sizeof( int ) * 3 );
			_Cv[ cp ][ 0 ] = _dummy[ b     ];
			_Cv[ cp ][ 1 ] = _dummy[ b + 1 ];
			_Cv[ cp ][ 2 ] = _dummy[ b + 2 ];
			_Clength[ cp ] = 3;
			cp++;

			free( Cv[ i ] );
		}
	}

	free( _dummy );
	free( Clength );
	Clength = _Clength;

	free( Cv );
	Cv = _Cv;

	printf( "c transformTo3SAT():: the transformation yielded %i variabels and %i clauses.\n", nrofvars, nrofclauses );
	nrofclauses = cp;
}

void lessRedundantTransformation()
{
	int **_Vc, *_VcTemp, **_Cv, *_Clength, *freq, A, B, X, maxPairs;
	int i, j, max, nrofvarsIn, nrofLRTvars, nrofLRTclauses, delta;
	int lit, posA, posB, clsidx, VA, VB, VX, last;

	A = 0;
	
	delta = 0;
	for( i = 0; i < nrofclauses; i++ )
		if( Clength[ i ] > 3 )
			delta += Clength[ i ] - 3;

	if( delta == 0 )
	{
		printf( "c lessRedundantTransformation():: nothing to be done.\n" );
		return;
	}

	nrofvarsIn     = nrofvars;		//wordt niet meer gebruikt?
	nrofLRTvars    = nrofvars + delta;
	nrofLRTclauses = 0;
	
#ifdef CHAINPLUS
	printf( "c lessRedundantTransformation():: CHAINPLUS defined.\n" );
	_Cv = (int**) malloc( sizeof( int* ) * delta * 3 );
	_Clength = (int*) malloc( sizeof( int ) * delta * 3 );
#else
	_Cv = (int**) malloc( sizeof( int* ) * delta );
	_Clength = (int*) malloc( sizeof( int ) * delta );
#endif
	freq = (int*) malloc( sizeof( int ) * ( 2 * nrofLRTvars + 1 ) );
		
	/*
		Create a Vc for clauses longer than 3 literals.
	*/
        _VcTemp = (int*) malloc( sizeof( int ) * ( 2 * nrofLRTvars + 1 ) );
        for( i = 0; i <= 2 * nrofLRTvars; i++ ) _VcTemp[ i ] = 1;

        _Vc = (int**) malloc( sizeof( int* ) * ( 2 * nrofLRTvars + 1 ) );
        for( i = 0; i <= 2 * nrofLRTvars; i++ ) _Vc[ i ] = NULL;

        for( i = 0; i < nrofclauses; i++ )
		if( Clength[ i ] > 3 )
	                for( j = 0; j < Clength[ i ]; j++ )
        	                _VcTemp[ VARLRT( Cv[ i ][ j ] ) ]++;

        /* allocate space... */
	for( i = ( nrofLRTvars - nrofvars ); i <= ( nrofLRTvars + nrofvars ); i++ )
        {
	    _Vc[ i ] = (int*) malloc( sizeof( int ) * _VcTemp[ i ] );
            _Vc[ i ][ 0 ] = _VcTemp[ i ] - 1;

            _VcTemp[ i ] = 1;
        }

        for( i = 0; i < nrofclauses; i++ )
	    if( Clength[ i ] > 3 )
		for( j = 0; j < Clength[ i ]; j++ )
		{
       	             lit = VARLRT( Cv[ i ][ j ] );
                     _Vc[ lit ][ _VcTemp[ lit ]++ ] = i;
		}

	free( _VcTemp );
	do
	{
		//	Find the most occuring literal.
		max = 0;
		for( i = ( nrofLRTvars - nrofvars ); i <= ( nrofLRTvars + nrofvars ); i++ )
			if( _Vc[ i ][ 0 ] >= max )
			{
				max = _Vc[ i ][ 0 ];
				A = i - nrofLRTvars;
			}

		last = 0;
		B = A;
	
		do
		{
			last = A;
			A = B;

			for( i = 0; i <= 2 * nrofLRTvars; i++ )
				freq[ i ] = 0;

			for( i = 1; i <= _Vc[ VARLRT( A ) ][ 0 ]; i++ )
			{
				clsidx = _Vc[ VARLRT( A ) ][ i ];
				for( j = 0; j < Clength[ clsidx ]; j++ )
					freq[ VARLRT( Cv[ clsidx ][ j ] ) ]++;
			}

			//	Find the literal which occurs the most with literal A.
			maxPairs = 1;
			for( i = ( nrofLRTvars - nrofvars ); i <= ( nrofLRTvars + nrofvars ); i++ )
				if( ( i != VARLRT( A ) ) && ( freq[ i ] >= maxPairs ) )
				{
					maxPairs = freq[ i ];
					B = i - nrofLRTvars;
				}

		}
		while( last != B );
		
		if( maxPairs > MAXPAIR )
		{
			//	Create new variable.
			X = ++nrofvars;
			VA = VARLRT( A );
			VB = VARLRT( B );
			VX = VARLRT( X );

			_Vc[ VX ] = (int*) malloc( sizeof( int ) * ( maxPairs + 1 ) );
			_Vc[ VX ][ 0 ] = 0;

			_Vc[ VARLRT( -X ) ] = (int*) malloc( sizeof( int ) );
			_Vc[ VARLRT( -X ) ][ 0 ] = 0;

			for( i = 1; i <= _Vc[ VA ][ 0 ]; i++ )
			{
				clsidx = _Vc[ VA ][ i ];
				posA = posB = -1;
				for( j = 0; j < Clength[ clsidx ]; j++ )
				{
					if( Cv[ clsidx ][ j ] == A )
					{
						posA = j;
					}
					else if( Cv[ clsidx ][ j ] == B )
					{	
						posB = j;
					}
				}
				if( posB >= 0 )
				{
					Cv[ clsidx ][ posB ] = X;

					if( posB == ( Clength[ clsidx ] - 1 ) )
						posB = posA;

					Cv[ clsidx ][ posA ] = Cv[ clsidx ][ Clength[ clsidx ] - 1 ];
					Clength[ clsidx ]--;

					//	Swap clause clsidx out of _Vc[ VARLRT( A ) ].
					_Vc[ VA ][ i ] = _Vc[ VA ][ _Vc[ VA ][ 0 ]-- ];

					for( j = 1; j <= _Vc[ VB ][ 0 ]; j++ )
						if( _Vc[ VB ][ j ] == clsidx )
							break;

					//	Swap clause clsidx out of _Vc[ VARLRT( B ) ].
					_Vc[ VB ][ j ] = _Vc[ VB ][ _Vc[ VB ][ 0 ]-- ];
							

					if( Clength[ clsidx ] > 3 )
					{
						_Vc[ VX ][ ++_Vc[ VX ][ 0 ] ] = clsidx;
					}
					else
					{
						//	Remove the other two literals.
						lit = VARLRT( Cv[ clsidx ][ ( posB + 1 ) % 3 ] );
						for( j = 1; j <= _Vc[ lit ][ 0 ]; j++ )
                		                if( _Vc[ lit ][ j ] == clsidx )
                                		        break;
						_Vc[ lit ][ j ] = _Vc[ lit ][ _Vc[ lit ][ 0 ]-- ];

						lit = VARLRT( Cv[ clsidx ][ ( posB + 2 ) % 3 ] );
						for( j = 1; j <= _Vc[ lit ][ 0 ]; j++ )
                		                if( _Vc[ lit ][ j ] == clsidx )
                                		        break;
						_Vc[ lit ][ j ] = _Vc[ lit ][ _Vc[ lit ][ 0 ]-- ];
					}

					i--;
				}
			}

			_Cv[ nrofLRTclauses ] = (int*) malloc( sizeof( int ) * 3 );
			_Clength[ nrofLRTclauses ] = 3;
			_Cv[ nrofLRTclauses ][ 0 ] = A;
			_Cv[ nrofLRTclauses ][ 1 ] = B;
			_Cv[ nrofLRTclauses ][ 2 ] = -X;
			nrofLRTclauses++;
#ifdef CHAINPLUS
			_Cv[ nrofLRTclauses ] = (int*) malloc( sizeof( int ) * 2 );
			_Clength[ nrofLRTclauses ] = 2;
			_Cv[ nrofLRTclauses ][ 0 ] = X;
			_Cv[ nrofLRTclauses ][ 1 ] = -A;
			nrofLRTclauses++;

			_Cv[ nrofLRTclauses ] = (int*) malloc( sizeof( int ) * 2 );
			_Clength[ nrofLRTclauses ] = 2;
			_Cv[ nrofLRTclauses ][ 0 ] = X;
			_Cv[ nrofLRTclauses ][ 1 ] = -B;
			nrofLRTclauses++;
#endif
		}
	}
	while( maxPairs > MAXPAIR );

	Cv = (int**) realloc( Cv, sizeof( int* ) * ( nrofclauses + nrofLRTclauses ) );
	Clength = (int*) realloc( Clength, sizeof( int ) * ( nrofclauses + nrofLRTclauses ) );

	for( i = 0; i < nrofLRTclauses; i++ )
	{
		Cv     [ nrofclauses ] = _Cv     [ i ];
		Clength[ nrofclauses ] = _Clength[ i ];
		nrofclauses++;
	}
	
	for( i = 0; i <= ( 2 * nrofLRTvars ); i++ )
	{
		if( _Vc[ i ] != NULL ) free( _Vc[ i ] );
	}
	free( _Vc );

	free( _Cv );
	free( _Clength );
	free( freq );

	/*
		Resize global data structures.
	*/

	printf( "c lessRedundantTransformation():: the transformation yielded %i variables and %i clauses.\n", nrofvars, nrofclauses );
}	


void compensateTransformation()
{
	/*
		Completed resizing global datastructures.
	*/

	/* This procedure has to compensate the fact that due to the 
	transformation the number of variables has increased and therefore
	some data-structures have to be reallocated.*/

	int i; 
	tstamp *_timeAssignments;

        _timeAssignments = (tstamp*) malloc( sizeof(tstamp) * (2 * nrofvars + 1) );
	VeqDepends      = (int*)    realloc( VeqDepends, sizeof( int  ) * ( nrofvars + 1 ) );
	Veq             = (int**)   realloc( Veq,        sizeof( int* ) * ( nrofvars + 1 ) );
	VeqLUT          = (int**)   realloc( VeqLUT,     sizeof( int* ) * ( nrofvars + 1 ) );
	VeqLength       = (int *)   realloc( VeqLength,  sizeof( int  ) * ( nrofvars + 1 ) );

	for( i = (original_nrofvars + 1); i < (nrofvars + 1); i++ )
	{
		Veq   [ i ]          = (int*) malloc( sizeof( int ) * 2 );
		VeqLUT[ i ]          = (int*) malloc( sizeof( int ) * 2 );
		Veq   [ i ][ 0 ]     = 1;
		VeqLength [ i ]      = 2;
		VeqLUT[ i ][ 0 ]     = 1;
#ifdef LOOKAHEAD_ON_DUMMIES
		VeqDepends[ i ]      = 0;
#else
		VeqDepends[ i ]      = DUMMY;
#endif
	}

	for( i = 0; i < (2 * nrofvars + 1); i++ )
	    _timeAssignments[ i ] = 0; 
	_timeAssignments += nrofvars;

	for( i = 0; i < (original_nrofvars + 1); i++ )
	{
	    _timeAssignments[  i ] = timeAssignments[  i ]; 
	    _timeAssignments[ -i ] = timeAssignments[ -i ];
	}

	timeAssignments -= original_nrofvars;
	free( timeAssignments );

	timeAssignments = _timeAssignments;

	resize_BinaryImp( );
}

void branch_on_dummies_from_long_clauses( )
{
	int i, j;
 
	for( i = original_nrofvars + 1; i <= nrofvars; i++ )
	{
            for( j = 0; j < TernaryImpSize[ i]; j++ )
            {
                if( NR(TernaryImp[i][ 2*j    ]) > original_nrofvars ) { VeqDepends[ i ] = INDEPENDENT; return; }
                if( NR(TernaryImp[i][ 2*j + 1]) > original_nrofvars ) { VeqDepends[ i ] = INDEPENDENT; return; }
            }

            for( j = 0; j < TernaryImpSize[-i]; j++ )
            {
                if( NR(TernaryImp[-i][ 2*j    ]) > original_nrofvars ) { VeqDepends[ i ] = INDEPENDENT; return; }
                if( NR(TernaryImp[-i][ 2*j + 1]) > original_nrofvars ) { VeqDepends[ i ] = INDEPENDENT; return; }
            }
        }
}
