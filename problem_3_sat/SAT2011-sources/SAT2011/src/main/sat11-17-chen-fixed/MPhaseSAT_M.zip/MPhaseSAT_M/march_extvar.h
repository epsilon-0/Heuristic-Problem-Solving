#ifndef __MARCH_EXTVAR_H__
#define __MARCH_EXTVAR_H__

/*
        --------------------------------------------------------------------------------------------------------------
        ------------------------------------------------[ variables ]-------------------------------------------------
        --------------------------------------------------------------------------------------------------------------
*/

#ifdef GLOBAL_AUTARKY
extern int *clause_reduction, *clause_red_depth;
extern int *clause_SAT_flag;
extern int **big_to_binary, *btb_size, *big_global_table;
#endif

#ifdef PARALLEL
extern int para_depth;
extern int para_bin;
#endif

extern float *hiRank, *clause_weight, *hiSum;
extern int kSAT_flag;
extern int dist_acc_flag; 

// used for big clauses and resolvent_look
extern int *literal_list, **clause_list, *clause_length, **clause_set, *clause_database, *big_occ;
extern int nrofbigclauses;

#ifdef LONG_LOOK
extern int ll_conflicts;
#endif
#ifdef DISTRIBUTION
extern int target_rights, current_rights;
#ifdef CUT_OFF
extern int *bins;
#endif
#endif


extern int jump_depth;

extern int percent;
extern float *Rank;
extern int Rank_trigger;
extern float *diff, *_diff, *size_diff, *diff_tmp, *_diff_tmp, **diff_depth, *diff_table;
extern int initial_freevars;

extern double percentage_forced;

#ifdef PLOT
extern  double sum_plot;
extern  int count_plot;
#endif

extern int *dpll_fixstackp, *end_fixstackp;

extern int64 dl_possibility_counter, dl_actual_counter;

extern int *TernaryImpReduction;

extern int tree_elements;

/* doublelook statistics */

extern float DL_trigger, DL_trigger_sum;
extern int64 doublelook_count, doublelook_failed;

extern int bin_sat, bin_unsat;
extern int non_tautological_equivalences;

/* solver AND lookahead AND pre-selection */

extern int **TernaryImp, *TernaryImpSize, *tmpTernaryImpSize;
extern int *lookaheadArray, lookaheadArrayLength;
extern int *bImp_satisfied;
extern int *bImp_start;

extern double *lengthWeight;

extern int *freevarsArray;

extern int *preBieq, preBieqSize;

/* statistics */
extern int nrofvars, nrofclauses, nrofceq, nroforigvars;
extern int original_nrofvars, original_nrofclauses;
extern int freevars, depth;

extern int **Ceq, **Veq, **VeqLUT, *CeqValues, *CeqSizes, *CeqSizes2, *CeqSizesNA;
extern int *CeqStamps;									//KAN BETER char* CeqFlag WORDEN
extern int *CeqDepends, *VeqDepends;
extern int *VeqLength;
extern int *CeqSizes1, *CeqValues1;
extern int *eq_found;

/* data structure */
extern tstamp current_node_stamp;
extern tstamp *timeAssignments, *node_stamps;
extern int **Cv, *Clength, **BinaryImp, *BinaryImpLength;

/* various stacks */
extern int *rstack, *rstackp, rstackSize;
extern int *look_fixstack, *look_fixstackp, look_fixstackSize;
extern int *look_resstack, *look_resstackp, look_resstackSize;
extern int *subsumestack,  *subsumestackp,  subsumestackSize;
extern int *bieqstack,  *bieqstackp,  bieqstackSize;
extern int *impstack,   *impstackp,   impstackSize;

/* lookahead */
extern int *forced_literal_array, forced_literals;
extern tstamp currentTimeStamp;
extern int iterCounter;

extern struct treeNode *treeArray;

/* accounting */
extern int nodeCount;
extern int lookAheadCount;
extern int unitResolveCount;
extern int necessary_assignments;
extern int lookDead, mainDead;

extern int efcount;
extern int *org_size;

#endif
