#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <limits.h>
//#include <conio.h>
#include "Multiflip.h"
#include "constants.h"
#include "MersenneTwister.h"

extern MTRand mtrand;

// for each var
int **neg_in,**pos_in;
int *neg_nb,*pos_nb;
my_type *var_value;
my_type *var_state;
int *flip_time;
int **neibor;
int *score;
int *tmp_score;
char *mark;
int *pattern;
int *prevpat;
int *candiVar;
int multilen;
int minocc,maxocc;
int minUnsat;
int minPos;

int *neibor_stack;
int neibor_stack_fill_pointer=0;

int *decreasing_vars_stack;
int decreasing_vars_stack_fill_pointer=0;

int *unitvar_STACK;
int unitvar_STACK_fill_pointer=0;

//for each clause
int **sat;
my_type *clause_state;
//my_type *clause_length;
int *most_recent;
int *most_recent_count;
//double *counter;
//double max_counter, ave_counter;
int64 *counter;
int64 max_counter, ave_counter;


int MY_CLAUSE_STACK_fill_pointer=0;
int *MY_CLAUSE_STACK;

int *index_in_MY_CLAUSE_STACK;

int *nb_lit_true;

int MAXTRIES=10000;
int MAXSTEPS=2000000000;
int NOISE=50;
int NOISE1=50;
int LNOISE=5;
extern int numatom;     // var #
extern int numClauses;  // clause #

unsigned int SEED=1;
int SEED_FLAG=FALSE;

void initNoise();
void adaptNoveltyNoise(int flip);
int verify_sol_input(char *input_file);
void freelocalsearch();
int numVarlocal;
int local_find_mem_flag;

void  getlocalsolution(int *solution)
{
	for (int vv =1; vv <= numatom; vv++) {
		if(var_value[vv]>0) solution[vv]=vv;
		else solution[vv]=-vv;
	 }
 	 freelocalsearch();
}

void allocMem()
{   numVarlocal=numatom+1;
    int numclause=numClauses+1;

	if(local_find_mem_flag==1) freelocalsearch();
    local_find_mem_flag=1;
//	counter=(double *)malloc(numVarlocal* sizeof(double));
	counter=(int64 *)malloc(numVarlocal* sizeof(int64));
    neg_in=(int **)malloc(numVarlocal* sizeof(int *));
    pos_in=(int **)malloc(numVarlocal* sizeof(int *));
	neg_nb=(int *)malloc(numVarlocal* sizeof(int));
	pos_nb=(int *)malloc(numVarlocal* sizeof(int));
    var_value=(int *)calloc (numVarlocal, sizeof(int));
    var_state=(int *)malloc(numVarlocal* sizeof(int));
    
	flip_time=(int *)malloc(numVarlocal* sizeof(int));
    neibor_stack=(int *)malloc(numVarlocal* sizeof(int));
    neibor=(int **)malloc(numVarlocal* sizeof(int *));
    score=(int *)malloc(numVarlocal* sizeof(int));
    tmp_score=(int *)malloc(numVarlocal* sizeof(int));
    decreasing_vars_stack=(int *)malloc(numVarlocal* sizeof(int));
	unitvar_STACK=(int *)malloc(numVarlocal*sizeof(int));
    mark=(char *)calloc (numVarlocal, sizeof(char));
  
	clause_state=(int *)malloc(numclause* sizeof(int));
	most_recent=(int *)malloc(numclause* sizeof(int));
	most_recent_count=(int *)malloc(numclause* sizeof(int));
	MY_CLAUSE_STACK=(int *)malloc(numclause* sizeof(int));
	nb_lit_true=(int *)malloc(numclause* sizeof(int));
	index_in_MY_CLAUSE_STACK=(int *)malloc(numclause* sizeof(int));
}

void freelocalsearch()
{
   local_find_mem_flag=0;
   if(neg_in==0) return;
   for (int i=1; i<numVarlocal; i++) {//numVarlocal=#var+1;  
		  free(neg_in[i]);
	      free(pos_in[i]);
   }
   free(neg_in);
   neg_in=0;
   free(counter);
   free(pos_in);
   free(neg_nb);
   free(pos_nb);
   free(var_value);
   free(var_state);
   free(flip_time);
   if(neibor_stack){
	   free(neibor_stack);
	   neibor_stack=0;
   }
   free(neibor);
   free(score);
   free(tmp_score);
   free(decreasing_vars_stack);
   free(unitvar_STACK);
   free(mark);
   free(clause_state);
   free(most_recent);
   free(most_recent_count);
   free(MY_CLAUSE_STACK);
   free(nb_lit_true);
   free(index_in_MY_CLAUSE_STACK);
}
/*
int verify_solution() 
{
  int i, lit,clause_truth;
 
  for (i=0; i<numClauses; i++) {
    clause_truth = FALSE;
    int len = sat[i+1]-sat[i];
    for(int j=0; j<len; j++){
		lit=sat[i][j];
        if (lit == var_value[ABS(lit)] ) {
	          clause_truth = TRUE;
	          break;
		}
	}
    if (clause_truth == FALSE) return FALSE;
  }
  return TRUE;
}
*/
void clause_value()
{ int lit,clause, nb_true;
   
  MY_CLAUSE_STACK_fill_pointer=0;  
  for (clause=0; clause<numClauses; clause++)
  {
      nb_true=0;
      int *pv;
 	  for(pv = sat[clause]; pv<sat[clause+1]; pv++){
		  lit=*pv;
		  if(var_value[ABS(lit)]==lit) nb_true++;        
	  }
	  nb_lit_true[clause]=nb_true;
      if (nb_true ==0 ) {
          index_in_MY_CLAUSE_STACK[clause]=MY_CLAUSE_STACK_fill_pointer;
          push(clause, MY_CLAUSE_STACK);
	  }
  } 
}

void pass(int the_var, int *clauses, int *var_count)
{
  for(int clause=*clauses; clause!=NOnum; clause=*(++clauses))
  {
       if (clause_state[clause] == ACTIVE)
	   {
          int len = sat[clause+1]-sat[clause];
          for(int j=0; j<len; j++) {
			   int lit=sat[clause][j];
			   int var=ABS(lit);
	           if (var_value[var]==0 && var != the_var) {
	                if (var_count[var]==0) push(var, neibor_stack);
	                var_count[var]=1;
			   }
		  }
	   }
  }
}

void getVarNeighbour() 
{ int var, i; 

  int *var_count=(int *)calloc (numatom+1, sizeof(int));
 
  for (var=1; var<=numatom; var++) {
      neibor_stack_fill_pointer=0;
      pass(var, neg_in[var],var_count);
      pass(var, pos_in[var],var_count);
      neibor[var]=(int *)malloc((neibor_stack_fill_pointer+1)*sizeof(int));
	
	  for(i=0; i<neibor_stack_fill_pointer; i++) neibor[var][i]=neibor_stack[i];       //neibor var
	  for(i=0; i<neibor_stack_fill_pointer; i++) var_count[neibor_stack[i]]=0;
      neibor[var][i]=0;
  }
  free(var_count);
  free(neibor_stack);
  neibor_stack=0;
}

//#define  random_integer(max)  (rand()%max)
#define  random_integer(max)  (signed int)mtrand.randInt(max-1)
void reset_seed()
{ 
	SEED=SEED+17;
	mtrand.seed(SEED);
}

int get_gradient(int var, int *clauses)
{ int clause, gradient=0, clause_gradient=1;
  
  for(clause=*clauses; clause!=NOnum; clause=*(++clauses))
  {
      if (clause_state[clause] == ACTIVE) {
           int *pv = sat[clause];  
		   int *endp=sat[clause+1];
		   clause_gradient=1;
           for(; pv<endp; pv++) {
	           int lit=*pv;
			   int vv=ABS(lit);
               if ((var_state[vv]==ACTIVE) && (vv!=var)) {
				   if (var_value[vv]==lit) { //true
	                       clause_gradient=0; break;
				   }
			  }
		   }
           gradient+=clause_gradient;
	  }
  }
  return gradient;
}

#define isDecreasingVar(var) score[var]>0

//after vars have initial values, call initialize()
int initialize() 
{
  int var, neg_gradient, pos_gradient, clause;
//gradient,
  decreasing_vars_stack_fill_pointer=0;
  for (var=1; var<=numatom; var++) {
  	   counter[var]=0; 
       tmp_score[var]=0;
       if (var_state[var]==ACTIVE) {
		   neg_gradient=get_gradient(var, neg_in[var]);
           pos_gradient=get_gradient(var, pos_in[var]);
           if(var_value[var]> 0) score[var]=neg_gradient-pos_gradient;
           else  score[var]=pos_gradient-neg_gradient;
           if (isDecreasingVar(var)) {
	           push(var, decreasing_vars_stack);   //promising decreasing variable
		   }
	   }
  }
  max_counter=0; ave_counter=0;
  for(clause=0; clause<numClauses; clause++) {
        most_recent[clause]=0;  // no var
        most_recent_count[clause]=0;
  }  
  return TRUE;
}

// uniformly select a var  wp=walk probability    
int get_wp_var(int random_clause_unsat)
{
  int number_vars=0, index_of_vars;
  int all_vars[100];

  int *pv = sat[random_clause_unsat]; 
  int *endp=sat[random_clause_unsat+1];
  for(; pv<endp; pv++){
	  int lit=*pv;
	  all_vars[number_vars++]=ABS(lit);
	  if(number_vars>40) break;
  }
  index_of_vars=random_integer(number_vars);
  return all_vars[index_of_vars];
 }

// walk in even case
int get_var_to_flip_in_clause_as_plus(int random_clause_unsat) 
{ int best_var, second_best_var=-1, nb, max_nb, second_max=-numClauses, lastflip=-1;
 
  if (random_integer(100)<LNOISE)  return get_wp_var(random_clause_unsat);   // 5% ->
  best_var=-1;
  int *pv = sat[random_clause_unsat]; 
  int *endp=sat[random_clause_unsat+1];
  max_nb=-numClauses;
  for(; pv<endp; pv++){
      int lit=*pv;
	  int var=ABS(lit);
	  nb=score[var];
      if ((nb>max_nb) || ((nb==max_nb) && (flip_time[var]<flip_time[best_var]))) {
          second_best_var=best_var; 
	      second_max=max_nb; 
		  best_var=var; 
	      max_nb=nb;
	  }
      else if ((nb>second_max) || ((nb==second_max) && (flip_time[var]<flip_time[second_best_var]))) {
          second_max=nb; second_best_var=var;
	  }
      if (flip_time[var]>lastflip) lastflip=flip_time[var];
  }
  if (flip_time[best_var]==lastflip) {
	  if (random_integer(100)<NOISE){
      	  return second_best_var;  //50%d -> 2nd best 
	  }
  }
  return best_var;
}

// walk in uneven case
int get_var_to_flip_in_clause_as_new(int random_clause_unsat)
{   int best_var, second_best_var=-1, nb, max_nb, second_max=-numClauses;// flip=-1;
   // int earliest=MAXSTEPS; //bug ???
    int earliest=0x7fffffff;
    int earliest_var=-1;
  
    best_var=0;
    int *pv = sat[random_clause_unsat]; 
    int *endp=sat[random_clause_unsat+1];
    max_nb=-numClauses;
    for(; pv<endp; pv++){
        int lit=*pv;
        int var=ABS(lit);
        nb=score[var];
        if ((nb>max_nb) || ((nb==max_nb) && (flip_time[var]<flip_time[best_var]))) {
           second_best_var=best_var; second_max=max_nb; best_var=var; max_nb=nb;
		}
        else if ((nb>second_max) || ((nb==second_max) && (flip_time[var]<flip_time[second_best_var]))) {
            second_max=nb; 
		    second_best_var=var;
		}
        if (flip_time[var]<earliest) {
            earliest=flip_time[var];
            earliest_var=var;
		}
	}
    if (random_integer(100)<LNOISE){
		return earliest_var;  // 5%  -> earliest var
    }
	if (best_var==most_recent[random_clause_unsat]) {
         switch(most_recent_count[random_clause_unsat]) {
           case 1: NOISE1=20; break;
           case 2: NOISE1=50; break;
           case 3: NOISE1=65; break;
           case 4: NOISE1=72; break;
           case 5: NOISE1=78; break;
           case 6: NOISE1=86; break;
           case 7: NOISE1=90; break;
           case 8: NOISE1=95; break;
           case 9: NOISE1=98; break;
           default: NOISE1=100; break;
      }
      if (random_integer(100)<NOISE1) return second_best_var;
	}
	return best_var;
}

void satisfy_clauses(int var, int *clauses) 
{
  int clause,  last_unsatisfied_clause, index;
  int neibor_lit;
  for (clause=*clauses; clause!=NOnum; clause=*(++clauses)) {
      int *pv =sat[clause];
      int *endp=sat[clause+1];
	  nb_lit_true[clause]++;
      switch(nb_lit_true[clause]) {
          case 1: 
	         last_unsatisfied_clause=pop(MY_CLAUSE_STACK);
             index=index_in_MY_CLAUSE_STACK[clause];
             MY_CLAUSE_STACK[index]=last_unsatisfied_clause;
             index_in_MY_CLAUSE_STACK[last_unsatisfied_clause]=index;
             for(; pv<endp; pv++){
				 neibor_lit=*pv;
		         int nvar= ABS(neibor_lit);
				 if (nvar!=var) tmp_score[nvar]--;
			 }
             break;
          case 2: 
	           for(; pv<endp; pv++){
			        neibor_lit=*pv;
				    int nvar= ABS(neibor_lit);
					if ((nvar!=var) && (var_value[nvar]==neibor_lit)) {
	                     tmp_score[nvar]++;
	                     break;
					}
			   }
      }
  }
}

/* let x1 be the new value of x and x0 be the old value of x
   then for each clause in *clauses here, (x1-x0)df/dx is positive */
void unsatisfy_clauses(int var, int *clauses) 
{
  int clause,neibor_lit;

  for (clause=*clauses; clause!=NOnum; clause=*(++clauses)) {
    int *pv =sat[clause];
    int *endp=sat[clause+1];
	nb_lit_true[clause]--;
    switch(nb_lit_true[clause]) {	//before flipping var, nb_lit_true[cause]>=1 because var is a positive literal  
       case 0:  
            if (most_recent[clause]==var) most_recent_count[clause]++;
            else {
	             most_recent[clause]=var;
	             most_recent_count[clause]=1;
			}
            index_in_MY_CLAUSE_STACK[clause]=MY_CLAUSE_STACK_fill_pointer;
            push(clause,MY_CLAUSE_STACK);
            for(; pv<endp; pv++){
			    neibor_lit=*pv;
		        int nvar=ABS(neibor_lit);
				if (nvar!=var) tmp_score[nvar]++;
			}
            break;
      case 1: 
            for(; pv<endp; pv++){
			   neibor_lit=*pv;
		       int nvar=ABS(neibor_lit);
			   if ((nvar!=var) && (var_value[nvar]==neibor_lit)) {
	              tmp_score[nvar]--;
	              break;
			}
		 }
	}
  }
}

void check_implied_clauses(int var, int value, int nb_flip) 
{ 
  int *neibors, neibor_var;
 
  if (value> 0) {
      satisfy_clauses(var, pos_in[var]);
      unsatisfy_clauses(var, neg_in[var]);
  }
  else {
      satisfy_clauses(var, neg_in[var]);
      unsatisfy_clauses(var, pos_in[var]);
  }
  neibors=neibor[var];
  for(neibor_var=*neibors; neibor_var; neibor_var=*(++neibors)) 
  {
       int newscore=score[neibor_var]+tmp_score[neibor_var];
	   if ((score[neibor_var]<=0) && (newscore>0)) push(neibor_var, decreasing_vars_stack);
       score[neibor_var]=newscore;
       tmp_score[neibor_var]=0;
  }
}
// delete var with score<=0
void simple_eliminate_increasing_vars()
{   int i, put_in, var;
 
    put_in=0;
    for (i=0; i<decreasing_vars_stack_fill_pointer; i++) {
        var=decreasing_vars_stack[i];
        if (score[var]>0) decreasing_vars_stack[put_in++]=var;
	}
    decreasing_vars_stack_fill_pointer=put_in;
}

int choose_best_decreasing_var() 
{
  int var, chosen_var, i, flip; 
  
  if(decreasing_vars_stack_fill_pointer<1) return -1;
  chosen_var=var=decreasing_vars_stack[0]; 
  flip=flip_time[var]; 
  for (i=1; i<decreasing_vars_stack_fill_pointer; i++) {
     var=decreasing_vars_stack[i];
     if (flip_time[var]<flip) {
          flip=flip_time[var]; chosen_var=var;	
     }
  }
  return chosen_var;
}

int update_gradient_and_choose_flip_var(int var)
{
   score[var]=-score[var];
   simple_eliminate_increasing_vars();
   return choose_best_decreasing_var();
 
}

// walk in even case
int choose_var_by_random_walk_as_plus()
{
  int  random_unsatisfied_clause,  var_to_flip;
  random_unsatisfied_clause=random_integer(MY_CLAUSE_STACK_fill_pointer);
  random_unsatisfied_clause=MY_CLAUSE_STACK[random_unsatisfied_clause];
  var_to_flip=get_var_to_flip_in_clause_as_plus(random_unsatisfied_clause);
  return  var_to_flip;
}

 // walk in uneven case
 int choose_var_by_random_walk_as_new() 
 {
  int  random_unsatisfied_clause,  var_to_flip;
  random_unsatisfied_clause=random_integer(MY_CLAUSE_STACK_fill_pointer);
  random_unsatisfied_clause=MY_CLAUSE_STACK[random_unsatisfied_clause];
  var_to_flip=get_var_to_flip_in_clause_as_new(random_unsatisfied_clause);
  return  var_to_flip;
}

void flip(int flipvar)
{   int clause,*posclauses,*negclauses;
	var_value[flipvar]=-var_value[flipvar]; 
    if (var_value[flipvar]> 0) {
        posclauses=pos_in[flipvar];
        negclauses=neg_in[flipvar];
	}
    else {
        negclauses=pos_in[flipvar];
        posclauses=neg_in[flipvar];
	}
//positive
	for (clause=*posclauses; clause!=NOnum; clause=*(++posclauses)) {
       nb_lit_true[clause]++;
      if(nb_lit_true[clause]==1){ 
	         int last_unsatisfied_clause=pop(MY_CLAUSE_STACK);
             int index=index_in_MY_CLAUSE_STACK[clause];
             MY_CLAUSE_STACK[index]=last_unsatisfied_clause;
             index_in_MY_CLAUSE_STACK[last_unsatisfied_clause]=index;
	  }
	}
//negative
    for (clause=*negclauses; clause!=NOnum; clause=*(++negclauses)) {
       // int *lits=sat[clause];
	    nb_lit_true[clause]--;
        if(!nb_lit_true[clause]) {	//before flipping var, nb_lit_true[cause]>=1 because var is a positive literal  
            index_in_MY_CLAUSE_STACK[clause]=MY_CLAUSE_STACK_fill_pointer;
            push(clause,MY_CLAUSE_STACK);
		}  
	}
}
void flip_Multi_var(int n)
{   int i;
	if(!n){
		if(!MY_CLAUSE_STACK_fill_pointer) return;
		int m=0;
		for(i=multilen; i>=1; i--){
			if(prevpat[i]!=pattern[i]) flip(candiVar[i-1]);
			prevpat[i]=pattern[i];
			m=m*2+pattern[i];
        }
		if(m==0) return;
		if(minUnsat>=MY_CLAUSE_STACK_fill_pointer){
			minPos=m;
			minUnsat=MY_CLAUSE_STACK_fill_pointer;
		}
		return;
	}
    flip_Multi_var(n-1);
	pattern[n]=1-pattern[n]; 
	flip_Multi_var(n-1);
}

void update_counter(int var_to_flip); 

void choose_Multi_var(int nb_flip)
{
  int i;

 int oldsat=MY_CLAUSE_STACK_fill_pointer;
 multilen=minocc;
 if(multilen==0) return;
 if(multilen>20) multilen=20;
// for(i=0; i<multilen; i++)  printf("%d ", candiVar[i]);

  minUnsat=MY_CLAUSE_STACK_fill_pointer+1000;

  for(i=0; i<=multilen; i++) prevpat[i]=pattern[i]=0;
  flip_Multi_var(multilen);
  if(MY_CLAUSE_STACK_fill_pointer==0) return;
    
  for(i=multilen; i>=1; i--) if(pattern[i]) flip(candiVar[i-1]);
  
  //int munsat=MY_CLAUSE_STACK_fill_pointer;
  if(minUnsat> oldsat) return;
//
  for(i=0; i<multilen; i++){
	  if(minPos%2==1){
    	    int var_flip=candiVar[i];
           	var_value[var_flip]=-var_value[var_flip]; 
            check_implied_clauses(var_flip, var_value[var_flip], nb_flip);
      }
	  minPos=minPos/2;
  }
}

void update_counter(int var_to_flip) 
{
   //double the_old_counter, the_new_counter;	
   int64 the_old_counter, the_new_counter;	
   the_old_counter=counter[var_to_flip];
 //  counter[var_to_flip]=1.0*(counter[var_to_flip]+1.0);  //s=0; //delete variable weight vw=(1-s)(vw+1)+s*t;
   counter[var_to_flip]=(counter[var_to_flip]+1);  //s=0; //delete variable weight vw=(1-s)(vw+1)+s*t;
   the_new_counter=counter[var_to_flip];
   //double old_ave_counter=ave_counter;
   int64 old_ave_counter=ave_counter;
  // ave_counter=old_ave_counter+(the_new_counter-the_old_counter)/(double)numatom;
   ave_counter=old_ave_counter+(the_new_counter-the_old_counter)/numatom;
   if (the_new_counter>max_counter) max_counter=the_new_counter;
}

int sortkey(int *keyvar,int *VarWeight);
void unit_Propagation()
{
    int i,cli,var;
    int *fixedVAR =(int *)calloc (numatom+1, sizeof(int));
   
	if (minocc==0){
        int *VarWeight=(int *)calloc (numatom+1, sizeof(int));
        for(i=1; i<=numatom; i++){
		    if (var_state[i]!=ACTIVE) VarWeight[i]=0;
            else VarWeight[i]=neg_nb[i]+pos_nb[i];
		}
        sortkey(fixedVAR,VarWeight);
        free(VarWeight);
	    int prew=-1;
    	int limit=2*numatom/3;
    	if(limit>1000) limit=1000;
		for(i=0; i<limit; i++) {
			candiVar[i]=fixedVAR[i];
			int vv=candiVar[i];
		    if (var_state[vv]!=ACTIVE) break;
    		int ww=neg_nb[vv]+pos_nb[vv];
            if(prew-ww>20 && i>32) break;
			prew=ww;
		}
		minocc=i;
	}
	int loop=0,minConflict;
	int *minpat =(int *)calloc (numatom+1, sizeof(int));
	int *pos =(int *)calloc (numatom+1, sizeof(int));
   
	bool train=true;
	minConflict=numClauses;
	int outi;
        for(outi=0; outi<60; outi++){
		for(i=0; i<minocc; i++)	pos[i]=0;
	    for(i=0; i<20; i++)	pos[random_integer(minocc)]=1;
        for(loop=0; loop<5; loop++){
		    for(i=1; i<=numatom; i++) fixedVAR[i]=0;
		    for(i=0; i<minocc; i++)	{
			    if(pos[i]) pattern[i]=random_integer(2);
				else  pattern[i]=0; 
                if(pattern[i]) fixedVAR[candiVar[i]]=-candiVar[i];
			    else fixedVAR[candiVar[i]]=candiVar[i];
			}
//
final:
            int prev=0;
	        int conflict,unitm=32;
	        int other=0;
    	        while(prev!=unitm){
		        conflict=0;
		        prev=unitm;
                for(cli=0; cli<numClauses; cli++){
			       int m=0;
				   int *pv =sat[cli];
                   int *endp=sat[cli+1];
				   for(; pv<endp; pv++){
	    		       int lit=*pv; 
					   var=ABS(lit);
				        if(fixedVAR[var]==lit) goto nextcls;
				        else if(fixedVAR[var]==0) {m++; other=lit;}
				   }
			       if(m==1) {
				      unitm++;
			          fixedVAR[ABS(other)]=other;
				   }
				   if(!m) conflict++;
nextcls:    
			 ;
				}
			}
//
	   if(!train) goto end;
            if(minConflict>=conflict){
				minConflict=conflict;
//			    printf("minConflict=%d ",minConflict);
		        for(i=0; i<minocc; i++)	minpat[i]=pattern[i];
			}
		}
	}
	train=false;
	for(i=1; i<=numatom; i++) fixedVAR[i]=0;
	for(i=0; i<minocc; i++)	{
	             if(minpat[i]) fixedVAR[candiVar[i]]=-candiVar[i];
			     else fixedVAR[candiVar[i]]=candiVar[i];
	}
    goto final;
end:
	for(i=1; i<=numatom; i++){
		if(fixedVAR[i] && var_state[i]==ACTIVE) var_value[i]=fixedVAR[i];
	}
	free(fixedVAR);
	free(minpat);
	free(pos);
}

int Local_search(int &tries,int & steps) 
{ int num_Unsat=100000,j,k;
  static int var_to_flip;
  //double coefficient_for_prm;
   int64 coefficient_for_prm;

//  MAXSTEPS=60000000;
  MAXSTEPS=5*6000000;
  int rate=numClauses/numatom;
  rate=rate/8;
  if(rate>1) MAXSTEPS=MAXSTEPS/rate;
  if(MAXSTEPS<1000000) MAXSTEPS=1000000;

  coefficient_for_prm = 10;
  if(tries==1 && steps==0){
      //coefficient_for_prm = 10.0;
      minocc=0;
      getVarNeighbour();
  	  candiVar =(int *)calloc (numatom, sizeof(int));
      prevpat =(int *)calloc (numatom, sizeof(int));
      pattern = (int *)calloc (numatom, sizeof(int));
  }
  {  if(steps) goto loop;
	 reset_seed(); 
     num_Unsat=numClauses;
     for (k=1;k<=numatom;k++) {  //initialize var value
    	  flip_time[k]=0; 
	      if(tries>1){
			 if(random_integer(20)) continue;
		  }
		 if (var_state[k]==ACTIVE) {
              if(random_integer(2)) var_value[k]=k;
			  else var_value[k]=-k;
		 }
	}
	 unit_Propagation();
	 initialize();
     clause_value();
	 initNoise();
	 var_to_flip = choose_best_decreasing_var();
loop:
     for (j=0;j<MAXSTEPS;j++) {
		 if(MY_CLAUSE_STACK_fill_pointer<num_Unsat){
			 num_Unsat=MY_CLAUSE_STACK_fill_pointer;
			// if(num_Unsat<4) printf("c Unsat#=%10d flip#=%10d \n",num_Unsat,j);
			 if(num_Unsat>=3 && j>5000000) MAXSTEPS=j; 
			 if(num_Unsat==1){
				 MAXSTEPS=2*j;
				 if(MAXSTEPS>30000000) MAXSTEPS=30000000;
				 //  MAXSTEPS=40000000;
				 if(tries==1){//sgen1-sat-240-100
					 if(rate<=1){
						 if(MAXSTEPS<=20000000) MAXSTEPS=20000000;
					 }
					 else if(MAXSTEPS<=10000000) MAXSTEPS=10000000;
		 		 }
				 else{
			 		 if(rate<=1){
						 if(MAXSTEPS<=5000000) MAXSTEPS=5000000;
					 }
					 else if(MAXSTEPS<=3000000) MAXSTEPS=3000000;
				 }
			 }
  		 }
		 if (walk_satisfiable()) break;
		 if (var_to_flip<=0) {// when there is no non-tabu decreasing var 
	    	// if (max_counter>=(double)coefficient_for_prm*ave_counter){	 // uneven case
	 	    if (max_counter>=coefficient_for_prm*ave_counter){	 // uneven case
				 var_to_flip=choose_var_by_random_walk_as_new();
         	 }
			 else {
				 var_to_flip=choose_var_by_random_walk_as_plus(); 		//even case
		 	 }
		 }
    //flip
		var_value[var_to_flip]=-var_value[var_to_flip]; 
		check_implied_clauses(var_to_flip, var_value[var_to_flip], j);
    	flip_time[var_to_flip]=j;
        update_counter(var_to_flip);
        adaptNoveltyNoise(j);
        var_to_flip=update_gradient_and_choose_flip_var(var_to_flip);
	 }
//    printf("c try %d-th flip# %d \n", tries, j);
     if(walk_satisfiable()) {
         clause_value();
         if (walk_satisfiable()) {
	         printf("c A solution found by local search \n");
//             for (var=1; var<=numatom; var++) if(var<100) printf("%d ", var_value[var]);
	         return SAT;
 		 }
	 }
  }
  if(tries<2) tries++;
  if(steps>=60000000){
	 tries++;
	 steps=0;
  }
  else steps+=MAXSTEPS;
  //printf("s UNKNOWN\n");
  return UNKNOWN;
}
