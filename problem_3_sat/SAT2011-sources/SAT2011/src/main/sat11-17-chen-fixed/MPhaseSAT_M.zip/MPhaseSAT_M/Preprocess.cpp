/*
 Preprocessing for CircleSAT
*/
#include <cassert>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "constants.h"

#define Swap(a,b) { int t; t=a; a=b; b=t;}

/************************************/
/* Constant parameters              */
/************************************/
int  numatom;                // the number of atoms 
int  numClauses;      //current number of clauses
extern int originClauses; // original number of clauses
extern char *Deletedclause;
extern int delclauses;
extern bool crypto_Gss;
int	deletedVnum;

int  numXOR;           // the number of active XOR clauses
int  numBigXOR;          //the number of big active XOR clauses
int  n_inative=0;         //the number of inactive XOR clauses

int *Lit_set;       // memory for literals   
int **Clit;        // literals for each clause       

int *CNF_index_Mem;  //* memory for clause numbers;
extern int **OccurenceA;      // where each literal occurs: indexed as OccurenceA[literal+numatom][n,1...n]
int CNF_space;

int *Leq_base;  // the set of literals for active XOR clauses
int **Leq;    //  literals for each active XOR clause
int *Eq_base; //  the set of active XOR clauses for each variables
extern int **XORoccurA;

int *BigEq_set;  // the set of big active XOR clauses
int **BigEq;     // indexs which point to each big active XOR clause

int *iLit_set;  // the set of big active XOR clauses
int **inaLit;   // literals of XOR clauses for each inactive variable

int *EqClause;   // flag for each XOR cluase
int *outEquAtom;

int *unit;	 // atom which occurs in unit clause
int *TimeAss;        // time assignment;
int cTimeA;           // current time assignment                

int *RankVar;               // ordered variable list

int equivalence_reasonA();
void shorten_equivalenceA( );

void Split_XOR_CNF();

int *vBoolookup;
int *DependentVar;
int *CeqLen;

extern int *seen;

void setDoubleDataIndex(int **Cl,int **clauseSet,int *clauseBase,int numCls,int offset);
void setSingleDataIndex(int **Cl,int **clauseSet,int *clauseBase,int numCls);
void setEqDataStruct(int **Veq,int **EqSet,int *EqBase,int numEq);
void setDoubleDataIndexDel(int **Cl,int **clauseSet,int *clauseBase,int numCls,char *Deletedclause);

void restoreSolution( int sol[]);

void sortColumn(int **Clit1,int **Clit2, int *Lit_set2, int j_th,int numCli);
void sortClause(int **Clit1,int *Lit_set1,int & numCls, int numcolumn,int delrepeat);

void SetClausePtr(int **clauseP,int *newPointer,int cntClauses);

// Find the solution of inactive variables by XOR equation
void inactiveSolution(int *Fsolution)
{   int i,trues,var,*px;

    for(i=n_inative-1; i>=0; i--){
		 trues=0;
       	 for(px=inaLit[i]+1; px<inaLit[i+1]; px++){
			 if(Fsolution[ABS(*px)]==0) { trues=-1; break;}
        		if(Fsolution[ABS(*px)]==*px) trues++;
         }
		 if(trues==-1) continue;
         var=inaLit[i][0];
		 if(var<0) {var=-var; trues++;}
		 if(trues%2==0) Fsolution[var]=var;
		 else Fsolution[var]=-var;
    }
    if(n_inative) {
		free(iLit_set);
		free(inaLit);
		n_inative=0;
	}
}

void restoreSolution(int sol[])
{  int i;
//   for(i=1; i<=numatom; i++)  if(unit[i]!=0) sol[i]=unit[i];
   if(outEquAtom==0) return;
   for(i=1; i<=numatom; i++){
       //if(unit[i]!=0) continue; //bug itox_vc1138
		int vv=ABS(outEquAtom[i]);
		if(vv==0 || vv==i) continue;
		if(sol[vv]==0) continue;
		if(outEquAtom[i]<0) vv=-sol[vv];
		else vv=sol[vv];
		if(vv<0) sol[i]=-i;
	    else sol[i]=i;
   }
}
int Large_Preprocess();
int PreProcessCNF()
{
 	 Lit_set=Clit[0];
	 int ret=Large_Preprocess();
	 return ret;
}

void setSingleDataIndex(int **Cl,int **clauseSet,int *clauseBase,int numCls)
{
    int i,sum;
    int *occLit,*pv;
	
	occLit =clauseBase;
    for(i=0; i <=numatom; i++) occLit[i]=0;
    for(pv=Cl[0]; pv<Cl[numCls]; pv++)	occLit[ABS(*pv)]++;
	sum=0;
    for(i=0; i <=numatom;i++) {
	     clauseSet[i] =clauseBase+sum;
		 sum+=occLit[i]+1;
    }
	for(i=0; i <=numatom;i++) clauseSet[i][0]=1;
  	for(i=0; i<numCls; i++) {
        for(pv=Cl[i]; pv<Cl[i+1]; pv++) {
			int var=ABS(*pv);
			int n=clauseSet[var][0];
			clauseSet[var][n]=i;
            clauseSet[var][0]=n+1;
		}
	}
}

void setDoubleDataIndex(int **Cl,int **clauseSet,int *clauseBase,int numCls,int offset)
{
    int i,sum;
    int *occLit,*pv;
	
	occLit =clauseBase;
	int numatom2=2*numatom+1;
    for(i=0; i <numatom2;i++) occLit[i]=0;
	occLit+=numatom;
	int endcls=offset+numCls;
	for(pv =Cl[offset]; pv < Cl[endcls]; pv++) occLit[*pv]++;
	sum=0;
	occLit-=numatom;
    clauseSet-=numatom;
    for(i = 0; i < numatom2;i++) {
	     clauseSet[i] =clauseBase+sum;
		 sum+=occLit[i]+1;
    }
	for(i = 0; i < numatom2;i++) clauseSet[i][0]=1;
    clauseSet+=numatom;
	for(i=offset; i<endcls; i++) {
  		for(pv=Cl[i]; pv<Cl[i+1]; pv++) {
			int n=clauseSet[*pv][0];
			clauseSet[*pv][n]=i;
            clauseSet[*pv][0]=n+1;
		}
	}
}

void setEqDataStruct(int **Veq,int **EqSet,int *EqBase,int numEq)
{
    int i,sum;
    int *occLit,*pv;
	
	occLit = EqBase;
    for(i=0; i <=numatom;i++) occLit[i]=0;
    for(pv=Veq[0]; pv<Veq[numEq]; pv++) occLit[ABS(*pv)]++;
	sum=0;
    for(i = 0; i <=numatom;i++) {
	     EqSet[i] = EqBase+sum;
		 sum+=occLit[i]+1;
    }
    for(i=1; i <=numatom; i++) EqSet[i][0]=1;
	for(i=0; i<numEq; i++) {
        for(pv=Veq[i]; pv<Veq[i+1]; pv++) {
			int var=ABS(*pv);
			int n=EqSet[var][0];
			EqSet[var][n]=i;
            EqSet[var][0]=n+1;
		}
	}
}

int checkUnitClause(int cli,int & change)
{
    int *pv,lit,size,var,k,rc;
    int aCNF[20];
    
	size=0; change=0;
    for(pv=Clit[cli]; pv<Clit[cli+1]; pv++){
	   lit=*pv; var=ABS(lit);
       if(unit[var]!=0) {
	        if(unit[var]!=lit) continue;
  			rc=SAT; goto ret;
	   }
   	   if(seen[ABS(lit)]==0) {
        	if(size>=10) continue;
	     	aCNF[size++]=lit;
		    seen[ABS(lit)]=lit;
	   	}
	    else{
			 if(seen[ABS(lit)]==-lit){
  			   rc=SAT; goto ret;
			 }
		}
	}
	rc=UNKNOWN;
ret:	
	for(k=0; k<size; k++) seen[ABS(aCNF[k])]=0;
	if(rc==SAT) return SAT;
//unit cluase found
    if(size==1){
        unit[ABS(aCNF[0])]=aCNF[0];
		change=1;
	}
	if(size==0) return UNSAT;
	return SAT;
}

int breakEquivalentLoop()
{    int i,cur,sign,next1;

    for(i=1; i<=numatom; i++) {
		if(ABS(outEquAtom[i])<=i) continue;
		cur=i;
		sign=1;
		do{ 
			next1=outEquAtom[cur];
			outEquAtom[cur]=sign*i;
			if(unit[cur]!=0){
				int lit=unit[i];
				unit[i]=(outEquAtom[cur]<0 && unit[cur]<0) || (outEquAtom[cur]>0 && unit[cur]>0)? i:-i;
				if(lit==-unit[i]) return UNSAT;
			}
			if(next1<0) {cur=-next1; sign=-sign;}
			else cur=next1;
		} while(cur!=outEquAtom[cur]);
	}

	for(i=1; i<=numatom; i++) {
		next1=ABS(outEquAtom[i]);
		if(outEquAtom[next1]==next1 || next1==0) continue;
		sign=outEquAtom[i]<0 ? -1: 1;
		outEquAtom[i]=sign*outEquAtom[next1];
	}
	return SAT;
}

//delete some cluases
int deletegarbage(int & change)
{
	int lit,var,newn,sum;
	int *NewClause=Clit[0];
	int i,k,True,*pv;

	sum=newn=0; 
    int oldsize=Clit[numClauses]-Clit[0];

	for(i=0; i<numClauses; i++){
		k=0;True=0;
		for(pv=Clit[i]; pv<Clit[i+1]; pv++){
			lit=*pv;
			if(lit==0) {True=1; break;} //deleted clause
			if(outEquAtom!=0){
				int lit1=outEquAtom[ABS(lit)];
			    if(lit1!=0)	lit=(lit<0)?-lit1:lit1;
			}
			var=ABS(lit);
			if(unit[var]){
				 if(unit[var]==lit) True=1;
				 continue;
			}
    		if(seen[var]==0) NewClause[sum+k++]=seen[var]=lit;
		    else if(seen[var]==-lit) True=1;
		}
		int j;
		for(j=0; j<k; j++) seen[ABS(NewClause[sum+j])]=0;
		if(True) continue;
		if(k==0){
			printf("c proprocessing binary CNF conflict \n");
			return UNSAT;
		}
		if(k==1){
			lit=NewClause[sum];
			unit[ABS(lit)]=lit;
	        continue;
		}
		Clit[newn++]=Clit[0]+sum;
		sum+=k;
	}
	Clit[newn]=Clit[0]+sum;
	numClauses=newn;
    change=(sum!=oldsize);
//    printf("c dg Clauses#=%d \n",numClauses);
	if(numClauses==0) return SAT;
	Lit_set=(int*)realloc(Clit[0], sizeof(int)*sum);
   	SetClausePtr(Clit,Lit_set,numClauses);
	return SAT;
}
//delete some cluases
void deleteClause(int **Clit1, int & numCli)
{
	int newn,sum;
	int i,*pv;
	int *NewClause=Clit1[0];
	sum=0;
	newn=1;
	for(i=0; i<numCli; i++){
	    if(Clit1[i][0]==0) continue;
        for(pv=Clit1[i]; pv<Clit1[i+1]; pv++) NewClause[sum++]=*pv;
		Clit1[newn++]=NewClause+sum;
	}
	numCli=newn-1;
   	int *Lit_set1=(int*)realloc(Clit1[0], sizeof(int)*sum);
   	SetClausePtr(Clit1,Lit_set1,numCli);
//	printf("c deleteClause cluase#=%d \n",numCli);
}

void mergeTwoEqu(int lit1, int lit2);

int mergeTwoEunit(int lit1, int lit2)
{
    int v1,v2;
	v1=ABS(lit1); v2=ABS(lit2);
	if(v1>v2){
		Swap(v1,v2);
        Swap(lit1,lit2);
  	}
   	if(lit2<0) lit1=-lit1;
    if(unit[v2]){// bug 2010.9.19
         if(unit[v2]<0) lit1=-lit1;
		 if(unit[v1]==-lit1) return UNSAT;
         unit[v1]=lit1;
		 return SAT;
	}
	outEquAtom[v1]=0;
	outEquAtom[v2]=lit1;
	return SAT;
}

void mergeAllEqu();
inline int find1(int lit)
{   int vv=ABS(lit);
	int lit1=outEquAtom[vv];
    while(lit1){
    	lit=(lit<0)?-lit1:lit1;
	    int vv=ABS(lit);
	    lit1=outEquAtom[vv];
		if(ABS(lit1)==vv){
			outEquAtom[vv]=0;
			break;
		}
	}
	return lit;
}

int old_BinaryEquReason(int & change)
{   int i;

//binary equivalent resoning
   sortClause(Clit, Lit_set,numClauses,4,0); //??no duplicate

   int sign,next1,next2,cur;
	for(i=0; i<numClauses-1; i++){
		int lit1,lit2,*pc1,*pc2;
		if(Clit[i+1]-Clit[i]!=2 || Clit[i+2]-Clit[i+1]!=2) continue;
		pc1=Clit[i];  pc2=Clit[i+1];
        lit1=*pc1; lit2=pc1[1];
		if(-lit1==*pc2){
			if(-lit2==pc2[1]){    //lit1==-lit2;
			   	int v1=lit1,v2;
			    if(v1<0) v1=-v1; 
			    else 	lit2=-lit2;
			    v2=ABS(lit2);
//check already exists A=B
			   if(outEquAtom[v1]){
                   cur=v1;
		           sign=1;
		           do{ 
			          next1=outEquAtom[cur];
		              if(next1<0) {cur=-next1; sign=-sign;}
			          else cur=next1;
					  if(cur==v2){
					//	  printf(" already CNF A==B ");
						  if(sign*cur==lit2) goto nextEq;   // already exists
            	          return UNSAT;
					  }
				   } while(cur!=v1);
			   }
		  	   sign=(lit2<0) ? -1:1;
		       next1=(outEquAtom[v1]==0)? v1: outEquAtom[v1];
			   next2=(outEquAtom[v2]==0)? v2: outEquAtom[v2];
			   outEquAtom[v1]=sign*next2;
			   outEquAtom[v2]=sign*next1;
			   i++;
			   continue;
			}
			if(lit2==pc2[1]){    //A v B  AND -A V B ==> B
			    //printf("\n +-A=%d B=%d ==> B ",lit1,lit2);
				int vv=ABS(lit2);
				if(unit[vv]==-lit2)	return UNSAT;
				unit[vv]=lit2;
			}
		}
        else{
			if(lit1==*pc2){
			    if(-lit2==pc2[1]){    //A v B  AND -A V B ==> B
			  //     printf("\n A=%d +-B=%d ==> A ",lit1,lit2); printf("\n A v B  & -A V B ==> B ");
				   int vv=ABS(lit1);
				   if(unit[vv]==-lit1) return UNSAT;
				   unit[ABS(lit1)]=lit1;
				}
			}
		}
nextEq:  ;
	}
    int rc=breakEquivalentLoop();
	if(rc==UNSAT) return UNSAT;
//delete some cluases
    rc=deletegarbage(change);
	return rc;
}

int BinaryEquReason(int & change)
{   int i;

//binary equivalent resoning
   sortClause(Clit, Clit[0],numClauses,4,0); //??no duplicate
   for(i=0; i<numClauses-1; i++){
		int lit1,lit2,*pc1,*pc2;
		if(Clit[i+1]-Clit[i]!=2 || Clit[i+2]-Clit[i+1]!=2) continue;
		pc1=Clit[i];  pc2=Clit[i+1];
        lit1=*pc1; lit2=pc1[1];
		if(-lit1==*pc2){
			if(-lit2==pc2[1]){    //lit1==-lit2;
			// printf("<CNF %d = %d> ", lit1,-lit2);
			   	  int a=find1(lit1);
				  int b=find1((-lit2));
			      if(a == b) continue;
	              if(a == -b) return UNSAT;
				  int rc=mergeTwoEunit(a,b);
				  if(rc==UNSAT) return UNSAT;
			}
			if(lit2==pc2[1]){    //A v B  AND -A V B ==> B
			  //  printf("\n +-A=%d B=%d ==> B ",lit1,lit2);
				int vv=ABS(lit2);
				if(unit[vv]==-lit2)	return UNSAT;
				unit[vv]=lit2;
			}
		}
        else{
			if(lit1==*pc2){
			    if(-lit2==pc2[1]){    //A v -B  AND A V -B ==> A
			    //   printf("\n A=%d +-B=%d ==> A ",lit1,lit2); printf("\n A v B  & -A V B ==> B ");
				   int vv=ABS(lit1);
				   if(unit[vv]==-lit1) return UNSAT;
				   unit[ABS(lit1)]=lit1;
				}
			}
		}
   }
    mergeAllEqu();
//delete some cluases
    int rc=deletegarbage(change);
	return rc;
}

int decompose (int *unitVar); 

int SimpfySATProblem()
{
	 int i,sum;
     int loop,change,rc;
    // printf("c SimpfySATProblem.... \n");

	 seen=(int *)calloc(numatom+1,sizeof(int));
  	 if(outEquAtom==0) outEquAtom=(int *)calloc(numatom+1,sizeof(int));
	 sum=0;
	 do{
		 loop=0;
		 for(i=0; i<numClauses; i++){
		     rc=checkUnitClause(i,change);
			 if(rc==UNSAT) return UNSAT;
			 if(change) loop=1;
		 }
		 sum++;
     } while (loop==1);
	 int cnt=0;
	 for(i=1; i<=numatom; i++) if(unit[i]) cnt++; 
	 sum=0;
	 do{
		 loop=0; sum++;
		 if(crypto_Gss){
		      if(old_BinaryEquReason(loop)==UNSAT) return UNSAT;
		 }
		 else if(BinaryEquReason(loop)==UNSAT) return UNSAT;

		 //	     printf("c BinaryEquReason loop #=%d numClauses=%d \n", sum,numClauses);
  
		 if(numClauses>5000000 && sum>10) break;
	 } while(loop!=0);
//	 printf("c BinaryEquReason loop #=%d \n", sum);
   	 free(seen);
	 for(i=1; i<=numatom; i++) { //SAT_dat.k50
		 if(unit[i]==0) continue;
		 if(outEquAtom[i]==0) continue;
		 int other=find1(i);
		 if(other==i) continue;	
		 if(unit[i]<0) other=-other;
		 int vv=ABS(other);
         if(unit[vv]==-other) return UNSAT;
		 unit[vv]=other;
	 }
	 return SAT;     	 
}

// Unit propagation for CNF and XOR clauses
int FixUnitVar(int *TureClauseMark)
{
    int cli,m,n,var;
	int CNF[10];
	int	*pv,previous=-1;
  
	int numUnit=0;
	while(numUnit!=previous){
        previous=numUnit;
	  	for(cli=0; cli<numClauses; cli++){
            if(TureClauseMark[cli]>0) continue;
			m=n=0;
	       	for(pv=Clit[cli]; pv<Clit[cli+1]; pv++){
	            var=ABS(*pv);
				if(unit[var]==*pv) n++;
		        else if(unit[var]==0 && m<2) CNF[m++]=*pv;
            }
			if(m==0 && n==0) return UNSAT; // { rc=-1; break;}
       		if(m==1){
			    if(n==0 || EqClause[cli]==1){
            		var=ABS(CNF[0]);
		            if(n%2==0) unit[var]=CNF[0];
					else unit[var]=-CNF[0];
					numUnit++;
	  			}
				TureClauseMark[cli]=1;
			}
			else{
			    if(n > 0 && EqClause[cli]!=1) TureClauseMark[cli]=1;
	      	}
		}
	}
  	return SAT;
}

void SortLiteral(int **Clit1,int numCli)
{    int i,*pv,*pw;

     for(i = 0; i < numCli; i++) {
		for(pv=Clit1[i]+1; pv<Clit1[i+1]; pv++){
            for(pw=pv; pw>Clit1[i] && ABS(*(pw-1)) > ABS(*pw); pw--){
				Swap(*(pw-1),*pw);
            }
		}
	 }
}

void sortClause(int **Clit1,int *Lit_set1,int & numCls, int numcolumn,int delrepeat)
{  
	if(numCls<2) return;
	int *plit;
	int *endlit=Clit1[numCls];
	// -x -> 2(-x)+1, x -> 2x
	if(delrepeat) for(plit=Clit1[0]; plit<endlit; plit++) *plit=lit2posLit(*plit);
//sort literals in each row    
    SortLiteral(Clit1,numCls);
//Sort 4 columns
	int size=Clit1[numCls]-Clit1[0];
	if(size<3) return; 
	int *Lit_set2=(int *) malloc( sizeof(int)*size);
    int **Clit2=(int **) malloc( sizeof(int *) * (numCls+1));
    if(numcolumn>2){
		sortColumn(Clit1,Clit2,Lit_set2,3,numCls);
        sortColumn(Clit2,Clit1,Lit_set1,2,numCls);
	}
	sortColumn(Clit1,Clit2,Lit_set2,1,numCls);
	sortColumn(Clit2,Clit1,Lit_set1,0,numCls);
	free(Lit_set2);
	free(Clit2);
//remove repeated clauses
	if(delrepeat && numCls>1){
		int i, j, newCn=0;
		int *newCls=Clit1[0];
		for(i=0; i<numCls-1; i++){
			 int *p1=Clit1[i], *p2=Clit1[i+1];
			 int len=p2-p1;
			 int equal=1;
			 for(j=0; j<len; j++){
				  newCls[j]=p1[j]; 
				  if(p1[j]!=p2[j]) equal=0;
			 }
			 if ( equal && len==Clit1[i+2]-p2 ) continue; //repeated clauses
	         Clit1[newCn++]=newCls;
			 newCls+=len;
		}
	    Clit1[newCn++]=newCls;
	    for(plit=Clit1[numCls-1]; plit<Clit1[numCls]; plit++,newCls++) *newCls=*plit;
		numCls=newCn;
		endlit=Clit1[newCn]=newCls;
	}
// 2x -> x,   2x+1 ->-x
  	if(delrepeat) for(plit=Clit1[0]; plit<endlit; plit++) *plit=posLit2lit(*plit);
}


void sortClause2(int **Clit1,int *Lit_set1,int & numCls)
{  
	if(numCls<2) return;
	int size=Clit1[numCls]-Clit1[0];
	if(size<3) return; 
	int *Lit_set2=(int *) malloc( sizeof(int)*size);
    int **Clit2=(int **) malloc( sizeof(int *) * (numCls+1));
//Sort 4 columns
	sortColumn(Clit1,Clit2,Lit_set2,3,numCls);
    sortColumn(Clit2,Clit1,Lit_set1,2,numCls);
	sortColumn(Clit1,Clit2,Lit_set2,1,numCls);
	sortColumn(Clit2,Clit1,Lit_set1,0,numCls);
	free(Lit_set2);
	free(Clit2);
}

void SortLiteral2(int **Clit1,int numCli,int changeNo)
{    int i;
     for(i = 0; i < numCli; i++) {
		 int size=Clit1[i+1]-Clit1[i];
		 if(size<2) continue;
		 if(size>2){
			 if(changeNo==1) {Swap(Clit1[i][1],Clit1[i][2]);}
        	 if(changeNo==2) {Swap(Clit1[i][0],Clit1[i][2]);}
         }
	     if(Clit1[i][0]>Clit1[i][1]) Swap(Clit1[i][0],Clit1[i][1]);
	 }
}

void forwardsubsume(int **Clit1,int & numCli, bool pos_neg)
{
	int *plit;
	int i,j,k;
	bool deleteCli;
    if(numCli<10) return;
	// -x -> 2(-x)+1, x -> 2x
    if(pos_neg) for(plit=Clit1[0]; plit<Clit1[numCli]; plit++) *plit=lit2posLit(*plit);
	int *Seen =(int *) calloc (2*numatom+2, sizeof (int));

	for(i=0; i<3; i++){
       deleteCli=false;
//sort literals in each row    
	   SortLiteral2(Clit1,numCli,i);
       int *Lit_set1=Clit1[0];
	   sortClause2(Clit1, Lit_set1,numCli);
       for(j = 1; j < numCli; j++) {
		   if(Clit1[j][0]==0) continue;
		   int size=Clit1[j]-Clit1[j-1];
		   if(size!=2) {//backward subsume
			   if(size>=8) continue;
			   int h=j-1;
			   int m,lit=Clit1[h][0];
			   if(lit==0) continue;
			   for(m=1; m<size; m++) Seen[Clit1[h][m]]=1;
			   for(int k=h-1; k>=0 && k>j-30; k--){
			         int size2=Clit1[k+1]-Clit1[k];
				     if(size2>=size) continue;
			    	 if(Clit1[k][0]==0) continue;
					 if(lit!=Clit1[k][0]) break;
			   		 for(m=1; m<size2; m++){
						 int lit2=Clit1[k][m];
						 if(Seen[lit2]==0) break;
						 
					 }
		             if(m>=size2){
						 Clit1[h][0]=0; // //delete
						 deleteCli=true;
						 break;
					 }
			   }
			   for(m=1; m<size; m++) Seen[Clit1[h][m]]=0;
        	   continue;
             }
		  
		   if(Clit1[j+1]-Clit1[j]<2) continue;
		  
		   if(Clit1[j-1][0]==Clit1[j][0] && Clit1[j-1][1]==Clit1[j][1]) {
			   Clit1[j][0]=0; //delete
			   deleteCli=true;
			   for(k=j+1; k<numCli && k<j+5; k++){
			       if(Clit1[k+1]-Clit1[k]<2) continue; 
		           if(Clit1[j-1][0]==Clit1[k][0] && Clit1[j-1][1]==Clit1[k][1]) {
					  Clit1[k][0]=0; //delete
				   }
			   }
		   }
	   }
	   if(deleteCli) deleteClause(Clit1, numCli);
	}
	if(pos_neg) for(plit=Clit1[0]; plit<Clit1[numCli]; plit++) *plit=posLit2lit(*plit);
    free(Seen);
}

void subsumptionResolution(int vi, int & deletedVnum,bool & NewUnit, int delta);

void XOR_varElimination()
{
	int *pa,*pb,pos,neg,cliB;
	int j,k,m,change,deletedVnum,preNum,lit;
        int alpha,beta;
        
        lit=0;  
        seen=(int *)calloc(numatom+1,sizeof(int));
   	m=deletedVnum=0;
	if(numClauses>150000 && numClauses<1000000){ alpha=4; beta=4;}
	else {alpha=2; beta=3;}
	while(1){
		int clauseLimit=numClauses/20;
	    if(clauseLimit<1000) clauseLimit=numClauses/2;
		clauseLimit+=numClauses;
        Clit=(int**)realloc(Clit, sizeof(int *)*(clauseLimit+100));
	    CNF_space=Clit[numClauses]-Clit[0];
        CNF_space=CNF_space+CNF_space/10;
        Lit_set=(int*)realloc(Clit[0], sizeof(int)*CNF_space);
   	    SetClausePtr(Clit,Lit_set,numClauses);
    	preNum=deletedVnum;
		for(; m < numClauses; m++) {
			if(Clit[m][0]==0) continue;
		    if(Clit[m+1]-Clit[m]>20) continue;
		    int MinOcc=1000000;
		    for(pa=Clit[m]; pa<Clit[m+1]; pa++) {
		       int occN=OccurenceA[*pa][0]+OccurenceA[-(*pa)][0];
			   if(occN<MinOcc) {lit=*pa; MinOcc=occN;}
			}
            if(MinOcc>40 || MinOcc<=4) continue;
            for(pa=Clit[m]; pa<Clit[m+1]; pa++) seen[ABS(*pa)]=*pa;
		    int occN=OccurenceA[-lit][0];
		    int num2=0;
		    for(j=1; j<occN; j++){
   	             k=0;
			     int cliB=OccurenceA[-lit][j];
				 if(Clit[cliB+1]-Clit[cliB]>64) { num2=100; break;}
				 for(pb=Clit[cliB]; pb<Clit[cliB+1]; pb++){
				 		if(seen[ABS(*pb)]==-(*pb)) k++;
				 }
		         if(k<2) num2++;
			}
		    for(pa=Clit[m]; pa<Clit[m+1]; pa++) seen[ABS(*pa)]=0;
		    if(num2>2) goto No_delete;
	        cliB=OccurenceA[-lit][1];
            for(pb=Clit[cliB]; pb<Clit[cliB+1]; pb++) seen[ABS(*pb)]=*pb;
            occN=OccurenceA[lit][0];
		    for(j=1; j<occN; j++){
   	              k=0;
			      int cliA=OccurenceA[lit][j];
				  if(Clit[cliA+1]-Clit[cliA]>64) { num2=10000; break;}
		      	  for(pa=Clit[cliA]; pa<Clit[cliA+1]; pa++){
				 		if(seen[ABS(*pa)]==-(*pa)) k++;
				  }
		          if(k<2) num2++;
			}
		    for(pb=Clit[cliB]; pb<Clit[cliB+1]; pb++) seen[ABS(*pb)]=0;
            if(num2>beta) goto No_delete;
	        pos=OccurenceA[lit][0];
            neg=OccurenceA[-lit][0];
	        num2=0;
			int i;
			for(i=1; i<pos; i++){
   	            int cliA=OccurenceA[lit][i];
   		        for(pa=Clit[cliA]; pa<Clit[cliA+1]; pa++) seen[ABS(*pa)]=*pa;
   	            for(j=1; j<neg; j++){
   	                cliB=OccurenceA[-lit][j];
			        k=0;
					for(pb=Clit[cliB]; pb<Clit[cliB+1]; pb++) if(seen[ABS(*pb)]==-(*pb)) k++;
					if(k<2) num2++;
               }
               for(pa=Clit[cliA]; pa<Clit[cliA+1]; pa++) seen[ABS(*pa)]=0;
			}
			if(num2/alpha>pos+neg) goto No_delete; //2
		    if(numClauses+num2>=clauseLimit) break; //mem Out;
			bool NewUnit;
		    subsumptionResolution(lit, deletedVnum,NewUnit,num2);
	No_delete:
			;
		}
	    if(preNum!=deletedVnum) {
			   int rc=deletegarbage(change);
			   if(rc==UNSAT){
					   printf("c \ns UNSATISFIABLE\n");
                       exit(20);
			   }
		}
		int size=Clit[numClauses]-Clit[0];
		OccurenceA-=numatom;
	    free(OccurenceA[0]);
	    OccurenceA+=numatom;
	   	CNF_index_Mem=(int *) malloc(sizeof(int *)*(size+2*numatom+1));
		setDoubleDataIndex(Clit,OccurenceA,CNF_index_Mem, numClauses,0);
        if(m>=numClauses) break;
	}
    free(seen);
	printf("c XOR_varElimination deleted var#=%d clauses#=%d \n", deletedVnum,numClauses);
}

void extendspace()
{
	CNF_space+=2048;
    Lit_set=(int*)realloc(Clit[0], sizeof(int)*CNF_space);
	SetClausePtr(Clit,Lit_set,numClauses);
}

void subsumptionResolution(int vi)
{
	int i,j,k,m,pos,neg,*pa,*pb,cliA,cliB,k1;
	int *CNF,nclauses;
    int usedSize,delta;

	pos=OccurenceA[vi][0];
	neg=OccurenceA[-vi][0];
	usedSize=Clit[numClauses]-Clit[0];
  	int lit=0;
	if(pos<=1) lit=-vi;
	if(neg<=1) lit=vi;
	if(lit){
		unit[vi]=lit;
	    for(i=1; i<OccurenceA[lit][0]; i++){
   	      cliA=OccurenceA[lit][i];
          Deletedclause[cliA]=1;
		}
		return;
	}
    delta=2;
	nclauses=numClauses;
	int newCNFs=0,end=0;
	for(i=1; i<pos; i++){
   	      cliA=OccurenceA[vi][i];
   		  if(usedSize>CNF_space-512) extendspace();
		  CNF=Clit[numClauses];
		  k1=0;
		  for(pa=Clit[cliA]; pa<Clit[cliA+1]; pa++){
			  if(*pa!=vi) {CNF[k1++]=seen[ABS(*pa)]=*pa;}
		  }
		  if(Deletedclause[cliA]) {
              end=1;
			  goto clearSeen;
		  }
		  k=k1;
	      for(j=1; j<neg; j++){
   	           cliB=OccurenceA[-vi][j];
       	       if(Deletedclause[cliB]) { // clause was deleted 
		             end=1;
			         goto clearSeen;
			   }
			   for(pb=Clit[cliB]; pb<Clit[cliB+1]; pb++){
				   if(*pb==-vi) continue;
                   if(seen[ABS(*pb)]==-(*pb)) goto nextj;
				   if(seen[ABS(*pb)]==0){CNF[k++]=*pb;}
               }
			   newCNFs++;
			   if(newCNFs>pos+neg-delta){
                     end=1;
					 goto clearSeen;
			   }
			   if(k==1){
				   unit[ABS(CNF[0])]=CNF[0];
				   continue;
			   }
		       Clit[++numClauses]=CNF+k;
               usedSize+=k;
			   if(usedSize>CNF_space-512) extendspace();
		       CNF=Clit[numClauses];
		       for(m=0; m<k1; m++) CNF[m]=CNF[m-k]; // move A-type CNF to next
nextj:          
			   k=k1;       
		  }
clearSeen:
          for(pa=Clit[cliA]; pa<Clit[cliA+1]; pa++) seen[ABS(*pa)]=0;
		  if(end) {numClauses=nclauses; return;}
	}
	if(newCNFs<=pos+neg-delta){//set delete mark
		for(i=1; i<pos; i++){ cliA=OccurenceA[vi][i];  Deletedclause[cliA]=1;}
		for(i=1; i<neg; i++){ cliA=OccurenceA[-vi][i]; Deletedclause[cliA]=1;}
		deletedVnum++;
	}
	else numClauses=nclauses;
}	

// subsumption resolution
void old_varElimination()
{   int i;
   
    seen=(int *)calloc(numatom+1,sizeof(int));
    int clauseLimit=2*numClauses;
	Deletedclause= (char *)calloc(clauseLimit+1,sizeof(char));
   	Clit=(int**)realloc(Clit, sizeof(int *)*clauseLimit);
	clauseLimit-=14;
   	deletedVnum=0;
//extend space for subsumption Resolution by clause distribution
	CNF_space=2*(Clit[numClauses]-Clit[0]);
    Lit_set=(int*)realloc(Clit[0], sizeof(int)*CNF_space);
   	SetClausePtr(Clit,Lit_set,numClauses);
	for(i=0; i<14; i++){
	    int vi,preNum=deletedVnum;
		for(vi=1; vi<=numatom; vi++){
			if(numXOR>0) if(XORoccurA[vi][0]>=2) continue;
		    int numOccur=OccurenceA[vi][0]+OccurenceA[-vi][0]; //2
			if(numOccur<=2)	continue;
			else{//14
				if(numClauses>=clauseLimit) break;
				if(numOccur<14 || OccurenceA[vi][0]<=1 || OccurenceA[-vi][0]<=1) {
					subsumptionResolution(vi);
				}
			}
		}
	    int size=Clit[numClauses]-Clit[0];
		free(CNF_index_Mem);
		CNF_index_Mem=(int *) malloc(sizeof(int *)*(size+2*numatom+1));
  		setDoubleDataIndexDel(Clit,OccurenceA,CNF_index_Mem, numClauses,Deletedclause);
		if(preNum==deletedVnum) break;
  	}
	Clit=(int**)realloc(Clit, sizeof(int *)*(numClauses+1));
	int size=Clit[numClauses]-Clit[0];
	Lit_set=(int*)realloc(Clit[0], sizeof(int )*(size));
  	SetClausePtr(Clit,Lit_set,numClauses);
	Deletedclause= (char *)realloc(Deletedclause,sizeof(char*)*(numClauses+1));
  
	printf("c old elimination clauses #=%d \n",numClauses);
   	free(seen);
	return;
}

void sortColumn(int **Clit1,int **Clit2, int *Lit_set2, int j_th,int numCli)
{    int i,j,k,len,lit,sum,clsNum;
     int *clauseCnt,*cluaseLen,*pv;
	 int maxLit=2*numatom+2;
	 
	 clauseCnt=(int *) malloc(sizeof(int)*(2*maxLit));
     cluaseLen=clauseCnt+maxLit;

	 for(i = 0; i < maxLit; i++) clauseCnt[i]=cluaseLen[i] = 0;
     for(i = 0; i < numCli; i++) {
		 len=Clit1[i+1]-Clit1[i];
		 if (j_th >= len) lit=0;
         else lit=ABS(Clit1[i][j_th]);
		 cluaseLen[lit]+=len;
         clauseCnt[lit]++;
     }
	 sum=clsNum=0;
     for(i = 0; i < maxLit;i++) {
 		 j=cluaseLen[i];  cluaseLen[i]=sum;   sum+=j;
		 j=clauseCnt[i];  clauseCnt[i]=clsNum; clsNum+=j;
     }
//copy
     for(i = 0; i < numCli;i++) {
		 len=Clit1[i+1]-Clit1[i];
		 if (j_th >= len) lit=0;
         else lit=ABS(Clit1[i][j_th]);
	
		 k=cluaseLen[lit];
		 Clit2[clauseCnt[lit]]=Lit_set2+k;
		 for(pv=Clit1[i]; pv<Clit1[i+1]; pv++) Lit_set2[k++]=*pv;
         cluaseLen[lit]+=len;
		 clauseCnt[lit]++;
	 }
	 Clit2[numCli]=Lit_set2+(Clit1[numCli]-Clit1[0]);
	 free(clauseCnt);
}	 

// l1 <-> l2
// l1 <-> l2 <-> l3
// l1 <-> l2 <-> l3 <-> l4
int get_2_3_4_equivalence(int **Clit,int *EqFlag,int numCli,int mergeFlag)
{   int i,j,k,m,n,mm,lit2=0;
    int *matchCli,match[17],pattern[17];
	int *pair,*XORno,Xn,mergeAB;

 	XORno=(int *) malloc(sizeof(int)*(numCli+numatom+1));
    pair=XORno+numCli;
	for(i=0; i <=numatom; i++) pair[i]=0;
   	int msize=64;
    matchCli=(int *) malloc(sizeof(int)*(msize));

	Xn=0;
	for(i=0; i< numCli; i++) EqFlag[i]=0;
	for(i=0; i< 16; i++) pattern[i]=0;
	pattern[3]=pattern[5]=pattern[6]=pattern[9]=pattern[10]=pattern[12]=pattern[15]=1;
	i=0; mergeAB=0;
	while (i < numCli ){
		if(EqFlag[i]) {i++; continue;}
		 int size1=Clit[i+1]-Clit[i];
		 if(size1!=4 && size1!=3 && size1!=2) { i=i+1; continue; }
		 mm=n=0;
		 match[3]=match[5]=match[6]=match[9]=match[10]=match[12]=match[15]=0;
		 for(j=i+1; j < numCli; j++){
    		 if((Clit[j+1]-Clit[j])!=size1) break;
			 m=0;
			 for(k=0; k<size1; k++){
			     m=2*m;
	             if(Clit[i][k]==-Clit[j][k]) m++;
			     else{
                   if(Clit[i][k]!=Clit[j][k]) break;
				 }  
			 }
			 if(k<size1) break;
			 if(pattern[m]!=1) continue;
			 if(mm>=msize){
				msize=2*msize;
			//	printf("c msize=%d \n",msize);
		     	matchCli=(int*)realloc(matchCli, sizeof(int)*msize);
			 }
			 matchCli[mm++]=j;
			 if(match[m]!=1){
				  n++;
                  match[m]=1;
			 }
		 }
		 if((size1==4 && n==7) || (size1==3 && n==3) || (size1==2 && n==1)){
			   EqFlag[i]=1;
			   for(k=0;k<mm;k++) EqFlag[matchCli[k]]=2;
//equivalent A <-> B <-> C and A <-> B <-> D ==> C=D    
			   if(size1==3 && mergeFlag==1){  //merge C and D
				   int pi;
				   for(k=0; k<Xn; k++){
 			            int Not,True,lit,lit1;
					    for(pi=0; pi<3; pi++) pair[ABS(Clit[i][pi])]=Clit[i][pi];
			            m=XORno[k]; Not=0, True=0;
                        for(pi=0; pi<3; pi++) {
							lit=Clit[m][pi];
							if(pair[ABS(lit)]==0) {Not++; lit2=lit;}
							else{
								if(pair[ABS(lit)]==-lit) True=True^1;
								pair[ABS(lit)]=0;
							}
						}
						if(Not!=1) continue;
						for(pi=0; pi<3; pi++) {
							lit1=Clit[i][pi];
							if(pair[ABS(lit1)]) break;
						}
			            if(True) lit2=-lit2;
						int a=find1(lit1);
				        int b=find1((lit2));
			            if (a == b) break; //continue;
	                    if (a == -b) { free(XORno); return UNSAT; }
//		            	printf(" a=%d b=%d ",a,b);
					    mergeTwoEqu(a,b);
						mergeAB=1;
						break;
				   }
				   for(pi=0; pi<3; pi++) pair[ABS(Clit[i][pi])]=0;
				   if(k>=Xn) XORno[Xn++]=i;
				   else {
					  EqFlag[i]=2;  // A==B 
				   } 
			   }
			   if(j-i>n+1) i++;
			   else i=j;
		 }
		 else i=j;
	}
	free(XORno);
    free(matchCli);
	if(mergeAB) {
		 mergeAllEqu();
	}
	return SAT;
}

int Remove_3_4_equivalent()
{
	 int i,j,k,sum,newn;
     int lit,True,*pv,var;
	 int delrepeat=0;

     Lit_set=Clit[0];
	 sortClause(Clit, Lit_set,numClauses,4,delrepeat);
	 int mergeFlag=1; 
	 get_2_3_4_equivalence(Clit,EqClause,numClauses,mergeFlag);
//delete non-XOR clauses, remain CNF and XOR clauses 
	int *NewClause=Clit[0];
	sum=newn=0; 
  	for(i=0; i<numClauses; i++){
		 if(EqClause[i]==2) continue;
 		 k=True=0;
  		 for(pv=Clit[i]; pv<Clit[i+1]; pv++){
			lit=*pv;
		   	int lit1=outEquAtom[ABS(lit)];
			if(lit1!=0)	lit=(lit<0)?-lit1:lit1;
			var=ABS(lit);
			if(unit[var]){
				 if(unit[var]==lit) True++;
				 continue;
			}
			if(seen[var]==0) NewClause[sum+k++]=seen[var]=lit;
			else {
				if(seen[var]==-lit) True++;
				if(EqClause[i]==1){
					seen[var]=0;
					int m=0;
                    for(j=0; j<k; j++) if(seen[ABS(NewClause[sum+j])]) NewClause[sum+m++]=NewClause[sum+j];
					k=m;
				}
			}
		 }
		 for(j=0; j<k; j++) seen[ABS(NewClause[sum+j])]=0;
		 if(k==0){
			 if((True==0 && EqClause[i]==0) || (True%2==0 && EqClause[i]==1)) return UNSAT;
			 continue;
		 }
		 if((True>0 && EqClause[i]==0)) continue;
		 if(True%2==1) NewClause[sum]=-NewClause[sum];  
		 if(k==1){
			lit=NewClause[sum];
			unit[ABS(lit)]=lit;
	        continue;
		}
		EqClause[newn]=EqClause[i];
		Clit[newn++]=Clit[0]+sum;
		sum+=k;
	}
	Clit[newn]=Clit[0]+sum;
	numClauses=newn;
	CNF_space=sum;
   	Lit_set=(int*)realloc(Clit[0], sizeof(int)*CNF_space);
   	SetClausePtr(Clit,Lit_set,numClauses);

    free(CNF_index_Mem);
	CNF_index_Mem=(int *) malloc(sizeof(int *)*(CNF_space+2*numatom+1));
	setDoubleDataIndex(Clit,OccurenceA,CNF_index_Mem, numClauses,0);
    return SAT;
}

int propagate_big_clauses(int *Queue,int Qend)
{   int i,cli,m,n,qbegin,lit0,var0;
    int lit1,var1,CNF[2],newTime;
    CNF[0]=0;
    for(qbegin=0; qbegin<=Qend; qbegin++){
		 lit0=Queue[qbegin];  var0=ABS(lit0);
	     TimeAss[var0]=cTimeA;
	     if(lit0<0) TimeAss[var0]++;
	}

	for(qbegin=0; qbegin<=Qend; qbegin++) {
		lit0=Queue[qbegin];
		int sum=OccurenceA[-lit0][0];
        for(i=1; i<sum; i++){
           cli=OccurenceA[-lit0][i];
		   if(Clit[cli+1]-Clit[cli]<3) continue; // it is not big clauses
		   m=n=0;
           int *pv;
		   for(pv=Clit[cli]; pv<Clit[cli+1]; pv++){
	             lit1=*pv;  var1=ABS(lit1);
			 	 if(TimeAss[var1] < cTimeA ){
					  if(m==0)  CNF[m++]=lit1;
					  else {m=2; break;}
				 }
				 else {
				      if(TimeAss[var1]%2==0) lit1=-lit1;
					  if(lit1>0) {n=1; break;}
                 }
			 }
			 if(n>0) continue;
			 if(m==0){
    	//		 printf("\n Big failure sp=%d  ", sp);
		  		 return UNSAT; //failure
			 }
			 if(m==1){
				 if(Qend>=200) break;
		 		 Queue[++Qend]=CNF[0];
				 newTime=cTimeA;
				 if(CNF[0]<0) newTime++;  //false
               	 TimeAss[ABS(CNF[0])]=newTime;
				 continue;
       		 }
		}
	}
    Queue[qbegin]=0;
   	return SAT;
}

// (A V B V C) and  A ^ -B ^ -C ==> D ^ E
// we obtain   (B V C V D) (B V C V E)
// A ^ -B ^ -C ==> false imply -A V B V C
int resolventlookA()
{    int numResolvent;        // the number of resolvent clauses
     int i,j,k,size,Rsize,rc;
     int maxSize,maxN,sum,m,*pv;
     int *queue1;

	 maxSize=12*numClauses;
	 if(maxSize>1200000) maxSize=3*numClauses;
	
	 int *Rlit_set=(int *) malloc(sizeof(int)*maxSize);
     maxN=2*numClauses;
	 if(numClauses>150000) maxN=numClauses; 
	 if(maxN>200000) maxN=200000;
	 int **Rlit=(int **) malloc(sizeof(int*)*(maxN+1));
     Rlit[0]=Rlit_set;
     queue1=(int *) malloc( sizeof(int)*(numatom));

	 numResolvent=sum=0;
	// printf("\nc resolvent \n");
	 for(i=0; i<numClauses; i++){
	     size=Clit[i+1]-Clit[i];
	     if(size<3 || size>10) continue;
//copy
   	     Rsize=0;
	     for(pv=Clit[i]; pv<Clit[i+1]; pv++) queue1[Rsize++]=-(*pv);
	     Rsize--;
	     for(j=0;j<size; j++){
		      queue1[j]=-queue1[j];
			  rc=propagate_big_clauses(queue1,Rsize);
    	      cTimeA+=2;
// add resolvents;
		       if(rc!=UNSAT){
			       if(queue1[size]!=0 && size<4 && numResolvent>numClauses/2) k=size+1; // remove one possibly bad resolvent
				   else k=size;
				   while(queue1[k]!=0){
                       if(sum+size>maxSize) break;
					   for(m=0;m<size;m++) Rlit_set[sum+m]=-queue1[m];
                       Rlit_set[sum+j]=queue1[k++];
                   	   sum+=size;
                       if(numResolvent>=maxN) break;
					   Rlit[++numResolvent]=Rlit_set+sum;
				   }
			   }
			   else{
	               if(sum+size>maxSize) break;
			 	   for(m=0;m<size;m++) Rlit_set[sum+m]=-queue1[m];
                   Swap(Rlit_set[sum+j],Rlit_set[sum+Rsize]);
				   sum+=Rsize;
                   if(numResolvent>=maxN) break;
				   Rlit[++numResolvent]=Rlit_set+sum;
			      // printf("<B: numResolvent=%d>",numResolvent);
			   }
			   queue1[j]=-queue1[j];
		 }
	 }
     free(queue1);
	 //printf("\nc before sorting numResolvent=%d \n",numResolvent);
	 if(numResolvent==0) {
	         free(Rlit); free(Rlit_set);
	         return SAT;
	 }
	 int delrepeat=1;
	 sortClause(Rlit,Rlit_set,numResolvent,4,delrepeat);
 //Copy to lit_set
	 sum=Clit[numClauses]-Clit[0];
	 CNF_space=sum+(Rlit[numResolvent]-Rlit[0]);
	 Lit_set=(int*)realloc(Lit_set, sizeof(int)*CNF_space);
	 SetClausePtr(Clit,Lit_set,numClauses);
//
	 int oldcnt=numClauses;
	 Clit=(int **)realloc(Clit, sizeof(int *)*(numClauses+numResolvent+4));
	 for(i=0; i<numResolvent; i++){
		 for(pv=Rlit[i]; pv<Rlit[i+1]; pv++) Lit_set[sum++]=*pv;
		 Clit[++numClauses]=Lit_set+sum;
     }
	 free(Rlit);
	 free(Rlit_set);
 //remove duplicate clauses
 	 oldcnt=numClauses;
	 sortClause(Clit,Lit_set, numClauses, 4,delrepeat);
         if(numClauses!=oldcnt){
		 CNF_space=Clit[numClauses]-Clit[0];
	     Lit_set=(int*)realloc(Lit_set, sizeof(int)*CNF_space);
		 SetClausePtr(Clit,Lit_set,numClauses);
	 }
         free(CNF_index_Mem);
	 CNF_index_Mem=(int *) malloc(sizeof(int *)*(CNF_space+2*numatom+1));
         setDoubleDataIndex(Clit,OccurenceA,CNF_index_Mem,numClauses,0);
	 return SAT;
}

void sortindex(int *keyvar1,int *keyvar2, int *VarWeight,int pos)
{   int *count;
    int i,sum,m,Msize,val,vv;
    int base;

    base=Msize=1024;
    count=(int *) malloc(sizeof(int)*Msize);
 	for (i = 0; i <Msize; i++) count[i]=0;
    for (i = 0; i <numatom; i++) {
		vv=keyvar1[i];
		if(pos) val=VarWeight[vv]/base;
		else val=VarWeight[vv]%base;
		if (val>=Msize) val=Msize-1;
		count[val]++;
	}
	sum=0;
	for(i=Msize-1; i>=0; i--){
        m=count[i];
		count[i]=sum;
	    sum+=m;
	}
//	int real=count[0];
    for (i = 0; i <numatom; i++){
		vv=keyvar1[i];
		if(pos) val=VarWeight[vv]/base;
		else val=VarWeight[vv]%base;
		if (val>=Msize) val=Msize-1;
		m=count[val];
		
		keyvar2[m]=vv;
		count[val]=m+1;
	}
    free(count);
}

int sortkey(int *keyvar,int *VarWeight)
{   int i,real,vv;
    int *keyvar2=(int *) malloc(sizeof(int)*numatom);
    for (i = 0; i <numatom; i++) keyvar[i]=i+1;
    sortindex(keyvar, keyvar2, VarWeight,0);
    sortindex(keyvar2,keyvar,  VarWeight,1);
    free(keyvar2);
	for (real=numatom-1; real>=0; real--) {
		vv=keyvar[real];
		if(VarWeight[vv]) break;
	}
	real++;
    keyvar[real]=0;
	return real;
}

void setDoubleDataIndexDel(int **Cl,int **clauseSet,int *clauseBase,int numCls,char *Deletedclause)
{
    int i,sum;
    int *occLit,*pv;
	
	occLit =clauseBase;
	int numatom2=2*numatom+1;
    for(i=0; i <numatom2;i++) occLit[i]=0;
	occLit+=numatom;
	for(i =0; i < numCls; i++){
		if(Deletedclause[i]) continue;
		for(pv=Cl[i]; pv<Cl[i+1]; pv++)	occLit[*pv]++;
	}
	sum=0;
	occLit-=numatom;
    clauseSet-=numatom;
    for(i = 0; i < numatom2;i++) {
	     clauseSet[i] =clauseBase+sum;
		 sum+=occLit[i]+1;
    }
	for(i = 0; i < numatom2;i++) clauseSet[i][0]=1;
    clauseSet+=numatom;
	for(i=0; i<numCls; i++) {
		if(Deletedclause[i]) continue; 
		for(pv=Cl[i]; pv<Cl[i+1]; pv++) {
			int n=clauseSet[*pv][0];
			clauseSet[*pv][n]=i;
            clauseSet[*pv][0]=n+1;
		}
	}
}

int Large_Preprocess()
{
    int rc=SimpfySATProblem();
  	if(rc==UNSAT) return UNSAT;

	 int sum=Clit[numClauses]-Clit[0];
	 CNF_index_Mem=(int *) malloc(sizeof(int *)*(sum+2*numatom+1));
	 setDoubleDataIndex(Clit,OccurenceA,CNF_index_Mem, numClauses,0);
  
     printf("c Simplified clause#=%d \n", numClauses);
	 return SAT;
}

int XOR_Preprocess()
{
    int vi,rc;
 
    seen=(int *)calloc(numatom+1,sizeof(int));
	EqClause=(int *) calloc(numClauses, sizeof(int));

	rc=Remove_3_4_equivalent();
 	if(rc==UNSAT) return UNSAT;
    
	numXOR=n_inative=0;
	Split_XOR_CNF();
	free(EqClause);
    if(numClauses>300000 ) goto Eq_reason_end;
 	if(numClauses/50>numatom) goto Eq_simplify; //rpoc_xits_08
	TimeAss=(int *) calloc((numatom+1), sizeof(int)); // time assignment;
    cTimeA=1;
	assert(TimeAss);
	resolventlookA();
    free(TimeAss);
//
Eq_simplify:
 	DependentVar=(int *) malloc( sizeof(int) *(numatom+1));
    for(vi=1; vi<=numatom; vi++) DependentVar[vi]=-2;          //independent

	rc=equivalence_reasonA();
	if(rc==UNSAT) return UNSAT;
 	free(DependentVar);
    printf("c inative var#=%d \n",n_inative);
Eq_reason_end:
   	free(seen);
	return SAT;
}

int GetInactiveXOR(int *inactiveVar,int inactivesize,int *clauseFlag)
{   int i,j,k,n,n1,n2,var=0,lit,Trues,jsum;
    int inaqueue[1000],*px;

 	for(i=0; i<numXOR; i++){
		 if(clauseFlag[i]!=inactivesize) continue;
		 Trues=1;
	     n2=0;
		 for(px=Leq[i]; px<Leq[i+1]; px++){
			 lit=*px;
             vBoolookup[lit]=(vBoolookup[lit]+1)%2;
		 	 inaqueue[n2]=inactiveVar[ABS(lit)];   //Equ No. of inactive var
			 if(inaqueue[n2]>0) n2++;     
         }
		 n1=0;
		 if(n2>=2){
			 if(inaqueue[0]>inaqueue[1]) Swap(inaqueue[0],inaqueue[1]);
			 if(n2==3) if(inaqueue[1]>inaqueue[2]) Swap(inaqueue[1],inaqueue[2]);
		 }
		 while(n1<n2){
			 n=inaqueue[n1++];
			 if(n<=0) continue;
			 Trues++;
			 int *p0=inaLit[n-1];
			 for(px=p0; px<inaLit[n]; px++){
				   lit=*px;
                   vBoolookup[lit]=(vBoolookup[lit]+1)%2;
				   if(px==p0) continue;
				   inaqueue[n2]=inactiveVar[ABS(lit)];
				   if(inaqueue[n2]>0) {
					   int pp=n2-1;
					   while(pp>=n1){
						   if(inaqueue[pp]<=inaqueue[n2]){
							   break;
						   }
						   pp--;
                       }
					   if(inaqueue[pp]==inaqueue[n2] && pp>=n1){
						     while(pp<n2) {inaqueue[pp]=inaqueue[pp+1];pp++;}
					 		 n2--;
                       }
					   else{
						    int p2=n2; 
                			while(pp<p2) {inaqueue[p2+1]=inaqueue[p2];p2--;}
                            inaqueue[pp+1]=inaqueue[++n2];
					   } 
				   }
        	 }
		 }
		 jsum=0;
	   	 for(px=Leq[i]; px<Leq[i+1]; px++){
			 lit=*px; 
             if(vBoolookup[lit]==0){
                  if(vBoolookup[-lit]!=0) inaLit[n_inative][jsum++]=-lit;
             }
			 else{
                 if(vBoolookup[-lit]==0) inaLit[n_inative][jsum++]=lit;
                 else Trues++;
			 }	 
			 vBoolookup[lit]=vBoolookup[-lit]=0;
	     }
		 n1=0;
		 while(n1<n2){
		 	 n=inaqueue[n1++];
			 for(px=inaLit[n-1]; px<inaLit[n]; px++){
					lit=*px;
                    if(vBoolookup[lit]==0){
                           if(vBoolookup[-lit]!=0) inaLit[n_inative][jsum++]=-lit;
					}
			        else{
                          if(vBoolookup[-lit]==0) inaLit[n_inative][jsum++]=lit;
                          else Trues++;
					}
					vBoolookup[lit]=vBoolookup[-lit]=0;
			 }
		 }
	  	 if(jsum==0){
			 if(Trues%2==1) return UNSAT;
			 //	 printf(" \n A: fails to obain an inactive var ");
			 continue;
		 }
//move inactive var to 1st position
		 for(j=0; j<jsum; j++){
              var=ABS(inaLit[n_inative][j]);
		      if(inactiveVar[var]==-1) {
			      Swap(inaLit[n_inative][0], inaLit[n_inative][j]);
			      break;
		      }
         }
		 if(Trues%2==0) inaLit[n_inative][0]=-inaLit[n_inative][0];
		 if(inactiveVar[var]!=-1){  //give up
		     for(k=0; k<jsum; k++) BigEq[numBigXOR][k]=inaLit[n_inative][k];
			 BigEq[numBigXOR+1]=BigEq[numBigXOR]+jsum;
			 numBigXOR++;
			 continue;
         }
		 clauseFlag[i]=-1;
		 inaLit[n_inative+1]=inaLit[n_inative]+jsum;
         n_inative++;
		 inactiveVar[var]=n_inative;
	}
	return SAT;
}

//move one A-eqution to B-equtions
int repalceNextXOR(int **A_eq,int Ano,int **B_eq,int Bno)
{   int n,n1,n2,lit,Trues;
    int *pv,*last;
    int *DepQueue,maxLen;

//	maxLen=Bno+64; //bug equilarge_l2
	maxLen=Bno+4096;
	DepQueue=(int *) malloc(sizeof(int *)*(maxLen+16)); //dependent Queue
    Trues=1;
    n2=0;
	for(pv=A_eq[Ano]; pv<A_eq[Ano+1]; pv++){
		  lit=*pv;
          vBoolookup[lit]=(vBoolookup[lit]+1)%2;
		  DepQueue[n2]=DependentVar[ABS(lit)];   //Equ No. of dependent var
		  if(DepQueue[n2]>0) {
			  seen[DepQueue[n2]]=1;
			  n2++;
		  }
	}
	n1=0;
	if(n2>=2){  //for shortening queue size
		 if(DepQueue[0]>DepQueue[1]) Swap(DepQueue[0],DepQueue[1]);
		 if(n2==3) if(DepQueue[1]>DepQueue[2]) Swap(DepQueue[1],DepQueue[2]);
	}
	while(n1<n2){
		 n=DepQueue[n1++];
		 if(n<=0) continue;
		 if(seen[n]==0){
              DepQueue[n1-1]=-1;
			  continue;
		 }
		 Trues++;
		 int *p0=B_eq[n-1];
		 seen[n]=0;
		 last=B_eq[n-1]+CeqLen[n-1]; //real size
		 for(pv=p0; pv<last; pv++){
			   lit=*pv;
               vBoolookup[lit]=(vBoolookup[lit]+1)%2;
			   if(pv==p0) continue;
			   DepQueue[n2]=DependentVar[ABS(lit)];
			   if(DepQueue[n2]>0) {
				   if(seen[DepQueue[n2]]) seen[DepQueue[n2]]=0;
				   else { 
					   seen[DepQueue[n2]]=1;
				       n2++;
					   if(n2>maxLen){  //reduce memory space
						   int i,j;
						   for(i=j=0; i<n2; i++){ 
							   if(i==n1) n1=j;
							   if(DepQueue[i]>0){
							      DepQueue[j++]=DepQueue[i];
							   }
						   }
						   n2=j;
					   }
				   }
			   }
		 }
	}
	int *Neq=B_eq[Bno];
	for(pv=A_eq[Ano]; pv<A_eq[Ano+1]; pv++){
		lit=*pv;
        if(vBoolookup[lit]==0){
			if(vBoolookup[-lit]!=0) { *Neq=-lit; Neq++;	}
		}
		else{
			if(vBoolookup[-lit]==0) { *Neq=lit;	Neq++;	}
            else Trues++;
		}	 
		vBoolookup[lit]=vBoolookup[-lit]=0;
	}
	n1=0;
	while(n1<n2){
		n=DepQueue[n1++];
		if(n<=0) continue;
		last=B_eq[n-1]+CeqLen[n-1]; //real size
		for(pv=B_eq[n-1]; pv<last; pv++){
			  lit=*pv;
              if(vBoolookup[lit]==0){
                      if(vBoolookup[-lit]!=0) {*Neq=-lit; Neq++;}
			  }
			  else{
                      if(vBoolookup[-lit]==0) {*Neq=lit; Neq++;}
                      else Trues++;
			  }
		      vBoolookup[lit]=vBoolookup[-lit]=0;
		 }
	}
	free(DepQueue);
  	if(Neq==B_eq[Bno]){
		if(Trues%2==1){
		//	printf("\nc false Constant XOR equation ?????\n");
			return UNSAT;
		}
		return CONST_EQ; 
	}
    else if(Trues%2==0) *(Neq-1)=-(*(Neq-1));
    B_eq[Bno+1]=Neq;
	return SAT;
}

/****************************************************************************
	We selects in all equivalence clauses one 
	variable to eliminate from all other equivalence clauses. The
	selection is based on the occurences of variables in the CNF.
*****************************************************************************/
int getXORdependent()
{ 
    int i,j,var,rc,weight;
    int *VeqValues;

    if(numXOR>(numatom+1)){
	    free(seen);
	    seen=(int *)calloc(numXOR,sizeof(int));
	}
	CeqLen=(int *) malloc( sizeof(int)*(numXOR+1));
    BigEq=(int **) malloc( sizeof(int *)*(numXOR+1));
	int virtualsize=64*(Leq[numXOR]-Leq[0]);//64
	
	BigEq_set=(int *) malloc( sizeof(int) *virtualsize);
    VeqValues=(int *) malloc( sizeof(int) *(numatom+1));
	
 //computer the occurences of variables in the CNF weight =11 or 1
	for(var=1; var<=numatom; var++) VeqValues[var]=0;
	for(i=0; i<numClauses; i++){
		 if(Clit[i+1]-Clit[i]==2) weight=11; 	//binary
		 else weight=1; 		//ternary
	     for(int *pv=Clit[i]; pv<Clit[i+1]; pv++){
			 var=ABS(*pv);
             VeqValues[var]+=weight;
		 }
	 }
//copy first XOR
	BigEq[0]=BigEq_set;
	CeqLen[0]=Leq[1]-Leq[0];
	for(j=0; j<CeqLen[0]; j++) BigEq[0][j]=Leq[0][j]; 
	BigEq[1]=BigEq[0]+CeqLen[0];
    numBigXOR=1;
	int oldeqNo,depFlag=1;
	for(oldeqNo=1; oldeqNo<=numXOR; oldeqNo++){
// find dependent variables
		if(depFlag){
			int *first=BigEq[numBigXOR-1];
		    int *minpos=first;
		    int min=600000;
		    int *p;
            for(p=first; p<BigEq[numBigXOR]; p++){
			   var=ABS(*p);
			   if(DependentVar[var]!=-2) continue; //not independent
			   if(VeqValues[var]<min){ min=VeqValues[var]; minpos=p;}
			}
	        if(min!=600000){
    		   Swap(*first, *minpos);
	           var=ABS(*first);
			   DependentVar[var]=numBigXOR;   //eq. no from 1 (not 0)
			}
		}
        if(oldeqNo==numXOR) break;
//get big XOR clause
		rc=repalceNextXOR(Leq,oldeqNo,BigEq,numBigXOR);
		if(rc==UNSAT) return UNSAT;
		if(rc==CONST_EQ) {
			free(BigEq_set);
         	free(BigEq);
        	free(VeqValues);
            free(CeqLen);
			return CONST_EQ; //constant equation
			//depFlag=0; continue;
		}
		depFlag=1;
		CeqLen[numBigXOR]=BigEq[numBigXOR+1]-BigEq[numBigXOR];
		numBigXOR++;
	}
	free(VeqValues);
//save old Leq
	int *old_Leq_base=Leq_base;
	int old_numXOR=numXOR;
	int **old_Leq=Leq;
    Leq=(int **) malloc( sizeof(int*)*(numXOR+1));
//remove all dependent var;
	numXOR=numBigXOR;
	BigEq_set=(int*)realloc(BigEq_set, sizeof(int)*(BigEq[numXOR]-BigEq[0]));
	int newEQsize=4*virtualsize;
	Leq_base=(int *) malloc( sizeof(int)*newEQsize);
//copy last XOR
    Leq[0]=Leq_base;
	int Asum=0;
	int *pv;
    for(pv=BigEq[numXOR-1]; pv<BigEq[numXOR]; pv++) Leq[0][Asum++]=*pv;
	CeqLen[0]=Asum;
	if(Asum<6) Asum=8*Asum;
	else Asum=4*Asum;
	Leq[1]=Leq[0]+Asum;
	numXOR=1;
//copy other XOR
	for(var=1; var<=numatom; var++) DependentVar[var]=-2; //-2 : independent  >0 : Equ.no
	for(i=numBigXOR-2; i>=-1; i--){
		var=Leq[numXOR-1][0];
		var=ABS(var);
		if(DependentVar[var]==-2) DependentVar[var]=numXOR;
		if(i==-1) break;
		
	    if(newEQsize-8000<Leq[numXOR]-Leq[0]){ //bug ???
//			printf("c extending memory=%d \n",newEQsize);
            free(Leq_base);
            free(BigEq_set);
        	free(BigEq);
            free(Leq);
            free(CeqLen);

            Leq=old_Leq;
	        Leq_base=old_Leq_base;
            numXOR=old_numXOR;
			return CONST_EQ;
		}
		
		rc=repalceNextXOR(BigEq,i, Leq,numXOR);
		int size=CeqLen[numXOR]=Leq[numXOR+1]-Leq[numXOR];
		numXOR++;
    	if(size<6) size=4*size;
	    else size=2*size;
		Leq[numXOR]+=size; //double (three) space for shortening Eq cluases
	}
//endeq:
	free(old_Leq);
	free(old_Leq_base);

	free(BigEq_set);
	free(BigEq);
	Leq_base=(int*)realloc(Leq_base, sizeof(int)*(Leq[numXOR]-Leq[0]));
	SetClausePtr(Leq, Leq_base, numXOR);
	return SAT;
}

// Copy XOR equation and CNF clauses from CNF bases
void Split_XOR_CNF()
{    int i,XORsum,CNFsum,*pv;
     int numCNF,size;

     numXOR=size=0;
	 for(i=0; i<numClauses; i++){
		 if(EqClause[i]!=1) continue;
         numXOR++;
         size+=Clit[i+1]-Clit[i];
	 }
	 if(numXOR==0) return;
	 XORoccurA=(int **) malloc( sizeof(int*)*(numatom+1));
	 Leq_base=(int *) malloc( sizeof(int)*(size));
     
	// printf(" Leq_base=%d size=%d numXOR=%d\n",Leq_base,size,numXOR);
	 
	 Eq_base=(int *) malloc( sizeof(int)*(size+numatom+1)); //bug ??? Leq_base+size;
     Leq=(int **) malloc( sizeof(int*)*(numXOR+1));
     numXOR=numCNF=XORsum=CNFsum=0;
	 Leq[0]=Leq_base;
	 for(i=0; i<numClauses; i++){
//         printClause(i);
      	 if(EqClause[i]==1){
		     for(pv=Clit[i]; pv<Clit[i+1]; pv++) Leq_base[XORsum++]=*pv;
		     Leq[++numXOR]=Leq_base+XORsum;
		 }
		 else{
             for(pv=Clit[i]; pv<Clit[i+1]; pv++) Lit_set[CNFsum++]=*pv;
		     Clit[++numCNF]=Lit_set+CNFsum;
		 }
	 }
     numClauses=numCNF;
	 setDoubleDataIndex(Clit,OccurenceA,CNF_index_Mem,numClauses,0);
	 setEqDataStruct(Leq,XORoccurA,Eq_base,numXOR);
}

/****************************************************************************
	Find inactive variables in equivalence clauses 
	Eliminate it from all other equivalence clauses. 
	This process is based on the occurences of variables in the CNF and XOR.

*****************************************************************************/
int RemoveInative_XOR_Equ() //c7bidw_i
{    int i,j,CnOccur;
     int *inactiveVar,*clauseFlag,*px;

   	 inactiveVar=(int *) malloc( sizeof(int) *(2*numatom+8+numXOR));
     clauseFlag=inactiveVar+numatom+1;

// find inactive variables
    n_inative=0;     
    for(i=1; i<=numatom; i++) {
		 inactiveVar[i]=-2;
		 CnOccur=OccurenceA[i][0]+OccurenceA[-i][0]; //2
    	 if(CnOccur<=2 && XORoccurA[i][0]>1) {
			 n_inative++;
			 inactiveVar[i]=-1;
		 }
    }
    if(n_inative==0) {
	    free(inactiveVar);
		return SAT;
	}

	inaLit=(int **) malloc( sizeof(int *) *(n_inative+10));
	iLit_set=(int *) malloc( sizeof(int) *(400*n_inative)); //100

// find inactive XOR equtions
	int max=0,min=1000, m=0;
	for(i=0; i<numXOR; i++){
		clauseFlag[i]=0;
		for(px=Leq[i]; px<Leq[i+1]; px++){
       		  if(inactiveVar[ABS(*px)]==-1) clauseFlag[i]++;
		}
		if(clauseFlag[i]==0) {m++; continue;}
		if(clauseFlag[i]<min) min=clauseFlag[i];
		if(clauseFlag[i]>max) max=clauseFlag[i];
	}
    
	BigEq=(int **) malloc( sizeof(int *)*(numXOR+1));
	int virtualsize=20*(Leq[numXOR]-Leq[0]);
	BigEq_set=(int *) malloc( sizeof(int) *virtualsize);

	inaLit[0]=iLit_set;
	BigEq[0]=BigEq_set;
	n_inative=numBigXOR=0;
    
	for(i=min;i<=max; i++) {
    	int rc=GetInactiveXOR(inactiveVar,i,clauseFlag);
		if(rc==UNSAT) return UNSAT;
    }
   
// Copy active XOR equtions
	int numclause=0;
   	for(i=0; i<numXOR; i++){
		 if(clauseFlag[i]!=0) continue;
         j=0;
		 for(px=Leq[i]; px<Leq[i+1]; px++) Leq[numclause][j++]=*px;
  		 Leq[numclause+1]=Leq[numclause]+j;
         numclause++;
 	}
	int newsize=Leq[numclause]-Leq[0];
    newsize+=(BigEq[numBigXOR]-BigEq[0]);
    Leq_base=(int*) realloc(Leq[0], sizeof(int)*(newsize));
    SetClausePtr(Leq, Leq_base, numclause);
 
//	printf("\n newsize=%d ",newsize);
 
// Copy big XOR clauses
	for(i=0; i<numBigXOR; i++){
		 j=0;
         for(px=BigEq[i]; px<BigEq[i+1]; px++) Leq[numclause][j++]=*px;
 		 Leq[numclause+1]=Leq[numclause]+j;
         numclause++;
 	}
    numXOR=numclause;
	free(BigEq);
	free(BigEq_set);
	free(inactiveVar);

//re-adjust memory size
	int isize=inaLit[n_inative]-inaLit[0];
	iLit_set=(int*) realloc(iLit_set, sizeof(int)*isize);
    for(i=1; i<=n_inative; i++){
         inaLit[i]=iLit_set+(inaLit[i]-inaLit[0]);
    }
	inaLit[0]=iLit_set;
	return SAT;
}

int equivalence_reasonA()
{  int i, rc;
   int num;
   int *p1;

   if(numXOR==0) return SAT;
   vBoolookup = (int *) malloc( sizeof(int) *(2*numatom+1));
   for(i=0; i<=2*numatom; i++) vBoolookup[i]=0; 
   vBoolookup+=numatom;

   rc=RemoveInative_XOR_Equ();
   if(rc==UNSAT) return UNSAT;
   if(numXOR==0){//bug
       free(vBoolookup-numatom);
   	   return SAT;
   }
   if(n_inative<50) crypto_Gss=false;
   if(numClauses>500000 || numatom>100000 || numXOR>10000 || crypto_Gss){
      free(vBoolookup-numatom);
      goto setpoint;
   }
   
   rc=getXORdependent();
   if(rc==UNSAT) return UNSAT;
   if(rc==CONST_EQ) {
       free(vBoolookup-numatom);
	   goto setpoint;
   }
   shorten_equivalenceA();
   free(vBoolookup-numatom);

//set active XOR equtions data structure
  
   p1=Leq[0];
   for(i=0; i<numXOR; i++){
       if(CeqLen[i]==0) continue; //empty
           int *pv;
           for(pv=Leq[i]; pv<Leq[i]+CeqLen[i]; pv++) {
		      *p1=*pv; p1++; 
		   }
   }
   num=1;
   for(i=0; i<numXOR; i++){
      if(CeqLen[i]==0) continue; //empty
	   Leq[num]=Leq[num-1]+CeqLen[i];
       num++;
   }
   num--;
   numXOR=num;
   free(CeqLen);
 //  Active size
setpoint:
   int size=Leq[numXOR]-Leq[0];
   Leq_base=(int*) realloc(Leq_base, sizeof(int)*(size));
   SetClausePtr(Leq, Leq_base, numXOR);
   Eq_base=(int*) realloc(Eq_base, sizeof(int)*(size+numatom+1));
   setEqDataStruct(Leq,XORoccurA,Eq_base,numXOR);
   return SAT;
}

void buildEQdatastructure(int **VarEq,int *Vspace)
{   int i, var,sum;
    int *pv, *last;
	
    for(i = 0; i <= numatom;i++) Vspace[i] = 0;
    for(i=0; i<numXOR; i++) {
	   last=Leq[i]+CeqLen[i];
	   for(pv=Leq[i]; pv<last; pv++) Vspace[ABS(*pv)]++;
	}
	sum=0;
    for(i = 1; i <= numatom;i++){
		if(Vspace[i]>=1){
		    if(Vspace[i]>=40) Vspace[i]+=20;  // resvered space
			else Vspace[i]=2*Vspace[i]+1;
		}
		sum+=Vspace[i];
    }
   	VarEq[0]=(int *) malloc( sizeof(int)*(sum));
    for(i=1; i <= numatom;i++) {
	  	 VarEq[i]=VarEq[i-1]+Vspace[i-1];
		 if(Vspace[i]>0) VarEq[i][0]=1; 
	}
   
	for(i=0; i<numXOR; i++) {
	//   last=ActXORclause[i]+CeqLen[i];
	   last=Leq[i]+CeqLen[i];
	   for(pv=Leq[i]; pv<last; pv++){
          var=ABS(*pv);
		  int k=VarEq[var][0];
		  VarEq[var][k]=i;
		  VarEq[var][0]=k+1;
	   }
	}
}

extern char *FileName;

//int solveLargeCNF(char *FileName, int *solution);
		 
//replace eqJ with eqI+eqJ
void replace_OneEquivalence(int eqI,int eqJ,int **VarEq,int *Vspace)
{   int NewEq[2000],m;
    int lit,var,i,j,n,Trues;
    int *last,*pv;

    m=0;
  
	last=Leq[eqJ]+CeqLen[eqJ];
	for(pv=Leq[eqJ]; pv<last; pv++){
		  NewEq[m++]=lit=*pv;
          vBoolookup[lit]=(vBoolookup[lit]+1)%2;
	}
    
	last=Leq[eqI]+CeqLen[eqI];
	for(pv=Leq[eqI]; pv<last; pv++){
		  NewEq[m++]=lit=*pv;
          vBoolookup[lit]=(vBoolookup[lit]+1)%2;
	}

	n=Trues=0;
	for(i=0; i<m; i++){
	     lit=NewEq[i];
         if(vBoolookup[lit]==0){
               if(vBoolookup[-lit]!=0) NewEq[n++]=-lit;
		 }
		 else{
               if(vBoolookup[-lit]==0) NewEq[n++]=lit;
               else Trues++;
		 }
	     vBoolookup[lit]=vBoolookup[-lit]=0;
	}
        if(Leq[eqJ]+n > Leq[eqJ+1]){
//           printf("c  No Space new size=%d old size[%d]=%d \n",n,eqJ,Leq[eqJ+1]-Leq[eqJ]);
//	       int result=solveLargeCNF(FileName, (int *)0);
		   exit(0);
           return; // No space
     }
	if(Trues%2==0) NewEq[0]=-NewEq[0];
    pv=Leq[eqJ];
	for(i=0; i<CeqLen[eqJ]; i++){
		var=ABS(pv[i]);
		for(j=1;j<VarEq[var][0]; j++){ //delete
			if(VarEq[var][j]==eqJ){
                int k=VarEq[var][0]-1;
				Swap(VarEq[var][j],VarEq[var][k]);
                VarEq[var][0]=k;
				break;
			}
		}
	}
	for(i=0; i<n; i++) pv[i]=NewEq[i]; //add new Eq
   	CeqLen[eqJ]=n;
   	for(i=0; i<n; i++) {
		var=ABS(NewEq[i]);
		if(Vspace[var]<=VarEq[var][0]){
			free(VarEq[0]);
			buildEQdatastructure(VarEq,Vspace);
            return;
        }
		int k=VarEq[var][0];
        VarEq[var][k]=eqJ;
        VarEq[var][0]=k+1;
	}
}
void replace_equivalence(int EqI,int var,int **VarEq,int *Vspace,int *EqnoJ)
{   int i,cnt;
    int *first,*last,*pv;

    cnt=0;
    for(i=1; i < VarEq[var][0] ; i++) if(EqI!=VarEq[var][i]) EqnoJ[cnt++]=VarEq[var][i];
   	first=Leq[EqI];
    last=first+CeqLen[EqI];
	for(pv=first+1; pv<last; pv++) if(var==ABS(*pv)) break;
    if(pv<last){ //Exchange Space
          int v1=ABS(*first);
	      Swap(*first,*pv);
          if(VarEq[v1][0]==2){
			 // printf("\n Var[%d]=%d v1=%d ", var,VarEq[var][0],v1);
			  int *tmp=VarEq[v1]; 
			  VarEq[v1]=VarEq[var]; VarEq[var]=tmp;
			  
			  VarEq[v1][0]=VarEq[var][0]=2;
			  VarEq[v1][1]=VarEq[var][1]=EqI;
			  Swap(Vspace[var],Vspace[v1]);
		  }
	}
    for(i=0; i < cnt; i++ ){
       replace_OneEquivalence(EqI,EqnoJ[i],VarEq,Vspace);
	}
}	

void shorten_equivalenceA()
{
	int i, j, k,n, doublenf,v1,v2,iterCounter;
	int current, counter,var;
    int **VarEq,*Vspace,*EqnoJ;

    int sum=0;
	for(i=0; i<numXOR; i++) sum+=CeqLen[i];
	printf("c before shortening average=%f, XOR clauses#=%d \n", (double)sum/(double)numXOR,numXOR);

	VarEq =(int **) malloc( sizeof(int *) *(numatom+1));
	Vspace=(int *) malloc( sizeof(int) *(numatom+1));
   	EqnoJ=(int *) malloc( sizeof(int)*numXOR);
	buildEQdatastructure(VarEq,Vspace);
  	do
	{
	       iterCounter = 0;
           for( i = numXOR-1; i >=0; i-- )
		   {   		       
			  if(CeqLen[i]<=2) continue;
        	  int *pv=Leq[i];
		      var=ABS(*pv);
		      if(DependentVar[var]<0) continue; //is not dependent ?
              if(CeqLen[i]== 3 )
			  {   
			      v1=ABS(*(pv+1));
	              v2=ABS(*(pv+2));
				  if(DependentVar[v1]==-3 || DependentVar[v2]==-3) continue; 
	              doublenf = 0;
//both are in the same clause ?
                  for( k=1; k < VarEq[v1][0]; k++ ){
		             for( n = 1; n < VarEq[v2][0]; n++)
						if( VarEq[v1][k] == VarEq[v2][n] ) doublenf++;
				  }
//Change dependent variables
                  if( VarEq[v1][0] <= VarEq[v2][0] )
				  {
                    if( VarEq[v1][0] < (2*doublenf) )
					{
						DependentVar[var]=-3; // -2 or -3 INDEPENDENT;
						DependentVar[v1] =i+1;  // dependent
						replace_equivalence(i,v1,VarEq,Vspace,EqnoJ);
		                iterCounter++;
                    }
				  }
                  else if( VarEq[v2][0] < (2*doublenf) )
				  {
                    	DependentVar[var]=-3; // INDEPENDENT;
						DependentVar[v2] =i+1;  // dependent
						replace_equivalence(i,v2,VarEq,Vspace,EqnoJ);
			            iterCounter++;
				  }
			  }
	          else if(CeqLen[ i ] == 4)
			  {   int *p1=pv+1; 
	  	          for( j = 0; j < 3; j++ )
				  {
			         current = ABS(*(pv+j));
					 v1      = *(p1+(j+1)%3);
					 v1=ABS(v1);
					 v2      = *(p1+(j+2)%3);
			         v2=ABS(v2);

					 if(DependentVar[current]==-3) continue; 
					 counter = 2 - VarEq[current][0];		
			         for( k = 1; k < VarEq[current][0]; k++ )
					 {
				         int eqNo = VarEq[current][k];
					     if( eqNo == i ) continue;
					     int *pn;
                         for(pn=Leq[eqNo]; pn<Leq[eqNo]+CeqLen[eqNo]; pn++ )
						 {	  int vv=ABS(*pn);				        
						      if( (vv==v1) || vv==v2 ) counter++;
						 }
			             if( counter > 0 )
						 {
		          	          DependentVar[var]=-3;    // INDEPENDENT;
						      DependentVar[current]=i+1;  ////dependent
						      replace_equivalence(i,current,VarEq,Vspace,EqnoJ);
							  iterCounter++;
                              break;
						 }
					 }
				  }
			  }
		   }
	} while( iterCounter );
    free(EqnoJ);
//
	sum=0; int Cqcnt=0;
	for(i=0; i<numXOR; i++) {
	    if(CeqLen[i]) Cqcnt++;
		sum+=CeqLen[i];
	}
	printf("c after shortening average=%f XOR clauses#=%d \n",	(double)sum/(double)Cqcnt, Cqcnt);
	
   free(VarEq[0]);
   free(VarEq);
   free(Vspace);
}
