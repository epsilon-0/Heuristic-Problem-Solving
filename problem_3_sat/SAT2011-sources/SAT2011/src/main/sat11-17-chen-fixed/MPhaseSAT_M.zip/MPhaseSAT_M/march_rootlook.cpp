#include <assert.h>
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>

#include "march_common.h"
#include "march_extvar.h"

int find_and_propagate_bieq();
void add_binary_equivalence( int lit1, int lit2 );
void fixEq( int nr, int pos, int value );

void allocateTernaryImp( int **_tImpTable, int ***_tImp, int **_tImpSize );
void freeTernaryImp( int *_tImpTable, int **_tImp, int *_tImpSize );
void allocateVc( int ***__Vc, int ***__VcLUT );
void allocateSmallVc( int ***__Vc, int length );
void freeVc( int **__Vc, int **__VcLUT );
void freeSmallVc( int **__Vc );
void rebuild_BinaryImp( );
void resize_BinaryImp( );
void free_BinaryImp( );

void cleanFormula();
void   ternarylook_detect_constraint_resolvents( const int lit1, const int lit2 );

void print_binary_all_equal();
void print_ternary_all_equal();
int root_iterative_lookahead();
int root_subsume();

int root_lookahead_literal( int nrval, int **_Vc, int **_qVc );
int root_iterative_unit_propagation( int nrval, int **_Vc, int **_qVc );
void root_clause_instantiation( int clsidx, int **_Vc, int **_qVc );

int root_add_constraint_resolvent( int nrval, int literal );

inline int  root_reduce_ternary_clauses( const int nrval, const int current );
int root_reduce_equivalences( int nrval, int current );
int  root_reduce_long_clauses( int nrval, int *_qVc );

void root_subsume_ternary_clauses( int nrval, int *__Vc );
void root_find_new_equivalences( int nrval, int *__Vc );

int root_fix_forced_literal( int nrval, int **_Vc);
int root_find_na( int nrval, int **_Vc );
int root_propagate_unary_clauses();

int  root_fix_binary_implications( int nrval );

int AddTernaryResolvents();

void cleanBinaryImp();
void fix_monotone();
int singlelook();

int root_iteration_flag;

int *root_fixstack, *root_fixstackp;
int *root_na_stack, *root_na_stackp;

int subsumed;

//#define ADD_BLOCKED_BINARIES // werkt nog niet

#ifdef ADD_BLOCKED_BINARIES
int *blocked_flag;
#endif

#define IS_PURE_LITERAL(__a)	(_Vc[ -(__a) ][ 0 ] == 0) && (_Vc[ __a ][ 0 ] > 0)

#define PUSH_ROOT_NA( __a ) \
{ \
	if( timeAssignments[ __a ] >= VARMAX ) \
	{ \
	    if( FIXED_ON_COMPLEMENT( __a )  )\
	 	return 0; \
	} \
	else \
	{ \
	    timeAssignments[  __a ] = VARMAX; \
	    timeAssignments[ -__a ] = VARMAX + 1; \
	    *( root_na_stackp++ ) = __a; \
	} \
}

int root_iterative_lookahead()
{
#ifdef ADD_BLOCKED_BINARIES
	MALLOC_OFFSET( blocked_flag, int, nrofvars, 0 );
#endif	
	do
	{
	    root_iteration_flag = 0;

	    if( root_subsume() == UNSAT )
		return UNSAT;

	    compactCNF();		

	    find_and_propagate_bieq();
	    sort_literals();

	    if( find_and_propagate_unary_clauses() == UNSAT )
		return UNSAT;

	    compactCNF();
	    sort_clauses();	
	}
	while( root_iteration_flag );

#ifdef ADD_BLOCKED_BINARIES
	FREE_OFFSET( blocked_flag );
#endif
	return SAT;
}
#ifdef ADD_BLOCKED_BINARIES
inline void root_add_blocked_binaries( const int nrval, const int clsidx )
{
	if( blocked_flag[ nrval ] == 0 )
	{
	    int i;

	    blocked_flag[ nrval ] = 1;

	    for( i = 0; i < Clength[ clsidx ]; i++ )
	    {
		if( Cv[ clsidx ][ i ] != nrval )	
		{ 
		    blocked_flag[ Cv[ clsidx ][ i ] ] = 1;
		    printf("adding blocked binary %i v %i\n",  -Cv[ clsidx ][ i ], -nrval );
		    CHECK_AND_ADD_BINARY_IMPLICATIONS( -Cv[ clsidx ][ i ], -nrval ); 
		}
	    }
	}
}
#endif
int root_subsume()
{
	int i, j, **_Vc, **_qVc, tmp, _result;
	int *_tImpTable, **_tImp, *_tImpSize;

	int *initial_binary_implications;

	rebuild_BinaryImp();

	initial_binary_implications = (int*) malloc( sizeof(int) * (2* nrofvars + 1) );
	initial_binary_implications += nrofvars;

	for( i = -nrofvars; i <= nrofvars; i++ )
		initial_binary_implications[ i ] = BinaryImp[ i ][ 0 ];

	subsumed = 0;
	_result  = 1;

	root_fixstack = (int *) malloc( sizeof(int) * ( nrofvars + 1) );
	root_na_stack = (int *) malloc( sizeof(int) * ( nrofvars + 1) );

	allocateTernaryImp( &_tImpTable, &_tImp, &_tImpSize );
	allocateSmallVc( &_qVc , 4 );
	allocateSmallVc( &_Vc  , 2 );

	_qVc  += nrofvars;
	_Vc   += nrofvars;

	TernaryImp     = _tImp;
	TernaryImpSize = _tImpSize;

        cleanFormula();
        currentTimeStamp = 4;


        for( i = 1; i < nrofvars; i++ )
	    if( Veq[ i ][ 0 ] == 1 )
	    {
	 	if     ( IS_PURE_LITERAL(-i) ) root_fix_forced_literal( -i, _Vc );
		else if( IS_PURE_LITERAL( i) ) root_fix_forced_literal(  i, _Vc );
		else if( i > original_nrofvars ) continue;
		if( _Vc[  i ][ 0 ] == 1 )				   // moet in het algemene beeld 
		{							   // van blocked clauses!!!
		    tmp = _Vc[  i ][ 1 ];
                    if( Clength[ tmp ] == 2 )
                    {
                        add_binary_equivalence( Cv[tmp][0], Cv[tmp][1] );
                        Clength[ tmp ] = 0;
		    }
		}
		if( _Vc[ -i ][ 0 ] == 1 )
		{
		    tmp = _Vc[ -i ][ 1 ];
                    if( Clength[ tmp ] == 2 )
                    {
                        add_binary_equivalence( Cv[tmp][0], Cv[tmp][1] );
                        Clength[ tmp ] = 0;
                    }
		}
#ifdef ADD_BLOCKED_BINARIES
		if( _Vc[  i ][ 0 ] == 1 ) 
		    root_add_blocked_binaries(  i, _Vc[  i ][ 0 ] );
		if( _Vc[ -i ][ 0 ] == 1 ) 
		    root_add_blocked_binaries( -i, _Vc[ -i ][ 0 ] );
#endif
	    }

        lookaheadArrayLength = 0;
        for( i = 1; i < nrofvars; i++ )
	{
	    if(  ((_Vc[ i ][ 0 ] + _Vc[ -i ][ 0 ] == 0)	// if variable does not occur in CNF
		  && (Veq[ i ][ 0 ] == 1 )) 		// and does not occur in CoE
		  || (timeAssignments[ i ] >= VARMAX) )	// or is already fixed 
		continue;				// then skip this variable

	    lookaheadArray[ lookaheadArrayLength++ ] =  i;
	}

	freevarsArray = lookaheadArray;
	freevars      = lookaheadArrayLength;

	//ComputeRank();

        cleanFormula();

        forced_literals  = 0;
        currentTimeStamp = 4;

        if( treebased_lookahead() == 0 ) return UNSAT;

        for( i = 0; i < tree_elements; i++ )
        {
	    currentTimeStamp += treeArray[ i ].gap;
            if( !root_lookahead_literal( treeArray[ i ].literal, _Vc, _qVc ) )
            {
		if( !root_fix_forced_literal( -treeArray[ i ].literal, _Vc ) )
		{
		    printf("c conflict occured during root_subsume()\n");
		    _result = 0;
		    goto rootlook_subsume_free;
		}
            }
	    else if( !root_find_na( treeArray[ i ].literal, _Vc ) )
	    {
		printf("c conflict occured during root_subsume()\n");
		_result = 0;
		goto rootlook_subsume_free;
	    }
            currentTimeStamp -= treeArray[ i ].gap;
 	}

	compactCNF();

	rootlook_subsume_free:;

	TernaryImpSize = NULL;
	TernaryImp     = NULL;
	
	_Vc   -= nrofvars;
	_qVc  -= nrofvars;
	freeSmallVc( _Vc  );
	freeSmallVc( _qVc );
	freeTernaryImp( _tImpTable, _tImp, _tImpSize );

	free( root_fixstack );
	free( root_na_stack );

	cleanFormula();

	if( _result == 0 ) return 0;

	tmp = 0;
	for( i = -nrofvars; i <= nrofvars; i++ )
	{
	    if( timeAssignments[ i ] >= VARMAX )	continue;

	    for( j = initial_binary_implications[ i ]; j < BinaryImp[  i ][ 0 ]; j++ )
	 	if( (timeAssignments[ BinaryImp[  i ][ j ] ] < VARMAX) && (NR(BinaryImp[  i ][ j ]) > NR(i)) )
		    tmp++;
	}

	Cv      = (int**) realloc( Cv     , sizeof( int*) * (nrofclauses + tmp) ); 
	Clength = (int* ) realloc( Clength, sizeof( int ) * (nrofclauses + tmp) ); 

	for( i = -nrofvars; i <= nrofvars; i++ )
	{
	    if( timeAssignments[ i ] >= VARMAX )	continue;

	    for( j = initial_binary_implications[ i ]; j < BinaryImp[  i ][ 0 ]; j++ )
		if( (timeAssignments[ BinaryImp[  i ][ j ] ] < VARMAX) && (NR(BinaryImp[ i ][ j ]) > NR(i)) )
		{
		    Cv     [ nrofclauses ] = (int *) malloc( sizeof(int ) * 2);
		    Clength[ nrofclauses ] =  2;
		    Cv[ nrofclauses ][ 0 ] = -i;
		    Cv[ nrofclauses ][ 1 ] = BinaryImp[ i ][ j ];
		    nrofclauses++;
		}
	}

	initial_binary_implications -= nrofvars;
	free( initial_binary_implications );

	printf("c root_subsume():: %i ternary clauses were subsumed, nrofceq = %i\n", subsumed, nrofceq);

	return 1;
}

int root_fix_forced_literal( int nrval, int **_Vc )
{
	int i, j, k, *_root_na_stackp, current, clsidx, lit1, lit2;

	root_iteration_flag = 1;

	root_na_stackp  = root_na_stack;
	_root_na_stackp = root_na_stackp;

        timeAssignments[  nrval ] = VARMAX;
        timeAssignments[ -nrval ] = VARMAX + 1;

        *( root_na_stackp++ ) = nrval;

        while( _root_na_stackp < root_na_stackp )
        {
	    current = *( _root_na_stackp++ );

	    freevars--;
		
	    for( i = 1; i <= _Vc[ current ][ 0 ] ; i++ )
               	Clength[ _Vc[ current ][ i ] ] = 0;

            for( i = 2; i < BinaryImp[ current ][ 0 ]; i++ )
		PUSH_ROOT_NA( BinaryImp[ current ][ i ] );

            for( i = 1; i <= _Vc[ -current ][ 0 ]; i++ )
            {
               	clsidx = _Vc[ -current ][ i ];
            	for( j = 0; j < Clength[ clsidx ]; j++ )
                {
                    if( Cv[ clsidx ][ j ] == -current )
                    {
			Cv[ clsidx ][ j-- ] = Cv[ clsidx ][ --( Clength[ clsidx ] ) ];

			if( Clength[ clsidx ] == 2 )
			{
			    lit1 = Cv[ clsidx ][ 0 ];
			    lit2 = Cv[ clsidx ][ 1 ];
						
			    for( k = 2; k < BinaryImp[ -lit1 ][ 0 ]; k++ )
			    {
			        if( BinaryImp[ -lit1 ][ k ] == lit2 )
				    goto skip_addition;
				else if( BinaryImp[ -lit1 ][ k ] == -lit2 ) 		
				{
				    PUSH_ROOT_NA( lit1 );
				    goto skip_addition;
				}
			    }

			    for( k = 2; k < BinaryImp[ lit1 ][ 0 ]; k++ )
			    {
			        if( BinaryImp[ lit1 ][ k ] == -lit2 )
			 	{
				    add_binary_equivalence( lit1, lit2 );
				    goto skip_addition;
				}
				else if( BinaryImp[ lit1 ][ k ] == lit2 ) 		
				{
					PUSH_ROOT_NA( lit2 );
					goto skip_addition;
				}
			    }

			    CHECK_AND_ADD_BINARY_IMPLICATIONS( lit1, lit2 );
			    Clength[ clsidx ] = 0;

			    skip_addition:;
			}
		    }
		}
	    }

	    while( Veq[ NR(current) ][ 0 ] > 1 )
	    {
	    	clsidx = Veq[ NR(current) ][ 1 ];
                                                                                                                                                           
	        fixEq( NR(current), 1, SGN(current));

		if( CeqSizes[ clsidx ] == 1 )
		{
		    PUSH_ROOT_NA( Ceq[ clsidx ][ 0 ] * CeqValues[ clsidx ] );
		}
	    }
	}
	return 1;
}

int root_find_na( const int nrval, int **_Vc )
{
	int i, current;

	for( i = 2; i < BinaryImp[ -nrval ][ 0 ]; i++ )
	{
	    current = BinaryImp[ -nrval ][ i ];
	    if( IS_FIXED( current ) && (timeAssignments[ current ] < VARMAX) )
	    {
		if( !FIXED_ON_COMPLEMENT( current ) )
		{
		    if( root_fix_forced_literal( current, _Vc ) == UNSAT )
			return UNSAT;
		}
		else
		    add_binary_equivalence( nrval, current );
	    }
	}	
	return 1;
}

int root_lookahead_literal( int nrval, int **_Vc, int **_qVc )
{
	if( timeAssignments[ nrval ] >= VARMAX )
	    return 1;

	if( IS_FIXED(nrval) )
	    return !FIXED_ON_COMPLEMENT(nrval);

	return root_iterative_unit_propagation( nrval, _Vc, _qVc );
}

int root_iterative_unit_propagation( int nrval, int **_Vc, int **_qVc )
{
	int *_root_fixstackp, current;

	root_fixstackp = root_fixstack;

        FIX( nrval, currentTimeStamp );
        *( root_fixstackp++ ) = nrval;

        _root_fixstackp = root_fixstack;
        while( _root_fixstackp < root_fixstackp )
            if( root_fix_binary_implications( *( _root_fixstackp++ ) ) == UNSAT )
            	return UNSAT;

        _root_fixstackp = root_fixstack;
        while( _root_fixstackp < root_fixstackp )
	{
	    current = *(_root_fixstackp++);
	    if( root_reduce_ternary_clauses( nrval, current ) == UNSAT )
		return UNSAT;

	    if( root_reduce_equivalences( nrval, current ) == UNSAT )
		return UNSAT;

	    if( root_reduce_long_clauses( nrval, _qVc[ -current ] ) == UNSAT )
		return UNSAT;
	}

	root_subsume_ternary_clauses( nrval, _Vc[ -nrval ] );

	return SAT;
}

/**********************************************************************

	root_reduce_ternary_clauses() reduces all ternary clauses
	that contain literal ~current.

**********************************************************************/

inline int root_reduce_ternary_clauses( const int nrval, const int current )
{
        int i, lit1, lit2, *tImp = TernaryImp[ -current ];

       	for( i = TernaryImpSize[ -current ]; i > 0; i-- )
	{
	    lit1 = *(tImp++);
	    lit2 = *(tImp++);

	    if( IS_FIXED(lit1) )
	    {		
	        if( FIXED_ON_COMPLEMENT(lit1) )
	        {
		    if( IS_FIXED(lit2) )
		    {
		    	if( FIXED_ON_COMPLEMENT(lit2) )
			   return UNSAT;
		    }
		    else if( root_add_constraint_resolvent( nrval, lit2 ) == UNSAT )
			return UNSAT;
	    	}
	    }
	    else if( IS_FIXED(lit2) && FIXED_ON_COMPLEMENT(lit2) )
		if( root_add_constraint_resolvent( nrval, lit1 ) == UNSAT )
		    return UNSAT;
	}
	return SAT;
}

/***********************************************************************
	
	root_subsume_ternary_clauses() removes all ternary clauses
	from the formula that contain variable ~nrval AND were 
	satisfied during a lookahead on nrval. Since either 
	nrval or ~nrval is true, these clauses could be subsumed.

***********************************************************************/

void root_subsume_ternary_clauses( int nrval, int *__Vc )
{
	int i, j, clsidx, tmp, original_length, reduceble_flag;
	

        for( i = __Vc[ 0 ]; i > 0; i-- )
	{	
		clsidx = __Vc[ i ];

		if( Clength[ clsidx ] < 3 ) continue;

		reduceble_flag = 0;
		original_length = Clength[ clsidx ];
	
		for( j = 0; j < Clength[ clsidx ]; j++ )
		   if( IS_FIXED(Cv[ clsidx ][ j ]) )
		   {
			if( !FIXED_ON_COMPLEMENT(Cv[ clsidx ][ j ]) )
		   	{
				subsumed++;
				Clength[ clsidx ] = 0;
				break;
			}
			else if( Cv[ clsidx ][ j ] == -nrval )
			{
				 reduceble_flag = 1;
			}
			else
			{
				Clength[ clsidx ]--;
				tmp = Cv[ clsidx ][ j ];
				Cv[ clsidx ][ j ] = Cv[ clsidx ][ Clength[ clsidx ] ];
				Cv[ clsidx ][ Clength[ clsidx ] ] = tmp;
				j--;
			}
		   }

		if( (reduceble_flag == 0) && (Clength[ clsidx ] > 0) )
			Clength[ clsidx ] = original_length;

		assert( Clength[ clsidx ] != 1 );
		assert( Clength[ clsidx ] != 2 );
	}
}

int root_reduce_long_clauses( int nrval, int *__qVc )
{
        int i, j, clsidx, current, var;

        for( i = __qVc[ 0 ]; i > 0; i-- )
        {
	    clsidx = __qVc[ i ];

	    if( Clength[ clsidx ] < 3 ) continue;

            var = 0;
            for( j = Clength[ clsidx ] - 1; j >= 0; j-- )
            {
		current = Cv[ clsidx ][ j ];

                if( IS_FIXED(current) )
		{
		    if( !FIXED_ON_COMPLEMENT(current) )
	            	goto root_longcls;
		}
                else if( var == 0 )
                    var = current;
                else
	 	    goto root_longcls;
            }

            if     ( var == 0 )						return 0;
	    else if( root_add_constraint_resolvent( nrval, var ) == 0 ) return 0;

	    root_longcls:;
        }
        return 1;
}

/**********************************************************************

	root_reduce_equivalence() reduces all equivalence claueses
	that contain literal current.

**********************************************************************/

int root_reduce_equivalences( int nrval, int current )
{
        int i, j, nr, ceqidx;
        int var, value;

        nr = NR( current );

        for( i = Veq[ nr ][ 0 ] - 1; i > 0; i-- )
        {
           ceqidx = Veq[ nr ][ i ];

            var   = 0;
            value = 1;

            for( j = CeqSizes[ ceqidx ] - 1; j >= 0; j-- )
            {
                if( IS_FIXED( Ceq[ ceqidx ][ j ] ) )
                    value *= EQSGN( Ceq[ ceqidx ][ j ] );
                else if( !var )
                    var = Ceq[ ceqidx ][ j ];
                else
                    goto root_ceqend;
            }

            if( var )
            {
                if( root_add_constraint_resolvent( nrval, var * value * CeqValues[ ceqidx ] ) == UNSAT )
                    return UNSAT;
            }
            else if( value == -CeqValues[ ceqidx ] )
                    return UNSAT;

            root_ceqend :;
        }
        return SAT;
}

/**********************************************************************

	root_add_constraint_resolvent( int nrval, int current) 
	adds contraint resolvent (~nrval OR current).

**********************************************************************/

int root_add_constraint_resolvent( const int nrval, const int current )
{
	int * _root_fixstackp;

	FIX( current, currentTimeStamp );
        *( root_fixstackp++ ) = current;

	_root_fixstackp = root_fixstackp;
        while( _root_fixstackp < root_fixstackp )
            if( root_fix_binary_implications( *( _root_fixstackp++ ) ) == UNSAT )
            	return UNSAT;

	root_iteration_flag = 1;

	CHECK_AND_ADD_BINARY_IMPLICATIONS( -nrval, current );

//	printf("adding binaries %i v %i\n", nrval, current );
//	printf("nr of equivalences = %i\n", nrofceq );

	return SAT;
}

int root_fix_binary_implications( int nrval )
{
        int i, imp, *implications;

        implications = BinaryImp[ nrval ] + 1;
        for( i = implications[ -1 ] - 1; --i; )
        {
             imp = implications[ i ];

             if( IS_FIXED(imp) )
             {   if( FIXED_ON_COMPLEMENT(imp) )  return UNSAT;   }
             else
             {
             	FIX( imp, currentTimeStamp );
                *( root_fixstackp++ ) = imp;
             }
        }
        return SAT;
}

int AddTernaryResolvents()
{
	int i, _nrofclauses;

	_nrofclauses = nrofclauses;

	for( i=0; i < nrofclauses; i++ )
	   if( Clength[ i ] == 3 )
	   {
		ternarylook_detect_constraint_resolvents( -Cv[ i ][ 0 ], -Cv[ i ][ 1 ] );
		ternarylook_detect_constraint_resolvents( -Cv[ i ][ 0 ], -Cv[ i ][ 2 ] );
		ternarylook_detect_constraint_resolvents( -Cv[ i ][ 1 ], -Cv[ i ][ 2 ] );
	   }

	if( nrofclauses != _nrofclauses )
	    printf("c AddTernaryResolvents(): ternary clauses increased from %i to %i\n", _nrofclauses, nrofclauses);

	cleanFormula();

	return nrofclauses - _nrofclauses;
}

void cleanBinaryImp()
{
	int i, j, varnr, *imp;

        for( i = 0; i < freevars; i++ )
	{
	    varnr = freevarsArray[ i ];
	
	    imp = BinaryImp[ varnr ];
	    for( j = 2; j < imp[0]; j++)
		if( timeAssignments[ imp[ j ] ] >= VARMAX )
		    imp[ j-- ] = imp[ --imp[0] ];

	    bImp_satisfied[ varnr ] = 2;

	    imp = BinaryImp[ -varnr ];
	    for( j = 2; j < imp[0]; j++)
		if( timeAssignments[ imp[ j ] ] >= VARMAX )
		    imp[ j-- ] = imp[ --imp[0] ];

	    bImp_satisfied[ -varnr ] = 2;
	}
}

void fix_monotone()
{
	int j, index, pos, neg;

        for( index = 1; index < nrofvars; index++ )
        {
	    if( timeAssignments[ index ] >= VARMAX ) continue;

            pos = TernaryImpSize[ -index ] + BinaryImp[ VAR(index) ][ 0 ] - bImp_satisfied[  index ];
            neg = TernaryImpSize[ index ] + BinaryImp[ VAR(-index) ][ 0 ] - bImp_satisfied[ -index ];

            if(      (pos == 0) && (Veq[ index ][ 0 ] == 1)              ) { IFIUP( index, 0); j=-1; continue; }
            else if( (neg == 0) && (Veq[ index ][ 0 ] == 1) && (pos > 0) ) { IFIUP(-index, 0); j=-1; continue; }
        }
}

int singlelook()
{
        int i;

        cleanFormula();

        forced_literals = 0;
        currentTimeStamp = 4;

        if( treebased_lookahead() == 0 ) return UNSAT;

        for( i = 0; i < tree_elements; i++ )
        {
	    currentTimeStamp += treeArray[ i ].gap;
            if( !treelookvar( treeArray[ i ].literal ) )
            {
               	currentTimeStamp -= treeArray[ i ].gap;
                return UNSAT;
            }
            currentTimeStamp -= treeArray[ i ].gap;
 	}

	if( IFIUP( 0, 1 ) == UNSAT ) return UNSAT;

        return 1;
}
