// Copyright (c) 2010, Jingchao Chen, Donghua University,China.  All rights reserved.

#include "lglib.h"
#include <stdio.h>
#include <ctype.h>
#include "constants.h"
#include "MPhaseSAT64.h"

int  pre_height;
extern int numatom;

extern int *StackLit;
extern int *fixedvar;
extern int originClauses;
extern int *AMOvar;
extern int ClsVarRate;
extern bool localfind;
extern bool crypto_Gss;
extern int now_Clauses;

//int **Blit;
//int Bclauses;
//int	BnumXor;
//void check(int sol[],int **CNFcls, int XorCls, int numCls);

void set_clauses();
void build_structure();

bool glueSolveType;
extern bool on_the_fly;

void OutputClause(LGL * lgl, intpp & clsLit, int &numCls,bool i2e, int *sol);

extern Stack<int> *BinCls; // binary clauses 
extern int *key_lit;
extern int RealNumVars;              // the real number of atoms
int sortkey(int *keyvar,int *VarWeight);
extern int *unit;
extern int *candidate;

bool parity (unsigned x)
{ bool res = false; while (x) res = !res, x &= x-1; 
    return res; 
}
int newVars(int **clsLit, int numXor)
{
    int nVar=numatom;
    int i;

    for (i = 0; i < numXor; i++){
  		int xor_size=clsLit[i+1]-clsLit[i];
		if(xor_size<=4) continue;
		nVar+=(xor_size/2)-1;
     }
	if(nVar!=numatom){
		fixedvar=(int *)realloc(fixedvar, sizeof(int)*(nVar+1));
		for(i=numatom+1; i<=nVar; i++) fixedvar[i]=0;
		if(AMOvar){
	         AMOvar=(int *)realloc(AMOvar, sizeof(int)*(nVar+1));
			 for(i=numatom+1; i<=nVar; i++) AMOvar[i]=0;
		}
	}
	return nVar;
}

int loadclause(LGL * lgl, intpp & clsLit,int & numCls, int & numXor,bool binClause)
{  int i;
 //  solver->candidateVar=candidate;
   now_Clauses=numCls;
   if(binClause){
	   for(i=2; i<2*numatom+2; i++){
		  int last=BinCls[i];
		  if(fixedvar[i/2]) continue;
		  for(int j=0; j<last; j++){  // A V B (A<B) ?
		     int other=BinCls[i][j];
			 if(i>=other) continue; 
		     if(fixedvar[other/2]) continue;
			 lgladd (lgl, posLit2lit(i));
			 lgladd (lgl, posLit2lit(other)); // add a lit
	         lgladd (lgl, 0); //close a clause
		  }
	   }
   }
  
   int *litbuf=(int *) malloc( sizeof(int) *(200));
//CNF clause   
    int endClsNo=numXor+numCls;	
    int CNFlen,j;
    for(i=numXor; i<endClsNo; i++){
		if(binClause){
			  if(clsLit[i+1]-clsLit[i]==2) continue;
		}
		int cls_size=clsLit[i+1]-clsLit[i];
	    if(cls_size>200) litbuf=(int *)realloc(litbuf, sizeof(int)*cls_size);
		CNFlen=0;
		for(j=0; j<cls_size; j++){
             int lit=clsLit[i][j];
			 int vv=ABS(lit);
			 if(fixedvar[vv]==0)  litbuf[CNFlen++]=lit;
			 else if(fixedvar[vv]==lit) goto nextCNF;
		 }
    	 for(j=0; j<CNFlen; j++) lgladd (lgl, litbuf[j]);
		 lgladd (lgl, 0); //close a clause
nextCNF:   ;   
	}
//XOR clause
    int nVar=numatom+1;
  	for (i = 0; i < numXor; i++){
  		unsigned int j;
		int value,xorlen,xor_size=clsLit[i+1]-clsLit[i];
        if(xor_size>200) litbuf=(int *)realloc(litbuf, sizeof(int)*xor_size);
		xorlen=value=0;
	  	for(j=0; j<(unsigned)xor_size; j++){
             int lit=clsLit[i][j];
             int vv=ABS(lit);
			 if(fixedvar[vv]==0)  litbuf[xorlen++]=lit;
			 else if(fixedvar[vv]==lit) value=value^1;
		}	 
        if(xorlen==0){
			if(value) continue;
        	free(litbuf);
			return UNSAT;
		}
		if(value) litbuf[0]=-litbuf[0]; 
		int size;
		int xbuf[10];
		for(int pos=0; pos<xorlen; pos+=size){
	     	if(xorlen<=4) size=xorlen;
			else{
				if(pos+3>=xorlen) size=xorlen-pos;
			    else size=2;
			}
			int xs;
			for(xs=0;xs<size; xs++) xbuf[xs]=litbuf[pos+xs];
			if(pos) {
				xbuf[xs++]=nVar;
            	nVar++;
			}
			if(size!=xorlen-pos) xbuf[xs++]=-nVar;
			unsigned pow2=1<<xs;
			for(j=0; j<pow2; j++){ // XOR -> CNF
		   	   if(parity(j)) continue;
           	   unsigned bits=j;
       		   for(int k=0; k<xs; k++) {
				    int lit=xbuf[k];
					if(bits & 1) lit=-lit;
	                lgladd (lgl, lit);
					bits=bits>>1;
			   }
		       lgladd (lgl, 0); //close a clause
			}
		}
	}
	free(litbuf);
	return _UNKNOWN;
}

extern int *mapvar;

// res = 10 : SATISFIABLE
//res = 20 : UNSATISFIABLE
// res =0  UNKNOWN
extern int *var_value;
void  freelocalsearch();

int assignSolution(LGL * lgl, int res, int *solution, bool map)
{
    if (res == 10) {
		  int maxvar = lglmaxvar (lgl);
		  int i;
		  for (i = 1; i <= maxvar; i++) {//extern var 
             int lit;
			 if(lgl->localsolution) {
			       lit = var_value[i];
				   if(ABS(lit)!=i) continue;
			 }
             else lit = (lglderef (lgl, i) > 0) ? i : -i;
			 if(!map){
				 	if(solution[i]==0) solution[i]=lit;
			 }
			 else{
				 int var=mapvar[i-1];
				 if(lit<0) solution[var]=-var;
				 else solution[var]=var;
			 }
	   }
//		check(solution,Blit,BnumXor,Bclauses);
	 if(lgl->localsolution) freelocalsearch();
       lglrelease (lgl);
  	   return SAT;
  } 
  lglrelease (lgl);
  if (res == 20) return UNSAT;
  return _UNKNOWN;
}

int Loadbigsolver(int decision_limit,int ** & clsLit, int numCls, bool vmap)
{ 
	printf("c A large instance  \n");
//optimal option
	LGL * lgl = lglinit ();

    lgl->limits.max_reduce=100000;
    lgl->maxDepth=0;
	
	if(AMOvar){
	     free(AMOvar);
	     AMOvar=0;
	}

	int newn=0;
    int *base=clsLit[0];
	int total=clsLit[numCls]-clsLit[0];
	for(int i=numCls; i>0; i--){
	    int size=clsLit[i]-clsLit[i-1];
	   	int *pv=base+(clsLit[i-1]-clsLit[0]);
		for(int j=0; j<size; j++){
			int lit=*(pv+j);
	        lgladd (lgl, lit); //add +-var
		}
	    lgladd (lgl, 0); //close a clause
    	int nowSize=clsLit[i]-clsLit[0];
		if(nowSize<total-10000 && i>10) {
			base=(int *)realloc(base, sizeof(int)*nowSize);
	        total=nowSize;
		}
		newn++;
	}
	free(base);
	free(clsLit);
    clsLit=0;
   	
   lgl->limits.decision_limit=decision_limit;
   int res = lglsat (lgl);
   return assignSolution(lgl, res,unit,vmap);
}

int Loadsolver_end(intpp & clsLit, int & numCls, int & numXor,int *RankVar)
{   int i;

    newVars(clsLit,numXor);

	LGL * lgl = lglinit ();
//optimal option
	int limit=(numCls/5)*2;
    if(numXor>0){
		if(limit<10000) limit=10000;  //SHA 
	}
	else if(limit<30000) limit=30000; 
    lgl->limits.max_reduce=limit; //DB size
	lgl->RankVar=RankVar;
	lgl->maxDepth=11; 
  
	int rc=loadclause(lgl, clsLit, numCls, numXor,true);
    if(rc==UNSAT){
          lglrelease (lgl);
  	      return UNSAT;
	}
	
    lgl->phase_type=HALF_IUP;
    if(numXor){
		if(numXor>2000){
			if(numXor>numatom/14) lgl->phase_type=JWHS; //ibm-2002-30r-k85
			if(numXor>numCls/12) {
				if(numatom<15000) {
					lgl->phase_type=IUP; //MD5 (240s) SHA
		        }
				else lgl->phase_type=JWHS; 
			}
		}
		else {
			if(numXor<1000 && numCls>300000) lgl->phase_type=JWHS; //anbul-part-10
        }
		if(glueSolveType) {
			lgl->phase_type=IUP; //post-cbmc-aes-d-r2
			//solver->sub_phase=true;
		}
		if(numXor<700 && numXor/2<lgl->stats.bin && ClsVarRate<8){// UTI-20-10p0
	       	 lgl->halfphaseLearning=true;
             lgl->phase_type=JWHS;
		}
   	}
	else{//anbul-part-10-13-s
		  if(ClsVarRate<6 && lgl->stats.irr/15>numatom){
		        if((lgl->stats.irr/3)*2<lgl->stats.bin) lgl->phase_type=JWHS;
		   }
		  if(ClsVarRate>100 && numatom<1500){ //vmpc_31 Precosat+tail JW 
            	lgl->halfphaseLearning=true;
	            lgl->phase_type=JWHS;
		  }
		  if(lgl->stats.irr<(lgl->stats.bin/9)*10 && ClsVarRate>55){ //11pipe_k
            	lgl->halfphaseLearning=true;
                lgl->phase_type=JWHS;
		  }
          if(lgl->stats.irr>900000 && numatom<80000 && ClsVarRate<6){//UR-15-10p0
                 lgl->phase_type=JWHS;
		  }
	}

	printf("c solve by multiple heuristics \n");
//	switch(lgl->phase_type){
//	  case JWHS: 	printf("c phase_type=JWHS \n"); break;
//	  case IUP: 	printf("c phase_type=IUP \n"); break;
//	  case HALF_IUP: printf("c phase_type=HALF_IUP \n");
//	}

	for (i= 2; i<2*numatom+2; i++) BinCls[i].release(); //bug (mem);
    free(BinCls);
    BinCls=0;

	int res =0;
	int cand2[2]={0};
    lgl->candidateVar=cand2;
   
	int bins=lgl->stats.bin;
	lgl->BinAddLimit=bins+bins/3;
	if(lgl->BinAddLimit<800000) lgl->BinAddLimit=800000;
 	if(originClauses>3000000) goto nopre;
 
	for(i=0; i<1 && res==0; i++){
          int candp=0;
          while(res==0){
		     if(candidate[candp]==0) break;
              lgl->candidateVar=candidate+candp;
		      lglbacktrack (lgl, 0); //undo(0);
              lgl_reinitialize(lgl);
              if(candp || i) lgl->limits.decision_limit=20000;
		      else 	lgl->limits.decision_limit=200000;
	          res = lglsat (lgl);
		      while(candidate[candp]) candp++;
		      candp++;
		  }
	}
nopre:
    if(res==0){
		  lgl->limits.decision_limit=0x7fffffff;
		  lgl->candidateVar=cand2;
		  
		  lglbacktrack (lgl, 0); //undo(0);
          lgl_reinitialize(lgl);
          res = lglsat (lgl);
		  if(res==0) {
              lglrelease (lgl);
			  return _UNKNOWN;
		  }
	}
    return assignSolution(lgl, res,fixedvar,false);
}

extern int **Clit;
extern int  numClauses;      //number of clauses
extern int numXOR;

int Loadsolver(int decision_limit,int **clsLit, int numCls, int numXor,int unit_sp,int *RankVar,bool loadbin)
{ 
	int **Clit_Copy;

    newVars(clsLit,numXor);
	LGL * lgl = lglinit ();
//optimal option
	int limit=(numCls/5)*2;
	if(limit<30000) limit=30000; 
    lgl->limits.max_reduce=limit; //DB size
 
    lgl->RankVar=RankVar;
	if(decision_limit<=5000) lgl->phase_type=JWHS;
    else lgl->phase_type=IUP;
    
   // solver->sub_phase=true;
	if(crypto_Gss) lgl->phase_type=JWHS;
//unit clause;
	for(int i=0; i<unit_sp; i++){
		  int lit=StackLit[i]; 
	      lgladd (lgl, lit); //add +-var
	      lgladd (lgl, 0);
	}
    int rc=loadclause(lgl, clsLit, numCls, numXor,loadbin);
  	if(rc==UNSAT){
         lglrelease (lgl);
 	     return UNSAT;
	}

	if(lgl->stats.irr>110000 && originClauses<90000){ //maxxororand032
			lgl->phase_type=JWHS;
    }
    int cand2[2]={0};
    lgl->maxDepth=0; 
    lgl->candidateVar=cand2;
    lgl->limits.decision_limit=decision_limit;
	
	if(lgl->phase_type==IUP){ //Clit is destroyed bug 5/13/2011
        Clit_Copy=Clit; 
		Clit=0;
	}
	else Clit_Copy=0;

	int res = lglsat (lgl);
	
	if(Clit_Copy){ //restore Clit bug 5/13/2011
		if(Clit){
			free(Clit[0]);
		    free(Clit);
		    Clit=Clit_Copy;
		    numClauses=numCls;
		    numXOR=numXor;
		}
	}    

    return assignSolution(lgl, res,fixedvar,false);
}

int preLoadsolver(intpp & clsLit, int & numCls)
{ 
    int decision_limit;
	bool re_solve=false;
retry:
	LGL * lgl = lglinit ();
//optimal option
	int maxnum=numCls/3;
//	if(maxnum<30000) maxnum=30000;
	if(maxnum<50000) maxnum=50000;
	lglset_max_reduce(lgl, maxnum);

    lglsetopt (lgl, "block", 0);// false block
    if(re_solve) lglsetopt (lgl, "block", 1); // true block

    lglset_RankVar(lgl, 0);
    lglset_maxDepth(lgl,0);

	printf("c phase 1 \n");

	bool binClause=false;
	int numXor=0;
	int rc=loadclause(lgl, clsLit, numCls, numXor,binClause);
    if(rc==UNSAT){
	    lglrelease (lgl);
  	    return UNSAT;
	}
    int res =0;
	int cand2[2]={0};
    lglset_candidateVar(lgl, cand2);

	//solver->Initialize();
    if(numCls>50000 && numCls<220000 && (numatom<40000 || originClauses==210223)){
	     lglset_randpick(lgl, true);
    }
    lgl->extendLimit=numCls>100000;
	if(lgl->extendLimit) decision_limit=600000; 
	else decision_limit=200000;	

	int bins=lgl->stats.bin;
	lgl->BinAddLimit=bins+bins/3;
	if(lgl->BinAddLimit<800000) lgl->BinAddLimit=800000;
    else{  
        if(bins>(numCls/5)*3 && numatom>numCls/4){
			  lgl->extendLimit=false;
              lgl->BinAddLimit=700000;
	          decision_limit=50000;
		}
		else{
			if(bins<1000000 && numCls>1200000) lgl->BinAddLimit=(bins/10)*4; 
			if(bins>800000){
				decision_limit=(bins/5)*4;
			}
		}
	}
    if(bins>1500000){
		if(numatom<numCls/20) {
			lgl->BinAddLimit=bins+bins/5;
			decision_limit=bins;
   		}
	}
	if(ClsVarRate>21 && ClsVarRate<28 && numatom<12000)	decision_limit=2000000;	
   	if(numCls<18000 && ClsVarRate!=3) lgl->phase_type=IUP;
	if(re_solve){
		decision_limit=0x7fffffff;
		lgl->extendLimit=false;
    }
    
//	decision_limit=100;
	lglset_decision_limit(lgl,decision_limit);
    res = lglsat (lgl);
//out:
	pre_height=0;
 	if(res==0){
		lglbacktrack (lgl, 0); //undo(0);
		lgl->extendLimit=false;
		if(lgl->stats.decisions) pre_height=(int)lglheight(lgl);
        printf("c height=%d \n", pre_height);
		//getchar();
		if(!re_solve){
			if(lgl->phase_type!=IUP && numCls==now_Clauses && ClsVarRate==3 && pre_height<26 && numCls<15000){
		          lglrelease (lgl); //par32
				  return 0;
			}
  			
			if(pre_height>2000 || (pre_height>95 && pre_height<180 && ClsVarRate<3 && lglrem(lgl)<8000)) {
				if(lgl->phase_type!=IUP && numCls==now_Clauses){
			             lglrelease (lgl);
  			             goto retry;
				}
			}
		}
	   	bool continue_solve=false;
		if(pre_height>390 && lglrem(lgl)<80000){
			if(numCls>1000000) continue_solve=true; 
		}
//	    printf("c numCls=%d \n",numCls);
		if(pre_height<17 && numatom<800 && numatom>600 && ClsVarRate==12) continue_solve=true; 
		if(((numCls>10000 && numCls<18000) || (numCls<10000 && originClauses>12000)) && pre_height ){ 
			if(numatom >2500 && pre_height<29 && lglrem(lgl)<2000) continue_solve=true; 
			if(pre_height<17 && numatom >1000) continue_solve=true; 
	//	    printf("c continue_solve=%d \n",continue_solve);
		}
		if(continue_solve){
			    lglsetopt (lgl, "block", 1); // true block
				decision_limit=0x7fffffff;
			    localfind=false;
		        if(pre_height>380 && numatom<27000 && ClsVarRate<15) localfind=true;
				if(lglagility (lgl)>19.0 && pre_height<17 && originClauses<70000) lgl->hybridpolicy=true;
            	lglset_decision_limit(lgl,decision_limit);
                res = lglsat (lgl);
		}
		if(res==0){
			OutputClause(lgl, clsLit, numCls,true,fixedvar);
			glueSolveType=false;
	        if(bins>400000 && bins>numCls/2){
			    if(numatom/20 > lglrem(lgl)) glueSolveType=true;
			}
	        lglrelease (lgl);
  		    return _UNKNOWN;
		}
	}
	return assignSolution(lgl, res,fixedvar,false);
}

int Loadsolver(intpp & clsLit, int & numCls, int & numXor,int *RankVar)
{ 
     int i;
   
//    Blit=(int **) malloc( sizeof(int *) * (numCls+numXor+1));
 //   int Lsize=clsLit[numCls+numXor]-clsLit[0];
//	Blit[0]=(int *) malloc( sizeof(int *) * (Lsize+1));
  //  Bclauses=numCls;
//	BnumXor=numXor;
 //   for (i=0; i<numCls+numXor; i++) Blit[i]=Blit[0]+(clsLit[i]-clsLit[0]);
  //  for (i=0; i<Lsize; i++) Blit[0][i]=clsLit[0][i];

	newVars(clsLit,numXor);
	if(localfind) {
		printf("c local search on \n");
	    set_clauses();
        build_structure();
	}
	else printf("c local search off \n");
    
	LGL * lgl = lglinit ();
//optimal option
	int limit=(numCls/5)*2;
	if(limit<30000) limit=30000; 
    lgl->limits.max_reduce=limit; //DB size
    
	lgl->RankVar=RankVar;
	lgl->maxDepth=0;
	
//unit clause;
    for(i=1; i<=numatom; i++){
          if(fixedvar[i]==0) continue; 
	      lgladd (lgl, fixedvar[i]); //add +-var
	      lgladd (lgl, 0);
	}

	int rc=loadclause(lgl, clsLit, numCls, numXor,true);
    if(rc==UNSAT){
	     lglrelease (lgl);
  	     return UNSAT;
	}

	//OutputClause(lgl, Blit, Bclauses,true);
	//BnumXor=0;
	
    int res =0;
	int cand2[2]={0};
    lgl->candidateVar=cand2;
    lgl_reinitialize(lgl);
 
	//lgl->hybridpolicy=true;
    //lgl->limits.decision_limit=0;
	//res = lglsat (lgl);
   	
	if(on_the_fly && originClauses<1000){
    	lgl->phase_type=JWHS;
		goto no_pre;
	}
 	if(numatom<1000) lgl->phase_type=JWHS;
	else lgl->phase_type=IUP;

    lgl->limits.decision_limit=30000;
	res = lglsat (lgl);

	if(ClsVarRate>5000) lgl->phase_type=JWHS; //rate=20000, Q3inK13 3/30/2011
    else lgl->phase_type=IUP;

	if(res==0){
		cand2[0]=0;
        lgl->candidateVar=cand2;
        lgl_reinitialize(lgl);
        lgl->limits.decision_limit=30000;
        res = lglsat (lgl);
   	}
	if(localfind) goto no_pre;

	lgl->maxDepth=1;
    for(i=0; i<1 && res==0; i++){
       int candp=0;
       while(res==0){
		  if(candidate[candp]==0) break;
          lgl->candidateVar=candidate+candp;
		  lglbacktrack (lgl, 0); //undo(0);
          lgl_reinitialize(lgl);
          if(candp || i) lgl->limits.decision_limit=10000;    //2000, 10000;
		  else 	lgl->limits.decision_limit=5000;
		  res = lglsat (lgl);
		  while(candidate[candp]) candp++;
		  candp++;
	   }
	}

   if(res==0){
       	cand2[0]=0;
     	if(numatom<5000 && numCls<20000) lgl->limits.decision_limit=30000;
		else lgl->limits.decision_limit=100000;
	  	lgl->candidateVar=cand2;
        lgl_reinitialize(lgl);
        res = lglsat (lgl);
	}
   
no_pre:
    if(res==0){
	    lgl->maxDepth=0; 
	    cand2[0]=0;
   		int height;
   	  	if(lgl->stats.decisions) height=(int)lglheight(lgl);		
		else height=0;
	    if(height<14 || ((originClauses>1000 && originClauses<30000 && height<24) && !on_the_fly)){
			lgl->hybridpolicy=true; //mod2c-3cage-unsat-10-3
  		}
		if(height<20 && originClauses<6000) {
			lgl->hybridpolicy=true;//eq.atree.braun.12
			if(on_the_fly && height<9) { 
		     	lgl->phase_type=JWHS;
				lgl->hybridpolicy=false; //aloul-chnl11-13
			}
		}
		if(height<13 && lgl->stats.irr>30000) {
			if(lglagility (lgl) < 25 ){//mod4block_3vars_7gates
				lgl->hybridpolicy=false; //QG7a-gensys-ukn002
		    	lgl->phase_type=IUP;
			}
		}
		if( lglagility (lgl) <20) {//simon-s02b-dp11u10
			lgl->hybridpolicy=false;//rpoc_xits_07_UNSAT
		   	lgl->phase_type=JWHS;
			if(originClauses<23000) lgl->phase_type=IUP;//QG7a-gensys-ukn002.sat05-3842
        }
		if( lglagility (lgl) > 35 && height<21) lgl->hybridpolicy=true; //eq.atree.braun.13.unsat
		
    	printf("c height=%d age=%f \n",height,  lglagility (lgl));

		if(localfind){
			if(height<33 && numatom<1000 && lglagility (lgl)>25) lgl->hybridpolicy=true;
		}
		if(originClauses<600 && height<30) lgl->hybridpolicy=true;//sgen1-sat-160-100
    	if(originClauses<10000 && height<16 && numatom<2500 &&   lglagility (lgl) >15) lgl->hybridpolicy=true;//v3500-c9345-S1286605994
	    if(height<8 && originClauses<2000 && numatom<500 && on_the_fly) lgl->hybridpolicy=false; //aloul-chnl11-13
        if(ClsVarRate>100 && numatom<200 && height<13) lgl->hybridpolicy=false;//mod3_4vars_6gates
	   	res=0;
		if(lgl->hybridpolicy && !localfind){
			if(numatom<340 && originClauses<3000){//mod2c-rand3bip-sat-210-3
		        lgl->limits.decision_limit=1000000;
	    	    lgl_reinitialize(lgl);
				lgl->hybridpolicy=false;
                res = lglsat (lgl);
   		 		lgl->hybridpolicy=true;
			}
		}
		if(res==0){
       	//	decision_limit=0x7fffffff;
		 	lgl->limits.decision_limit=0;
			lgl_reinitialize(lgl);
			res = lglsat (lgl);
   		}
	}
//out:    
	if(res==0){
        lglrelease (lgl);
       	return _UNKNOWN;
	}
    return assignSolution(lgl, res,fixedvar,false);
}
