/* Copyright 2010 Armin Biere, Johannes Kepler University, Linz, Austria */

#ifndef lglib_h_INCLUDED
#define lglib_h_INCLUDED

#include "MPhaseSAT64.h"


typedef struct LGL LGL;

#ifdef _MSC_VER
typedef __int64  int64_t;
typedef unsigned __int64 uint64_t;
#define i64d "I64d"
#else

#include <stdint.h> 
typedef long long longlong;
#define i64d "lld"
#endif

enum Phase {
  JWHS = 0,
  IUP = 1,    //Iterative Unit prop
  HALF_IUP = 2,
};

LGL * lglinit (void);				// constructor
void lglrelease (LGL *);			// destructor

void lglsetopt (LGL *, const char *, int);	// set option value
int lglgetopt (LGL *, const char *);		// get option value
int lglhasopt (LGL *, const char *);		// exists option?
void lglusage (LGL *);				// print usage "-h"
void lglopts (LGL *, const char * prefix);	// ... current options "-d"
void lglrgopts (LGL *);				// ... option ranges "-r"
void lglbnr (const char * name);		// ... banner
void lglsizes (void);				// ... data structure sizes
void lglbacktrack (LGL * lgl, int level);
double lglheight (LGL * lgl); 
int lglrem (LGL * lgl);
double lglagility (LGL * lgl);
void lgl_reinitialize(LGL * lgl);
int findmaxVar(LGL * lgl,bool single,int findLimit);
int HybridSolve(LGL * lgl);
int computeDiff(LGL * lgl,int idx);
void delorgs_e (LGL * lgl);
void outlocalsolution(LGL * lgl);
void buildorg_e(LGL * lgl);
int IterativeUnitPropagation_e(LGL * lgl, int sp, float & diff,int *Queue,int sp_size);

// main interface as in PicoSAT:
int lglmaxvar (LGL *);
void lgladd (LGL *, int lit);
int lglsat (LGL *);
int lglderef (LGL *, int lit);			// neg=false, pos=true
int HybridSolve();

// stats:
void lglstats (LGL *);
int lglgetconfs (LGL *);
int lglgetdecs (LGL *);
double lglgetprops (LGL *);
double lglmb (LGL *);
double lglmaxmb (LGL *);
double lglsec (LGL *);
double lglprocesstime (void);

// threaded support:

void lglseterm (LGL *, int (*term)(void*), void*);
void lglsetproduce (LGL *, void (*produce)(void*, int), void*);
void lglsetconsume (LGL *, void (*consume)(void*,int**,int**), void*);

// threaded support for logging and statistics:
void lglsetid (LGL *, int);
void lglsetconsumed (LGL *, void (*consumed)(void*,int), void*);
void lglsetmsglock (LGL *, void (*lock)(void*), void (*unlock)(void*), void*);
void lglsetime (LGL *, double (*time)(void));

// term: called regularly if set, terminate if non zero return value
// unit: called for each derived unit in this instances of the library
// lock: return zero terminated vector of externally derived units
// unlock: unlock using the locked list and return number of consumed units

void lglset_decision_limit(LGL * lgl, int decision_limit);
void lglset_max_reduce(LGL * lgl, int max_reduce);
void lglset_RankVar(LGL * lgl, int *RankVar);
void lglset_maxDepth(LGL * lgl, int maxDepth);
void lglset_candidateVar(LGL * lgl, int *candidateVar);
void lglset_randpick(LGL * lgl, bool randpick);


typedef Stack<int>  Orgs_i; //original clauses # aasociated with lit

typedef enum State {
  UNUSED = 0,
  USED = 1,
  READY = 2,
  UNKNOWN = 3,
  SATISFIED = 4,
  UNSATISFIED = 5,
} State;

typedef struct Opt { 
  char shrt;
  const char * lng, * descrp; 
  int val, min, max;
} Opt;

typedef struct Opts {
  Opt beforefirst;
  Opt agile;
  Opt bias;
  Opt block;
  Opt blkmaxeff;
  Opt blkmineff;
  Opt blkreleff;
  Opt blkocclim;
#ifndef NDEBUG
  Opt check;
#endif
  Opt decompose;
  Opt dcpcintinc;
  Opt dcpvintinc;
  Opt defragint;
  Opt defragfree;
  Opt distill;
  Opt dstcintinc;
  Opt dstvintinc;
  Opt dstmaxeff;
  Opt dstmineff;
  Opt dstreleff;
  Opt elim;
  Opt elmcintinc;
  Opt elmvintinc;
  Opt elmaxeff;
  Opt elmineff;
  Opt elmreleff;
  Opt elmreslim;
  Opt elmocclim;
  Opt elmpenlim;
  Opt gccintinc;
  Opt gcvintinc;
  Opt hte;
  Opt htemaxeff;
  Opt htemineff;
  Opt htereleff;
  Opt lhbr;
#ifndef NLGLOG
  Opt log;
#endif
  Opt phase;
  Opt plain;
  Opt probe;
  Opt prbcintinc;
  Opt prbvintinc;
  Opt prbmaxeff;
  Opt prbmineff;
  Opt prbreleff;
  Opt seed;
  Opt smallve;
  Opt smallvevars;
  Opt randec;
  Opt randecint;
  Opt rebias;
  Opt rebiasint;
  Opt redlinit;
  Opt redlinc;
  Opt redlmininc;
  Opt restartint;
  Opt scincinc;
  Opt transred;
  Opt trdcintinc;
  Opt trdvintinc;
  Opt trdmineff;
  Opt trdmaxeff;
  Opt trdreleff;
  Opt verbose; 
  Opt witness;
  Opt afterlast;
} Opts;

#define FIRSTOPT(lgl) (&(lgl)->opts.beforefirst + 1)
#define LASTOPT(lgl) (&(lgl)->opts.afterlast - 1)

#define MAXLDFW		31		
#define REPMOD 		23
#define MAXPHN		2
#define FUNVAR		11
#define FUNQUADS	(1<<(FUNVAR - 6))

#define LOCKED		(1 << 30)
#define COLLECT		(LOCKED - 1)
#define REMOVED		(COLLECT - 1)
#define MAXVAR		((LOCKED >> RMSHFT) - 2)
#define SCINCLEXP	(1<<20)
#define GLUESHFT	4
#define GLUE 		(1 << GLUESHFT)
#define MAXGLUE		(GLUE - 1)
#define GLUEMASK	(GLUE - 1)
#define MAXREDLIDX	((1 << (31 - GLUESHFT)) - 2)
#define MAXIRRLIDX	((1 << (31 - RMSHFT)) - 2)
#define FLTPRC 		32
#define EXPMIN 		(0x0000 ## 0000)
#define EXPZRO 		(0x1000 ## 0000)
#define EXPMAX		(0x7fff ## ffff)
#ifdef _MSC_VER
  #define MNTBIT		(0x0000 ## 0001 ## 0000 ## 0000 ##)
  #define MNTMAX		(0x0000 ## 0001 ## ffff ## ffff ##)
  #define FLTMIN		(0x0000 ## 0000 ## 0000 ## 0000 ##)
  #define FLTMAX		(0x7fff ## ffff ## ffff ## ffff ##)
  #define FALSECNF	((int64_t)1<<32)
  #define TRUECNF	(int64_t)0
#else
 #define MNTBIT		(0x0000 ## 0001 ## 0000 ## 0000 ## ull)
  #define MNTMAX		(0x0000 ## 0001 ## ffff ## ffff ## ull)
  #define FLTMIN		(0x0000 ## 0000 ## 0000 ## 0000 ## ll)
  #define FLTMAX		(0x7fff ## ffff ## ffff ## ffff ## ll)
  #define FALSECNF	(1ll<<32)
  #define TRUECNF		0ll
#endif

#define cover(b) assert(!(b))


typedef struct Stats {
  int defrags, rescored, iterations, skipped, uips;
  int confs, reduced, restarts, rebias, reported, gcs;
  int irr, decomps, decisions, randecs;
  int bin; //new
  int64_t prgss, enlwchs, rdded, ronflicts, pshwchs, height;
  struct { int64_t search, simp; } props, visits; 
  struct { size_t current, max; } bytes;
  struct { int bin, trn, lrg; } red;
  struct { int cnt, trn, lrg, sub; } hbr;
  struct { int current, sum; } fixed, equivalent;
  struct { 
    struct { double process, phase[MAXPHN], * ptr[MAXPHN]; 
             int nesting; } entered; 
    double all; } time;
  struct { int count, elm; int64_t res; } blk;
  struct { int count, trn, lrg, failed; int64_t steps; } hte;
  struct { int red, lits, clauses, count, failed; } dst;
  struct { int count, failed, lifted; int64_t probed; } prb;
  struct { int count, red, failed; int64_t lits, bins, steps; } trd;
  struct { 
    int count, skipped, elmd, forced, large, sub, str, blkd;
    struct { int elm, tried, failed; } small;
    int64_t resolutions, copies, subchks, strchks, steps; } elm;
  struct { 
    struct { struct { int irr, red; } dyn; int stat; } sub, str; 
    int driving; } otfs;
  struct { 
    double prb,dcp,elm,trd,gc,gcd,gce,gcb,dst,dfg,red,blk,trj,hte; } tms;
  struct { int64_t nonmin, learned; } lits;
  struct { int learned; int64_t glue; } clauses;
} Stats;

typedef struct Limits { 
  int reduce, randec;
  int decision_limit;//new 
  int max_reduce; //new

  struct { int confs, luby; } rebias;
  struct { int confs, wasmaxdelta, maxdelta, luby; } restart;
  struct { int confs, cinc, vinc; int64_t visits, prgss; } dcp, dst;
  struct { int cinc, vinc, confs; int64_t visits, steps, prgss; } trd;
  struct { int cinc, vinc, confs, skip, penalty;
           int64_t visits, steps, prgss; } elm;
  struct { int cinc, vinc, confs, fixedoreq; int64_t visits; } gc;
  struct { int cinc, vinc, confs; int64_t visits, prgss; } prb;
  struct { int64_t pshwchs, prgss; } dfg;
  struct { int64_t steps; } term, sync, hte;
} Limits;

typedef struct Stk { int * start, * top, * end; } Stk;

typedef int Exp;
typedef uint64_t Mnt;
//typedef int64_t Mnt;
typedef int64_t Flt;
typedef int64_t Scr;
typedef signed char Val;

typedef struct HTS { int offset, count; }  HTS;
typedef struct DVar { HTS hts[2]; } DVar;

typedef struct AVar {
  Scr score; int pos;
  unsigned type : 3;
#ifndef NDEBUG
  unsigned simp : 1;
  unsigned wasfalse : 1;
#endif
  int phase : 2, bias : 2;
  int mark, level;
  int rsn[2];
} AVar;

typedef struct EVar { int occ[2], score, pos; } EVar;

typedef struct Conf { int lit, rsn[2]; } Conf;

typedef struct Lir { 
  Stk lits; int mapped; 
#ifndef NLGLSTATS
  int64_t added, resolved, forcing, conflicts;
#endif
} Lir;

struct LGL {
  State state;
  Opts opts;
  DVar * dvars; AVar * avars; Val * vals;  EVar * evars;
  int nvars, szvars, * i2e, * repr;
  Flt scinc, scincf, scincl;
  Stk e2i, clause, dsched, esched, extend;
  Lir red[GLUE]; Stk irr; int mt;
  struct { struct { Stk bin, trn; } red, irr; } dis;
  struct { int pivot, negcls, necls, neglidx;
    Stk lits, next, csigs, lsigs, sizes, occs, noccs, mark, m2i; } elm;
  Stk trail, control, frames, saved, clv;
  Stk wchs; int freewchs[MAXLDFW], nfreewchs;
  int next, level, decision, unassigned;
  Conf conf; Stk seen, stack;
  unsigned flips, rng;
  char decomposing, measureagility, probing, distilling;
  char simp, eliminating, simplifying, blocking;
  char dense, propred, igntrn;
  int ignlidx, ignlits[3];
  int bias;
  int tid;
  Limits limits;
  Stats stats;
  struct { int (*fun)(void*); void * state;  } term;
  struct { void (*fun)(void*,int); void * state; } produce, consumed;
  struct { void(*fun)(void*,int**,int**); void*state; } consume;
  double (*getime)(void);
  
  int *RankVar; //new
  int maxDepth; //new
  int *candidateVar; //new
  bool randpick; //new
  int extendLimit;// new
  int BinAddLimit;
  int phase_type;
  bool hybridpolicy;
  bool halfphaseLearning;
  bool localbegin;
  bool firstsearch;
  bool sub_phase;
  Orgs_i * orgs_e;  //literal-to-clause # list used in decide
  Orgs_i * orgs_ehead; 
  int aveheight;
  int local_tries,local_step;
  bool localsolution;

#ifndef NCHKSOL
  Stk orig;
#endif
#ifdef RESOLVENT
  Stk resolvent;
#endif
  struct { void(*lock)(void*); void (*unlock)(void*); void*state; } msglock;
#ifndef NLGLOG
  char scstr[100];
#endif
#ifndef NLGLPICOSAT
  struct { int res, chk; } picosat;
#endif
};

#endif
