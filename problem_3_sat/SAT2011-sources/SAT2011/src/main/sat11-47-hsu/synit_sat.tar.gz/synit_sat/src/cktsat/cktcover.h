#ifndef CKT_Cover_H
#define CKT_Cover_H

#include "isop.h"
#include "icut.h"
#include "SolverTypes.h"
#include <cstring>


// forward declaration 
class Solver;
struct BestCut;

class Cover
{
   public:
   virtual ~Cover(){}

   virtual unsigned ncls()=0;
   virtual unsigned area()=0;
   virtual void dumpClause( unsigned , Lit * , Solver & , uint8_t ph)=0;
   
   virtual unsigned size()const=0;
   virtual unsigned at( unsigned i )const=0;
};
class CutCover : public Cover , public Cut 
{
   unsigned sz;
   
   public:
   CutCover(unsigned short s , const Cut & c );
   virtual ~CutCover(){}

   virtual void dumpClause( unsigned , Lit * , Solver & , uint8_t ph);
   virtual unsigned ncls();
   virtual unsigned area();
   
   virtual unsigned size()const{ return sz ;}
   virtual unsigned at( unsigned i ) const{ return node[i];}
};
class ANDCover : public Cover 
{
   unsigned sign:1;
   unsigned sz:31;
   AigLit * dat;
   public:
   ANDCover( unsigned s , unsigned * d , unsigned sg )
      :sign(sg),sz(s)
   { 
      dat=new AigLit [sz] ; 
      memcpy( dat , d , sizeof( AigLit )*sz );
   }
   virtual ~ANDCover(){ delete [] dat; }
   
   virtual void dumpClause( unsigned , Lit * , Solver & , uint8_t ph );
   virtual unsigned ncls(){ return sz+1;}
   virtual unsigned area(){ return sz*3+1;}

   virtual unsigned size()const{return sz;}
   virtual unsigned at( unsigned i ) const {return var( dat[i]);}
};
class CktCover : public InfoCut , ISOP
{
   friend class Fraig;
   // covering : producing the circuit cover for dump 
    
   void dp_covering();
   void dp_covering(BestCut * );
   void dp_compute( unsigned short * refcnt , BestCut * );
   void dp_refine( BestCut * , unsigned short * refcnt);

   void bigAnd_covering();
   bool bigAnd_covering( unsigned n );
   bool isCut_an_and( unsigned , vec<AigLit> & fanin, uint8_t & );
   
   unsigned deactivate( unsigned n , unsigned lim , vec<unsigned> & );
   void deactivate( unsigned n );
   int activate( Cover * , int );
   void deactivate( vec<unsigned> & );
   bool change( unsigned n , Cover * c );
   void optimize();
   bool check();

   Cover **  _cover;
   uint8_t * _satph;
   unsigned  _nvar;

   public:
   Lit   *   _lits;
   CktCover();
   ~CktCover();

   void init();
   void covering();
   // assign all po is 0 
   void write_cnf( const char * file );

   void report_covering()const;
   unsigned nClause()const;
   unsigned nVars()const{return _nvar ;}

   void assignLit( );
   void assignCNFPO( Solver & s );
   void assignCNF(   Solver & s );
   void assignCNF0(  Solver & s );
   void assignCNF(   Solver & s , unsigned * v , unsigned );
   void dump_and (   unsigned i , Solver & s );
   void const_propagation( Solver & S );
};

#endif
