#ifndef INFO_CUT_H
#define INFO_CUT_H

#include "cktinfo.h"

typedef unsigned sign_t;
inline sign_t toSignature( unsigned v ) { return 1 << ( v % SIGSIZE ) ; } 

struct Cut 
{
   unsigned node[ DBSIZE ];
   fun_t    fun;
   sign_t   signature;

   Cut(){}
   Cut( unsigned x ): fun(0x1) ,signature(toSignature(x)){ node[0] = x ;}
   void init( unsigned x ){ fun = 0x1 , signature = toSignature(x), node[0] = x; }

   unsigned operator[]( unsigned i )const{return node[i];}
   unsigned & operator[]( unsigned i ){return node[i];}
   unsigned size()const{ return DBSIZE ; }
};

struct CutSet
{
   int   size;
   Cut * dat;

   CutSet():dat(NULL){}
   ~CutSet(){ delete [] dat; }

   const Cut & operator[]( unsigned i )const{return dat[i];}
   Cut & operator[]( unsigned i ){return dat[i];}
   void allocate( unsigned s ){ if(s) dat = new Cut [s] ; size=s;}
   bool empty()const{ return dat==NULL;}
};

struct CutArray
{   
   CutSet dat[ DBSIZE ];
   const CutSet & operator[]( unsigned i )const{return dat[i] ; }
   CutSet & operator[]( unsigned i ){return dat[i] ; }
};

class InfoCut : public CktInfo 
{
   public:
   vec< CutArray > _cut;

   void update( unsigned i );
   bool setted( unsigned i )const{ return _cut[i][0].dat != NULL;}

   void create_base();
   void validation();
   bool exist( Cut & c );
   void set_base( unsigned i );
};
#endif
