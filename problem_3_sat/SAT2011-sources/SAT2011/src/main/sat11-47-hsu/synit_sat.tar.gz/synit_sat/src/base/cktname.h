#ifndef CKTNAME_H
#define CKTNAME_H

#include <string>
#include <vector>
using std::string;
using std::vector;

struct CktName
{
   vector<string>   piName;
   vector<string>   poName;
   vector<string>   latchName;
   void initialize( unsigned I , unsigned L , unsigned O)
   {
      piName.resize(I);
      latchName.resize(L);
      poName.resize(O);
   }
   void read_aig( FILE * f )
   {
      char str1[100]={}, str2[100]={};
      while( !feof( f ))
      {
         fscanf( f, "%s" , str1 );
         if( str1[0] == 'c' )break;
         fscanf( f , "%s" , str2);
         unsigned id =atoi( str1+1 );
         switch( str1[0] ) 
         {
            case 'i' : piName[id] = str2 ;  break;
            case 'o' : poName[id] = str2 ;  break;
            case 'l' : latchName[id] = str2;break;
         }
      } 
   }
   void write_aig( FILE * f )
   {
      #define OUTNAME( n , s ) \
      for( unsigned i = 0 ; i < n.size() ; ++i )\
         if( n[i].size() != 0 )\
            fprintf(f , "%c%d %s\n", s , i , n[i].c_str() );

      OUTNAME( piName , 'i');
      OUTNAME( latchName , 'l');
      OUTNAME( poName , 'o');
      #undef OUTNAME
   }
};

static bool iomatching( const StrashAIG & ckt , const CktName & name )
{
   return 
           ckt._ppiFlag == name.piName.size()+1  &&                  // equal pi size  
           (ckt._andFlag - ckt._ppiFlag) == name.latchName.size() && // equal ppi size 
           (ckt._andFlag - ckt._ppiFlag) == ckt._ppo.size() &&  // ppi equal to ppo 
           ckt._ppo.size() == name.latchName.size() ;           // equal ppo size
}
#endif
