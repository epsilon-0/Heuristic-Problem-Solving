#ifndef REWRITE_H
#define REWRITE_H
#include "vec.h"
class InfoCut;
class RewriteDB;

class Rewrite
{
   InfoCut       &  _cut;
   RewriteDB     *  _db;

   vec<unsigned> _tmp_cone;
   public:
   Rewrite( InfoCut & in );

   void init();
   void read_db( RewriteDB & db );
   void run();
   void run( unsigned i );

   typedef InfoCut info_t;
   
   int DIRECTION;     // 0 forward 1 backward
   int REPLACEMENT;   // 0 min 1 pluse 2 .
};

#endif 
