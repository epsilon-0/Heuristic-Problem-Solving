#ifndef SYNIT_H
#define SYNIT_H

#include "rwtdb.h"
#include "refactor.h"
#include "balance.h"
#include "icut.h"

void rewrite     ( RewriteDB & db , InfoCut & in , StrashAIG & out );
void rewriteb    ( RewriteDB & db , InfoCut & in , StrashAIG & out );
void rewrite     ( InfoCut & in  , StrashAIG & out );
void rewriteb    ( InfoCut & in  , StrashAIG & out );
void balance     ( Balance & in  , StrashAIG & out );
void refactor    ( Refactor & in , StrashAIG & out );
void refactor_inv( Refactor & in , StrashAIG & out );
void synit       ( InfoCut & in  , StrashAIG & out );
void report      ( CktInfo & ckt );
void report      ( StrashAIG & ckt );

#endif
