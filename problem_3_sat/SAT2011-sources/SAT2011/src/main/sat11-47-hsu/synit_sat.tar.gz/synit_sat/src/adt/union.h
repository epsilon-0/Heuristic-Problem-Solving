#ifndef UNION_H
#define UNION_H

#include "vec.h"

class Union : public vec<unsigned> 
{
   vec< vec<unsigned>*> _eqClass;

   private: 

   void set( const vec<unsigned> & a , unsigned b  );// setting element in a as b
   vec<unsigned> * create( unsigned a , unsigned b );// create a vec ptr

   public:
   Union( );
   ~Union();

   void conjunct( unsigned a , unsigned b ); // setting the reference to b (invoke(b) if a === b)
   void validation( unsigned nsize );
};

#endif

/*
 *  'vec<unsigned> *' memory recycle do not enhance 
 * */
