#ifndef AIG_H
#define AIG_H

#include "vec.h"
#include "aigType.h"
#include <google/dense_hash_map>

class CktName;
extern uint64 hash64shift(uint64 a);

class StrashAIG : public vec<AigNode> 
{
   struct StrashEq {  
      inline bool operator()( AigNode p,AigNode q )const{return p.key==q.key;} 
   };
   struct Strash_key{ 
      inline size_t operator()( AigNode a )const{return hash64shift(a.key);} 
   };
   typedef google::dense_hash_map<AigNode , unsigned, Strash_key,StrashEq> AigHash;
   //typedef std::tr1::unordered_map<AigNode , unsigned, Strash_key,StrashEq> AigHash;

   private:
   AigHash          _hash;
   void             read_initialization( unsigned I , unsigned L , unsigned O , unsigned M = 0 );

   public:

   unsigned         _andFlag;
   unsigned         _ppiFlag;
   vec<AigLit>      _po;
   vec<AigLit>      _ppo;

   StrashAIG();
   bool read_aig (const char * str , CktName * names = NULL );
   bool write_aig(const char * str , CktName * names = NULL)const;
   void write_dot(const char * str , unsigned char * color = NULL )const;

   //--- Atomic construction
   void     createBase(){ assert( _hash.size() == 0 ); push(); }

   AigLit   createAND( AigLit a , AigLit b );
   void     pop_back(){ _hash.erase( last() ) ; pop() ; }

   AigLit   pseudo_createAND( AigLit a , AigLit b );
   void     pseudo_pop_back(){ pop(); }
   void     realize_and(unsigned i ){ for(;i!=size();++i)_hash.insert(AigHash::value_type(data[i],i));} 

   AigLit   test_createAND( AigLit a , AigLit b )const;
   bool     created( AigNode n )const{ return _hash.find(n) != _hash.end() ;}
   bool     isPI( unsigned n )const{return n < _andFlag ; }

   void     report()const;
   bool     check ()const;
   unsigned andSize()const{return _hash.size() ;}
};

#endif
