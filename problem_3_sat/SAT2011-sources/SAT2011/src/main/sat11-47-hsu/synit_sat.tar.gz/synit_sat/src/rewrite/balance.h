#ifndef BALANCE_H
#define BALANCE_H

#include "cktinfo.h"

class Balance : public CktInfo
{
   bool collectAND( unsigned n , vec<AigLit> & fin);

   vec<uint8>   _polar;
   public :
   Balance();

   void init();
   void run();
   void run( unsigned target , vec<AigLit> & pool );
};

#endif
