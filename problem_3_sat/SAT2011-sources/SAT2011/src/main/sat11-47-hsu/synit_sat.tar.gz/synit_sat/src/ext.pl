#! /usr/bin/perl
use strict;
use warnings;

#construct extinclude 
#for the project( arg1 )
foreach my $pkg (@ARGV)
{
   print "linking external header files ... $pkg \n";
   chdir "$pkg";
   foreach my $header (<*.h>)
   {
       system("rm -f ../../include/$header");
       system("ln -fs ../src/$pkg/$header ../../include/$header");
   }
   chdir "..";
}
#system("echo \"done\" > .ext ");
