#ifndef JACKY_DEFINITION_H
#define JACKY_DEFINITION_H

typedef unsigned char       uint8;
typedef unsigned short      uint16;
typedef unsigned int        uint32;
typedef unsigned long long  uint64;

typedef uint16 fun_t;

#define DBSIZE  4
#define SIGSIZE 32
#define RF_CUT_LIMIT 12
#define TABLE_SIZE (1<<(RF_CUT_LIMIT-6))
#define RF_MEM_SIZE 4096
#define RF_MAX_SOP_SIZE 64

#ifndef NDEBUG
#include <iostream>
using std::cout;
using std::endl;
#endif

#endif 
