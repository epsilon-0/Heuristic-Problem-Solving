#ifndef AIG_TYPE_H
#define AIG_TYPE_H 

#include "def.h"

//--- AigLit ------------------------------------------------------------------
typedef uint32 AigLit;
inline AigLit   toAigLit( uint32 var , unsigned sgn){return (var+var)+sgn;}
inline AigLit   inv ( AigLit p ){ return p ^ 1 ;}
inline unsigned sign( AigLit p ){ return p & 1 ;}
inline unsigned var ( AigLit p ){ return p >>1 ;}
//=============================================================================

//--- AigNode -----------------------------------------------------------------
struct AigNode
{
   union
   {
      uint64 key;
      AigLit fanin[2];
   };
   AigNode(){}
   inline AigNode( uint64 a , AigLit b ):key( a<<32|b){}
};
//=============================================================================

#endif
