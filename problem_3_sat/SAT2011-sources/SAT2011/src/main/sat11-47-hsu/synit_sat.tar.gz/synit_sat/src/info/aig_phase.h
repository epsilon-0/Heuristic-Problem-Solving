#ifndef AIG_PHASE_H
#define AIG_PHASE_H

#include"aig.h"

class AigPhase : public vec<uint8>
{
   StrashAIG    & _ckt;

   public:
   AigPhase( StrashAIG & ckt ): _ckt(ckt){ }

   void init(){growTo( _ckt._andFlag , 0 );}
   void validation()
   {
      unsigned i = size();
      unsigned end=_ckt.size();
      if( end > i )
      {
         growTo( end );
         for( ; i < end ; ++i )
         {
            AigNode n = _ckt[i];
            data[i] = ( data[ var(n.fanin[0]) ]^sign( n.fanin[0] )) &&
                      ( data[ var(n.fanin[1]) ]^sign( n.fanin[1] ));
         }
      }else downTo( end );
   }
};

#endif
