#include "cktinfo.h"
#include "aig.h"
#include <cstring>

//____ Local function _________________________________________________________
//  
//  LvlMt , CapMt 
//
//=============================================================================

static const unsigned char sign_pos = 0x01;
static const unsigned char sign_neg = 0x02;
static const unsigned char sign_bi  = 0x03;
static const unsigned char sign_int = 0x04;

struct LvlMt
{
   level_t * lvl;
   unsigned * focnt;
   LvlMt( level_t * c , unsigned * f  ):lvl(c),focnt(f){}
   bool operator()(AigLit a,AigLit b)const
   {
      if( lvl[var(a)] > lvl[var(b)] ) return true;
      if( lvl[var(a)] < lvl[var(b)] ) return false;
      return focnt[ var(a) ] < focnt[ var(b) ] ;
   }
};
struct CapMt
{
   level_t * level;
   level_t * arrival;
   CapMt( level_t * l , level_t * a ) : level( l ) , arrival( a ) {}
   bool operator()( AigLit a , AigLit b )const
   {
      return level[var(a)]+arrival[var(b)] > level[var(b)] + arrival[var(a)];
   }
};
//____ Initialize functions ___________________________________________________
//
//  creat fanout count : traverse , build 
//  reset level        : 
//
//=============================================================================
void CktInfo::init()
{
   LitUnion::init();
   LitUnion::validation( sz );
   _mrk.growTo( sz , 0 );
   create_focnt();
   reset_level();
}
void CktInfo::create_focnt()
{
   assert( _focnt.size() == 0 && _mrk.size() != 0 );

   unsigned * order = new unsigned [sz];
   int k = 0; 

   _focnt.growTo( _andFlag , 1 );
   _focnt.growTo( sz , 0 );
   unsigned * focnt = _focnt.data;
   
   for( unsigned sel = 0 ; sel < 2 ;++ sel ){
      const vec<AigLit> & po = sel==0?_po:_ppo;
      for( unsigned i = 0 ; i < po.size() ; ++i )
      {
         unsigned next = eqIdx( var( po[i] ) );
         focnt[next] +=1 ;
         if( _mrk[ next ] == 0 )
         {
            _mrk[ next ] = 1;
            order[k++] = next;
         }
      }
   }

   int ptr = 0;
   while( k != ptr )
   {
      unsigned n = order[ ptr ++ ];
      if( n < _andFlag ) continue; 
      for( unsigned i = 0 ; i < 2 ; ++ i )
      {
         unsigned next = eqInIdx( n , i ) ;
         focnt[next] +=1 ;
         if( _mrk[ next ] == 0 )
         {
            _mrk[ next ] = 1 ; 
            order[ k ++ ] = next;
         }
      }
   }
   delete [] order;
   memset( _mrk.data , 0 , _mrk.sz * sizeof( mark_t ) );
}
void CktInfo::reset_level()
{
   assert( _level.size() == 0 && _rlevel.size() == 0 );

   _level.resize( _andFlag , 1 );
   _level.growTo( size() , 0 );

   _rlevel.resize( size(),0 );
   level_t * arrival = _rlevel.data;
   for( unsigned i = sz-1 ; i >= _andFlag ; -- i)
   {
      level_t carrival = arrival[i] + 1 ;
      for( int j = 0 ; j < 2 ; ++ j )
      {
         unsigned n = eqInIdx( i , j );
         if( arrival[n] < carrival ) arrival[n] = carrival;
      }
   }

   if( LEVEL_CONSIDER == 0 )
   {
      memcpy( _level.data , _rlevel.data , sizeof( level_t ) * _andFlag ); 
      _level[0]=1;
   }

   _max_level = 0;
   for( unsigned i = 1 ; i < _andFlag ; ++ i )
      if( _max_level < arrival[i] ) _max_level = arrival[i];
}
//____ factor a new circuit ___________________________________________________
//
//  topological traversal 
//  factor 
//
//=============================================================================
void CktInfo::topological_traversal( vec<unsigned> & ord)
{
   assert( _focnt.size() != 0 );

   ord.clear();
   
   for( unsigned sel = 0 ; sel < 2 ; ++ sel ){
      const vec<AigLit> & po = sel==0?_po:_ppo;
      for( unsigned i = 0 ; i < po.size() ; ++i )
      { 
         unsigned next = eqIdx( var( po[i] ) );
         _focnt[ next ] -=1;
         if( _focnt[ next ] == 0 && next >= _andFlag )
            ord.push( next );
      }
   }
   unsigned ptr = 0;
   while ( ptr != ord.size() )
   {
      unsigned n = ord[ ptr ++ ];
      for( unsigned j = 0 ; j < 2 ; ++ j )
      {
         unsigned next = eqInIdx( n , j );
         _focnt[ next ] -=1;
         if( _focnt[ next ] == 0 && next >= _andFlag )
            ord.push( next );
      }
   }
#ifndef NDEBUG
   {
      for( int i = _focnt.size() - 1  ; i > _andFlag ; --i)
         if( _focnt[i] != 0 ) {
            cout <<"Fanout count error "<< i << "\t"<<_focnt[i]<<endl;
         }
   }
#endif
   _focnt.clear();
}
void CktInfo::factor( StrashAIG & ckt )
{
   assert( _focnt.size() != 0 );

   vec<unsigned> ord(sz); ord.clear();
   AigLit * lut = new AigLit [sz];
   lut[0] = 0;

   {
      for( unsigned i = 1 ; i < _andFlag ; ++ i) 
         ckt.createBase();
      ckt._andFlag   = ckt.size();
      ckt._ppiFlag   = ckt._andFlag - _ppo.size();
   }

   for( unsigned i = 1 ; i < _andFlag ; ++ i)
      lut[ i ] = eq( toAigLit(i,0) );

   {  
      topological_traversal( ord );
      for( int i = ord.size() -1 ; i >= 0 ; -- i )
      {
         unsigned idx = ord[i];
         AigLit in[2];
         for( unsigned j = 0 ; j < 2 ; ++ j )
         {
            AigLit o_eq = eqIn( idx , j );
            in[j] = toAigLit( var( lut[ var(o_eq) ]) , sign(lut[ var(o_eq) ]) ^ sign(o_eq) );
         }
         lut[idx] = ckt.createAND( in[0] , in[1] );
      }
   }
   {// po , ppo construct
      ckt._po.growTo( _po.size());
      ckt._ppo.growTo( _ppo.size() );
      for( unsigned sel = 0 ; sel < 2 ; ++ sel)
      {
         const vec<AigLit> & rpo = sel==0?_po:_ppo;
         vec<AigLit> & cpo = sel ==0?ckt._po:ckt._ppo;

         for( unsigned i = 0 ; i < rpo.size() ; ++ i )
         {
            AigLit o_eq = eq( rpo[i] );
            cpo[i] = toAigLit( var(lut[ var(o_eq) ]) , sign(lut[ var(o_eq) ]) ^ sign(o_eq) );
         }
      }
   }
   delete [] lut;
}
//____ simple update functions ________________________________________________
//
//  capacity update 
//  rlevel recover 
//  level queraing 
//
//=============================================================================
void CktInfo::validation()
{
   LitUnion::validation( sz );
   _mrk.resize( sz , 0 );
   _focnt.resize( sz, 0 );
   _level.resize( sz , 0 );
   _rlevel.resize( sz , 0 );
}
//--- event propagate
void CktInfo::rlevel_recover( unsigned n )
{
   for( int i = 0 ; i < 2 ; ++ i )
   {
      unsigned m = eqInIdx(n,i);
      if( _rlevel[m] <= _rlevel[n] )
      { 
         _rlevel[m] = _rlevel[n]+1;
         if( m >= _andFlag)rlevel_recover(m);
      }
   }
}
//--- recursive construction
unsigned CktInfo::lvl( unsigned n )
{
   if( _level[n] == 0 )
      _level[n] = std::max( lvl( eqInIdx(n,0) ) , lvl( eqInIdx(n,1) ) ) + 1;
   return _level[n];
}
void CktInfo::update_level( unsigned n )
{
   _level[n] = std::max( _level[ var( data[n].fanin[0])]  , _level[ var( data[n].fanin[1]) ] ) + 1;
}
//____ Traversing Functions ___________________________________________________
//
//
//=============================================================================
void CktInfo::resume( unsigned * cone , unsigned s )
{
   for( unsigned i = 0 ; i < s ;++i)
   {
      unsigned n = cone[i];
      _focnt[ eqInIdx(n,0) ] += 1;
      _focnt[ eqInIdx(n,1) ] += 1;
   }
}
void CktInfo::rm_cone( unsigned n )
{ 
   if( (-- _focnt[eqInIdx(n,0)]) == 0 )rm_cone( eqInIdx(n,0) );
   n=eqInIdx(n,1);
   if( (-- _focnt[n]) == 0 )rm_cone(n);
}
unsigned CktInfo::get_cone( unsigned next , vec<unsigned> & cone)
{ 
   assert( _focnt[next] == 0 && _mrk.size() && _focnt.size() );
   cone.clear();

   if( ! _mrk[next] )
   {
      cone.push( next );

      unsigned ptr = 0 ;
      while( cone.size() != ptr )
      {
         unsigned node = cone[ptr++];
         for( unsigned j = 0 ; j < 2 ; ++ j)
         {
            next = eqInIdx( node , j );
            assert( _focnt[next] != 0 );
            _focnt[ next ] -=1 ;
            if( _focnt[ next ] == 0 && ! _mrk[ next ] )
               cone.push( next );
         }
      }
   }
   
   return cone.size();
}
unsigned CktInfo::get_freeCone( unsigned next , vec<unsigned> & cone)
{
   assert( _mrk.size() && _focnt.size() );
   cone.clear();

   if( _focnt[next] == 0 && ! _mrk[next] )
   {
      cone.push( next );
      _mrk[ next ] = 1; 

      unsigned ptr = 0 ;
      while( cone.size() != ptr )
      {
         unsigned node = cone[ptr++];
         for( unsigned j = 0 ; j < 2 ; ++ j)
         {
            next = eqInIdx( node , j );
            if( _focnt[ next ] == 0 && ! _mrk[ next ] )
            {
               cone.push( next );
               _mrk[next] = 1; 
            }
         }
      }
      for( unsigned i = 0 ; i < cone.size() ; ++i )
         _mrk[ cone[i] ] = 0; 
   }
   
   return cone.size();
}
void CktInfo::replace( unsigned n , unsigned p , unsigned focnt )
{
   assert( n == eqIdx(n) && _mrk.size() != 0 && _focnt[n] == 0 && p != n );
   unsigned eqp = eqIdx( p );
   if( eqp!=n) p = eqp;

   if( LEVEL_CONSIDER == 2 && _rlevel[p] < _rlevel[n] )
   {
      _rlevel[p] = _rlevel[n];
      if( p >= _andFlag )rlevel_recover( p );
   }

   get_freeCone( p , _tmp_cone);
   resume( _tmp_cone.data , _tmp_cone.sz );
   _focnt[p] += focnt;
   rm_cone( n );

   conjunct( n , p );
}
//____ Balance Construction  __________________________________________________
//
//
//=============================================================================
bool CktInfo::todo( unsigned idx )
{
   AigLit node[2] = { eqIn( idx , 0 ) , eqIn( idx ,1 ) };
   unsigned c = node[0] ^ node[1];
   
   if( (c & (~1)) == 0  )
   {
      c = c?0:var(node[0]);
      conjunct( idx , c );
      _focnt[ c ] += _focnt[ idx ]-2;
      _focnt[ idx ]=0;
      if( c == 0 )rm_cone( idx ),_focnt[0]+=2;
      return 0;
   }
   return _focnt[ var(node[0]) ] == 1 || _focnt[ var(node[1]) ] == 1 ;
}
AigLit CktInfo::build_blAND( AigLit * q , unsigned k )
{
   if( k < 3 )
   {
      if( k == 1 ) return q[0];
      if( k == 2 ){ AigLit p = createAND( q[0] , q[1] ); validation(); return p;}
   }

   for( unsigned i = 0 ; i < k ; ++ i )
      if( _level[ var(q[i]) ] == 0 ) lvl( var(q[i]) );
   std::sort( q , q+k , LvlMt( _level.data , _focnt.data ) );
   //std::sort( q , q+k , CapMt( _level.data , _rlevel.data ) );

   k-=1;
   while(k)
   {
      int i , t = std::max( (int)k-64 , 0 );
      for(i=k-2;i>=t;--i)
      {
         unsigned v = var( test_createAND(q[k],q[i]));
         if( v < _focnt.sz && _focnt[v] != 0 )
         {
            std::swap( q[i] , q[k-1] );
            break;
         }
      }
      k-=1;

      q[k] = createAND( q[k],q[k+1]);
      validation(); // lvl must increase 
      lvl( var(q[k]) );//update level
      for(i = k ; i > 0 ; -- i )
         if( _level[var(q[i])] > _level[var(q[i-1])] )
            std::swap( q[i],q[i-1]);
         else break;
   }
   return q[0];
}
