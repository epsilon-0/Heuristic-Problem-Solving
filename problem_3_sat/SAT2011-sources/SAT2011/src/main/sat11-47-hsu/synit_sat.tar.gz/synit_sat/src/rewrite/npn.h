#ifndef NPN_H
#define NPN_H

struct NPin 
{
   unsigned char permute:3;
   unsigned char sign:1;

   NPin(){}
   NPin( unsigned char idx , unsigned s ) : permute( idx ), sign( s ){}
   unsigned char encode()const{return permute+permute+sign ;}
   void decode( unsigned char c ){ permute = c>>1 ; sign = c&1 ; }
};

struct NP
{
   NPin in[DBSIZE];
};

struct NPNPtr : public NP
{
   unsigned short sign:1;
   unsigned short setted:1;
   unsigned short idx:14; // upper . 222

   NPNPtr( NP p ) : NP( p){}
   NPNPtr():setted(0){}
};

#endif
