#ifndef RWTDB_H
#define RWTDB_H

#include "def.h"
#include "aigType.h"
#include "vec.h"
#include "npn.h"

class CktInfo ;
class StrashAIG;
class Cut;

struct Arpreggio    // TODO modify the ret variable with npn.idx variable
   // 24 byte ?
{
   NPNPtr          npn;   //6
   AigNode     * tapes;   //8
   unsigned short size;   //2
   unsigned short score;  //2
   unsigned short var;    //2
   Arpreggio( NPNPtr p ):npn( p ),tapes(NULL),size(0),score(0){}
   Arpreggio(){} 
};

class RewriteDB
{
   friend class Rewrite;
   public:
   AigLit   *_bucket;
   unsigned  _bucketSize;         // optional 
   NPNPtr    _mixers[1<<(1<<4)];  // a sound mapping to a chord and its rotate

   vec< vec<Arpreggio> > _composition;        // a chord to a rhythm which rhythm is composed by a chord call  

   StrashAIG        *    _ckt;      // to be build 
   vec<unsigned>    *    _focnt;    // to be check the existance 
   CktInfo          *    _info;

   public:

   RewriteDB( const RewriteDB & s );
   RewriteDB():_bucket(NULL),_bucketSize(0){ _mixers[0].setted = _mixers[(1<<(1<<DBSIZE))-1].setted = 1; }
   ~RewriteDB();

   bool read_DB( const char * path );
   bool write_DB( const char * path);
   void report_arpreggio();

   // rewrite used
   NPNPtr   get_mixer( fun_t f)const{ return _mixers[ f ] ; }  
   bool     setted( fun_t f )const{ return _mixers[f].setted ; } 

   void     put_bases( const Cut & c ,unsigned s, NPNPtr mixer , const Arpreggio & arp );
   unsigned construct( const Arpreggio & arp , unsigned lim , unsigned & winner );
   unsigned construct( fun_t f , const Cut & ,unsigned s, unsigned lim , unsigned & ret );
};

#endif
