/*
 * restarts.c
 *
 *  Created on: 02.03.2011
 *      Author: zelle
 *
 ***
 * Restart Heuristic: Avoidance of Plateaux
 */

#include "assignment.h"

#define PLATEAU_INTERVAL 24
#define PLATEAU_MAX_ELEMENTS 4
#define PLATEAU_MIN_HEIGHT 51
#define PLATEAU_MIN_CONFLICTS 666

static int backtracking_levels[PLATEAU_INTERVAL];
static int plateau_column = 0;

static int nof_conflicts_since_last_restart = 0;


/**
 * to be called at each conflict
 */
int have_plateau(int backtracking_level) {
	int minimum_count = 0;
	int minimum = backtracking_levels[0];
	int i;
	backtracking_levels[plateau_column] = backtracking_level;
	plateau_column = (plateau_column+1) % PLATEAU_INTERVAL;
	nof_conflicts_since_last_restart++;

	if (nof_conflicts_since_last_restart > PLATEAU_MIN_CONFLICTS && backtracking_level > PLATEAU_MIN_HEIGHT) {
		for (i=1; i<PLATEAU_INTERVAL; ++i) {
			if (backtracking_levels[i] < minimum) {
				minimum = backtracking_levels[i];
				minimum_count = 1;
			} else if (backtracking_levels[i] == minimum) {
				++minimum_count;
			}
		}

		if (minimum_count > PLATEAU_MAX_ELEMENTS) {
			nof_conflicts_since_last_restart = 0;
			return 1;
		} else {
			return 0;
		}
	} else {
		return 0;
	}
}
