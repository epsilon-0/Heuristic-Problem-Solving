/*
 * learnts.h
 *
 *  Created on: 02.03.2011
 *      Author: zelle
 */

#ifndef LEARNTS_H_
#define LEARNTS_H_

#include "clause.h"

extern void learnts_dump_create(int capacity);
extern void learnts_ditch_create(int capacity);

extern void learnts_clause_ditch(clause_t *clause);

extern void generate_conflict_clause();


extern int get_polarity_mode();
extern void switch_polarity_mode();

#endif /* LEARNTS_H_ */
