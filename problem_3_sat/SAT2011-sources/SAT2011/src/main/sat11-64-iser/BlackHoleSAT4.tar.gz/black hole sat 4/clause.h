/*
 * clause.h
 *
 *  Created on: 10.02.2011
 *      Author: zelle
 */

#ifndef CLAUSE_H_
#define CLAUSE_H_

typedef struct clause_t {
	struct literal_t **literals;

	int nof_lits;

	struct literal_t *watch[2];

	int learnt_activity;
	int dismissed;
} clause_t;


extern void clauses_flat_array_create(int initial_size);

extern clause_t *clause_new(int nof_lits);
extern clause_t *clause_new_learnt(int nof_lits);
extern void clause_attach_literal(clause_t *clause, struct literal_t *lit);
extern void clause_create_watchers(clause_t *clause);

extern struct literal_t *clause_get_first_open_unwatched_literal(clause_t *clause);
extern int clause_is_solved(clause_t *clause);

extern int validate();

#endif /* CLAUSE_H_ */
