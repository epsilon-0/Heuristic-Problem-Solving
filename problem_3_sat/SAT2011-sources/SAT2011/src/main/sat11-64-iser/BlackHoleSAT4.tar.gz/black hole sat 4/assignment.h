/*
 * assignment.h
 *
 *  Created on: 10.02.2011
 *      Author: zelle
 */

#ifndef ASSIGNMENT_H_
#define ASSIGNMENT_H_

#include "variable.h"
#include "clause.h"

extern void assignment_stack_create(int num);
extern void assignment_push(var_t *var);
extern var_t *assignment_pop();
extern var_t *get_first_reason();
extern var_t *get_last_reason();
extern int get_nof_reasons();
var_t *get_reason(int i);

extern void print_assignment();

#endif /* ASSIGNMENT_H_ */
