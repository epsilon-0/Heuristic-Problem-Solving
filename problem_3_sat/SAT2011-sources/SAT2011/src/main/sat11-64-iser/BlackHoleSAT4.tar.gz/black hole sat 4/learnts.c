/*
 * learnts.c
 *
 *  Created on: 02.03.2011
 *      Author: zelle
 *
 ***
 * Clause Learning: Simply all Reasons
 */

#include <stdio.h>
#include <stdlib.h>

#include "clause.h"
#include "variable.h"
#include "assignment.h"
#include "pairing_heap.h"


static void print_clause(char* prefix, clause_t *clause) {
//	int i;
//	fprintf(stdout, prefix);
//	for (i=0; i<clause->nof_lits; i++) {
//		literal_t *literal = clause->literals[i];
//		if (literal->sign == 0) {
//			fprintf(stdout, "-%i ", literal->var->pos);
//		} else {
//			fprintf(stdout, "%i ", literal->var->pos);
//		}
//	}
//	fprintf(stdout, "\n");
}


/*
 * polarity mode often is responsible
 * for 'good' learnts
 */

static int polarity_mode = 0;

void switch_polarity_mode() {
	fprintf(stderr, "c Switching Polarity Mode\n");
	polarity_mode = !polarity_mode;
}

int get_polarity_mode() {
	return polarity_mode;
}


/*
 * Learnts Dump: for register all active learnts
 */

static int nof_learnts = 0;
static int old_nof_learnts = 0;

static int learnts_dump_capacity = 0;
static clause_t **learnts_dump;

static int activity_limit = 1; // regualarly muck out based on this limit

void learnts_dump_create(int capacity) {
	learnts_dump_capacity = capacity;
	learnts_dump = calloc(learnts_dump_capacity, sizeof(clause_t*));
}

static void learnts_dump_grow(int new_capacity) {
	learnts_dump_capacity = new_capacity;
	learnts_dump = realloc(learnts_dump, learnts_dump_capacity*sizeof(clause_t*));
}

static void learnts_dump_muck_out() {
	int i, j;
	fprintf(stdout, "c Pruning learnts\n");
	for (i=0, j=0; i<nof_learnts; i++) {
		clause_t *learnt = learnts_dump[i];
		if (learnt->learnt_activity > activity_limit || learnt->nof_lits < 4) {
			print_clause("c USE: ", learnt);
			learnts_dump[j] = learnt;
			j++;
		} else {
			print_clause("c NOT: ", learnt);
			learnt->dismissed = 1;
		}
	}
	fprintf(stdout, "c Kept: %i learnts\n", j);

	if (j*2 <= old_nof_learnts) {
		old_nof_learnts = j;
		switch_polarity_mode();
		learnts_dump_grow(learnts_dump_capacity*2);
	} else {
		old_nof_learnts = j;
		activity_limit++;
		if (j*2 > learnts_dump_capacity) {
			learnts_dump_grow(learnts_dump_capacity+j);
		}
	}
	nof_learnts = j;
//	getchar();
}

//static int clause_find_lit(clause_t *clause, literal_t *literal) {
//	int i;
//	for (i=0; i<clause->nof_lits; i++) {
//		if (clause->literals[i] == literal) {
//			return 1;
//		}
//	}
//	return 0;
//}

/**
 * uses assignment-stack ordering assumption (optimization vs. find-lit)
 */
static int clause_implies(clause_t *new_learnt, clause_t *learnt) {
	if (new_learnt->nof_lits >= learnt->nof_lits) {
		return 0;
	} else {
		int i;
		for (i=0; i<new_learnt->nof_lits; i++) {
			if (learnt->literals[i] != new_learnt->literals[i]) {
				return 0;
			}
		}
		return 1;
	}
}

static void learnts_dump_add(clause_t *new_learnt) {
	while (nof_learnts > 0) {
		clause_t *old_learnt = learnts_dump[nof_learnts-1];

		if (clause_implies(new_learnt, old_learnt)) {
			print_clause("c DIS: ", old_learnt);
			old_learnt->dismissed = 1;
			nof_learnts--;
		} else {
			break;
		}
	}

	if (nof_learnts == learnts_dump_capacity) {
		learnts_dump_muck_out();
	}

	learnts_dump[nof_learnts++] = new_learnt;
}


static int nof_ditched_learnts = 0;
static int learnts_ditch_capacity = 0;
static clause_t **learnts_ditch;

/*
 * Learnts Ditch: Optimize Alloc-/Free-Cycle of Learnts
 */

void learnts_ditch_create(int capacity) {
	learnts_ditch_capacity = capacity;
	learnts_ditch = calloc(learnts_ditch_capacity, sizeof(clause_t*));
}

void learnts_clause_ditch(clause_t *clause) {
	if (nof_ditched_learnts == learnts_ditch_capacity) {
		learnts_ditch_capacity *= 2;
		learnts_ditch = realloc(learnts_ditch, learnts_ditch_capacity*sizeof(clause_t*));
	}
	learnts_ditch[nof_ditched_learnts++] = clause;
}

static clause_t *learnts_recycle_or_create_clause(int nof_lits) {
	if (nof_ditched_learnts > 0) {
		clause_t *clause = learnts_ditch[--nof_ditched_learnts];
		if (clause->nof_lits < nof_lits) {
			clause->literals = realloc(clause->literals, nof_lits*sizeof(literal_t*));
		}
		clause->nof_lits = 0;
		clause->dismissed = 0;
		return clause;
	} else {
		return clause_new_learnt(nof_lits);
	}
}


clause_t *buffered_clause = NULL;

void generate_conflict_clause() {
	clause_t *clause;
	int i;
	int nof_reasons = get_nof_reasons();

	clause = learnts_recycle_or_create_clause(nof_reasons);

	clause->learnt_activity = activity_limit;

	for (i=0; i<nof_reasons; i++) {
		var_t *variable = get_reason(i);
		literal_t *lit = var_get_lit(variable, !(variable->value));
		clause_attach_literal(clause, lit);
	}

	if (buffered_clause != NULL) {
		if (clause_implies(clause, buffered_clause)) {
			buffered_clause->dismissed = 1;
			learnts_clause_ditch(buffered_clause);
		} else {
			clause_create_watchers(buffered_clause);
			learnts_dump_add(buffered_clause);
		}
	}

	buffered_clause = clause;
}
