/*
 * variable.c
 *
 *  Created on: 10.02.2011
 *      Author: zelle
 */

#include <stdio.h>
#include <stdlib.h>

#include "variable.h"
#include "clause.h"
#include "assignment.h"
#include "pairing_heap.h"


#define CLAUSE_ARRAY_INITIAL_SIZE 2;

static int nof_variables;
static var_t *variables_flat;

static int nof_literals;
static literal_t *literals_flat;

/*
 * init flat-array of var_t
 */
void variables_flat_array_create(int capacity) {
	int pos;
	nof_variables = capacity+1;
	variables_flat = calloc(nof_variables, sizeof(var_t));
	nof_literals = nof_variables*2;
	literals_flat = calloc(nof_literals, sizeof(literal_t));

	heap_create(nof_variables);

	for (pos = 1; pos < nof_variables; pos++) {
		var_t *variable = &(variables_flat[pos]);
		literal_t *literal0 = &(literals_flat[pos*2]);
		literal_t *literal1 = &(literals_flat[1+pos*2]);

		variable->literal[0] = literal0;
		variable->literal[1] = literal1;

		literal0->var = variable;
		literal0->sign = 0;
		literal0->watchers = NULL;

		literal1->var = variable;
		literal1->sign = 1;
		literal1->watchers = NULL;

		variable->value = -1;
		variable->polarity = 0;
		variable->pos = pos;

		heap_insert(variable);
	}
}

var_t *variable_get_at(int pos) {
	return &(variables_flat[pos]);
}

int lit_is_open(literal_t *lit) {
	return lit->var->value < 0;
}

int lit_is_satisfied(literal_t *lit) {
	return lit->sign == lit->var->value;
}

literal_t* var_get_lit(var_t* var, int sign) {
	return var->literal[sign];
}


literal_clause_t *watcher_ditch = NULL;

void literal_ditch_watcher(literal_clause_t *watcher) {
	watcher->next = watcher_ditch;
	watcher_ditch = watcher;
}

void literal_recycle_or_create_watcher(literal_t *literal, clause_t *clause) {
	literal_clause_t *watcher;

	if (watcher_ditch == NULL) {
		watcher = malloc(sizeof(literal_clause_t));
	} else {
		watcher = watcher_ditch;
		watcher_ditch = watcher_ditch->next;
	}

	watcher->clause = clause;

	// attach to litaral
	watcher->next = literal->watchers;
	literal->watchers = watcher;
}

