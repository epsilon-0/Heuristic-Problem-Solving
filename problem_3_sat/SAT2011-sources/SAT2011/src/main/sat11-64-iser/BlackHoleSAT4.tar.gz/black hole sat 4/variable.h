/*
 * variable.h
 *
 *  Created on: 10.02.2011
 *      Author: zelle
 */

#ifndef VARIABLE_H_
#define VARIABLE_H_

typedef struct literal_clause_t {
	struct clause_t *clause;
	struct literal_clause_t *next;
} literal_clause_t;


typedef struct literal_t {
	struct var_t *var;
	int sign;

	literal_clause_t *watchers;
} literal_t;

typedef struct var_t {
	literal_t *literal[2];

	int pos;
	int in_heap;
	int value;
	int polarity;
	int is_reason;
} var_t;


extern void variables_flat_array_create(int num);
extern var_t *variable_get_at(int pos);

extern void literal_ditch_watcher(literal_clause_t *watcher);
extern void literal_recycle_or_create_watcher(literal_t *literal, struct clause_t *clause);

extern int lit_is_open(literal_t *lit);
extern int lit_is_satisfied(literal_t *lit);
extern literal_t* var_get_lit(var_t* var, int sign);

#endif /* VARIABLE_H_ */
