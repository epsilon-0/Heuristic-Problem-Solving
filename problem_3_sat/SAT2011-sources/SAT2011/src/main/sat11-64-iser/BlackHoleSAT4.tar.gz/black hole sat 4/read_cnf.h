/*
 * read_cnf.h
 *
 *  Created on: 24.12.2010
 *      Author: zelle
 */

#ifndef READ_CNF_H_
#define READ_CNF_H_

extern int read_cnf_file(char* filename);

#endif /* READ_CNF_H_ */
