/*
 * assignment.c
 *
 *  Created on: 10.02.2011
 *      Author: zelle
 */

#include <stdlib.h>
#include <stdio.h>

#include "variable.h"
#include "clause.h"
#include "assignment.h"
#include "pairing_heap.h"


static var_t **assignments;
static int nof_assignments = 0;

static var_t **reasons;
static int nof_reasons = 0;

void assignment_stack_create(int num) {
	assignments = calloc(num, sizeof(var_t*));
	reasons = calloc(num, sizeof(var_t*));
}

void assignment_push(var_t *variable) {
	assignments[nof_assignments] = variable;
	++nof_assignments;

	if (variable->is_reason > 0) {
		reasons[nof_reasons] = variable;
		++nof_reasons;
	}
 }

var_t *assignment_pop() {
	var_t *variable;
	if (nof_assignments == 0) {
		return NULL;
	}

	--nof_assignments;
	variable = assignments[nof_assignments];

	if (variable->is_reason > 0) {
		--nof_reasons;
	}

	return variable;
}

var_t *get_first_reason() {
	if (nof_reasons == 0) {
		return NULL;
	} else {
		return reasons[0];
	}
}

var_t *get_last_reason() {
	if (nof_reasons == 0) {
		return NULL;
	} else {
		return reasons[nof_reasons-1];
	}
}

int get_nof_reasons() {
	return nof_reasons;
}

var_t *get_reason(int i) {
	return reasons[i];
}

void print_assignment() {
	int i, j;
	for (i=0; i<nof_assignments; ) {
		fprintf(stdout, "v ");
		for (j=0; j<10 && i<nof_assignments; j++, i++) {
			var_t *var = assignments[i];
			if (var->value == 0) {
				fprintf(stdout, "-%i ", var->pos);
			} else {
				fprintf(stdout, "%i ", var->pos);
			}
		}
		fprintf(stdout, "\n");
	}
	fprintf(stdout, "0\n");
}
