/*
 * read_cnf.c
 *
 *  Created on: 24.12.2010
 *      Author: zelle
 */

#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#ifndef _MSWIN
	#include <sys/mman.h>
#endif
#include <stdlib.h>
#include <unistd.h>

#include "variable.h"
#include "clause.h"
#include "learnts.h"
#include "units.h"
#include "assignment.h"
#include "pairing_heap.h"

static void skip_whitespace(char **p) {
	while ((**p >= 9 && **p <= 13) || **p == 32) {
		++*p;
	}
}

static void skip_line(char **p, char *eof) {
	while (1) {
		if (*p >= eof) return;
		if (**p == '\n') {
			++*p;
			return;
		}
		++*p;
	}
}

static int read_int(char **p) {
	int val = 0;
	int neg = 0;

	if (**p == '-') {
		neg = 1;
		++*p;
	} else if (**p == '+') {
		++*p;
	}

	if (**p < '0' || **p > '9') {
		fprintf(stderr, "PARSE ERROR! Unexpected char: %c\n", **p);
		exit(3);
	}

	while (**p >= '0' && **p <= '9') {
		val = val*10 + (**p - '0');
		++*p;
	}

	return neg ? -val : val;
}

static int read_number_of_literals(char *p) {
	int nof_lits = 0;
	int var = read_int(&p);

	while (var != 0) {
		++nof_lits;
		skip_whitespace(&p);
		var = read_int(&p);
	}

	return nof_lits;
}

/*
 * initializes data-structures from cnf-file (unchecked)
 * returns 1 on failure
 */
int read_cnf_file(char* filename) {
	char *file, *pos, *eof;

#ifndef _MSWIN
	struct stat sb;

	int fd = open(filename, O_RDONLY);
	if (fd == -1) {
		perror ("fopen");
		return 1;
	}
	if (fstat(fd, &sb) == -1) {
		perror ("fstat");
		return 1;
	}
	if (!S_ISREG(sb.st_mode)) {
		fprintf (stderr, "%s is not a file\n", filename);
		return 1;
	}

	file = mmap(0, sb.st_size, PROT_READ, MAP_PRIVATE, fd, 0);

	if (file == MAP_FAILED) {
		perror ("mmap");
		return 1;
	}

	if (close (fd) == -1) {
		perror ("fclose");
		return 1;
	}

	eof = file + sb.st_size;
#else
	int length;

	FILE *fd = fopen(filename, "r");
	if (fd == NULL) {
		perror ("fopen");
		return 1;
	}

	fseek(fd, 0, SEEK_END);
	length = ftell(fd);
	rewind(fd);

	file = calloc(length, sizeof(char));
	fread(file, 1, length, fd);

	fclose(fd);

	eof = file + length;
#endif

	pos = file;

	while (pos < eof) {
		skip_whitespace(&pos);

		// overread comments
		if (*pos == 'c' || *pos == '%'|| *pos == '0') {
			skip_line(&pos, eof);
			skip_whitespace(&pos);
		}
		// read meta-information
		else if (*pos == 'p') {
			++pos;
			skip_whitespace(&pos);
			pos += 3; // 'cnf'
			skip_whitespace(&pos);

			int vars = read_int(&pos);
			skip_whitespace(&pos);

			int clauses = read_int(&pos);
			skip_line(&pos, eof);

			// init data-structures
			variables_flat_array_create(vars);
			unit_buffer_create(vars);
			assignment_stack_create(vars);
			clauses_flat_array_create(clauses);
			learnts_dump_create(clauses);
			learnts_ditch_create(clauses);
		}
		// read clause-information
		else {
			// number of literals read-ahead
			int nof_lits = read_number_of_literals(pos);

			// init clause
			clause_t *clause = clause_new(nof_lits);
			var_t *variable;
			literal_t *literal;

			int lit_no = read_int(&pos);

			do {
				// add literals
				variable = variable_get_at(abs(lit_no));
				literal = var_get_lit(variable, lit_no > 0 ? 1 : 0);

				clause_attach_literal(clause, literal);

				skip_whitespace(&pos);

				lit_no = read_int(&pos);
			} while (lit_no != 0);

			clause_create_watchers(clause);

			if (nof_lits == 1) {
				register_unit(literal);
			}

			skip_line(&pos, eof);
		}
	}

#ifndef _MSWIN
	if (munmap (file, sb.st_size) == -1) {
		perror ("munmap");
		return 1;
	}
#else
	free(file);
#endif

	return 0;
}
