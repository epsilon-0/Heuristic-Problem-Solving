/*
 * clause.c
 *
 *  Created on: 10.02.2011
 *      Author: zelle
 */

#include <stdlib.h>

#include "variable.h"
#include "clause.h"
#include "assignment.h"


static int next_clause;
static int nof_clauses;
static clause_t *clauses_flat;

/*
 * allocate flat-array of clause_t
 */
void clauses_flat_array_create(int capacity) {
	next_clause = 0;
	nof_clauses = capacity;
	clauses_flat = calloc(nof_clauses, sizeof(clause_t));
}

static int validate_clause(clause_t *clause) {
	int i, valid = 0;
	for (i=0; i<clause->nof_lits && !valid; i++) {
		literal_t *literal = clause->literals[i];
		if (literal->sign == literal->var->value) {
			valid |= 1;
		}
	}
	return valid;
}

int validate() {
	int pos, valid = 1;
	for (pos = 0; pos < nof_clauses && valid; pos++) {
		valid &= validate_clause(&(clauses_flat[pos]));
	}
	return valid;
}

/*
 * initialize clause-struct at next position and return position
 */
clause_t *clause_new(int nof_lits) {
	int pos = next_clause;

	clauses_flat[pos].learnt_activity = 0; //0 relevance for not-learnt clauses
	clauses_flat[pos].dismissed = 0; //0 relevance for not-learnt clauses

	clauses_flat[pos].watch[0] = NULL;
	clauses_flat[pos].watch[1] = NULL;

	clauses_flat[pos].literals = calloc(nof_lits, sizeof(literal_t*));
	clauses_flat[pos].nof_lits = 0;

	++next_clause;

	return &(clauses_flat[pos]);
}

clause_t *clause_new_learnt(int nof_lits) {
	clause_t *clause = malloc(sizeof(clause_t));

	clause->learnt_activity = 1;
	clause->dismissed = 0;

	clause->watch[0] = NULL;
	clause->watch[1] = NULL;

	clause->literals = calloc(nof_lits, sizeof(literal_t*));
	clause->nof_lits = 0;

	return clause;
}

/*
 * attach literal to clause and register watcher with literal
 */
void clause_attach_literal(clause_t *clause, literal_t *lit) {
	clause->literals[clause->nof_lits] = lit;
	clause->nof_lits++;
}

void clause_create_watchers(clause_t *clause) {
	if (clause->nof_lits == 1) {
		literal_t *lit = clause->literals[0];
		clause->watch[0] = lit;
		literal_recycle_or_create_watcher(lit, clause);
		clause->watch[1] = NULL;
	} else {
		literal_t *lit = clause->literals[clause->nof_lits-1];
		clause->watch[0] = lit;
		literal_recycle_or_create_watcher(lit, clause);
		lit = clause->literals[clause->nof_lits-2];
		clause->watch[1] = lit;
		literal_recycle_or_create_watcher(lit, clause);
	}
}


struct literal_t *clause_get_first_open_unwatched_literal(clause_t *clause) {
	int i;

	for (i=0; i < clause->nof_lits; i++) {
		literal_t *lit = clause->literals[i];
		if (lit_is_open(lit) && lit != clause->watch[0] && lit != clause->watch[1]) {
			return lit;
		}
	}
	return NULL;
}

int clause_is_solved(clause_t *clause) {
	int i;

	for (i=0; i < clause->nof_lits; i++) {
		literal_t *lit = clause->literals[i];
		if (lit_is_satisfied(lit)) {
			return 1;
		}
	}
	return 0;
}
