/*
 * units.h
 *
 *  Created on: 05.03.2011
 *      Author: zelle
 */

#ifndef UNITS_H_
#define UNITS_H_

extern void unit_buffer_create(int capacity);
extern int register_unit(literal_t *lit);
extern int get_nof_units();
extern literal_t *get_unit(int i);
extern void flush_unit_buffer();

#endif /* UNITS_H_ */
