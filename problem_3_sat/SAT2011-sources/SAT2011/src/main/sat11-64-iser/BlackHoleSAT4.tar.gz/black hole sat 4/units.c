/*
 * units.c
 *
 *  Created on: 05.03.2011
 *      Author: zelle
 */

#include <stdlib.h>

#include "variable.h"

static int nof_units = 0;
static literal_t **units;
static int *unit_positions;

void unit_buffer_create(int capacity) {
	units = calloc(capacity+1, sizeof(literal_t*));
	unit_positions = calloc(capacity+1, sizeof(int));
}

int register_unit(literal_t *literal) {
	int pos = literal->var->pos;
	if (units[pos] == NULL) {
		units[pos] = literal;
		unit_positions[nof_units++] = pos;
		return 1;
	} else if (units[pos] != literal) {
		// Opposite literal is (not yet processed) unit -> conflict
		return 0;
	} else {
		return 1;
	}
}

int get_nof_units() {
	return nof_units;
}

void flush_unit_buffer(int from) {
	int i;
	for (i=from; i<nof_units; i++) {
		units[unit_positions[i]] = NULL;
	}
	nof_units = 0;
}

literal_t *get_unit(int i) {
	literal_t *unit = units[unit_positions[i]];
	units[unit_positions[i]] = NULL;
	return unit;
}
