/*
 * pairing_heap.c
 *
 *  Created on: 11.02.2011
 *      Author: zelle
 */


#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "pairing_heap.h"
#include "clause.h"

heap_node *heap_flat_array;
int heap_capacity;
int heap_num;

heap_node *heap_insertion_buffer = NULL;
heap_node *heap_tree_pool = NULL;
int heap_tree_pool_maximum;
int heap_tree_pool_count;

heap_node *heap_maximum;


void heap_create(int capacity) {
	heap_capacity = capacity;
	heap_flat_array = calloc(heap_capacity, sizeof(heap_node));
	heap_maximum = NULL;
	heap_num = 0;

	heap_tree_pool_maximum = round(log(heap_capacity));
	heap_tree_pool_count = 0;
}


static inline heap_node* heap_node_get_at(int pos) {
	return &(heap_flat_array[pos]);
}


//static void heap_tree_pool_check_count() {
//	heap_node *node = heap_tree_pool;
//	int count = 0;
//	while (node != NULL) {
//		count++;
//		node = node->next;
//	}
//	if (count != heap_tree_pool_count) {
//		fprintf(stderr, "tree pool error: count: %i; in fact: %i", heap_tree_pool_count, count);
//	}
//}
//
//static void heap_check_parent_in_heap() {
//	int i;
//	for (i=0; i<heap_capacity; i++) {
//		heap_node *node = heap_node_get_at(i);
//		if (node->clause->in_heap) {
//			if (node->parent && !node->parent->clause->in_heap) {
//				fprintf(stderr, "red alert");
//			}
//		}
//	}
//}
//
//static void heap_check_parent_has_child(heap_node *node) {
//	heap_node *parent = node->parent;
//	if (parent) {
//		heap_node *child = parent->children;
//		int found = 0;
//		while (child) {
//			if (node == child) found = 1;
//			child = child->next;
//		}
//		if (!found) {
//			fprintf(stderr, "red alert");
//		}
//	}
//}
//
//static void heap_check_each_parent_has_child() {
//	int i;
//	for (i=0; i<heap_capacity; i++) {
//		heap_node *node = heap_node_get_at(i);
//		if (node->clause->in_heap) {
//			heap_check_parent_has_child(node);
//		}
//	}
//}
//
//static int heap_check_count_children(heap_node *node) {
//	heap_node *child = node->children;
//	int count = 0;
//	while (child != NULL) {
//		count = count + 1 + heap_check_count_children(child);
//		child = child->next;
//	}
//	return count;
//}
//
//static int heap_check_count_list(heap_node *start) {
//	int count = 0;
//	while (start != NULL) {
//		++count;
//		start = start->next;
//	}
//	return count;
//}
//
//static int heap_check_count_all() {
//	int count = heap_check_count_list(heap_insertion_buffer);
//	heap_node *root = heap_tree_pool;
//	while (root != NULL) {
//		count += 1 + heap_check_count_children(root);
//		root = root->next;
//	}
//	return count;
//}
//
//static void heap_check_maximum_has_parent() {
//	if(heap_maximum->parent != NULL) {
//		fprintf(stderr, "red alert");
//	}
//}


static heap_node* heap_link(heap_node *root1, heap_node *root2) {
	if (root1 == NULL) {
		root2->parent = NULL;
		return root2;
	}
	if (root2 == NULL) {
		root1->parent = NULL;
		return root1;
	}
	if (root1->weight > root2->weight) {
		root1->parent = NULL;

		root2->next = root1->children;
		root1->children = root2;
		root2->parent = root1;
		return root1;
	} else {
		root2->parent = NULL;

		root1->next = root2->children;
		root2->children = root1;
		root1->parent = root2;
		return root2;
	}
}

static heap_node* heap_multipass_pairing(heap_node *start) {
	if (start != NULL)
	while (start->next != NULL) {
		heap_node *position = start;
		heap_node **link = &start;

		while (position != NULL && position->next != NULL) {
			heap_node *node1 = position;
			heap_node *node2 = position->next;
			heap_node *pair;
			position = node2->next;
			node1->next = NULL;
			node2->next = NULL;
			pair = heap_link(node1, node2);
			pair->next = position;
			*link = pair;
			link = &(pair->next);
		}
	}
	return start;
}

static void heap_tree_pool_ensure_ordering() {
	heap_node **link = &heap_tree_pool;
	heap_node *odd = NULL;

	while (*link != NULL) {
		if ((*link)->next != NULL && (*link)->weight > (*link)->next->weight) {
			odd = *link;
			*link = (*link)->next;
		}
		if (odd != NULL) {
			if ((*link)->next == NULL) {
				odd->next = NULL;
				(*link)->next = odd;
				odd = NULL;
			}
			else if (odd->weight < (*link)->next->weight) {
				odd->next = (*link)->next;
				(*link)->next = odd;
				odd = NULL;
			}
		}
		link = &((*link)->next);
	}
}

static void heap_tree_pool_insert(heap_node *root) {
	heap_node **link;

	if (root == NULL) return;

	if (heap_tree_pool == NULL || heap_tree_pool->weight > root->weight) {
		root->next = heap_tree_pool;
		heap_tree_pool = root;
		heap_tree_pool_count++;
		return;
	}

	link = &heap_tree_pool;
	while ((*link)->next != NULL && ((*link)->next)->weight < root->weight) {
		link = &((*link)->next);
	}

	if ((*link)->next == NULL && (*link)->weight < root->weight) {
		// insert at end
		(*link)->next = root;
	} else {
		// insert between
		root->next = (*link)->next;
		(*link)->next = root;
	}

	heap_tree_pool_count++;
}

static heap_node* heap_combine_insertion_buffer() {
	heap_node *node = heap_multipass_pairing(heap_insertion_buffer);
	heap_insertion_buffer = NULL;
	return node;
}

/*
 * assert tree-pool to be sorted linked-list
 */
static void heap_combine_tree_pool() {
	if (heap_tree_pool != NULL)
	while (heap_tree_pool->next != NULL) {
		heap_node *root1 = heap_tree_pool;
		heap_node *root2 = heap_tree_pool->next;
		heap_node *rest = heap_tree_pool->next->next;
		root1->next = NULL;
		root2->next = NULL;
		heap_tree_pool = heap_link(root1, root2);
		heap_tree_pool->next = rest;
	}
	heap_tree_pool_count = 1;
}

static void heap_combine() {
	heap_node* insertion_buffer = heap_combine_insertion_buffer();
	heap_tree_pool_insert(insertion_buffer);
	heap_combine_tree_pool();
	heap_maximum = heap_tree_pool;
}

void heap_insert(var_t *variable) {
	heap_node *node = heap_node_get_at(variable->pos);
	node->var = variable;

	variable->in_heap = 1;

	node->next = heap_insertion_buffer;
	heap_insertion_buffer = node;

	if (heap_num == 0 || node->weight > heap_maximum->weight) {
		heap_maximum = node;
	}

	heap_num++;
}

void heap_increase_key(var_t *variable) {
	heap_node *cut;

	if (!variable->in_heap) return;

	cut = heap_node_get_at(variable->pos);

	if (cut->weight > 2*heap_capacity) return;

	cut->weight += 1;

	if (cut->parent != NULL) {
		// paste leftmost-child as substitute for node
		heap_node *paste = cut->children;
		heap_node *parent = cut->parent;

		// find reference to cut-node (sll-disadvantage)
		heap_node **link = &(parent->children);
		while (*link != cut) {
			link = &((*link)->next);
		}

		if (paste != NULL) {
			// unlink paste-node
			cut->children = paste->next;

			// relink paste-node
			*link = paste;
			paste->next = cut->next;
			paste->parent = cut->parent;
		} else {
			// nothing to paste, just cut
			*link = cut->next;
		}

		// unlink cut
		cut->next = NULL;
		cut->parent = NULL;

		heap_tree_pool_insert(cut);
	} else {
		// just for the case node belongs to tree-pool
		heap_tree_pool_ensure_ordering();
	}

	if (cut->weight > heap_maximum->weight) {
		heap_maximum = cut;
	}

	if (heap_tree_pool_count > heap_tree_pool_maximum) {
		heap_combine();
	}
}

var_t *heap_get_max() {
	return heap_maximum->var;
}

int heap_get_nof_variables() {
	return heap_num;
}

var_t *heap_delete_max() {
	heap_node *max;

	if (heap_maximum == NULL) {
		return NULL;
	}

	heap_combine();

	max = heap_maximum;

	heap_maximum = NULL;
	heap_tree_pool = NULL;
	heap_tree_pool_count = 0;
	heap_num--;

	if (max->children != NULL) {
		heap_maximum = heap_multipass_pairing(max->children);
		heap_tree_pool_insert(heap_maximum);
		max->children->parent = NULL;
		max->children = NULL;
	}

	max->var->in_heap = 0;

	return max->var;
}

/***
 * HEAP FLUSH
 */
void heap_flush() {
	int i = 0;
	int nof_min = rand() % 10;
	heap_node *minimum = heap_node_get_at(1);
	heap_node *current;
	for (i = 1; i < heap_capacity; i++) {
		current = heap_node_get_at(i);
		if (current->weight < minimum->weight) {
			minimum = current;
		} else if (current->weight == minimum->weight) {
			nof_min--;
			if (nof_min >= 0) {
				minimum = current;
			}
		}
		current->weight = 0;
	}

	heap_increase_key(minimum->var);
}

/***
 * HEAP DUMP
 */
static void heap_dump_node(heap_node *node) {
	if (node == NULL) return;
	fprintf(stdout, "%i", node->weight);
}

static void heap_dump_tree(heap_node *root);

static void heap_dump_list(heap_node *child) {
	int i = 0;
	while (child != NULL) {
		i++;
		heap_dump_tree(child);
		child = child->next;
		if (child != NULL) fprintf(stdout, ", ");
		//if (i % 100 == 0) fprintf(stdout, "\n ++ ");
		if (i > 100) break;
	}
}

static void heap_dump_tree(heap_node *root) {
	if (root == NULL) return;
	heap_node *child = root->children;
	heap_dump_node(root);
	fprintf(stdout, "[");
	heap_dump_list(child);
	fprintf(stdout, "]");
}

void heap_dump() {
	fprintf(stdout, " *** MAXIMUM *** \n *** ");
	heap_dump_tree(heap_maximum);
	fprintf(stdout, "\n *** \n");
	fprintf(stdout, " *** INSERTION BUFFER *** \n *** ");
	heap_dump_list(heap_insertion_buffer);
	fprintf(stdout, "\n *** \n");
	fprintf(stdout, " *** TREE POOL *** \n *** ");
	heap_dump_list(heap_tree_pool);
	fprintf(stdout, "\n *** \n\n\n");
}





