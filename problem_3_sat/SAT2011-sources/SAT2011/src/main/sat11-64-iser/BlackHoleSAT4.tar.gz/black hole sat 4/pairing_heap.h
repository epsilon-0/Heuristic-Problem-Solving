/*
 * pairing_heap.h
 *
 *  Created on: 11.02.2011
 *      Author: zelle
 */

#ifndef PAIRING_HEAP_H_
#define PAIRING_HEAP_H_

#include "variable.h"

typedef struct heap_node {
	struct var_t *var;
	int weight;
	struct heap_node *parent;
	struct heap_node *next;
	struct heap_node *children;
} heap_node;

extern void heap_create(int capacity);

extern void heap_insert(var_t *clause);

extern var_t *heap_get_max();
extern var_t *heap_delete_max();

extern int heap_get_nof_variables();

extern void heap_increase_key(var_t *var);

extern void heap_flush();
extern void heap_dump();

#endif /* PAIRING_HEAP_H_ */
