/*
 * restarts.h
 *
 *  Created on: 02.03.2011
 *      Author: zelle
 */

#ifndef RESTARTS_H_
#define RESTARTS_H_

extern int have_plateau(int backtracking_level);

#endif /* RESTARTS_H_ */
