/*
 * saturn.c
 *
 *  Created on: 16.12.2010
 *      Author: zelle
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "variable.h"
#include "clause.h"
#include "assignment.h"
#include "restarts.h"
#include "read_cnf.h"
#include "pairing_heap.h"
#include "learnts.h"
#include "units.h"


/*
 * assign value,
 * register assignment,
 * check for unit clauses
 */
static int propagate_assignment(var_t* var) {
	literal_t *falsified_literal = var_get_lit(var, !var->value);

	literal_clause_t **watcher_link = &(falsified_literal->watchers);

	while (*watcher_link != NULL) {
		literal_clause_t *watcher = *watcher_link;
		clause_t *clause = watcher->clause;

		if (clause->dismissed) {
			// unlink and ditch watcher
			*watcher_link = watcher->next;
			literal_ditch_watcher(watcher);
			// unlink and ditch clause
			if (clause->watch[0] == falsified_literal) {
				clause->watch[0] = NULL;
				if (clause->watch[1] == NULL) {
					learnts_clause_ditch(clause);
				}
			} else if (clause->watch[1] == falsified_literal) {
				clause->watch[1] = NULL;
				if (clause->watch[0] == NULL) {
					learnts_clause_ditch(clause);
				}
			}
			continue;
		}

		literal_t *open_literal = clause_get_first_open_unwatched_literal(clause);

		// watch another open lit
		if (open_literal != NULL) {
			if (falsified_literal == clause->watch[0]) {
				clause->watch[0] = open_literal;
			} else if (falsified_literal == clause->watch[1]) {
				clause->watch[1] = open_literal;
			}
			// unlink watcher
			*watcher_link = watcher->next;
			// relink watcher
			watcher->next = open_literal->watchers;
			open_literal->watchers = watcher;

			heap_increase_key(open_literal->var);
		}
		// or check for unit-lit
		else {
			literal_t* possible_unit;

			if (falsified_literal == clause->watch[0]) {
				possible_unit = clause->watch[1];
			} else {
				possible_unit = clause->watch[0];
			}

			if (!clause_is_solved(clause)) {
				if (clause->learnt_activity) {
					clause->learnt_activity++;
				}
				if (possible_unit != NULL && lit_is_open(possible_unit)) {
					if (!register_unit(possible_unit)) {
						return 0;
					}
				} else {
					return 0;
				}
			}

			watcher_link = &(watcher->next);
		}
	}
	return 1;
}


static int propagate_units() {
	int i, satisfied = 1;
	literal_t *lit;
	for (i=0; satisfied && i<get_nof_units(); i++) {
		lit = get_unit(i);
		if (lit_is_open(lit)) {
			lit->var->is_reason = 0;
			lit->var->value = lit->sign;
			assignment_push(lit->var);
			satisfied &= propagate_assignment(lit->var);
		} else {
			satisfied &= lit_is_satisfied(lit);
		}
	}
	flush_unit_buffer(i);
	return satisfied;
}

static void backtrack_until(var_t *reason) {
	var_t *assignment_variable = NULL;

	while (assignment_variable != reason) {
		assignment_variable = assignment_pop();
		assignment_variable->polarity = assignment_variable->value;
		assignment_variable->value = -1;

		if (!assignment_variable->in_heap) {
			heap_insert(assignment_variable);
		}
	}
	flush_unit_buffer(0);
}

static var_t *make_decision() {
	var_t *variable;
	do {
		variable = heap_delete_max();
		if (variable == NULL) return NULL;
	} while (variable->value >= 0);

	if (get_polarity_mode() == 0) {
		variable->value = variable->polarity;
	} else {
		variable->value = !variable->polarity;
	}
	variable->is_reason = 1;
	assignment_push(variable);

	return variable;
}

static int dpll() {
	var_t *variable;

	if (!propagate_units()) {
		return 0;
	}

	variable = make_decision();
	if (variable == NULL) return 1;

	while (variable != NULL) {
		// ASSIGNMENT LOOP
		while (propagate_assignment(variable)) {
			if (propagate_units()) {
				variable = make_decision();
				if (variable == NULL) return 1;
			} else {
				break;
			}
		}

		// CONFLICT HANDLING
		if (get_nof_reasons() > 0) {
			generate_conflict_clause();

			if (have_plateau(get_nof_reasons())) {
				backtrack_until(get_first_reason());

				heap_flush();

				//getchar();

				fprintf(stderr, "c RESTART\n");

				variable = make_decision();
				if (variable == NULL) return 1;
			} else {
				int conflicting_assignment;
				variable = get_last_reason();
				conflicting_assignment = variable->value;

				backtrack_until(variable);

				variable->value = !conflicting_assignment;
				variable->is_reason = 0;
				assignment_push(variable);
			}
		}

		// NO REASON, UNSAT
		else {
			return 0;
		}
	}

	return 1;
}

int main(int argc, char** argv) {
	if (argc < 2) {
		fprintf (stderr, "usage: %s <file>\n", argv[0]);
		return 1;
	}

	if (read_cnf_file (argv[1])) {
		return 1;
	}

	if (dpll()) {
		if (!validate()) {
			fprintf(stdout, "c Validation Error\n");
			fprintf(stdout, "s UNKNOWN\n");
		} else {
			fprintf(stdout, "s SATISFIABLE\n");
			print_assignment();
		}
	} else {
		fprintf(stdout, "s UNSATISFIABLE\n");
	}

	return 0;
}
