/*
 *  FastTrail.cpp
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "Trail.h"
#include <iostream>
#include <cassert>
#include <algorithm>

void Trail::pop() {
	if(_firstUnitLiteral >= _trail.size()) --_firstUnitLiteral;
	Literal lit = _trail.back();
	_assertionLevelMap[lit.index()] = 0;
	_decisionLevelMap[lit.index()] = INIT_SIZE;
	_trail.pop_back();
	if(_trail.size() == _decisions.back())
		_decisions.pop_back();
}

void Trail::push(Literal lit, bool decision) {
	assert(std::find(_trail.begin(), _trail.end(), lit) == _trail.end());
	if(decision) _decisions.push_back(_trail.size());
	_decisionLevelMap[lit.index()] = _decisions.size();
	_trail.push_back(lit);
	_assertionLevelMap[lit.index()] = _trail.size();
	++_firstUnitLiteral;
}

void Trail::enqueueUnitLiteral(Literal lit) {
	assert(std::find(_trail.begin(), _trail.end(), lit) == _trail.end());
	_decisionLevelMap[lit.index()] = _decisions.size();
	_trail.push_back(lit);
	_assertionLevelMap[lit.index()] = _trail.size();
	
}

Literal Trail::assertNextUnitLiteral() {
	assert(_firstUnitLiteral<_trail.size());
	return _trail[_firstUnitLiteral++];
}

bool Trail::hasUnitLiteral() const {
	return _firstUnitLiteral < _trail.size();
}

std::ostream &operator<<(std::ostream &stream, Trail &trail) {
	std::vector<size_t>::const_iterator dptr = trail._decisions.begin();
	for(std::vector<Literal>::iterator lp = trail._trail.begin(); lp != trail._trail.end(); ++lp) {
	  if(std::distance(trail._trail.begin(), lp) == trail._firstUnitLiteral + 1) stream << "/ ";
	  stream << lp->variable() << " ";
	}
	return stream << '0';
}
