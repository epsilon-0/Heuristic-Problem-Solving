/*
 *  Trail.h
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _FASTTRAIL_H__
#define _FASTTRAIL_H__

#include "Literal.h"
#include <vector>
#include <iosfwd>
#include <cassert>
#include <algorithm>

#include <iostream>
#define INIT_SIZE ((size_t)(-1))

class Trail {
public:
	struct Contains : public std::unary_function<Literal, bool> {
		Trail const * _trail;
		Contains(Trail const & trail) : _trail(&trail) {}
		bool operator()(Literal lit) const { return _trail->contains(lit);}
	};
	
	Trail(size_t numberOfVariables = 0) :
  _firstUnitLiteral(0),
	_decisionLevelMap(numberOfVariables, INIT_SIZE),
	_assertionLevelMap(numberOfVariables, 0)
	{}
	
	void push(Literal, bool);
	void pop();
	Literal peek() const { return _trail.back(); }
	
	size_t level(Literal lit) const { return _decisionLevelMap[lit.index()]; }
	size_t currentLevel() const { return _decisions.size(); }
	bool contains(Literal lit) const { 
	  assert(
		 (
		  _assertionLevelMap[lit.index()] != 0 &&
		  std::find(_trail.begin(), _trail.end(), lit) != _trail.end()
		  ) 
		 || 
		 (
		  _assertionLevelMap[lit.index()] == 0 &&
		  std::find(_trail.begin(), _trail.end(), lit) == _trail.end()
		  )
		 );
	  return _assertionLevelMap[lit.index()] != 0; 
	}
	
	void enqueueUnitLiteral(Literal);
	Literal assertNextUnitLiteral();
	int numberOfUnitLiterals() const { return _trail.size() - _firstUnitLiteral; }
	bool hasUnitLiteral() const;
	
	void addVariable(size_t variable) {
		while(_decisionLevelMap.size() < 2*(variable+1)) {
			_decisionLevelMap.push_back(INIT_SIZE);
			_decisionLevelMap.push_back(INIT_SIZE);
			_assertionLevelMap.push_back(0);
			_assertionLevelMap.push_back(0);
		}
	}
	std::vector<Literal>::const_reverse_iterator rbegin() const { return _trail.rbegin(); }
	std::vector<Literal>::const_reverse_iterator rend() const { return _trail.rend(); }
	void resize(size_t maxVariable) { addVariable(maxVariable); }
	size_t size() const { return _trail.size(); }
	
private:
	typedef std::vector<size_t> LevelMap;
	
	size_t _firstUnitLiteral;
	std::vector<Literal> _trail;
	std::vector<size_t> _decisions;
	LevelMap _decisionLevelMap;
	LevelMap _assertionLevelMap;
	
	friend std::ostream &operator<<(std::ostream &, Trail&);
};

#endif
