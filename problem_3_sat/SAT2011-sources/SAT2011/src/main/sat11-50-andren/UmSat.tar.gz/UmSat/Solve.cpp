/*
 *  Solve.cpp
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-07.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "Solve.h"
#include "Trail.h"
#include "Clauses.h"
#include "Policies.h"
#include "Conflict.h"
#include "Constraint.h"
#include "Listeners.h"
#include "ConstraintManager.h"
#include "ReasonManager.h"

#include <iterator>

#ifndef NDEBUG
#define DEBUG 0
#endif

Solve::Solve(Trail &trail, ConstraintManager &cm, ReasonManager &reasons) :
  _sat_flag(UNKNOWN),
  _trail(trail),
  _watches(cm),
  _reasons(reasons),
  _conflictHandler(_trail, cm, _reasons, _listeners),
  _conflict(0),
  _literalSelectionPolicy(new LiteralSelectionPolicy),
  _restartPolicy(new RestartPolicy),
  _forgetPolicy(new ForgetPolicy),
  _stopPolicy(new StopPolicy)
{
  _reasons.resize(_watches.maxVariable());
}

Solve::Answer Solve::solve() {
  for(std::vector<Listeners *>::const_iterator lip = _listeners.begin(); lip != _listeners.end(); ++lip) {
    (*lip)->init();
  }
	
  while(_sat_flag == UNKNOWN) {
    do{
      applyExhaustiveUnitPropagation();
      checkSymmetry();
    } while(_trail.hasUnitLiteral() && !isConflict());
    if(isConflict()) {
      Reason res;
      _conflict->reason(res);
      applyConflictHandling();
    } else {
      if(_literalSelectionPolicy->done()) {
	_sat_flag = SAT;
      } else if(_restartPolicy->restart()) {
	applyRestart();
      } else if(_forgetPolicy->forget()) {
	applyForget();
      } else if(_stopPolicy->stop()) {
	backtrackToLevel(0);
	return _sat_flag;
      } else {
	applyDecide();
      }
    }
  }
  return _sat_flag;
}

void Solve::applyExhaustiveUnitPropagation() {
  bool ret(true);
  while (ret && !isConflict()) {
    ret = applyUnitPropagation();
  }
}

void Solve::applyConflictHandling() {
  if(_trail.currentLevel() == 0) {
    _sat_flag = UNSAT;
  } else {
    for(std::vector<Listeners *>::const_iterator lip = _listeners.begin(); lip != _listeners.end(); ++lip) {
      (*lip)->onConflict(_conflict);
    }
    LearntClause2 *reason = _conflictHandler.handleConflict(_conflict);
    applyBackjump(reason);
  }
}

void Solve::applyRestart() {
  for(std::vector<Listeners *>::const_iterator lip = _listeners.begin(); lip != _listeners.end(); ++lip) {
    (*lip)->onRestart();
  }
  backtrackToLevel(0);
}

void Solve::applyForget() {
  ConstraintManager::iterator mid = _forgetPolicy->select(_watches.begin(), _watches.end());
  _watches.removeFrom(mid);
}

void Solve::applyDecide() {
  Literal lit = _literalSelectionPolicy->select();
  _reasons.setReason(lit, 0);
  for(std::vector<Listeners *>::const_iterator lip = _listeners.begin(); lip != _listeners.end(); ++lip) {
    (*lip)->onDecide(lit);
  }
  assertLiteral(lit, true);
}

//=============================================================

bool Solve::applyUnitPropagation() {
  if(!_trail.hasUnitLiteral()) return false;
	
  Literal lit = _trail.assertNextUnitLiteral();
  for(std::vector<Listeners *>::const_iterator lip = _listeners.begin(); lip != _listeners.end(); ++lip) {
    (*lip)->onPropagation(_reasons.getReason(lit), lit);
    (*lip)->onAssert(lit);		
  }
  _conflict = _watches.notify(lit);
  return true;
}

void Solve::assertLiteral(Literal lit, bool decision) {
  _trail.push(lit, decision);
  for(std::vector<Listeners *>::const_iterator lip = _listeners.begin(); lip != _listeners.end(); ++lip) {
    (*lip)->onAssert(lit);
  }
  _conflict = _watches.notify(lit);
}

void Solve::applyBackjump(LearntClause2 *reason) {
  Literal clit = reason->conflictLiteral();
  Literal blit = reason->backtrackLiteral();
  size_t blevel = blit == Literal(0) ? 0 : _trail.level(blit.opposite());
  backtrackToLevel(blevel);
  _conflict = 0;
  _reasons.setReason(clit, reason);
  assertLiteral(clit, false);
}

//==============================================================

void Solve::backtrackToLevel(size_t level) {
  while(_trail.currentLevel() > level)
    backtrack();
}

void Solve::backtrack() {
  Literal lit = _trail.peek();
  _trail.pop();
  _reasons.setReason(lit, 0);
  for(std::vector<Listeners *>::const_iterator lip = _listeners.begin(); lip != _listeners.end(); ++lip) {
    (*lip)->onBacktrack(lit);
  }
}

//==============================================================

void Solve::checkSymmetry() {
  
}

