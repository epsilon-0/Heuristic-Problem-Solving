/*
 *  ConstraintManager.cpp
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-31.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "ConstraintManager.h"
#include "ReasonManager.h"
#include "Constraint.h"
#include "Clauses.h"

Constraint::Result ConstraintManager::add(Constraint *cons) {
	if(cons->maxVariable() > _maxVariable) {
		_maxVariable = cons->maxVariable();
		_trail.resize(_maxVariable);
		_reasons.resize(_maxVariable);
		_watches.resize(2*(_maxVariable+1));
	}
	Constraint::Result res = cons->simplify(_trail, *this);
	if(res == Constraint::keep) {
		++_numberOfConstraints;
		cons->add(*this);
	}
	return res;
}

void ConstraintManager::learn(LearntClause2 *cons) {
	cons->add(*this);
	_learntClauses.push_back(cons);
}

void ConstraintManager::forget(LearntClause2 *cons) {
	cons->remove2(*this);
	delete cons;
	_learntClauses.erase(std::find(_learntClauses.begin(), _learntClauses.end(), cons));
}

void ConstraintManager::removeFrom(iterator mid) {
  for(iterator cons(mid);cons != _learntClauses.end(); ++cons) {
    (*cons)->remove2(*this);
    delete *cons;
  }
  _learntClauses.erase(mid, _learntClauses.end());
}

Constraint *ConstraintManager::notify(Literal lit) {
	Constraint *conflict(0);
	_notefying = true;
	_lit = lit;
	WatchList::iterator begin(_watches[lit.index()].begin());
	WatchList::iterator cons(begin);
	WatchList::iterator mid(begin);
	WatchList::iterator end(_watches[lit.index()].end());
	
	while (cons != end) {
		Constraint::Result res = (*cons)->propagate(lit, _trail, _reasons, *this);
		__builtin_prefetch(*(cons+1), 0, 1);
		if(res == Constraint::keep) {
			*mid = *cons; ++mid;
		} else if(res == Constraint::conflict) { 
			conflict = *cons; break;
		}
		++cons;
	}
	while(cons != end) { *mid++ = *cons++; }
	WatchList::iterator begin2(_watches[lit.index()].begin());	
	std::ptrdiff_t d = std::distance(begin, mid);
	assert(begin == begin2);
	_watches[lit.index()].resize(d);
	_notefying = false;
	_lit = 0;
	return conflict;
}
