/*
 *  Literal.h
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-07.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _LIERAL_H__
#define _LIERAL_H__

#include <cstdlib>
#include <vector>
#include <iosfwd>
#include <functional>

typedef int Variable;

class Literal {
public:
	struct Opposite : public std::unary_function<Literal, Literal> {
		Literal operator()(Literal lit) { return lit.opposite(); }
	};
	Literal(Variable var) : _literal(var < 0 ? (abs(var)<<1)|0x1 : (abs(var)<<1)) {}
	Literal(unsigned int literal, int) : _literal(literal) {}
	Literal() : _literal(0) {}
	Literal opposite() const { return Literal(_literal^0x1, 0); }
	Variable variable() const { return (1 - 2*(_literal & 0x1)) * (_literal >> 1); }
	Variable absVariable() const { return _literal >> 1; }
	unsigned int index() const { return _literal; }
	bool operator==(Literal right) const { return _literal == right._literal; }
	bool operator!=(Literal right) const { return _literal != right._literal; }
	bool operator<(Literal right) const { return _literal < right._literal; }
	
	struct FromVariable : public std::unary_function<Literal, Variable> {
		Literal operator()(Variable var) { return Literal(var); }
	};
	struct VariableLessThan : public std::binary_function<bool, Literal, Literal> {
	  bool operator()(Literal l1, Literal l2) { return l1.absVariable() < l2.absVariable(); }
	};

private:
	unsigned int _literal;
};

//typedef std::vector<Literal> Reason;

class Reason : public std::vector<Literal>{};

std::ostream& operator<<(std::ostream& s, const Reason& r);

std::ostream& operator<<(std::ostream& s, const Literal& l);

#endif
