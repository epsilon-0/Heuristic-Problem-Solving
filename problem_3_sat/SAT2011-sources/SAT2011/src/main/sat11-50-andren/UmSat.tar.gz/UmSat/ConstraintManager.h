/*
 *  ConstraintManager.h
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-31.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _CONSTRAINTMANAGER_H__
#define _CONSTRAINTMANAGER_H__

#include "Literal.h"
#include "Constraint.h"
#include <map>
#include <vector>
#include <algorithm>
#include <cassert>

class Constraint;
class Trail;
class LearntClause2;
class ReasonManager;

class ConstraintManager {
private:
	typedef std::vector<Constraint*> WatchList;
	typedef std::vector<WatchList> WatchMap;
public:
	typedef std::vector<LearntClause2*>::iterator iterator;

	ConstraintManager(Trail &trail, ReasonManager &reasons) 
	:
	_numberOfConstraints(0),
	_maxVariable(0),
	_notefying(false),
	_lit(0),
	_trail(trail),
	_reasons(reasons)
	{}
	~ConstraintManager() {
	  removeFrom(_learntClauses.begin());
	}
	void setWatch(Literal const lit, Constraint *cons) {
		assert(!_notefying || lit != _lit);
		_watches[lit.index()].push_back(cons);
	}
	void removeWatch(Literal lit, Constraint *cons) {
		_watches[lit.index()].erase(std::find(_watches[lit.index()].begin(), _watches[lit.index()].end(), cons));
	}
	
	Constraint *notify(Literal);
	
	Constraint::Result add(Constraint *cons);
	
	void learn(LearntClause2 *);
	void forget(LearntClause2 *);
	void removeFrom(iterator);
		
	iterator begin() { return _learntClauses.begin(); }
	iterator end() { return _learntClauses.end(); }
	
	size_t numberOfInitialConstraints() const { return _numberOfConstraints; }
	size_t numberOfLearntConstraints() const { return _learntClauses.size(); }
	size_t maxVariable() const { return _maxVariable; }
	
private:
	size_t _numberOfConstraints;
	size_t _maxVariable;
	bool _notefying;
	Literal _lit;
	
	ReasonManager &_reasons;
	Trail &_trail;

	std::vector<LearntClause2*> _learntClauses;
	WatchMap _watches;
};


#endif
