/*
 *  Constraint.h
 *  UmSATii
 *
 *  Created by Daniel Andrén on 2010-05-07.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _CONSTRAINT_H__
#define _CONSTRAINT_H__

#include "Literal.h"
class Trail;
class ReasonManager;
class ConstraintManager;

class Constraint {
public:
	enum Result {skip = 0, OK, conflict, keep};
	virtual void reason(Reason &) const = 0;
	virtual size_t size() const = 0;
	virtual void add(ConstraintManager &) {};
	virtual void remove2(ConstraintManager &) {};
	virtual size_t maxVariable() const { return 0; };
	virtual Result propagate(Literal, Trail &, ReasonManager &, ConstraintManager &) {
		return skip;
	}
	virtual Result simplify(Trail &, ConstraintManager &) = 0;
	virtual bool satisfied(Trail const &) = 0;
	virtual ~Constraint() {};
protected:
	virtual std::ostream &doPrint(std::ostream &s) const = 0;
	friend std::ostream &operator<<(std::ostream &s, Constraint const *c) {
		c->doPrint(s);
		return s;
	}
};

#endif
