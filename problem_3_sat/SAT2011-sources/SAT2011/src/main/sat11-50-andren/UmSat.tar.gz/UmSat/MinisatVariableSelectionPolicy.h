/*
 *  MinisatVariableSelectionPolicy.h
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-12.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _MINISATVARIABLESELECTIONPOLICY_H__
#define _MINISATVARIABLESELECTIONPOLICY_H__ 1

#include "PhaseSelectionPolicy.h"
#include "Constraint.h"
#include <vector>
class Trail;

class MinisatVariableSelectionPolicy : public Listeners, public VariableSelectionPolicy {
 public:
  MinisatVariableSelectionPolicy(Trail&, size_t);
  /*
 MinisatVariableSelectionPolicy(Trail &trail, size_t numberOfVariables) :
  _max_activity(100000.0),
    _activities(numberOfVariables+1, 0.0),
    _numberOfVariables(numberOfVariables),
    _bumpAmount(1.0),
    _decayFactor(1.0/0.95),
    _variableCounter(0),
    _trail(trail)
    {_activities.at(0) = -1.0; }
  */
 public: // Variable selection policy
  virtual bool done() { return _variableCounter >= _numberOfVariables; };
  virtual Variable select();
  
 public: // Listener
  virtual void onConflict(Constraint *con) {
    Reason reason;
    con->reason(reason);
    bumpVariableInReason(reason); decay(); 
  }
  virtual void onExplain(Literal, Reason &res) { bumpVariableInReason(res); }
  virtual void onAssert(Literal);
  virtual void onBacktrack(Literal);
 private:
  typedef std::vector<double> ActivityMap;
  void decay();
  void bumpVariableInReason(Reason const&);
  void rescale();
  
  const double _max_activity;
  ActivityMap _activities;
  Variable _selectedVariable;
  size_t _numberOfVariables;
  double _bumpAmount;
  double _decayFactor;
  int _variableCounter;
  Trail &_trail;
};

#endif
