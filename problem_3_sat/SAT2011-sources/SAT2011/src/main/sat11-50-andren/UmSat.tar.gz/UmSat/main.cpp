#include "Reader.h"
#include "ConstraintManager.h"
#include "ReasonManager.h"
#include "Trail.h"
#include "Solve.h"

#include "PhaseSelectionPolicy.h"
#include "MinisatRestartPolicy.h"
#include "MinisatVariableSelectionPolicy.h"
#include "MinisatForgetPolicy.h"

#include <iostream>
#include <iterator>
#include <fstream>
#include <ctime>

struct Unsatisfied : public std::unary_function<Constraint *, bool> {
  Unsatisfied(Trail const &T) : T_(T) {}
  bool operator()(Constraint *c) { return !c->satisfied(T_); }
  Trail const & T_;
};

int main (int argc, char * const argv[]) {
  Trail trail;
  ReasonManager rm;
  ConstraintManager cm(trail, rm);
  std::vector<Constraint *> constraints;
	
  for(int i = 1; i < argc; ++i) {
    std::ifstream infile(argv[i]);
    Reader reader(infile);
    TypeProblemPair pprob(reader.read());
    for(PreProblem::const_iterator cp = pprob.begin(); cp != pprob.end(); ++cp) {
      Reason reason;
      std::transform(cp->begin(), cp->end(), std::back_inserter(reason), Literal::FromVariable());
      Constraint *constraint(0);
      if(pprob.type() == "cnf" ) {
	std::random_shuffle(reason.begin(), reason.end());
	if(reason.size() >= 2) {
	  constraint = new LearntClause2(reason, cp->at(0), cp->at(1));
	} else {
	  constraint = new LearntClause2(reason, cp->at(0), cp->at(0));
	}
      }
			
      if(constraint && cm.add(constraint) != Constraint::keep) {
	delete constraint;
      } else {
	constraints.push_back(constraint);
      }

    }
  }

  Solve solver(trail, cm, rm);
	
  MinisatVariableSelectionPolicy mvsp(trail, cm.maxVariable());
  PhaseSelectionPolicy psp(cm.maxVariable(), mvsp, PhaseSelectionPolicy::Saved);
  delete solver.setLiteralSelectionPolicy(&psp);
  solver.addListener(&mvsp);
  solver.addListener(&psp);

  MinisatRestartPolicy minisatR;
  delete solver.setRestartPolicy(&minisatR);
  solver.addListener(&minisatR);
	
  MinisatForgetPolicy mfp(cm, rm);
  delete solver.setForgetPolicy(&mfp);
  solver.addListener(&mfp);

  Solve::Answer a = solver.solve();

  if(a == Solve::SAT) {
    std::cout << "s SATISFIABLE" << std::endl;
    std::cout << "v " << trail << std::endl;
  }
  else if(a == Solve::UNSAT) {
    std::cout << "s UNSATISFIABLE" << std::endl;
  }
  else {
    std::cout << "s UNKNOWN" << std::endl;
  }

  for(std::vector<Constraint *>::iterator cons = constraints.begin(); cons != constraints.end(); ++cons) {
    delete *cons;
  }

  return 0;
}
