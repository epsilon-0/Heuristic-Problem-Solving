/*
 *  Conflict.h
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-07.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _CONFLICT_H__
#define _CONFLICT_H__

#include "Literal.h"
#include <vector>

class Trail;
class ConstraintManager;
class Listeners;
class LearntClause2;
class ReasonManager;
class Constraint;

class Conflict {
public:	
	Conflict(Trail &, ConstraintManager &, ReasonManager &, std::vector<Listeners*> &);
	LearntClause2 *handleConflict(Constraint *);
private:
	void applyExplainUIP();
	void applySubsumption();

	void applyExplain();
	bool subsumes(Reason const &);
	void resolve(Literal, Reason const &);
	bool isUIP();
	LearntClause2 *buildConflictClause();
	
	Literal lastAssertedLiteral();
	void add(Literal);
	void del(Literal);
	
	size_t _currentLevelLiterals;
	size_t _currentLevel;
	std::vector<bool> _literals;
	Reason _reason;
	Reason _currentLevelLiteralsVector;
	Trail &_trail;
	ConstraintManager &_cm;
	ReasonManager &_reasons;
	std::vector<Listeners*> &_listeners;
};
#endif
