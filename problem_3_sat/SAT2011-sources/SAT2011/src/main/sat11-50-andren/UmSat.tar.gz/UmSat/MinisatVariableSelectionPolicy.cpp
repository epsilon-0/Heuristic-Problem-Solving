/*
 *  MinisatVariableSelectionPolicy.cpp
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-12.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "MinisatVariableSelectionPolicy.h"
#include "Literal.h"
#include "Trail.h"

#include <iostream>
#include <iterator>
#include <cstdlib>

void MinisatVariableSelectionPolicy::onAssert(Literal l) {
  ++_variableCounter; 
}
void MinisatVariableSelectionPolicy::onBacktrack(Literal l) { 
  --_variableCounter; 
}

Variable MinisatVariableSelectionPolicy::select() {
  assert(!_trail.hasUnitLiteral());
  ActivityMap::iterator ai(_activities.begin()), ma;
  ma = ai;
  ++ai;
  for(; ai != _activities.end(); ++ai) {
    if(*ma < *ai) {
      int i = std::distance(_activities.begin(),ai);
      Literal lit(i<<1,0);
      if(!_trail.contains(lit) && !_trail.contains(lit.opposite()))
	{
	  ma = ai;
	}
    }
  }
  return std::distance(_activities.begin(), ma);
}

void MinisatVariableSelectionPolicy::decay() {
	_bumpAmount *= _decayFactor;
}

void MinisatVariableSelectionPolicy::rescale() {
	_bumpAmount *= 1.0/_max_activity;
	ActivityMap::iterator vp = _activities.begin();
	++vp;
	for(;vp != _activities.end(); ++vp) {
		(*vp) *= 1.0/_max_activity;
	}
}

void MinisatVariableSelectionPolicy::bumpVariableInReason(Reason const& reason) {
  Reason::const_iterator litp = reason.begin();
  for(;litp != reason.end(); ++litp) {
    Variable var = litp->absVariable();
    _activities[var] += _bumpAmount;
    if(_activities[var] > _max_activity) rescale();
  }
}


struct RandomNumber {
  RandomNumber(unsigned int seed) { std::srand(seed); }
  double operator()() { return (std::rand() % 1000)/10000000.0; }
};

MinisatVariableSelectionPolicy::MinisatVariableSelectionPolicy(Trail &trail, size_t numberOfVariables) :
  _max_activity(100000.0),
  _activities(numberOfVariables+1, 0.0),
  _numberOfVariables(numberOfVariables),
  _bumpAmount(1.0),
  _decayFactor(1.0/0.95),
  _variableCounter(0),
  _trail(trail)
{
  std::generate(_activities.begin(), _activities.end(), RandomNumber(1234));
  _activities.at(0) = -1.0;
}
