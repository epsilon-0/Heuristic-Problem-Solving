/*
 *  Conflict.cpp
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-07.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "Conflict.h"
#include "Literal.h"
#include "Trail.h"
#include "ReasonManager.h"
#include "Clauses.h"
#include "Listeners.h"
#include "ConstraintManager.h"
#include <algorithm>

#include <iterator>

#ifndef NDEBUG
#define DEBUG 0
#endif

void printReason(Reason const & res) {
	std::copy(res.begin(), res.end(), std::ostream_iterator<Literal>(std::cerr, " "));
}

Conflict::Conflict(Trail &trail, ConstraintManager &cm, ReasonManager &rm, std::vector<Listeners*> &listeners) :
_literals(2*(cm.maxVariable()+1), false),
_trail(trail),
_cm(cm),
_reasons(rm),
_listeners(listeners)
{}

LearntClause2 *Conflict::handleConflict(Constraint *cons) {
	assert(_literals == std::vector<bool>(2*(_cm.maxVariable()+1), false));
	Reason reason;
	reason.reserve(20);
	cons->reason(reason);
	_reason.clear();
	_currentLevelLiterals = 0;
	_currentLevel = _trail.currentLevel();
	for(Reason::const_iterator lp = reason.begin(); lp != reason.end(); ++lp)
		add(*lp);
	assert(_currentLevelLiterals + _reason.size() == reason.size());
	applyExplainUIP();
	assert(_currentLevelLiterals == 1);
	assert(std::count_if(_reason.begin(), _reason.end(), Trail::Contains(_trail)) == _reason.size() || 
		   (std::cerr << _trail << "\n" << std::count_if(_reason.begin(), _reason.end(), Trail::Contains(_trail)) << "\n" 
			<< _reason.size() << std::endl && (printReason(_reason), false)));		
	applySubsumption();
	LearntClause2 *lc = buildConflictClause();
	for(std::vector<Listeners *>::const_iterator lip = _listeners.begin(); lip != _listeners.end(); ++lip) {
		(*lip)->onLearn(lc);
	}
	//std::cerr << "Learn: " << *lc << std::endl;
	_cm.learn(lc);
	return lc;
}

void Conflict::applyExplainUIP() {
	while (!isUIP()) {
		applyExplain();
	}
}

void Conflict::applyExplain() {
	Literal lit = lastAssertedLiteral();
	Constraint* con = _reasons.getReason(lit);
	Reason reason;
	con->reason(reason);
	for(std::vector<Listeners*>::const_iterator lp = _listeners.begin(); lp != _listeners.end(); ++lp)
		(*lp)->onExplain(lit, reason);
	resolve(lit, reason);
}

void Conflict::resolve(Literal lit, Reason const & reason) {
	del(lit);
	for(Reason::const_iterator lp = reason.begin(); lp != reason.end(); ++lp)
		if(lit.opposite() != *lp && _literals[lp->index()] == false)
			add(*lp);
}

void Conflict::applySubsumption() {
	Reason marked_litterals;
	for(Reason::const_iterator lptr = _reason.begin(); lptr != _reason.end(); ++lptr) {
		Constraint const* clause = _reasons.getReason(lptr->opposite());
		if(clause != 0) {
			Reason reason;
			clause->reason(reason);
			if(subsumes(reason)) {
				marked_litterals.push_back(*lptr);
			}
		}
	}
	for(Reason::const_iterator lptr = marked_litterals.begin(); lptr != marked_litterals.end(); ++lptr) {
		_reason.erase(std::find(_reason.begin(), _reason.end(), *lptr));
	}
}

bool Conflict::subsumes(Reason const & reason) {
	for (Reason::const_iterator lptr = reason.begin(); lptr != reason.end(); ++lptr) {
		if(std::find(_reason.begin(), _reason.end(), *lptr) == _reason.end()) return false; 
	}
	return true;
}

struct Literals : public std::unary_function<Literal, bool> {
	Literals(std::vector<bool> const & literals) : _literals(literals) {}
	bool operator()(Literal l) { return _literals[l.index()]; }
	std::vector<bool> const & _literals;
};

LearntClause2 *Conflict::buildConflictClause() {
	Literal w0 = lastAssertedLiteral();
	del(w0);
	w0 = w0.opposite();
	Literal w1 = Literal(0);
	if(_reason.size() > 0) w1 = std::find_if(_trail.rbegin(), _trail.rend(), Literals(_literals))->opposite();
	for(Reason::iterator litp = _reason.begin(); litp != _reason.end(); ++litp) {
		assert(_literals[litp->index()] == true);
		del(*litp);
		*litp = litp->opposite();
	}
	_reason.push_back(w0);
	assert(_literals == std::vector<bool>(_literals.size(), false));
	LearntClause2 *lc = new LearntClause2(_reason, w0, w1, true);
	return lc;
}

Literal Conflict::lastAssertedLiteral() {
	while(_literals[_trail.peek().index()] == false) {
	  Literal lit = _trail.peek();
	  if(!_trail.hasUnitLiteral())
	    for(std::vector<Listeners *>::const_iterator lip = _listeners.begin();
		lip != _listeners.end();
		++lip) {
	      (*lip)->onBacktrack(lit);
	    }
	  _reasons.setReason(lit, 0);
	  _trail.pop();
	}
	//std::cerr << "lAl " << _trail.peek() << std::endl;
	return _trail.peek();
}

inline
bool Conflict::isUIP() {
	return _currentLevelLiterals == 1; 
}

inline
void Conflict::add(Literal lit) {
	//std::cerr << "add " << lit << std::endl;
	_literals[lit.index()] = true;
	assert(_literals[lit.opposite().index()] == false);
	if(_trail.level(lit) == _currentLevel) {
		++_currentLevelLiterals;
		_currentLevelLiteralsVector.push_back(lit);
	} else {
		_reason.push_back(lit);
	}
}

void Conflict::del(Literal lit) {
	//std::cerr << "del " << lit << std::endl;
	_literals[lit.index()] = false;
	if(_trail.level(lit) == _currentLevel) {
		--_currentLevelLiterals;
		_currentLevelLiteralsVector.erase(std::find(_currentLevelLiteralsVector.begin(), _currentLevelLiteralsVector.end(), lit));
	}
}
