/*
 *  Clauses.h
 *  UmSATiii
 *
 *  Created by Daniel Andrén on 2010-05-11.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _CLAUSES_H__
#define _CLAUSES_H__ 1

#include "Constraint.h"
#include "Trail.h"

#include "ReasonManager.h"
#include "ConstraintManager.h"
#include <functional>
#include <cassert>

class InitialClauseConstraints;
class LearntClauseConstraints;

class LearntClause2 : public Constraint {
private:
	struct GreaterAbsLiteral : public std::binary_function<Literal, Literal, bool> {
		bool operator()(Literal a, Literal b) const { return a.absVariable() < b.absVariable(); }
	};
	struct NewWatch : public std::unary_function<Literal, bool> {
		NewWatch(Trail &trail, Literal w0, Literal w1) : _trail(trail), _w0(w0), _w1(w1) {}
		bool operator()(Literal const lit) {
			return lit != _w0 &&
			lit != _w1 &&
			!_trail.contains(lit.opposite());
		}
		Trail const &_trail;
		Literal const _w0;
		Literal const _w1;
	};
public:
	LearntClause2(Reason &res, Literal w0, Literal w1, bool isLearnt = false) : _activity(0.0), _isLearnt(isLearnt), _w0(w0), _w1(w1) {
		_literals.swap(res);
	}
	virtual void reason(Reason &reason_) const { std::transform(_literals.begin(), _literals.end(), std::back_inserter(reason_), Literal::Opposite());}
	virtual size_t size() const { return _literals.size(); }
	virtual size_t maxVariable() const { return std::max_element(_literals.begin(), _literals.end(), GreaterAbsLiteral())->absVariable(); }
	virtual void add(ConstraintManager &cm) {
		cm.setWatch(_w0.opposite(), this);
		cm.setWatch(_w1.opposite(), this);
	}
	virtual void remove2(ConstraintManager &cm) {
		cm.removeWatch(_w0.opposite(), this);
		cm.removeWatch(_w1.opposite(), this);
	}
	virtual Result propagate(Literal lit, Trail &trail, ReasonManager &rm, ConstraintManager &cm) {
		if(lit.opposite() == _w0) {
			std::swap(_w0, _w1);
		}
		
		const Literal w0(_w0);
		const Literal w1(_w1);
		
		if(trail.contains(w0)){
			return keep;
		}
		
		std::vector<Literal>::const_iterator lip = std::find_if(_literals.begin(), _literals.end(), NewWatch(trail, w0, w1));
		if(lip != _literals.end()) {
			_w1 = *lip;
			cm.setWatch(_w1.opposite(), this);
			return skip;
		} else if(trail.contains(w0.opposite())) {
			return conflict;
		} else {
			trail.enqueueUnitLiteral(w0);
			rm.setReason(w0, this);
			return keep;
		}
	}
	virtual Constraint::Result simplify(Trail &, ConstraintManager &);
	virtual bool satisfied(Trail const &);

	bool isReason(ReasonManager const & rm) const {
		return rm.getReason(_w0) == this || rm.getReason(_w1) == this;
	}
	bool isLearnt() const { return _isLearnt; }
	
	Literal conflictLiteral() const { return _w0; }
	Literal backtrackLiteral() const { return _w1; }
	Reason::const_iterator begin() const { return _literals.begin(); }
	Reason::const_iterator end() const { return _literals.end(); }
	double const & activity() const { return _activity; }
	double & activity() { return _activity; }
	
	friend std::ostream &operator<<(std::ostream&, LearntClause2 const &);
private:
	virtual std::ostream & doPrint(std::ostream &s) const { return (s << *this); }
	double _activity;
	const bool _isLearnt;
	Literal _w0, _w1;
	std::vector<Literal> _literals;
};

bool add_Clause(std::vector<int> preLiterals, Trail &trail, ConstraintManager &cm);
#endif
