
`./ubcsat $1 $2 $3 ; pkill sleep`
echo "HOLA"
