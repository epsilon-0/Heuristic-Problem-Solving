/*
	waitfunc.hh
	This file is part of riss.
	
	25.05.2009
	Copyright 2009 Norbert Manthey
*/

#ifndef __WAITFUNC
#define __WAITFUNC

#include <iostream>

bool isAdressContentZero( volatile void* adress );

#endif
