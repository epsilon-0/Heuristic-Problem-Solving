#include <stdio.h>
#include <stdlib.h>
#include "Multiflip.h"

extern int NB_VAR;     // var #
extern int NB_CLAUSE;  // clause #
extern my_type *clause_state;
extern my_type *clause_length;

extern int **sat;
extern my_type *var_state;

extern int MY_CLAUSE_STACK_fill_pointer;
extern int *neg_nb;
extern int *pos_nb;
extern int **neg_in;
extern int **pos_in;

extern my_type *var_value;
// (A V B)(A V B V C) => A V B 
my_type redundant(int *new_clause, int *old_clause)
{
  int lit1, lit2, old_clause_diff=0, new_clause_diff=0;
    
  lit1=*old_clause; lit2=*new_clause;
  while ((lit1 != 0) && (lit2 != 0)) {
      if ( ABS(lit1) < ABS(lit2) ) {
          lit1=*(++old_clause); old_clause_diff++;
	  }
      else
      if ( ABS(lit2) < ABS(lit1) ) {
        	lit2=*(++new_clause); new_clause_diff++;
  	  }
      else
	     if ( lit1==-lit2 ) return FALSE; // old_clause_diff++; new_clause_diff++; j1++; j2++; 
	     else {
             lit1=*(++old_clause);  lit2=*(++new_clause);
		 }
  }
  if ((lit1 == 0) && (old_clause_diff == 0)) return NEW_CLAUSE_REDUNDANT; 
  if ((lit2 == 0) && (new_clause_diff == 0)) return OLD_CLAUSE_REDUNDANT; 
  return FALSE;
}

void remove_passive_clauses() 
{
  int clause, put_in;
 
  for(clause=0; clause<NB_CLAUSE; clause++) 
      if (clause_state[clause]==PASSIVE) free(sat[clause]);
	  
  for(put_in=clause=0; clause<NB_CLAUSE; clause++) {
      if (clause_state[clause]==ACTIVE) {
            sat[put_in]=sat[clause]; 
		    clause_state[put_in]=ACTIVE; 
	        clause_length[put_in]=clause_length[clause];
	        put_in++;
	  }
  }
  NB_CLAUSE=put_in;
}

void remove_passive_vars_in_clause(int clause) 
{
    int *lits, *newlit;
	int len=0;
	for(newlit=lits=sat[clause]; *lits; lits++){
	    if(var_value[ABS(*lits)]) continue;
        *newlit++=*lits;
		len++;
	}
	clause_length[clause]=len;
	*newlit=0;
}

int clean_structure()
{
  int clause, var, NB_ACTIVE_VAR;
  
  remove_passive_clauses();
  if (NB_CLAUSE==0)  return SATISFIABLE;
  for (clause=0; clause<NB_CLAUSE; clause++) remove_passive_vars_in_clause(clause);
  
  NB_ACTIVE_VAR=0;
  for (var=1; var<=NB_VAR; var++) { 
       neg_nb[var] = pos_nb[var] = 0;
       if (var_value[var]==0) NB_ACTIVE_VAR++;
  }
  for (clause=0; clause<NB_CLAUSE; clause++) {
     for(int *lits=sat[clause]; *lits; lits++){
		  int var=ABS(*lits);
          if (*lits>0) pos_in[var][pos_nb[var]++]=clause;
          else  neg_in[var][neg_nb[var]++]=clause;
	  }
  }
  for (var=1; var<=NB_VAR; var++) { 
      neg_in[var][neg_nb[var]]=NOnum;
      pos_in[var][pos_nb[var]]=NOnum;
  }
  return TRUE;
}

int unitclause_process();
void allocMem();

int read_clauses(char *input_file)
{
  int i, j, jj, ii, length, tautologie, *lits, lit, lit1,lsize;
  char ch, word2[WORD_LENGTH],rc;
  
  FILE* fp_in=fopen(input_file, "r");
  if (fp_in == NULL) return FALSE;
  
  char prech='\n';
  while(1){
      rc=fscanf(fp_in, "%c", &ch);
      if(ch=='p' && prech=='\n') break;
	  prech=ch;
  }
  rc=fscanf(fp_in, "%s%d%d", word2, &NB_VAR, &NB_CLAUSE);
  printf("c var#=%d clause#=%d \n",NB_VAR, NB_CLAUSE);

  allocMem();
  lsize=64;
  lits= (int *)malloc(lsize* sizeof(int));
  for (i=0; i<NB_CLAUSE; i++) {
      length=0; 
      rc=fscanf(fp_in, "%d", lits+length);
      while (lits[length] != 0) {
         length++;
		 if(lsize<=length){
              lsize=2*lsize;
			  lits=(int*) realloc(lits, lsize* sizeof(int));
		 }
         if (fscanf(fp_in, "%d", lits+length)==EOF) {
	         fprintf(stdout, "c error in the input file\n");
             goto false_ret;
		 }
	  }
      tautologie = FALSE;
    /* test if some literals are redundant and sort the clause */
      for (ii=0; ii<length-1; ii++) {
        lit = lits[ii];
        for (jj=ii+1; jj<length; jj++) {// find min
	       if (abs(lit)>abs(lits[jj])) {
	           lit1=lits[jj]; lits[jj]=lit; lit=lit1;
		   }
	       else
	          if (lit == lits[jj]) {
	              lits[jj] = lits[length-1]; 
	              jj--; length--; lits[length] = 0;
	              printf("c literal %d is redundant in clause %d \n", lit, i+1);
			  }
	          else
                 if (abs(lit) == abs(lits[jj])) tautologie = TRUE; break;
		}
        if (tautologie == TRUE) break;
        lits[ii] = lit;
	  }
      if (tautologie == FALSE) {
           sat[i]= (int *)malloc((length+1) * sizeof(int));
           for (j=0; j<=length; j++) sat[i][j]=lits[j];
           clause_length[i]=length;
           clause_state[i] = ACTIVE;
	  }
      else { i--; NB_CLAUSE--;}
  }
  fclose(fp_in);
  free(lits);
//  printf("c lsize=%d \n",lsize);
  return TRUE;
false_ret:  
  free(lits);
  fclose(fp_in);
  return FALSE;
}

void build_structure()
{
  int i, j, var, *lits1, lit;

  for (i=0; i<=NB_VAR; i++) neg_nb[i] =pos_nb[i] = 0;
  for (i=0; i<NB_CLAUSE; i++) {
      for(j=0; j<clause_length[i]; j++) {
	       var=sat[i][j]; 
		   if (var<0) neg_nb[-var]++;    //negative literal
		   else  pos_nb[var]++;    	   //positive literal
	  }
      if (sat[i][clause_length[i]]!=0) printf("c data structure error \n");
  }
  for (i=1; i<=NB_VAR; i++) { 
      neg_in[i] = (int *)malloc((neg_nb[i]+1) * sizeof(int));
      pos_in[i] = (int *)malloc((pos_nb[i]+1) * sizeof(int));
      neg_in[i][neg_nb[i]]=pos_in[i][pos_nb[i]]=NOnum;
      neg_nb[i] = pos_nb[i] = 0;
      var_value[i]=0;
	  var_state[i] = ACTIVE;
 
  }   
  for (i=0; i<NB_CLAUSE; i++) {
    lits1 = sat[i];
    for(lit=*lits1; lit; lit=*(++lits1)) {
      if (lit>0) pos_in[lit][pos_nb[lit]++] = i;
      else	neg_in[-lit][neg_nb[-lit]++] = i;
    }
  }
}

void pushunitclause(int clause); 

void eliminate_redundance()
{
  int *lits, i, lit, *clauses, res=0, clause;

  for (i=0; i<NB_CLAUSE; i++)
  {
      if (clause_state[i]==ACTIVE) {
          if (clause_length[i]==1) pushunitclause(i);

          lits = sat[i];
          for(lit=*lits; lit; lit=*(++lits)) {
	          if(lit>0) clauses=pos_in[lit];
	          else clauses=neg_in[-lit];
	          for(clause=*clauses; clause!=NOnum; clause=*(++clauses)) {
	              if ((clause<i) && (clause_state[clause]==ACTIVE)) {
	                  res=redundant(sat[i], sat[clause]);
	                  if (res==NEW_CLAUSE_REDUNDANT) {
	                          clause_state[i]=PASSIVE;
	                          break;
					  }
	                  if (res==OLD_CLAUSE_REDUNDANT) clause_state[clause]=PASSIVE;
				  }
			  }
	          if (res==NEW_CLAUSE_REDUNDANT)  break;
		  }
	  }
  }
}

my_type build_simple_sat_instance(char *input_file)
{
  int res; //, *pos_nb, *neg_nb; //number of positive,negative
  if (read_clauses(input_file)==FALSE) return FALSE;

  build_structure();

  eliminate_redundance();

  if (unitclause_process()==UNSATISFIABLE) return UNSATISFIABLE;

  res=clean_structure();

  return res; //  FALSE / SATISFIABLE / return TRUE;
}

int verify_sol_input(char *input_file) 
{
   char ch, word2[WORD_LENGTH];
   int i,ret, lit, nb_var1, nb_clause1;

   FILE* fp_in=fopen(input_file, "r");
   if (fp_in == NULL) return FALSE;

   char prech='\n';
   while(1){
      ret=fscanf(fp_in, "%c", &ch);
      if(ch=='p' && prech=='\n') break;
	  prech=ch;
  }
  ret=fscanf(fp_in, "%s%d%d", word2, &nb_var1, &nb_clause1);
  
  for (i=0; i<nb_clause1; i++) {
      ret=fscanf(fp_in, "%d", &lit);
      while (lit != 0) {
          if (var_value[ABS(lit)]==lit) break;
          ret=fscanf(fp_in, "%d", &lit);
	  }
      if (lit==0) {
          fclose(fp_in);
          return FALSE;
	  }
      else {
         do ret=fscanf(fp_in, "%d", &lit);
         while (lit != 0) ;
	  }
  }
  fclose(fp_in);
  return TRUE;
}
