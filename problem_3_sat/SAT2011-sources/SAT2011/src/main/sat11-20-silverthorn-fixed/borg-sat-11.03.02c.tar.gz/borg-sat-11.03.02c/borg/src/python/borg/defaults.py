"""
@author: Bryan Silverthorn <bcs@cargo-cult.org>
"""

solvers_root = "/scratch/cluster/bsilvert/sat-competition-2011/solvers"
machine_speed = 1.0

try:
    from borg_site_defaults import *
except ImportError:
    pass

