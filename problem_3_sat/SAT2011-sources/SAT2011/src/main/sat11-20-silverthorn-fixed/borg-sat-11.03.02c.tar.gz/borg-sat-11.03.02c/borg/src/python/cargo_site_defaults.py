"""@author: Bryan Silverthorn <bcs@cargo-cult.org>"""

condor_matching = "InMastodon && ((Arch == \"X86_64\")) && (OpSys == \"LINUX\") && regexp(\"rhavan-.*\", ParallelSchedulingGroup)"

