#define LGL_CC "gcc (Ubuntu 4.4.3-4ubuntu5) 4.4.3"
#define LGL_CFLAGS "-Wall -O3 -DNLGLOG -DNLGLSTATS -DNDEBUG -DNLGLPICOSAT "
