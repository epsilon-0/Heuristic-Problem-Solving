def test_cluster_coefficients():
    pass

