"""@author: Bryan Silverthorn <bcs@cargo-cult.org>"""

import plac

if __name__ == "__main__":
    from borg.tools.dump_model import main

    plac.call(main)

import json
import cPickle as pickle
import cargo

logger = cargo.get_logger(__name__, default_level = "INFO")

def classifier_to_json(classifier):
    return {
        "C": classifier.C,
        "coefficients": classifier.coef_.tolist(),
        "epsilon": classifier.eps,
        "intercept": classifier.intercept_.tolist(),
        "labels": classifier.label_.tolist(),
        "loss": classifier.loss,
        "penalty": classifier.penalty,
        }

def model_to_json(model):
    return {
        "latent_solver_classes": model._rclass_SKB.tolist(),
        "latent_task_classes": model._tclass_LSK.tolist(),
        "task_class_weights": model._tclass_weights_L.tolist(),
        "classifier": classifier_to_json(model._classifier),
        }

@plac.annotations(
    model_path = ("path to model file",),
    )
def main(model_path):
    """Dump the data in a model file as JSON."""

    cargo.enable_default_logging()

    with open(model_path) as model_file:
        portfolio = pickle.load(model_file)

    root = {
        "solvers": portfolio._solver_names,
        "budgets": portfolio._budgets,
        "model": model_to_json(portfolio._model),
        }

    print json.dumps(root, indent = 4)

