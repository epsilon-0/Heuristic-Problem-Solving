"""
@author: Bryan Silverthorn <bcs@cargo-cult.org>
"""

from cargo.gsl.errno import set_error_handler_off

set_error_handler_off() # FIXME horrible hack

