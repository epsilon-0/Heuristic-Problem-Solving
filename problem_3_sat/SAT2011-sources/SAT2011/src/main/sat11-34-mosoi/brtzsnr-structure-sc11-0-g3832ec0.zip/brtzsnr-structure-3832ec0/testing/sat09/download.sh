#!/bin/sh

cd `dirname $0`

# SAT09
wget http://www.cril.univ-artois.fr/SAT09/bench/appli.7z
wget http://www.cril.univ-artois.fr/SAT09/bench/crafted.7z
wget http://www.cril.univ-artois.fr/SAT09/bench/random.7z
wget http://www.cril.univ-artois.fr/SAT09/bench/random-additional.7z

# SAT07
wget http://www.satcompetition.org/2007/crafted.tar

