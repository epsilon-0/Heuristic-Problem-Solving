package ibis.structure;

/**
 * ContradictionException is thrown when a contradiction is detected.
 */
public class ContradictionException extends Exception {
}
