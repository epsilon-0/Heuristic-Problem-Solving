cd lib
$IPL_HOME/bin/iplc constellation-0.7.0.jar  constellation-tests-0.2.jar
cd -
