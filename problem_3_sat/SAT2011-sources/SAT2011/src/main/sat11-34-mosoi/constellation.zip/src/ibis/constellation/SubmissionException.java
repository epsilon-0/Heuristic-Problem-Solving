package ibis.constellation;

public class SubmissionException extends Exception {

    private static final long serialVersionUID = -2676533288785729968L;

    public SubmissionException() {
        // TODO Auto-generated constructor stub
    }

    public SubmissionException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public SubmissionException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

    public SubmissionException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

}
