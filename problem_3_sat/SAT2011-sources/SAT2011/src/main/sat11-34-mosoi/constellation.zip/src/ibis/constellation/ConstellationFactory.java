package ibis.constellation;

import ibis.constellation.impl.DistributedConstellation;
import ibis.constellation.impl.MultiThreadedConstellation;
import ibis.constellation.impl.SingleThreadedConstellation;

import java.util.Properties;

/**
 * Creates the constellation.
 *
 * Important properties:
 *
 * <ul>
 * <li><tt>ibis.constellation.impl</tt> - Can be <stroke>distributed</stroke> or <stroke>multithreaded</stroke></li>
 * </ul>
 */
public class ConstellationFactory {
    /** Creates a constellation with System properties and one executor */
	public static Constellation createConstellation(Executor e) throws Exception { 
		return createConstellation(System.getProperties(), e);
	}

    /** Creates a constellation with given propeties and one executor */
	public static Constellation createConstellation(Properties p, Executor e) throws Exception { 
		return createConstellation(p, new Executor [] { e });
	}
	
    /** Creates a constellation with System properties and several executors. */
	public static Constellation createConstellation(Executor ... e) throws Exception { 
		return createConstellation(System.getProperties(), e);
	}
		
    /** Creates a constellation with given properties and several executors. */
    public static Constellation createConstellation(Properties p, Executor ... e) throws Exception { 
    	if (e == null || e.length == 0) { 
    		throw new IllegalArgumentException("Need at least one executor!");
    	}

        String impl = p.getProperty("ibis.constellation.impl", "distributed");
        boolean distributed;
        if (impl.equals("distributed")) {
            distributed = true;
        } else if (impl.equals("multithreaded")) {
            distributed = false;
        } else {
            throw new Exception("ibis.constellation.impl can be only 'distributed' or 'multithreaded'");
        }

        // Creates the top layer.
        DistributedConstellation dc = null;
        if (distributed) {
            dc = new DistributedConstellation(p);
        }

        // Creates the middle layer.
        MultiThreadedConstellation mtc = new MultiThreadedConstellation(dc, p);                

        // Creates the bottem layer.
    	for (int i = 0; i < e.length; i++) { 
    	    new SingleThreadedConstellation(mtc, e[i], p);          
    	}

        if (distributed) {
            return dc.getConstellation();
        }
        return mtc.getConstellation();
    }
}
