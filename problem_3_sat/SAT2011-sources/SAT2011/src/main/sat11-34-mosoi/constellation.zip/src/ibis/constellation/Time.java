package ibis.constellation;

public class Time {
    // Not implemented yet!
}
