package ibis.constellation.impl;

import ibis.constellation.ConstellationIdentifier;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import java.util.TimerTask;
import java.util.Vector;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

/**
 * Implements the live monitoring mechanism in Constellation.
 *
 * System properties:
 *
 * ibis.constellation.tracer.port - port to run the webserver on (defaults to 8080)
 * ibis.constellation.tracer.outputfile - file to write history to
 */
class Tracer extends TimerTask {
    private static final int HISTORY_MAXSIZE = 750;
    private static final String DEFAULT_PORT = null;

    private final long startTime = System.currentTimeMillis();
    private final Random random = new Random();

    private HashMap<ConstellationIdentifier, Info> workers = new HashMap<ConstellationIdentifier, Info>();
    private boolean isMaster = false;
    private Vector<Info> history = null;
    private HttpServer server = null;

    public Tracer(boolean isMaster) {
        this.isMaster = isMaster;
        if (isMaster) {
            String port = System.getProperty(
                    "ibis.constellation.tracer.port", DEFAULT_PORT);
            if (port != null) {
                try {
                    createHttpServer(Integer.parseInt(port));
                } catch (IOException e) {
                    System.err.println("Tracing server not available: " + e);
                }
            }
        }
    }

    private void createHttpServer(int port) throws IOException {
        history = new Vector<Info>();
        InetSocketAddress addr = new InetSocketAddress(port);
        server = HttpServer.create(addr, 0);

        server.createContext("/", new RootHandler());
        server.createContext("/states_times.html", new ChartDrawer(history, new StatesTimesDP()));
        server.createContext("/jobs_processed.html", new ChartDrawer(history, new JobsProcessedDP()));
        server.createContext("/jobs_speed.html", new ChartDrawer(history, new JobsSpeedDP()));
        server.setExecutor(java.util.concurrent.Executors.newCachedThreadPool());
        server.start();
    }

    public void run() {
        long pollTime = System.currentTimeMillis();
        Info global = new Info(pollTime);

        synchronized (this) {
            Iterator<Info> it = workers.values().iterator();
            while (it.hasNext()) {
                Info local = it.next();
                global.merge(local);
                local.reset(pollTime);
            }
        }

        synchronized (history) {
            history.add(global);

            if (history.size() > HISTORY_MAXSIZE) {
                // If the history is too large merges too adjiacent samples.
                int bestPos = 0;
                long bestValue = history.get(0).totalTime() + history.get(1).totalTime();
                for (int pos = 0; pos < HISTORY_MAXSIZE; pos++) {
                    long value = history.get(pos).totalTime() + history.get(pos + 1).totalTime();
                    if (value < bestValue) {
                        bestPos = pos;
                        bestValue = value;
                    }
                }

                history.get(bestPos).merge(history.get(bestPos + 1));
                history.remove(bestPos + 1);
            }
        }
    }

    /** Stops http server and dumps history. */
    public void done() {
        if (!isMaster || server == null) {
            return;
        }

        // Stops http server
        if (server != null) {
            server.stop(0);
        }

        // Dumps history to file
        String outputfile = System.getProperty(
                "ibis.constellation.tracer.outputfile");
        System.err.println("Dumping history to " + outputfile);
        if (outputfile != null) {
            try {
                PrintStream out = new PrintStream(
                        new FileOutputStream(new File(outputfile)));
                writeXML(out);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /** Writes history as an XML. */
    public void writeXML(PrintStream out) {
        out.println("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>");
        out.println("<history>");
        writeXML(out, "  ");
        out.println("</history>");
    }

    private void writeXML(PrintStream out, String indent) {
        synchronized (history) {
            for (int i = 0; i < history.size(); i++) {
                out.println(indent + "<sample>");
                history.get(i).writeXML(out, indent + "  ");
                out.println(indent + "</sample>");
            }
        }
    }


    /**
     * Sets the default state and timer for identifier if missing.
     *
     * @return Info for identifier
     */
    private synchronized Info setDefault(ConstellationIdentifier identifier) {
        Info info = workers.get(identifier);
        if (info == null) {
            info = new Info(startTime);
            workers.put(identifier, info);
        }
        return info;
    }

    public synchronized void stopped(ConstellationIdentifier identifier) {
        setDefault(identifier).changeState(Info.STOPPED);
    }

    public synchronized void idle(ConstellationIdentifier identifier) {
        setDefault(identifier).changeState(Info.IDLE);
    }

    public synchronized void event(ConstellationIdentifier identifier) {
        setDefault(identifier).changeState(Info.EVENT);
    }

    public synchronized void active(ConstellationIdentifier identifier) {
        setDefault(identifier).changeState(Info.ACTIVE);
    }

    public synchronized void jobProcessed(ConstellationIdentifier identifier) {
        setDefault(identifier).jobProcessed();
    }

    public synchronized void jobSubmitted(ConstellationIdentifier identifier) {
        setDefault(identifier).jobSubmitted();
    }

    public synchronized void steals(ConstellationIdentifier identifier) {
        setDefault(identifier).steals();
    }

    public synchronized void stolenJobs(ConstellationIdentifier identifier, int count) {
        setDefault(identifier).stolenJobs(count);
    }
}

class Info {
    public static final int STOPPED = 0;
    public static final int IDLE = 1;
    public static final int EVENT = 2;
    public static final int ACTIVE = 3;
    public static final int NUM_STATES = 4;

    /** Current state. */
    public int state = STOPPED;
    public long flipTime;
    /** Time spent in each state */
    public long[] times = new long[NUM_STATES];
    /** Number of jobs processed. */
    public long numJobsProcessed = 0;
    /** Number of jobs submitted. */
    public long numJobsSubmitted = 0;
    /** Number of steals. */
    public long numSteals = 0;
    /** Number of stolen jobs. */
    public long numStolenJobs = 0;

    public Info(long time) {
        flipTime = time;
    }

    /** Returns total time spend in all states.  */
    public long totalTime() {
        long sum = 0;
        for (int i = 0; i < NUM_STATES; i++) {
            sum += times[i];
        }
        return sum;
    }

    /** Resets statistics, but not state and updates flipTime. */
    public void reset(long time) {
        flipTime = time;
        for (int i = 0; i < NUM_STATES; i++) {
            times[i] = 0;
        }
        numJobsProcessed = 0;
        numJobsSubmitted = 0;
        numSteals = 0;
        numStolenJobs = 0;
    }

    /** Writes this info as XML to stream. */
    public void writeXML(PrintStream out, String indent) {
        out.println(indent + "<flipTime>" + flipTime + "</flipTime>");
        out.println(indent + "<times>");
        out.println(indent + "  <stopped>" + times[STOPPED] + "</stopped>");
        out.println(indent + "  <idle>"    + times[IDLE]    + "</idle>");
        out.println(indent + "  <event>"   + times[EVENT]   + "</event>");
        out.println(indent + "  <active>"  + times[ACTIVE]  + "</active>");
        out.println(indent + "</times>");
        out.println(indent + "<numJobsProcessed>" + numJobsProcessed + "</numJobsProcessed>");
        out.println(indent + "<numJobsSubmitted>" + numJobsSubmitted + "</numJobsSubmitted>");
        out.println(indent + "<numSteals>" + numSteals + "</numSteals>");
        out.println(indent + "<numStolenJobs>" + numStolenJobs + "</numStolenJobs>");
    }

    /** Merges statistics of other into current info.  */
    public void merge(Info other) {
        for (int i = 0; i < NUM_STATES; i++) {
            times[i] += other.times[i];
        }
        numJobsProcessed += other.numJobsProcessed;
        numJobsSubmitted += other.numJobsSubmitted;
        numSteals += other.numSteals;
        numStolenJobs += other.numStolenJobs;
    }

    /** Changes the state to newState and updates time.  */
    public void changeState(int newState) {
        long newFlipTime = System.currentTimeMillis();
        times[state] += newFlipTime - flipTime;
        state = newState;
        flipTime = newFlipTime;
    }

    /** Increments number of jobs processed. */
    public void jobProcessed() {
        assert state == ACTIVE;
        changeState(state);
        numJobsProcessed++;
    }

    /** Increments number of jobs submitted. */
    public void jobSubmitted() {
        assert state == ACTIVE;
        changeState(state);
        numJobsSubmitted++;
    }

    /** Increments number of steals. */
    public void steals() {
        changeState(state);
        numSteals++;
    }

    /** Increments number of steals. */
    public void stolenJobs(int count) {
        changeState(state);
        numStolenJobs += count;
    }
}

/**
 * HttpHandler for main page.
 */
class RootHandler implements HttpHandler {
    public void handle(HttpExchange exchange) throws IOException {
        String requestMethod = exchange.getRequestMethod();
        if (!requestMethod.equalsIgnoreCase("GET")) {
            return;
        }

        Headers responseHeaders = exchange.getResponseHeaders();
        // responseHeaders.set("Content-Type", "text/plain");
        exchange.sendResponseHeaders(200, 0);

        OutputStream responseBody = exchange.getResponseBody();
        Headers requestHeaders = exchange.getRequestHeaders();

        StringBuffer buffer = new StringBuffer();

        buffer.append("<html>\n");
        buffer.append("<head>\n");
        buffer.append("</head>\n");
        buffer.append("<body>\n");
        chart(buffer, "states_times");
        buffer.append("<br/>\n");
        chart(buffer, "jobs_processed");
        chart(buffer, "jobs_speed");
        buffer.append("</body>\n");
        buffer.append("</html>\n");

        responseBody.write(buffer.toString().getBytes());
        responseBody.close();
    }

    private void chart(StringBuffer buffer, String name) {
        buffer.append("<iframe src='" + name + ".html' width='640' height='400'></iframe>\n");
    }
}

/**
 * Stores data for one axis.
 */
class DataStore {
    private String labels;
    private double min;
    private double max;
    private double[][] data;

    public DataStore(String labels, double min, double max, double[][] data) {
        this.labels = labels;
        this.min = min;
        this.max = max;
        this.data = data;
    }

    public String labels()   { return labels; }
    public double min()      { return min; }
    public double max()      { return max; }
    public double[][] data() { return data; }
}

interface DataProducer {
    public DataStore evaluate(Vector<Info> history);
}

/**
 * Draws one chart.
 */
class ChartDrawer implements HttpHandler {
    protected Vector<Info> history;
    protected DataProducer producer;

    public ChartDrawer(Vector<Info> history, DataProducer producer) {
        this.history = history;
        this.producer = producer;
    }

    public void handle(HttpExchange exchange) throws IOException {
        String requestMethod = exchange.getRequestMethod();
        if (!requestMethod.equalsIgnoreCase("GET")) {
            return;
        }

        Headers responseHeaders = exchange.getResponseHeaders();
        // responseHeaders.set("Content-Type", "text/plain");
        exchange.sendResponseHeaders(200, 0);

        OutputStream responseBody = exchange.getResponseBody();
        Headers requestHeaders = exchange.getRequestHeaders();

        StringBuffer buffer = new StringBuffer();

        buffer.append("<html>\n");
        buffer.append("<head>\n");
        buffer.append("\t<script type='application/javascript'>\n");
        buffer.append("\t\t// Send the POST when the page is loaded,\n");
        buffer.append("\t\t// which will replace this whole page with the retrieved chart.\n");
        buffer.append("\t\tfunction loadGraph() {\n");
        buffer.append("\t\t\tvar frm = document.getElementById('post_form');\n");
        buffer.append("\t\t\tif (frm) { frm.submit(); }\n");
        buffer.append("\t\t}\n");
        buffer.append("\t</script>\n");
        buffer.append("</head>\n");
        buffer.append("<body onload='loadGraph()'>\n");
        try {
            chartSubmitForm(buffer);
        } catch (Exception e) {
            e.printStackTrace();
        }
        buffer.append("</body>\n");
        buffer.append("</html>\n");

        responseBody.write(buffer.toString().getBytes());
        responseBody.close();
    }

    private void chartSubmitForm(StringBuffer buffer) {
        buffer.append("<form\n");
        buffer.append("\taction='https://chart.googleapis.com/chart'\n");
        buffer.append("\tmethod='POST' id='post_form'>\n");
        buffer.append("\t<input type='hidden' name='cht' value='lxy'/>\n");
        buffer.append("\t<input type='hidden' name='chs' value='640x400'/>\n");
        buffer.append("\t<input type='hidden' name='chma' value='5,5,5,25'/>\n");
        buffer.append("\t<input type='hidden' name='chg' value='5,0'/>\n");
        buffer.append("\t<input type='hidden' name='chco' value='3072F3,FF0000,FF9900,00FFFF,0000FF'/>\n");
        buffer.append("\t<input type='hidden' name='chdlp' value='b'/>\n");
        buffer.append("\t<input type='hidden' name='chxt' value='x,y'/>\n");
        
        synchronized (history) {
            // Computes the x axis
            DataStore xAxis = (new TimeDP()).evaluate(history);
            String x = encode(xAxis.data()[0], xAxis.min(), xAxis.max());

            // Computes the y axises
            buffer.append("\t<input type='hidden' name='chd' value='e:");
            DataStore yAxis = producer.evaluate(history);
            for (double[] data : yAxis.data()) {
                String y = encode(data, yAxis.min(), yAxis.max());
                buffer.append(x);
                buffer.append(',');
                buffer.append(y);
                buffer.append(',');
            }
            buffer.deleteCharAt(buffer.length() - 1);
            buffer.append("'/>\n'");

            buffer.append("\t<input type='hidden' name='chdl' value='"
                    + yAxis.labels() + "'/>\n");
            buffer.append("\t<input type='hidden' name='chxr' value='"
                    + "0," + xAxis.min() + "," + xAxis.max() + "|"
                    + "1," + yAxis.min() + "," + yAxis.max() + "'/>\n");
        }
        buffer.append("</form>\n");
    }

    private String encode(double[] data, double min, double max) {
        final char[] alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-.".toCharArray();
        StringBuffer buffer = new StringBuffer(data.length * 2);
        for (double e : data) {
            int v = (int) ((e - min) / (max - min) * 4095);
            assert 0 <= v && v < 4096;
            buffer.append(alphabet[v / 64]);
            buffer.append(alphabet[v % 64]);
        }
        return buffer.toString();
    }
}

class Misc {
    public static double min(double[][] data) {
        double min = Double.POSITIVE_INFINITY;
        for (double[] row : data) {
            for (double cell : row) {
                min = Math.min(min, cell);
            }
        }
        return min;
    }

    public static double max(double[][] data) {
        double max = Double.NEGATIVE_INFINITY;
        for (double[] row : data) {
            for (double cell : row) {
                max = Math.max(max, cell);
            }
        }
        return max;
    }
}

class TimeDP implements DataProducer {
    public DataStore evaluate(Vector<Info> history) {
        double[][] data = new double[1][];
        double startTime = history.get(0).flipTime;
        data[0] = new double[history.size()];
        for (int i = 0; i < history.size(); i++) {
            data[0][i] = (double) (history.get(i).flipTime - startTime) / 1000.;
        }

        double max = (double) data[0][history.size() - 1];
        return new DataStore(null, 0, max, data);
    }
}

class JobsProcessedDP implements DataProducer {
    public DataStore evaluate(Vector<Info> history) {
        double[][] data = new double[2][];
        data[0] = new double[history.size()];
        for (int i = 0; i < history.size(); i++) {
            data[0][i] = (double) history.get(i).numJobsProcessed;
            if (i != 0) data[0][i] += data[0][i - 1];
        }
        data[1] = new double[history.size()];
        for (int i = 0; i < history.size(); i++) {
            data[1][i] = (double) history.get(i).numJobsSubmitted;
            if (i != 0) data[1][i] += data[1][i - 1];
        }

        return new DataStore("Processed Jobs|Submitted Jobs", 0, Misc.max(data), data);
    }
}

class JobsSpeedDP implements DataProducer {
    public DataStore evaluate(Vector<Info> history) {
        double[][] data = new double[2][];
        data[0] = new double[history.size()];
        for (int i = 0; i < history.size(); i++) {
            data[0][i] = 1000. * history.get(i).numJobsProcessed / history.get(i).totalTime();
        }
        data[1] = new double[history.size()];
        for (int i = 0; i < history.size(); i++) {
            data[1][i] = 1000. * history.get(i).numJobsSubmitted / history.get(i).totalTime();
        }

        return new DataStore("Processed Jobs Per Second|Submitted Jobs Per Second", 0, Misc.max(data), data);
    }
}

class StatesTimesDP implements DataProducer {
    public DataStore evaluate(Vector<Info> history) {
        double[][] data = new double[Info.NUM_STATES][];
        for (int s = 0; s < Info.NUM_STATES; ++s) {
            data[s] = new double[history.size()];
            for (int i = 0; i < history.size(); i++) {
                data[s][i] = (double) history.get(i).times[s] / history.get(i).totalTime();
            }
        }

        return new DataStore("Stopped|Idle|Event|Active", 0, Misc.max(data), data);
    }
}
