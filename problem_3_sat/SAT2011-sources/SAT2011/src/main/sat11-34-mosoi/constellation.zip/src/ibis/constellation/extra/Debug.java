package ibis.constellation.extra;

public class Debug {

    private static final boolean DEBUG_ALL  = false;    
    
    public static final boolean DEBUG_STEAL = DEBUG_ALL || false;
    public static final boolean DEBUG_LOOKUP = DEBUG_ALL || false;
    public static final boolean DEBUG_CONTEXT = DEBUG_ALL || false;
    public static final boolean DEBUG_SUBMIT = DEBUG_ALL || false;
    public static final boolean DEBUG_COMMUNICATION = DEBUG_ALL || false;
    public static final boolean DEBUG_EVENTS = DEBUG_ALL || false;
    public static final boolean DEBUG_ACTIVATE = DEBUG_ALL || false;

}
