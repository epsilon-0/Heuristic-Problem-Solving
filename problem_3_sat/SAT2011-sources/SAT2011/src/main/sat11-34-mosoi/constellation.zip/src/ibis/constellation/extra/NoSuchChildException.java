package ibis.constellation.extra;

public class NoSuchChildException extends Exception {

    public NoSuchChildException() {
        // TODO Auto-generated constructor stub
    }

    public NoSuchChildException(String arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    public NoSuchChildException(Throwable arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    public NoSuchChildException(String arg0, Throwable arg1) {
        super(arg0, arg1);
        // TODO Auto-generated constructor stub
    }

}
