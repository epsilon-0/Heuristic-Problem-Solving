/*
 * verification_sls.c
 *
 *  Created on: 23.10.2010
 *      Author: Oliver Gableske
 *  	Content: This file contains all methods to perform verifications for the SLS component.
 *
 */
#include "verification_sls.h"
#ifdef VERIFICATION_SLS
void verification_sls_verifySolution(){
	register int i,satisfying,lit,j;
	int *ptr;
	#ifdef HYBRID
	for (i = 0; i < numCDCLClauses; i++){
	#else
	for (i = 0; i < numOriginalClauses; i++){
	#endif
		satisfying = 0;
		for (ptr = clauseLiterals[i]; (lit = *ptr) != 0; ptr++){
			if ((lit > 0) == assignment[abs(lit)]) satisfying++;
		}
		if (satisfying == 0){
			printf("c e Error because supposed solution fails verification:\n");
			printf("c e Clause %i: ",i);
			for(j = 0; (lit = clauseLiterals[i][j]) != 0; j++){
			#ifdef HYBRID
			printf("%i(%i,%i) ",lit, assignment[abs(lit)],tvalue[abs(lit)]);
			#else
			printf("%i(%i) ",lit, assignment[abs(lit)]);
			#endif
			}
			printf("\n");
			fprintf(stderr, "Error because supposed solution fails verification.\n");
			exit(-1);
		}
	}
	printf("c Solution verified.\n");
}
#endif
