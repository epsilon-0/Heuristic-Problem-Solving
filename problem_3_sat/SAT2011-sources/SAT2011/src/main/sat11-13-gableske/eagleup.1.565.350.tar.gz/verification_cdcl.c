/*
 * verification_cdcl.c
 *
 *  Created on: 23.10.2010
 *      Author: Oliver Gableske
 *     Content: This file contains all methods to perform verifications for the CDCL component.
 *
 */
#include "verification_cdcl.h"
#ifdef HYBRID
#ifdef VERIFICATION_CDCL
int verification_cdcl_countNumberOfSatsifyingLiterals(int cNum){
	int res = 0, *clsPtr;
	for (clsPtr = clauseLiterals[cNum]; *clsPtr != 0; ++clsPtr){
		if (tvalue[abs(*clsPtr)] != 2 && ((tvalue[abs(*clsPtr)] > 0) == (*clsPtr > 0))) {
			++res;
		} else if ((tvalue[abs(*clsPtr)] == 2) && ((assignment[abs(*clsPtr)] > 0) == (*clsPtr > 0))){
			++res;
		}
	}
	return res;
}

int verification_cdcl_countNumberOfUnassignedVaribales(int cNum){
	int res = 0, *clsPtr;
	for (clsPtr = clauseLiterals[cNum]; *clsPtr != 0; ++clsPtr){
		if (tvalue[abs(*clsPtr)] == 2){
			++res;
		}
	}
	return res;
}

#ifndef VERBOSE_CDCL
void cdcl_printClauseInline(int cNum){
	register int i;
	printf("[%6.1i|%6.1i|%6.1i] ",
			cNum,watchedLiteral1[cNum],watchedLiteral2[cNum]);
	for (i = 0; clauseLiterals[cNum][i] != 0; i++){
		printf("%6.1i(pval:%i,tval:%i)", clauseLiterals[cNum][i],
				assignment[abs(clauseLiterals[cNum][i])], tvalue[abs(clauseLiterals[cNum][i])]);
		fflush(stdout);
	}
}
#endif

void verification_cdcl_verifyInitCall(){
	int lit,*arrPtr,cNum,found,pos;
	//We will assert here that the call was correctly initialized. First we assert that the watched literals are
	//correct. Check from the point of view of the variables.
	for (lit = -numVars; lit < numVars+1; ++lit){
		//Literal lit as first watcher.
		if (lit == 0){
			//Lit 0 should not watch anything.
			if (watches1[lit][0] != 0 || watches1[lit][2] != -1){
				printf("c e Error because literal 0 has something to watch as first watcher. Not possible.\n");
				exit(-1);
			}
		} else {
			for (arrPtr = watches1[lit]+2; *arrPtr != -1; ++arrPtr){
				if (watchedLiteral1[*arrPtr] != lit){
					printf("c e Error because literal %i is spposed to watch clause %i, but clause is not aware.",
							lit, *arrPtr);
					exit(-1);
				}
			}
		}
		//Literal lit as second watcher.
		if (lit == 0){
			//Lit 0 should not watch anything.
			if (watches2[lit][0] != 0 || watches2[lit][2] != -1){
				printf("c e Error because literal 0 has something to watch as second watcher. Not possible.\n");
				exit(-1);
			}
		} else {
			for (arrPtr = watches2[lit]+2; *arrPtr != -1; ++arrPtr){
				if (watchedLiteral2[*arrPtr] != lit){
					printf("c e Error because literal %i is spposed to watch clause %i, but clause is not aware.",
							lit, *arrPtr);
					exit(-1);
				}
			}
		}
	}

	//Check from the point of view of the clauses.
	for (cNum = 0; cNum < numCDCLClauses; ++cNum){
		#ifdef PREPROCESSING
		if (cNum < numClauses && isIgnoredClause[cNum]) {
			continue; //Skip this if ignored.
		}
		#endif
		//Check if the clause correctly knows about its first watcher.
		if (watchedLiteral1[cNum] == 0){
			printf("c e Error because having a clause with no first watched literal is crap.\n");
			exit(-1);
		}
		lit = watchedLiteral1[cNum];
		found = 0; pos = 2;
		while (watches1[lit][pos] > -1){
			if (watches1[lit][pos++] == cNum){
				found = 1; break;
			}
		}
		if (!found){
			printf("c e Error because clause names first watched literal for which the clause is not found in the"
					" watches1 array.\n");
			exit(-1);
		}
		//Check if the clause correctly knows about its second watcher. If the clause has none we assert that it
		//is a unit clause.
		lit = watchedLiteral2[cNum];
		if (lit != 0){
			found = 0; pos = 2;
			while (watches2[lit][pos] > -1){
				if (watches2[lit][pos++] == cNum){
					found = 1; break;
				}
			}
			if (!found){
				printf("c e Error because clause names second watched literal for which the clause is not found "
						"in the watches2 array.\n");
				exit(-1);
			}
		} else {
			if (clauseLiterals[cNum][1] != 0){
				printf("c e Error because the clause has no second watcher but it is not unit: %i.\n",cNum);
				exit(-1);
			}
		}
	}
	//We also check if all variables in tvalue are either unassigned or part of a unit clause.
	for (pos = 1; pos < numVars+1; ++pos){
		if (tvalue[pos] != 2){
			//Here we need to find the clause that contains the respective literal and is unit. The corresponding
			//variable is pos.
			if (tvalue[pos] == 0){
				//The respective literal is -pos. -pos must be the first watcher of the clause being unit, so we check
				//all the clauses where this is the case.
				for (arrPtr = watches1[-pos]; *arrPtr != -1; ++arrPtr){
					if (clauseLiterals[*arrPtr][1] == 0){
						found = 1; break;
					}
				}
			} else {
				//The respective literal is pos. pos must be the first watcher of the clause being unit, so we check
				//all the clauses where this is the case.
				for (arrPtr = watches1[pos]; *arrPtr != -1; ++arrPtr){
					if (clauseLiterals[*arrPtr][1] == 0){
						found = 1; break;
					}
				}
			}
			if (!found){
				printf("c e Error because after initialization of the CDCL, no variable should be assigned that is not"
						"part of a unit clause.\n");
				exit(-1);
			}
		}
	}
}

void verification_cdcl_verifyMemoryAllocation(){
	if (cdcl_decisionStack_assignments == (void*)0
			|| watches1 == (void*)0
			|| watches2 == (void*)0
			|| clauseLiterals == (void*)0
			|| watchedLiteral1 == (void*)0
			|| watchedLiteral2 == (void*)0
			|| watches1pos == (void*)0
			|| watches2pos == (void*)0){
		printf("c e Error because allocation of memory failed. Pointers are:\n");
		printf("c watches1 = %p\n",(void*)watches1);
		printf("c watches2 = %p\n",(void*)watches2);
		printf("c clauseLiterals %p\n", (void*)clauseLiterals);
		printf("c watchedLiteral1 %p\n", (void*)watchedLiteral1);
		printf("c watchedLiteral2 %p\n", (void*)watchedLiteral2);
		printf("c watches1pos %p\n", (void*)watches1pos);
		printf("c watches2pos %p\n", (void*)watches2pos);
		printf("c cdcl_decisionStack_assignments = %p\n",(void*)cdcl_decisionStack_assignments);
		exit(-1);
	}
}

void verification_cdcl_learnedClauseHasFirstWatcher(){
	if (watchedLiteral1[numCDCLClauses] == 0){
		printf("c e Error because selection of first watcher failed for learned clause.\n");
		exit(-1);
	}
	//We now see to it that the clause is correctly found in the watches array of the second watcher.
	int found = 0, pos = 2;
	while (watches1[watchedLiteral1[numCDCLClauses]][pos] > -1){
		if (watches1[watchedLiteral1[numCDCLClauses]][pos++] == numCDCLClauses){
			found = 1; break;
		}
	}
	if (!found){
		printf("c e Error because the newly learned clause has a first watcher but it does not appear in "
				"the watches1 array.\n");
		exit(-1);
	}
}

void verification_cdcl_learnedClauseHasSecondWatcher(){
	if (watchedLiteral2[numCDCLClauses] == 0){
		printf("c e Error because selection of second watcher failed for learned clause.\n");
		exit(-1);
	}
	//We now see to it that the clause is correctly found in the watches array of the second watcher.
	int found = 0, pos = 2;
	while (watches2[watchedLiteral2[numCDCLClauses]][pos] > -1){
		if (watches2[watchedLiteral2[numCDCLClauses]][pos++] == numCDCLClauses){
			found = 1; break;
		}
	}
	if (!found){
		printf("c e Error because the newly learned clause has a second watcher but it does not appear in "
				"the watches2 array.\n");
		exit(-1);
	}
	//We also assert, that the first and second watcher are different.
	if (watchedLiteral1[numCDCLClauses] == watchedLiteral2[numCDCLClauses]){
		printf("c e Error because watched literals must always be different which is not the case for the newly"
				" learned clause.\n");
		exit(-1);
	}
}


void verification_cdcl_clauseHasOldFirstWatcher(int cNum){
	if (watchedLiteral1[cNum] == 0){
		printf("c e Error because clause has no first watcher.\n");
		exit(-1);
	}
	if (watches1[watchedLiteral1[cNum]][2+watches1pos[cNum]] != cNum){
		printf("c e Error because clause has first watcher but it is not found in the said position.\n");
		exit(-1);
	}
}

void verification_cdcl_clauseHasOldScondWatcher(int cNum){
	if (watchedLiteral2[cNum] == 0){
		printf("c e Error because clause has no second watcher.\n");
		exit(-1);
	}
	if (watches2[watchedLiteral2[cNum]][2+watches2pos[cNum]] != cNum){
		printf("c e Error because clause has second watcher but it is not found in the said position.\n");
		exit(-1);
	}
}

void verification_cdcl_verifyFirstWatcherReplacement_primary(int cNum, int oldLit, int newLit){
	//We assert that cNum is indeed a valid clause.
	if (cNum < 0 || cNum >= numCDCLClauses){
		printf("c e Error because clause number seems to be invalid.\n");exit(-1);
	}
	//We do assert here that newLit is not oldLit and that both values make sense.
	if (newLit == oldLit || newLit == 0 || oldLit == 0){
		printf("c e Error because clause has second watcher but it is not found in the said position.\n");exit(-1);
	}
	if (newLit < -numVars || newLit > numVars || oldLit < -numVars || oldLit > numVars){
		printf("c e Error because newLit or oldLit does not seem to be a literal.\n");	exit(-1);
	}
	//We also assert that newLit is indeed in the clause.
	int *clsPtr,found = 0;
	for (clsPtr = clauseLiterals[cNum]; *clsPtr != 0; ++clsPtr){
		if (*clsPtr == newLit) {
			found = 1;
			break;
		}
	}
	if (!found){
		printf("c e Error because new watcher is not part of the clause.\n");exit(-1);
	}
	//We also assert that oldLit is indeed in the clause.
	found = 0;
	for (clsPtr = clauseLiterals[cNum]; *clsPtr != 0; ++clsPtr){
		if (*clsPtr == oldLit) {
			found = 1;
			break;
		}
	}
	if (!found){
		printf("c e Error because old watcher is not part of the clause.\n");exit(-1);
	}
	//We assert here that watches1 contains cNum at the said position.
	if (watches1[oldLit][2+watches1pos[cNum]] != cNum){
		printf("c e Error because clause does not appear in the said watches1 position.\n");exit(-1);
	}
}
void verification_cdcl_verifyFirstWatcherReplacement_secondary(int cNum,int oldLit, int newLit){
	//We assert here that oldLit is not the watcher of clause cNum anymore. We also check that cNum is not part
	//of the watches1 array of oldLit anymore.
	//Check if a change happened.
	if (watchedLiteral1[cNum] == oldLit){
		printf("c e Error because after first watched literal replacement, the new watcher is the same as the "
				"old one.\n");
		exit(-1);
	}
	//Check if cNum is not part of the old literals watches1 array.
	int found = 0, pos = 2;
	while (watches1[oldLit][pos] > -1){
		if (watches1[oldLit][pos++] == cNum){
			found = 1; break;
		}
	}
	if (found){
		printf("c e Error because after replacement of the first watcher the clause is still in the watches1"
				" array of the old watched literal.");
		exit(-1);
	}
	//Check if cNum is part of the new literal watches1 array.
	found = 0; pos = 2;
	while (watches1[newLit][pos] > -1){
		if (watches1[newLit][pos++] == cNum){
			found = 1; break;
		}
	}
	if (!found){
		printf("c e Error because after replacement of the first watcher the clause is not found in the watches1"
				" array of the new watcher.");
		exit(-1);
	}
}

void verification_cdcl_verifySecondWatcherReplacement_primary(int cNum, int oldLit,int newLit){
	//We assert that cNum is indeed a valid clause.
	if (cNum < 0 || cNum >= numCDCLClauses){
		printf("c e Error because clause number seems to be invalid.\n");exit(-1);
	}
	//We do assert here that newLit is not oldLit and that both values make sense.
	if (newLit == oldLit || newLit == 0 || oldLit == 0){
		printf("c e Error because clause has second watcher but it is not found in the said position.\n");exit(-1);
	}
	if (newLit < -numVars || newLit > numVars || oldLit < -numVars || oldLit > numVars){
		printf("c e Error because newLit or oldLit does not seem to be a literal.\n");	exit(-1);
	}
	//We also assert that newLit is indeed in the clause.
	int *clsPtr,found = 0;
	for (clsPtr = clauseLiterals[cNum]; *clsPtr != 0; ++clsPtr){
		if (*clsPtr == newLit) {
			found = 1;
			break;
		}
	}
	if (!found){
		printf("c e Error because new watcher is not part of the clause.\n");exit(-1);
	}
	//We also assert that oldLit is indeed in the clause.
	found = 0;
	for (clsPtr = clauseLiterals[cNum]; *clsPtr != 0; ++clsPtr){
		if (*clsPtr == oldLit) {
			found = 1;
			break;
		}
	}
	if (!found){
		printf("c e Error because old watcher is not part of the clause.\n");exit(-1);
	}
	//We assert here that watches2 contains cNum at the said position.
	if (watches2[oldLit][2+watches2pos[cNum]] != cNum){
		printf("c e Error because clause does not appear in the said watches2 position.\n");exit(-1);
	}
}

void verification_cdcl_verifySecondWatcherReplacement_secondary(int cNum,int oldLit, int newLit){
	//We assert here that oldLit is not the watcher of clause cNum anymore. We also check that cNum is not part
	//of the watches2 array of oldLit anymore.
	//Check if a change happened.
	if (watchedLiteral2[cNum] == oldLit){
		printf("c e Error because after second watched literal replacement, the new watcher is the same as the "
				"old one.\n");
		exit(-1);
	}
	//Check if cNum is not part of the old literals watches2 array.
	int found = 0, pos = 2;
	while (watches2[oldLit][pos] > -1){
		if (watches2[oldLit][pos++] == cNum){
			found = 1; break;
		}
	}
	if (found){
		printf("c e Error because after replacement of the second watcher the clause is still in the watches2"
				"array of the old watched literal.");
		exit(-1);
	}
	//Check if cNum is part of the new literal watches2 array.
	found = 0; pos = 2;
	while (watches2[newLit][pos] > -1){
		if (watches2[newLit][pos++] == cNum){
			found = 1; break;
		}
	}
	if (!found){
		printf("c e Error because after replacement of the second watcher the clause is not found in the watches2"
				" array of the new watcher.");
		exit(-1);
	}
}


void verification_cdcl_verifyWatcher1Adaption_case1(int cNum){
	//We do assert here that the number of unassigned variables in this clause is indeed 0.
	if (verification_cdcl_countNumberOfUnassignedVaribales(cNum) != 0){
		printf("c e Error because the conflict clause has not equal 0 unassigned variables.\n");
		exit(-1);
	}
}

void verification_cdcl_verifyWatcher1Adaption_case2(int cNum){
	//We do assert here that the number of unassigned variables in this clause is indeed 1.
	if (verification_cdcl_countNumberOfUnassignedVaribales(cNum) != 1){
		printf("c e Error because clause has not equal 1 unassigned variable.\n");
		exit(-1);
	}
	//We also assert that the watched literal 1 is assigned.
	if (tvalue[abs(watchedLiteral1[cNum])] == 2){
		printf("c e Error because other watcher is unassigned too. Cannot force unit prop.\n");
		exit(-1);
	}
}

void verification_cdcl_verifyWatcher1Adaption_case3(int cNum){
	//We do assert here that the number of unassigned variables in this clause is indeed 0.
	if (verification_cdcl_countNumberOfUnassignedVaribales(cNum) != 0){
		printf("c e Error because clause has not equal 0 unassigned variable.\n");
		exit(-1);
	}
	//We also assert that this clause is indeed a conflict.
	if (verification_cdcl_countNumberOfSatsifyingLiterals(cNum) != 0){
		printf("c e Error because supposed conflict has satisfying literal in it.\n");
		exit(-1);
	}
}

void verification_cdcl_verifyWatcher1Adaption_case4(int cNum){
	//We also assert that this clause is indeed satisfied.
	if (verification_cdcl_countNumberOfSatsifyingLiterals(cNum) < 1){
		printf("c e Error because supposedly satisfied clause is not satisfied.\n");
		cdcl_printClauseInline(cNum);
		exit(-1);
	}
}

void verification_cdcl_verifyWatcher2Adaption_case0(int cNum){
	if (clauseLiterals[cNum][1] == 0){
		printf("c e Error because of a unit clause having a second watcher.\n");
		exit(-1);
	}
}

void verification_cdcl_verifyWatcher2Adaption_case1(int cNum){
	//We do assert here that the number of unassigned variables in this clause is indeed 0.
	if (verification_cdcl_countNumberOfUnassignedVaribales(cNum) != 0){
		printf("c e Error because the conflict clause has not equal 0 unassigned variables.\n");
		exit(-1);
	}
}

void verification_cdcl_verifyWatcher2Adaption_case2(int cNum){
	//We do assert here that the number of unassigned variables in this clause is indeed 1.
	if (verification_cdcl_countNumberOfUnassignedVaribales(cNum) != 1){
		printf("c e Error because clause has not equal 1 unassigned variable.\n");
		exit(-1);
	}
	//We also assert that the watched literal 2 is assigned.
	if (tvalue[abs(watchedLiteral2[cNum])] == 2){
		printf("c e Error because other watcher is unassigned too. Cannot force unit prop.\n");
		exit(-1);
	}
}

void verification_cdcl_verifyWatcher2Adaption_case3(int cNum){
	//We do assert here that the number of unassigned variables in this clause is indeed 0.
	if (verification_cdcl_countNumberOfUnassignedVaribales(cNum) != 0){
		printf("c e Error because clause has not equal 0 unassigned variable.\n");
		exit(-1);
	}
	//We also assert that this clause is indeed a conflict.
	if (verification_cdcl_countNumberOfSatsifyingLiterals(cNum) != 0){
		printf("c e Error because supposed conflict has satisfying literal in it.\n");
		exit(-1);
	}
}

void verification_cdcl_verifyWatcher2Adaption_case4(int cNum){
	//We also assert that this clause is indeed satisfied.
	if (verification_cdcl_countNumberOfSatsifyingLiterals(cNum) < 1){
		printf("c e Error because supposedly satisfied clause is not satisfied.\n");
		cdcl_printClauseInline(cNum);
		exit(-1);
	}
}

void verification_cdcl_verifyLearnedClauseIsUnit(){
	//We assert here that the just learned clause is indeed a unit clause.
	if (clauseLiterals[numCDCLClauses][1] != 0){
		//The newly learned clause is no unit clause.
		printf("c e Error because the newly learned clause is treated as unit but it is not.\n");
		exit(-1);
	}
}

void verification_cdcl_verifyVariableStates(){
	//Before each round (decision or conflict handling) of the CDCL, we make sure that alle the stored information
	//about the variables check out. We check:
	//	- is the number of watched clauses by a literal equivalent with the watches[lit][0] information?
	//Add anything else that you want to check on the variables before each round here.
	int pos, lit, num;
	for (lit = -numVars; lit < numVars+1; ++lit){
		pos = 2;
		num = 0;
		while (watches1[lit][pos++] > -1){
			++num;
		}
		if (watches1[lit][0] != num){
			printf("c e Error because the number of watched clauses is not what watches1[lit][0] says.\n");
			exit(-1);
		}
		pos = 2;
		num = 0;
		while (watches2[lit][pos++] > -1){
			++num;
		}
		if (watches2[lit][0] != num){
			printf("c e Error because the number of watched clauses is not what watches2[lit][0] says.\n");
			exit(-1);
		}
	}
}

void verification_cdcl_verifyClauseStates(){
	//We will assert the state of the clauses before each round of the CDCL here. Add anything you want to check
	//for the clauses in each round here.
	int cNum;
	for (cNum = 0; cNum < numCDCLClauses; ++cNum){
		#ifdef PREPROCESSING
		if (cNum < numClauses && isIgnoredClause[cNum]){
			//Ignored clauses do not matter.
			continue;
		}
		#endif
		//We check that a clause is not empty.
		if (clauseLiterals[cNum][0] == 0){
			printf("c e Error because an empty clause was detected.\n");
			exit(-1);
		}
	}
}
#endif /* VERIFICATION_CDCL */
#endif /* HYBRID */
