/*
 * global.h
 *
 *  Created on: 10.09.2010
 *      Author: Oliver Gableske
 *  	Content: This file contains all the global definitions for the SLS component, that can also be used by the CDCL.
 */

#ifndef GLOBAL_H_
#define GLOBAL_H_

//BASIC INCLUDES
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "time.h"

//COMPILE AND FEATURE CONTROL
////GENERAL FLAGS
#define COMPETITION		//Set this for competition mode. Not much output. No memory disposing. No timing. Printing solution.
#define LONGHEADER			//Set this if you want lots of information printed in the header (slow, not necessary).
//#define PRINTSOLUTION		//If you want the solver to print out all assignments of a found solution.
#define DISPOSE				//Set this if you want the solver to cleanup its memory after finishing computations
							//(not too slow but also not necessary in the competition).
#define HYBRID				//Set this if you want the solver to work in hybrid mode.
#define PREPROCESSING		//Set this to use the preprocessor.
//#define TIMING			//Set this to have the SLS check if maximum time is reached if given.

////PREPROCESSOR SPECIFIC FLAGS
	#ifdef PREPROCESSING
		//#define VERBOSE_PREPROC		//Enable this if you want the preprocessor to be verbose (slow).
		//#define COLLINF_PREP			//Set this if you want additional info collected by preprocessor (slow).
		#define PURELIT					//Enable the check for pure literals.
		#define UNITPROP				//Enable the unit clause propagation.
	#endif

////SLS SPECIFIC FLAGS
	//#define VERBOSE_SLS		//Set this if you want the extra talking of the SLS (slow).
	//#define COLLINF_SLS		//Set this to have the solver collect additional information (slow).
	#define VERIFICATION_SLS	//Enable the verification of a found solution (not too slow but also not necessary).
	#define WEIGHTING			//Set this to use clause weighting (suggested).
	#define TABULIST			//Set this if you want to use a TABU-list in greedy search (suggested).

////CDCL SPECIFIC FLAGS
	#ifdef HYBRID
		//#define VERBOSE_CDCL				//Set this if you want the extra talking of the CDCL (slow).
		//#define VERIFICATION_CDCL 		//Have CDCL do consistency checks (extremely slow, really not recommended).
		//#define COLLINF_CDCL				//Set this if you want additional info collected in the CDCL (slow).
		#define UNITWALK					//Set this if you want the CDCL to perform only unit walk (makes solver incomplete).
		//#define USELUBYSERIES				//Set this if you want the CDCL to use the Luby series to determine its runtime.
		#define TRANSFERASSIGNMENTCHANGES	//Set this if you want the CDCL override the SLS assignment with changes.
		#define LEARNUIP					//Set this if you want the learning to be done according to UIP.
		#ifdef LEARNUIP
			//#define FIRSTUIP				//If you want to learn the first UIP conflict clause. Otherwise its last UIP.
		#endif
		//#define RANDOMHEURISTIC			//Set this if you want the CDCL to have the random variable ordering enabled.
		#define HIHEURISTIC					//Set this if you want the CDCL to have the HI-heuristic enabled.
		//#define VSIDSHEURISTIC			//Set this if you want the CDCL to have the VSIDS-heuristic enabled.
		//#define AGEHEURISTIC				//Set this if you want the CDCL to have the AGE-heuristic enabled.
		#ifdef AGEHEURISTIC
			#define AGEYOUNG				//Priority to the youngest variables in CDCL. Otherwise its the oldest.
		#endif
		#ifdef VSIDSHEURISTIC
			#define VSIDSMAX					//Sort variables by maximum score first. Otherwise minimum first.
			#define VSIDS_INCREASEINCONFLICT	//If you want the VSIDS scores bumped in every conflicting clause.
			#ifdef VSIDS_INCREASEINCONFLICT
				double bump_factor_conflict;	//The factor used to bump VSIDS scores of variables in a conflict.
			#endif
			#define VSIDS_INCREASEINFLIPS		//Set this if you want the VSIDS scores bumped in every flip.
			#ifdef VSIDS_INCREASEINFLIPS
				double bump_factor_flips;		//The factor used to bump VSIDS scores of variables being flipped.
			#endif
		#endif
		#define MINIMACALLING					//Check for CDCL call in local minimum only.
		#ifdef MINIMACALLING
			#define DISTRIBUTIONCAUCHY			//Enable the CAUCHY distribution for calculating cool-downs.
		#endif
	#endif

//CONDITIONAL FLAGGING
#ifndef MINIMACALLING
	#define MINIMACALLING
#endif

#ifdef MINIMACALLING
	#ifndef DISTRIBUTIONCAUCHY
		#define DISTRIBUTIONCAUCHY
	#endif
#endif

#ifdef UNITWALK
	#undef LEARNUIP
	#undef VSIDS_INCREASEINCONFLICT
#endif

#ifdef COMPETITION
	//We disable all the stuff that is not absolutely necessary for the solver to work in competition mode.
	#undef LONGHEADER
	#undef VERIFICATION_CDCL
	#undef VERBOSE_SLS
	#undef VERBOSE_CDCL
	#undef VERBOSE_PREPROC
	#undef COLLINF_SLS
	#undef COLLINF_CDCL
	#undef COLLINF_PREP
	#undef TIMING
	#undef DISPOSE
	#define PRINTSOLUTION
#endif

//ADDITIONAL INCLUDES DEPENDING ON THE FLAGS
#include "sls.h"
#ifdef VERIFICATION_SLS
	#include "verification_sls.h"
#endif
#ifdef HYBRID
	#include "cdcl.h"
	#ifdef VERIFICATION_CDCL
		#include "verification_cdcl.h"
	#endif
#endif

//GLOBAL CONSTANTS AND VARIABLES
enum {
	#ifdef TIMING
	TIMECHECKINTERVAL = 600000,	//How many flips may pass before we check the clock?
	#endif
	VERSION_MAJOR = 1,			//The major version of the solver.
	VERSION_SLS = 565,			//The version of the SLS component.
	VERSION_CDCL = 350,			//The version of the CDCL component.
	SAT = 0,					//Return value if formula is satisfiable.
	UNSAT = 1,					//Return value if formula is unsatisfiable.
	UNKNOWN = 2,				//Return value if satisfiability of formula is unknown.
	SOL_SLS = 50,				//The solution was found by the SLS component.
	SOL_CDCL = 51,				//The solution was found by the CDCL component.
	MAXCLAUSESIZE = 255,		//The maximum clause length we assume. We need +1 for termination with 0.
	INTBITS = 8*sizeof(int)		//The number of bits an integer has.
};

#ifdef TABULIST
int tabulistlength;
extern unsigned int TABU;		//The TABU list length.
#endif

extern const float OORANDMAX;	//1.0f divided by RAND_MAX (see top of global.c)
float SP;						//Smoothing probability for walk sat scheme (see top of global.c).

extern float* PS_TABLE;			//Lookup-table for sparrow scores (p_s values; see top of global.c).
extern float PS_TABLE3SAT[10];	//The lookup-table for 3-SAT;
extern float PS_TABLE4SAT[10];	//The lookup-table for 4-SAT;
extern float PS_TABLE5SAT[10];	//The lookup-table for 5-SAT;
extern float PS_TABLE6SAT[10];	//The lookup-table for 6-SAT;
extern float PS_TABLE7SAT[10];	//The lookup-table for >=7-SAT;
extern float ageMeasure;		//The usual age measuring (100000000000000000000.0f in standard sparrow).
extern float ageIgnore;			//The usual ignore for age (10000.0f in standard sparrow).

//GENERAL
char looksrandom;				//Is set to 1 if the formula looks random and to 0 if not.
unsigned char returnValue;		//The return value of certain operations like the preprocessor, the SLS and later the DPLL.
int seed;						//The initial seed for the random number generator.
unsigned int flips;				//The number of flips we have performed so far.
float ra;						//The random number for the smoothing/increasing of clause weights.
FILE *input;					//The file containing the formula in DIMACS CNF INPUT format.
int maxTime;					//The maximum runtime in seconds.
int solutionFoundBy;			//What component found the solution.

//VARIABLE RELATED
int numVars;					//The number of variables in the formula.
int chosenVar;					//The momentarily chosen variable for flipping.
unsigned char* assignment;		//The assignment a variable has.
unsigned int* lastFlipped;		//At what flip was a variable last flipped?
char* score;					//The variables scores.
float* prob;					//The probability for a variable to be chosen using the sparrow scheme.
int** tempClauseAppearance;		//The temporary set of clause appearances for a variable. Used for loading and for preprocessing.
int** clauseAppearance;			//clauseAppearance[i][j]: What is the j-th clause LITERAL i appears in?
int** partners;					//The variables that the specific variable appears together in a clause with. The first two
								//elements in the array of the second dimension tell you how much memory for storing partners
								//is available and how many are in use.
int* decVars;					//The variables with positive score.
unsigned char* isDecVars;		//Is 1 if the corresponding variable is listed in decVars or if blocked.
int numDecVars;					//The number of variables with positive score.

//CLAUSE RELATED
int minClauseSize;				//The size of the smallest clause.
int maxClauseSize;				//The size of the largest clause.
int numClauses;					//The number of clauses in the formula.
int* clauses;					//This is the array storing the formula in a linear way. Never access this directly.
int** clauseLiterals;			//Points into the clauses array. clauseLiterals[i][j] gives you the j-th literal of clause i.
int numOriginalClauses;			//The number of original clauses of the formula.
int* largeWeightClauses;		//All clauses that have weight > 1.
int numLargeWeightClauses;		//The number of clauses with weight > 1.
unsigned char weightStepping;	//The amount of a single weight increase.
int* unsatClauses;				//The numbers of the unsatisfied clauses.
int numUnsatClauses;			//The number of unsatisfied clauses under the current assignment.
unsigned char* clauseSize;		//The size of a clause.
unsigned char* numTrue;			//The number of true literals in a clause.
short int* trueVar;				//One variable making the clause true (might be out-dated for clauses with several true vars).
unsigned char* weight;			//The current weight of a clause. Must not be larger than 255!
int* whereUnsat;				//Where this clause is found in the unsatClauses array.
int** tempClauseLiterals;		//Its clauseLiterals that are initialized way to large to read the formula
								//while the size of the clauses is yet unknown.
								//This array gets copied over to clauseLiterals once the length of all
								//clauses is known. The method copying over to clauseLiterals and freeing
								//the tempClauseLiterals is allocateAndInitializeSecondary().

//GLOBAL FORWARD DECLARATIONS
inline int abs(int);
int arrayContains(int*,int,int);
void readInteger(int, char**, int, int*);
void readUnsignedInteger(int, char**, int, unsigned int*);
void readDouble(int, char**, int, double*);
void readFloat(int, char**, int, float*);
void readParameters(int, char**);
#ifdef VERBOSE_SLS
void printClauseInline(int**,int,int);
void printClauses();
void printLargeWeightClauses();
void printVariables();
void printVariableScores();
void printUnsatClauses();
void printDecVars();
void printDecVarsInline();
void printCurrentAssignment();
void printCurrentAssignmentInline();
#endif
#ifdef LONGHEADER
void printFormulaStats();
#endif
void printHeader();
void printSolution();
void printStats();
char isFormulaRandom();
void allocateAndInitializePrimary();
void allocateAndInitializeSecondary();
#ifdef DISPOSE
void sls_dispose();
#endif
void adaptToInstance();
void loadFormula();
int main(int, char**);
#endif /* GLOBAL_H_ */
