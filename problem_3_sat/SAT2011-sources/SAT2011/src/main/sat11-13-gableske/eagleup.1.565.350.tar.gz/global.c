/**
 * global.c
 *
 *   Created on: 10.09.2010
 *  	 Author: Oliver Gableske
 *  	Content: This file contains all the important functions and parameters for the SLS component, that can
 *  			 also be used by the CDCL.
 */

#include "global.h"
#ifdef PREPROCESSING
#include "preprocessor.h"
#endif

#ifdef TABULIST
unsigned int TABU = 3;							//The TABU list length.
#endif
const float OORANDMAX = 1.0f/RAND_MAX;  		//Needed constant in the optimized sparrow calculations.
float SP = 0.347f;						//The smoothing probability for the clause weighting scheme. 0.347 is optimal on 3-SAT.
float ageMeasure = 100000000000000000000.0f;	//The age weighting in the Sparrow scheme.
float ageIgnore = 10000.0f;						//The age gets ignored below this value.
float* PS_TABLE;								//We use one of the following to lookup the scores in a table:
//Lookup-table 3-SAT Sparrow C1 value: 4.16
float PS_3SAT[10] = {
		9.5367431640625E-7f,		//1.0/1048576.0
		0.25f,						//1.0/4.0
		0.0625f,					//1.0/16.0
		0.015625f,					//1.0/64.0
		0.00390625f,				//1.0/256.0
		9.765625E-4f,				//1.0/1024.0
		2.44140625E-4f,				//1.0/4096.0
		6.103515625E-5f,			//1.0/16384.0
		1.52587890625E-5f,			//1.0/65536.0
		3.814697265625E-6f			//1.0/262144.0
		/* More optimal setting:
		6.442681968934999E-7f,		//1.0/1552148.631302538
		0.24038461538461536f,		//1.0/4.16
		0.05778476331360946f,		//1.0/17.305600000000002
		0.013890568104233045f,		//1.0/71.991296
		0.003339078871209866f,		//1.0/299.48379136000005
		8.026631901946792E-4f,		//1.0/1245.8525720576004
		1.9294788225833636E-4f,		//1.0/5182.7466997596175
		4.638170246594623E-5f,		//1.0/21560.22627100001
		1.1149447708160153E-5f,		//1.0/89690.54128736004
		2.6801556990769594E-6f		//1.0/373112.6517554178
		*/
};
//Lookup-table 4-SAT Sparrow C1 value: 3.14
float PS_4SAT[10] = {
		1.0732564799232118E-5f,		//1.0/93174.3733866435
		0.3184713375796178f,		//1.0/3.14
		0.1014239928597509f,		//1.0/9.8596
		0.03230063466871048f,		//1.0/30.959144000000002
		0.010286826327614802f,		//1.0/97.21171216
		0.003276059340004714f,		//1.0/305.2447761824
		0.0010433310000015012f,		//1.0/958.4685972127361
		3.3227101910875834E-4f,		//1.0/3009.5913952479914
		1.0581879589450901E-4f,		//1.0/9450.116981078694
		3.370025346958886E-5f		//1.0/29673.367320587102
};
//Lookup-table 5-SAT Sparrow C1 value: 2.13
float PS_5SAT[10] = {
		5.202402690630164E-4f,		//1.0/1922.188764435824
		0.4694835680751174f,		//1.0/2.13
		0.2204148206925434f,		//1.0/4.536899999999999
		0.10348113647537249f,		//1.0/9.663596999999998
		0.04858269318092606f,		//1.0/20.583461609999993
		0.02280877614127984f,		//1.0/43.842773229299986
		0.010708345606234666f,		//1.0/93.38510697840897
		0.005027392303396557f,		//1.0/198.9102778640111
		0.0023602780767119987f,		//1.0/423.67889185034363
		0.001108111773104225f		//1.0/902.4360396412319
};
//Lookup-table 6-SAT Sparrow C1 value: 1.98
float PS_6SAT[10] = {
		0.0010798118704315241f,		//1.0/926.0872448090156
		0.5050505050505051f,		//1.0/1.98
		0.2550760126517702f,		//1.0/3.9204
		0.12882626901604557f,		//1.0/7.762391999999999
		0.06506377223032606f,		//1.0/15.36953616
		0.032860491025417195f,		//1.0/30.431681596799997
		0.016596207588594546f,		//1.0/60.25472956166399
		0.008381923024542699f,		//1.0/119.30436453209471
		0.004233294456839747f,		//1.0/236.2226417735475
		0.0021380275034544177f		//1.0/467.72083071162405
};
//Lookup-table 7-SAT Sparrow C1 value: 1.84. This is also used for instances with k > 7.
float PS_7SAT[10] = {
		0.0022481318057713503f,		//1.0/444.8137771249995
		0.5434782608695652f,		//1.0/1.84
		0.2953686200378072f,		//1.0/3.3856
		0.16052642393359084f,		//1.0/6.229504
		0.0872426217030385f,		//1.0/11.462287360000001
		0.04741446831686875f,		//1.0/21.090608742400004
		0.02576873278090693f,		//1.0/38.80672008601601
		0.014004746076579852f,		//1.0/71.40436495826945
		0.007611275041619484f,		//1.0/131.3840315232158
		0.0041365625226192845f		//1.0/241.7466180027171
};

//The abstract method using bit-shifts.
inline int abs(int i){return (i + (i >> (INTBITS - 1))) ^ (i >> (INTBITS - 1));}

//This method returns the position of value in array. The array must be terminated with the terminator. If the
//element value is not found in the array, the method will return the position of the found terminator with a
//negative sign. If value is found in the array it returns the position of the element with a positive sign.
int arrayContains(int* array, int value, int terminator){
	register int i;
	for (i = 0; 1; i++){
		if (array[i] == terminator) return -i;
		if (array[i] == value) return i;
	}
	return 0;
}

//To read an integer from the parameters of the program call.
void readInteger(int argc, char *argv[], int i, int *varptr) {
	if (i >= argc || sscanf(argv[i],"%i", varptr)!=1){
		fprintf(stderr, "Error while reading the integer: %s.\n", i<argc ? argv[i] : argv[argc-1]);
		exit(-1);
	}
}

//To read an unsigned integer from the parameters of the program call.
void readUnsignedInteger(int argc, char *argv[], int i, unsigned int *varptr) {
	if (i >= argc || sscanf(argv[i],"%u", varptr)!=1){
		fprintf(stderr, "Error while reading the unsigned integer: %s.\n", i<argc ? argv[i] : argv[argc-1]);
		exit(-1);
	}
}

//To read a float from the parameters of the program call.
void readFloat(int argc, char *argv[], int i, float *varptr) {
	if (i >= argc || sscanf(argv[i],"%f", varptr)!=1){
		fprintf(stderr, "Error while reading the float: %s.\n", i<argc ? argv[i] : argv[argc-1]);
		exit(-1);
	}
}

//To read a double from the parameters of the program call.
void readDouble(int argc, char *argv[], int i, double *varptr) {
	if (i >= argc || sscanf(argv[i],"%lf", varptr)!=1){
		fprintf(stderr, "Error while reading the double: %s.\n", i<argc ? argv[i] : argv[argc-1]);
		exit(-1);
	}
}

//To read all the parameters of the program call.
void readParameters(int argc, char* argv[]){
	if (argc < 2){
		printf("c\n");
		printf("c Too few parameters. Exiting.\n");
		printf("c USAGE: ./EagleUP BENCHNAME RANDOMSEED [TIMEOUTINSECONDS]\n");
		exit(-1);
	}
	#ifdef LONGHEADER
	printf("c\tTrying to open the file %s...\n", argv[1]);
	#endif
	input = fopen(argv[1], "r");
	if (input == NULL) {
		printf("c e Error. You must specify an input file that you have read access to!\n");
		fprintf(stderr, "c e Error. You must specify an input file that you have read access to!\n");
		exit(-1);
	}

	if (argc > 2){
		#ifdef LONGHEADER
		printf("c\tTrying to read seed... ");
		#endif
		readInteger(argc, argv, 2, &seed); //Additionally provided seed.
		#ifdef LONGHEADER
		printf("%i.\n",seed);
		#endif
		srand(seed);
	} else {
		#ifdef LONGHEADER
		printf("c\tTrying to generate seed... ");
		#endif
		seed = (int)time(NULL);
		seed = seed << 16 | seed >> 16;
		seed = abs(seed);
		#ifdef LONGHEADER
		printf("%i.\n",seed);
		#endif
		srand(seed);
	}
	#ifdef TIMING
	if (argc > 3){
		#ifdef LONGHEADER
		printf("c\tTrying to read max time in seconds... ");
		#endif
		readInteger(argc, argv, 3, &maxTime);
		#ifdef LONGHEADER
		printf("%i.\n",maxTime);
		#endif
		if (maxTime < 0){
			fprintf(stderr,"c Error. You need to specify a positive time. 0 seconds means no timeout.");
			exit(-1);
		}
	} else {
		#ifdef LONGHEADER
		printf("c\tNo maxTime given, assuming infinite run.\n");
		#endif
		maxTime = 0;
	}
	#else
	#ifdef LONGHEADER
	printf("c\tTiming disabled, assuming infinite run.\n");
	#endif
	maxTime = 0;
	#endif


	//This part here can be used to read parameters from the command line. It is disabled for the competition.
	/*
	if (argc > 4){
		#ifdef LONGHEADER
		printf("c\tTrying to read weight stepping... ");
		#endif
		int temp;
		readInteger(argc, argv, 4, &temp);
		weightStepping = (unsigned char) temp;
		#ifdef LONGHEADER
		printf("%i.\n",weightStepping);
		#endif
	}

	if (argc > 5){
		#ifdef LONGHEADER
		printf("c\tTrying to read smooth probability... ");
		#endif
		readFloat(argc, argv, 5, &SP);
		#ifdef LONGHEADER
		printf("%f.\n",SP);
		#endif
	}

	if (argc > 6){
		#ifdef LONGHEADER
		printf("c\tTrying to read tabu list length... ");
		#endif
		readInteger(argc, argv, 6, &tabulistlength);
		#ifdef LONGHEADER
		printf("%i.\n",tabulistlength);
		#endif
	}

	if (argc > 7){
		#ifdef HYBRID
			#ifdef DISTRIBUTIONCAUCHY
				#ifdef LONGHEADER
				printf("c\tTrying to read cool-down parameters... ");
				#endif
				readDouble(argc, argv, 7, &CAUCHY_GAMMA);
				readDouble(argc, argv, 8, &CAUCHY_OFFSET_FRACTION);
				readInteger(argc, argv, 9, &CAUCHY_FLIPINCREASE);
				readInteger(argc, argv, 10, &CAUCHY_TABSIZE);
				#ifdef LONGHEADER
				printf("%f %f %i %i done.\n", CAUCHY_GAMMA, CAUCHY_OFFSET_FRACTION, CAUCHY_FLIPINCREASE, CAUCHY_TABSIZE);
				#endif
			#endif
		#endif
	}
	*/

	#ifdef LONGHEADER
	printf("c\n");
	#endif
}

#ifdef VERBOSE_SLS
//What follows is a set of functions used to produce some human readable output.

//To print a clause in-line. This method does not produce a comment symbol and it does not produce a new-line.
void printClauseInline(int** clauseLiterals,int cNum, int condensed){
	register int i;
	if (condensed){
		printf("[%6.1i] ", cNum);
	} else {
		printf("[%6.1i|%3.1i] ",cNum,weight[cNum]);
	}
	for (i = 0; i < clauseSize[cNum]; i++){
		printf("%6.1i ", clauseLiterals[cNum][i]);
	}
}

//This method outputs the numbers of all clauses having a weight > 1.
void printLargeWeightClauses(){
	register int i;
	printf("c The %i clauses with weight > 1 are:\nc ",numLargeWeightClauses);
	for (i = 0; i < numLargeWeightClauses; i++){
		printf("%i(%i) ",largeWeightClauses[i],weight[largeWeightClauses[i]]);
	}
	printf("\nc\n");
}

//This method is used to print out all the clauses.
void printClauses(){
	register int i,j,satisfiedBy;
	printf("c The %i clauses of the formula [cNum|weight][isIgnored]{Literals}<numTrue>(trueVar):\n",numClauses);
	for (i = 0; i < numClauses; i++){
		satisfiedBy = 0;
		printf("c [%i\t|%i\t]",i,weight[i]);
		#ifdef PREPROCESSING
		printf("[%i] ",isIgnoredClause[i]);
		#else
		printf(" ");
		#endif
		for (j = 0; j < clauseSize[i]; j++){
			printf("%i{%i}\t",clauseLiterals[i][j],assignment[abs(clauseLiterals[i][j])]);
			if ((assignment[abs(clauseLiterals[i][j])] > 0) == (clauseLiterals[i][j] > 0)){
				satisfiedBy++;
			}
		}
		if (numTrue[i] > 0){
			printf("0\t\t<%i>(%i)\n",satisfiedBy, trueVar[i]);
		}else{
			printf("0\t\t<%i>(%i)\t UNSAT\n",satisfiedBy, trueVar[i]);
		}
	}
	printf("c\n");
}

//This method is used to print out all the variables along with their appearance listes and the partners they have.
void printVariables(){
	register int i,j,cNum,count;
	printf("c The %i variables of the formula appear in the flowing clauses:\n",numVars);
	for (i = 1; i < numVars+1; i++){
		count = 0;
		printf("c [%i\t]\t",i);
		for (j=0; (cNum = clauseAppearance[i][j]) > -1; j++){
			printf("%i ",cNum);
			++count;
		}
		printf(" (%i total)\n",count);
		count = 0;
		printf("c [%i\t]\t",-i);
		for (j=0; (cNum = clauseAppearance[-i][j]) > -1; j++){
			++count;
			printf("%i ",cNum);
		}
		printf(" (%i total)\n",count);
	}
	printf("c\n");
	printf("c The partners of the specific variable(number of Partners):\n");
	for (i = 1; i < numVars+1; i++){
		printf("c Partners %i:\t",i);
		count = 0;
		for (j=0; partners[i][j] != 0; j++){
			printf("%5.i ", partners[i][j]);
			++count;
		}
		printf(" (%i total)\n",count);
	}
	printf("c\n");
	printf("c The initial assignment of the variables:");
	for (i = 1; i < numVars+1; i++){
		if (i % 10 == 1) printf("\nc ");
		printf("%7.i ", assignment[abs(i)] > 0 ? i : -i);
	}
	printf("\nc\n");
}

//This method is used to print out all the scores of the varibales.
void printVariableScores(){
	register int i;
	register int sum = 0;
	for (i = 0; i < numUnsatClauses; i++){
		sum = sum + weight[unsatClauses[i]];
	}
	printf("c The scores of the variables:\n");
	for (i = 1; i < numVars+1; i++){
		printf("c\tVariable %i:\t%i\tisDecVars: %i ",i, score[i], isDecVars[i]);
		if (score[i] == sum){
			printf(" Final flip possible!!! (flips:%u)\n", flips);
			//if (!isDecVars[i] && numUnsatClauses > 0) exit(0);
		} else {
			printf("\n");
		}
	}
	printf("c\nc\n");
}

//To print out all the decreasing variables from the decVars array.
void printDecVars(){
	register int i;
	printf("c The %i decreasing variables are:\nc ",numDecVars);
	for (i = 0; i < numDecVars; i++){
		printf("%i(%i) ", decVars[i], score[decVars[i]]);
	}
	printf("\nc\n");
}

//To print out all the decreasing variables from decVars in-line.
void printDecVarsInline(){
	register int i;
	printf("[%i]: ",numDecVars);
	for (i = 0; i < numDecVars; i++){
		printf("%i(%i) ", decVars[i], score[decVars[i]]);
	}
}

//To print out all the unsatisfied clauses under the current assignment of the SLS.
void printUnsatClauses(){
	register int i;
	printf("c The %i unsatisfied Clauses:\nc ", numUnsatClauses);
	for (i = 0; i < numUnsatClauses; i++){
		printf("%i(%i) ", unsatClauses[i], weight[unsatClauses[i]]);
	}
	printf("\nc\n");
}

//To print out the current assignment as a bit-string.
void printCurrentAssignment(){
	register int i;
	printf("c Current assignment: ");
	for (i = 1; i < numVars+1; i++){
		printf("%i",assignment[i]);
	}
	printf("\n");
}

//To print out the current assignment as a bit-string in-line.
void printCurrentAssignmentInline(){
	register int i;
	printf("Assignment: ");
	for (i = 1; i < numVars+1; i++){
		printf("%i",assignment[i]);
	}
	printf(" ");
}
#endif

#ifdef LONGHEADER
//To print out some formula statistics.
void printFormulaStats(){
	printf("c\n");
	printf("c Formula stats:\n");
	printf("c\tType:\t\t\t\tCNF\nc\tVariables:\t\t\t%i\nc\tClauses:\t\t\t%i\nc\tSmallest clause:\t%i\nc\tLargest clause:\t%i\n",
			numVars, numClauses, minClauseSize, maxClauseSize);
	int* numClausesOfSize = malloc(sizeof(int)*(maxClauseSize+1));
	int i;
	for (i = 0; i < maxClauseSize+1; ++i){
		numClausesOfSize[i] = 0;
	}
	for (i = 0; i < numClauses; ++i){
		#ifdef PREPROCESSING
		if (isIgnoredClause[i]) continue;
		#endif
		++numClausesOfSize[clauseSize[i]];
	}
	printf("c\tNumber of clauses of specific size:\n");
	for (i = 1; i < maxClauseSize+1; ++i){
		if (numClausesOfSize[i] != 0)
		printf("c\t\t%6.1i:%20.1i\n",i,numClausesOfSize[i]);
	}
	free(numClausesOfSize);
	printf("c\n");
}
#endif

//This method is used to print out all the header information like version and authors.
void printHeader(){
	#ifdef HYBRID
	printf("c EagleUP SAT solver\n");
	#else
	printf("c Eagle SAT solver\n");
	#endif
	printf("c\tAUTHOR:\t\tOliver Gableske\t<oliver.gableske at uni-ulm.de>\t"
			"(Implemented most of the solver.)\n"
		   "c\tCONTRIBUTORS:\tJulian Rueth\t<julian.rueth at gmail.com>\t"
		   "(Implemented the Luby-series calculation.)\n"
		   "c\t\t\tMarijn Heule\t<marijn at heule.nl>\t\t(Provided various ideas.)\n");
	printf("c\tVERSION:\t%i.%i.%i\n", VERSION_MAJOR, VERSION_SLS,VERSION_CDCL);
	#ifdef LONGHEADER
	printf("c\t\t\tSLS COMPONENT:  %i \"Silvester Stallone\"\n",VERSION_SLS);
	printf("c\t\t\tDPLL COMPONENT: %i \"Arnold Schwarzenegger\"\n",VERSION_CDCL);
	printf("c\tLICENSE:\tFree use for scientific and teaching purposes, "
			"costly if you use it commercially (contact the author).\n");
	printf("c\tCONSTANTS:\tMAXCLAUSESIZE:\t\t%i\n"
			"c\t\t\tRAND_MAX:\t\t%i\n"
			"c\t\t\tOORANDMAX:\t\t%.20f\n"
			"c\t\t\tSP:\t\t\t%.4f\n"
			"c\t\t\tINTBITS:\t\t%i\n"
			#ifdef TIMING
			"c\t\t\tTIMECHECKINTERVAL:\t%i\n"
			#endif
			#ifdef HYBRID
			#ifdef HIHEURISTIC
			"c\t\t\tHIDEPTH:\t\t%i\n"
			#endif
			"c\t\t\tMAXINITDECLEVELS:\t%i\n"
			"c\t\t\tMAXINITELEMENTS:\t%i\n",
			#else
			,
			#endif
			MAXCLAUSESIZE,RAND_MAX,OORANDMAX,SP,INTBITS
			#ifdef TIMING
			,TIMECHECKINTERVAL
			#endif
			#ifdef HYBRID
			#ifdef HIHEURISTIC
			,HIDEPTH
			#endif
			,MAXINITDECLEVELS,MAXINITELEMENTS
			#endif
			);
	printf("c\tFLAGS:\t\tGENERAL:\t");
	#ifdef LONGHEADER
	printf("LONGHEADER ");
	#endif
	#ifdef PRINTSOLUTION
	printf("PRINTSOLUTION ");
	#endif
	#ifdef DISPOSE
	printf("DISPOSE ");
	#endif
	#ifdef TIMING
	printf("TIMING ");
	#endif
	#ifdef PREPROCESSING
	printf("\nc\t\t\tPREPROCESSOR:\t");
		printf("PREPROCESSING ( ");
		#ifdef VERBOSE_PREPROC
		printf("VERBOSE_PREPROC ");
		#endif
		#ifdef COLLINF_PREP
		printf("COLLINF_PREP ");
		#endif
		#ifdef UNITPROP
		printf("UNITPROP ");
		#endif
		#ifdef PURELIT
		printf("PURELIT ");
		#endif
		printf(") ");
	#endif
	printf("\nc\t\t\tSLS:\t\t");
	#ifdef WEIGHTING
	printf("WEIGHTING ");
	#endif
	#ifdef TABULIST
	printf("TABULIST ");
	#endif
	#ifdef VERBOSE_SLS
	printf("VERBOSE_SLS ");
	#endif
	#ifdef COLLINF_SLS
	printf("COLLINF_SLS ");
	#endif
	#ifdef VERIFICATION_SLS
	printf("VERIFICATION_SLS ");
	#endif
	#ifdef HYBRID
	printf("\nc\t\t\tCDCL:\t\t");
		printf("HYBRID ( ");
		#ifdef VERIFICATION_CDCL
		printf("VERIFICATION_CDCL ");
		#endif
		#ifdef COLLINF_CDCL
		printf("COLLINF_CDCL ");
		#endif
		#ifdef TRANSFERASSIGNMENTCHANGES
		printf("TRANSFERASSIGNMENTCHANGES ");
		#endif
		#ifdef MINIMACALLING
		printf("MINIMACALLING ( ");
			#ifdef DISTRIBUTIONCAUCHY
			printf("DISTRIBUTIONCAUCHY");
			#endif
		printf(" ) ");
		#endif
		#ifdef LEARNUIP
		printf("LEARNUIP ( ");
			#ifdef FIRSTUIP
				printf("FIRSTUIP ");
			#else
				printf("LASTUIP ");
			#endif
		printf(") ");
		#endif
		#ifdef UNITWALK
		printf("UNITWALK ");
		#endif
		#ifdef RANDOMHEURISTIC
		printf("RANDOMHEURISTIC ");
		#endif
		#ifdef HIHEURISTIC
		printf("HIHEURISTIC ");
		#endif
		#ifdef AGEHEURISTIC
		printf("AGEHEURISTIC ( ");
			#ifdef AGEYOUNG
			printf("AGEYOUNG ");
			#endif
			printf(") ");
		#endif
		#ifdef VSIDSHEURISTIC
			printf("VSIDSHEURISTIC ( ");
			#ifdef VSIDS_INCREASEINCONFLICT
			printf("VSIDS_INCREASEINCONFLICT ");
			#endif
			#ifdef VSIDS_INCREASEINFLIPS
			printf("VSIDS_INCREASEINFLIPS ");
			#endif
			#ifdef VSIDSMAX
			printf("VSIDSMAX ");
			#else
			printf("VSIDS_USEMIN ");
			#endif
			printf(") ");
		#endif
		printf(") ");
	#endif
	printf("\n");
	#else
	printf("c\tINFO:\t\tRe-compile without the flag COMPETITION and the following flags in global.h enabled to see further\n"
			"c\t\t\toutput: LONGHEADER,VERBOSE_SLS,VERBOSE_CDCL,VERBOSE_PREPROC,COLLINF_SLS,COLLINF_CDCL,COLLINF_PREP.\n");
	#endif
	printf("c\n");
}

//To print out the solution if the formula is satisfiable.
void printSolution(){
	printf("s SATISFIABLE\n");
	#ifdef PRINTSOLUTION
	register int i;
	printf("v ");
	for (i = 1; i < numVars+1; i++){
		printf("%i ", assignment[i] == 0 ? -i : i);
	}
	printf("0\n");
	#else
	printf("c Satisfying assignment is omitted. Use the flag PRINTSOLUTION if you want to see it.\n");
	#endif
}

//To print the final statistics and information gathered during the search.
void printStats(){
	printf("c\n");
	printf("c STATS:\n");
	#ifdef PREPROCESSING
	#ifdef COLLINF_PREP
	printf("c\tPREPROCESSING RELATED STATS:\n");
	#ifdef UNITPROP
	printf("c\t\tNumber of unit propagations: %i\n",preproc_unitProps);
	#endif
	#ifdef PURELIT
	printf("c\t\tNumber of removed pure literals (clauses therefore ignored): %i (%i)\n"
			,preproc_pureLits, preproc_pureLitsIgnoredCls);
	#endif
	#endif
	#endif
	#ifdef COLLINF_SLS
	printf("c\tSLS RELATED STATS:\n");
	printf("c\t\tFlips by variable / back to back flips by variable (while random)/ longest marking distance:\n");
	int i;
	for (i = 1; i < numVars+1; i++){
	printf("c\t\t\t%i:\t%i\t/\t%i (%i)\t %i (%i)\n",
			i,variables[i].numFlipped,variables[i].numBackToBackFlips, variables[i].numBackToBackRand,
			variables[i].longestMarkingDistance, variables[i].longestMarkingDistEnd);
	}
	printf("c\t\tMax variable score ever occurred: %i\n",maxVariableScore);
	printf("c\t\tMin variable score ever occurred: %i\n",minVariableScore);
	printf("c\t\tHow often a variable was added to decVars during clause weight increase: %i\n",addIncrease);
	printf("c\t\tHow often a variable was added to decVars during clause weight decrease: %i\n",addDecrease);
	printf("c\t\tRandom flips: %i\n",numRandomFlip);
	printf("c\t\tQuotient random flips / flips: %f\n", ((double)numRandomFlip) / ((double)flips));
	printf("c\t\tFlipped back to back: %i\n", doubleFlips);
	printf("c\t\tQuotient back to back / flips: %f\n", ((double) doubleFlips) / ((double) flips));
	printf("c\t\tThe number of times some clause changed its numTrue: %i\n", clauseStateChangesTotal);
	printf("c\t\tA literal became true  in a clause with no   true literal: %i\n", litTrueOne);
	printf("c\t\tA literal became true  in a clause with one  true literal: %i\n", litTrueTwo);
	printf("c\t\tA literal became true  in a clause with more than one true literal: %i\n", litTrueMore);
	printf("c\t\tA literal became false in a clause with one  true literal: %i\n", litFalseZero);
	printf("c\t\tA literal became false in a clause with two  true literals: %i\n", litFalseOne);
	printf("c\t\tA literal became false in a clause with more than two true literals: %i\n", litFalseMore);
	printf("c\t\tSearches for a new true variable: %i\n", trueVarMiss);
	printf("c\t\tMax clause weight ever occurred: %i\n",maxClauseWeight);
	printf("c\t\tNumber of clause weight decreases: %i\n", numWeightDecrease);
	printf("c\t\tNumber of clause weight increases: %i\n", numWeightIncrease);
	printf("c\t\tNumber of clause weight checks: %i\n", numCheckClauseWeight);
	printf("c\t\tMaximum number of clause appearances of a single literal: %i\n", maxNumClauseAppearance);
	printf("c\t\tNumber of assignments leaving only one clause unsatisfied: %i\n", numOfLocalMinima);
	#endif
	#ifdef COLLINF_CDCL
	printf("c\tCDCL RELATED STATS\n");
	if (cdcl_callNumber > 0){
		printf("c\t\tMean call distance in flips: %u\n", cdcl_callDistances / cdcl_callNumber);
	} else {
		printf("c\t\tMean call distance in flips: nan\n");
	}
	#ifdef TRANSFERASSIGNMENTCHANGES
	if (cdcl_callNumber > 0){
	printf("c\t\tNumber of assignments changes in the SLS assignment: %i (%i on average)\n",
			cdcl_numTransferredAssignmnetChanges, (int) (cdcl_numTransferredAssignmnetChanges/cdcl_callNumber));
	} else {
		printf("c\t\tNumber of assignments changes in the SLS assignment: 0 (0 on average)\n");
	}
	#endif
	printf("c\t\tNumber of back-jumps in last call: %i\n",cdcl_numBackjumpsLastCall-1);
	printf("c\t\tNumber of unit propagations based on learned in last call: %i\n",cdcl_numPropsBasedOnLearnedLastCall);
	printf("c\t\tNumber of unit propagations based on learned total: %i\n",cdcl_numPropsBasedOnLearned);
	printf("c\t\tNumber of enlargements of the unit propagation buffer: %i\n",cdcl_numUnitPropBufferIncreases);
	printf("c\t\tMaximum of the necessary number of unsatisfied clauses: %i\n", cdcl_maxNecNumUnsatCls);
	printf("c\t\tIncreases of the necessary number of unsatisfied clauses: %i\n", cdcl_necNumUnsatClsIncreases);
	printf("c\t\tDecreases of the necessary number of unsatisfied clauses: %i\n", cdcl_necNumUnsatClsDecreases);
	printf("c\t\tMaximum decision level: %i\n", maxDecLevel);
	printf("c\t\tTotal number of decisions: %i\n", cdcl_numberOfDecisions);
	printf("c\t\tTotal number of back-jumps: %i\n", cdcl_numberOfBackjumps);
	printf("c\t\tTotal number of learned clauses of length:\n");
	int length,totalLearned=0;
	for (length = 0; length < numVars; length++){
		if (cdcl_learnedClausesOfLength[length] > 0){
			printf("c\t\t\t%6.1i:%20.1i\n",length,cdcl_learnedClausesOfLength[length]);
			totalLearned += cdcl_learnedClausesOfLength[length];
		}
	}
	printf("c\t\t\t TOTAL:%20.1i\n",totalLearned);
	#endif
	printf("c\tGLOBAL STATS:\n");
	#ifdef HYBRID
	if (returnValue != UNKNOWN){
		if (solutionFoundBy == SOL_SLS)	printf("c\t\tSolution found by:\tSLS ");
		else printf("c\t\tSolution found by:\tCDCL ");
		if (returnValue == SAT) printf("(SATISFIABLE)\n");
		else printf("(UNSATISFIABLE)\n");
	}
	#endif
	printf("c\t\tSeed:\t\t\t%i\n", seed);
	printf("c\t\tSLS flips:\t\t%u\n",flips);
	#ifdef HYBRID
	printf("c\t\tCDCL calls:\t\t%i\n", cdcl_callNumber);
	#endif
	float totaltime = ((float)clock())/((float)CLOCKS_PER_SEC);
	printf("c\t\tTotal time:\t\t%f seconds\n", totaltime);
	#ifdef HYBRID
	#ifdef TIMING
	float slstime = totaltime - cdcl_runtime;
	printf("c\t\tSLS time:\t\t%f scenods (%.3f%%)\n", slstime, (slstime/totaltime)*100.0f);
	printf("c\t\tCDCL time:\t\t%f seconds (%.3f%%)\n",cdcl_runtime, (cdcl_runtime/totaltime)*100.0f);
	#endif
	#endif
}

//This method checks if the formula is random.
char isFormulaRandom(){
	//This method will check whether the investigated formula is a random formula.
	return minClauseSize == maxClauseSize ? 1 : 0; //Very simple check.
}

//This method allocates the primary (partially temporary) memory for the solver.
void allocateAndInitializePrimary(){
	register int i;
	//The primary memory is the memory that we have to allocate before we can load anything from the
	//formula file. Here we initialize the tempClauseLiterals array with clauses of super large size, simply
	//because we do not know how big a clause can be.
	//We also do allocate memory for all the data structures we already know the size of. For example, the
	//unsatClauses array, that will later hold the clause numbers of the unsatisfied clauses, must have size
	//numClauses (in the worst case, all clauses could be unsatisfied).
	//Refer to the global.h file for a description of each variable initialized here.
	#ifdef LONGHEADER
	printf("c Allocating primary memory... ");fflush(stdout);
	#endif
	//GENERAL
	returnValue 				= UNKNOWN;
	flips 						= 0;
	numUnsatClauses 			= 0;
	numLargeWeightClauses 		= 0;
	chosenVar 					= 0;
	numDecVars 					= 0;
	solutionFoundBy				= SOL_SLS;
	numOriginalClauses 			= numClauses;
	minClauseSize 				= MAXCLAUSESIZE;
	maxClauseSize 				= 0;

	//VARIABLE SPECIFIC ARRAYS
	decVars 				= malloc(sizeof(int)*(numVars+1)); //Does not need to be initialized.
	isDecVars				= malloc(sizeof(unsigned char)*(numVars+1)); //Is initialized later.

	assignment				= malloc(sizeof(unsigned char)*(numVars+1));
	for (i = 0; i < numVars+1; i++){assignment[i] = rand()%2;}

	lastFlipped				= malloc(sizeof(unsigned int)*(numVars+1));
	for (i = 0; i < numVars+1; i++){lastFlipped[i] = 0;}

	score					= malloc(sizeof(char)*(numVars+1));
	for (i = 0; i < numVars+1; i++){score[i] = 0;}

	//CLAUSE SPECIFIC ARRAYS
	clauseSize				= malloc(sizeof(unsigned char)*numClauses);
	for (i = 0; i < numClauses; i++){clauseSize[i] = 0;}

	numTrue					= malloc(sizeof(unsigned char)*numClauses);
	for (i = 0; i < numClauses; i++){numTrue[i] = 0;}

	trueVar					= malloc(sizeof(short int)*numClauses);
	for (i = 0; i < numClauses; i++){trueVar[i]	= 0;}

	weight					= malloc(sizeof(unsigned char)*numClauses);
	//Is initialized later during adaption. This is necessary because we do not know the base clause-weight yet.

	whereUnsat				= malloc(sizeof(int)*numClauses);
	//Does not need to be initialized. This gets updated whenever a clause is added to unsatClauses.

	unsatClauses 			= malloc(sizeof(int)*numClauses);
	//Does not need to be initialized. Gets updated when clauseLiterals are loaded in secondary memory method.

	largeWeightClauses 		= malloc(sizeof(int)*numClauses);
	//Does not need to be initialized. There are no clauses with weight > 1 in the beginning anyway.

	//TEMPORARY ARRAYS
	tempClauseAppearance	= malloc(sizeof(int*)*(2*numVars+1));
	for (i = 0; i < 2*numVars+1; i++){
		//We allocate very small arrays and increase every time we need more memory.
		tempClauseAppearance[i]			= malloc(sizeof(int)*18);
		tempClauseAppearance[i][0]		= 0;	//We do not yet have a temporary appearance of the literal.
		tempClauseAppearance[i][1]		= 16;	//We have 16 integers ready to store appearances.
		tempClauseAppearance[i][2]		= -1;	//Clause appearance arrays are always terminated with a -1.
	}
	tempClauseAppearance += numVars;//We shift the array pointer to the center for easier literal access later.
	//The second dimension of tempClauseLiterals is initialized in the method loadFormula().
	tempClauseLiterals		= malloc(sizeof(int*)*numClauses);

	#ifdef COLLINF_SLS
	//When collecting additional information, the solver will initialize and use a ton of more variables.
	//They slow it down of course, thats why we will not have this in the competition version of the solver.
	variables 								= malloc(sizeof(struct variable)*(numVars+1));
	for (i = 0; i < numVars+1; i++){
		variables[i].numFlipped 			= 0;
		variables[i].numBackToBackFlips 	= 0;
		variables[i].numBackToBackRand		= 0;
		variables[i].longestMarkingDistance = 0;
		variables[i].lastMarkedAt           = 0;
		variables[i].longestMarkingDistEnd  = 0;
	}
	litTrueOne 					= 0;	litTrueTwo 					= 0;
	litTrueMore					= 0;	litFalseZero 				= 0;
	litFalseOne 				= 0;	litFalseMore 				= 0;
	trueVarMiss 				= 0;	clauseStateChangesTotal 	= 0;
	maxClauseWeight				= 1;	maxVariableScore			= 0;
	minVariableScore			= 0;	addDecrease					= 0;
	addIncrease					= 0;	numCheckClauseWeight		= 0;
	numRandomFlip 				= 0;	doubleFlips 				= 0;
	numWeightDecrease 			= 0;	numWeightIncrease			= 0;
	numOfLocalMinima			= 0;	maxNumClauseAppearance		= 0;
	#endif
	#ifdef LONGHEADER
	printf("done.\n");fflush(stdout);
	#endif
}

//This method will, after preprocessing and all the basic operations, allocate the final data structures. It will
//transfer over all the information from the temporary arrays. It will also free the tomporarily allocated memory.
void allocateAndInitializeSecondary(){
	register int i,j,lit,var,*arrPtr,*cls,count;
	#ifdef LONGHEADER
	printf("c Allocating secondary memory... ");fflush(stdout);
	#endif

	//First of all we reset the clauseAppearances and numClauseAppearances arrays for all the literals.
	for (i = -numVars; i < numVars+1; i++){
		tempClauseAppearance[i][0] = 0;
		tempClauseAppearance[i][2] = -1;
	}

	//Then we count the number of integers we need to allocate for clauses.
	count = 0;
	for (i = 0; i < numOriginalClauses; ++i){
		count += (clauseSize[i] + 1);
	}
	clauses = malloc(sizeof(int)*count);

	//Introduce array clauses. Count the number of literals per clause and add +1 for each clause. Allocate clauses
	//with that size.

	//For all the clauses there will be a pointer pointing into the clauses array.
	clauseLiterals			= malloc(sizeof(int*)*(numClauses));

	count = 0;
	for (i = 0; i < numOriginalClauses; i++){
		numTrue[i] = 0;
		clauseLiterals[i] = clauses+count;
		for (j = 0; j < clauseSize[i]; j++){
			lit = tempClauseLiterals[i][j];
			clauseLiterals[i][j] = lit;//Copying.
			if ((assignment[abs(lit)] > 0) == (lit > 0)){
				numTrue[i]++;
				trueVar[i] = abs(lit);
			}
		}
		free(tempClauseLiterals[i]);
		clauseLiterals[i][clauseSize[i]] = 0;//Add the terminating 0 here.
		count += (clauseSize[i]+1);
		if (clauseSize[i] < minClauseSize) minClauseSize = clauseSize[i];
		if (clauseSize[i] > maxClauseSize) maxClauseSize = clauseSize[i];
		#ifdef PREPROCESSING
		if (isIgnoredClause[i]) continue; //We ignore this clause if it was marked to be ignored.
		#endif
		//At this point, we either had no preprocessing or we had preprocessing but the clause is not ignored.
		//We update the literal appearances. This will later make the SLS component respect this clause when
		//flipping variables and picking new variables to flip. This clause will also introduce connections
		//between variables and therefore creates partner relationships.
		for (j = 0; j < clauseSize[i]; j++){
			lit = clauseLiterals[i][j];
			tempClauseAppearance[lit][2+tempClauseAppearance[lit][0]] = i;
			++tempClauseAppearance[lit][0];
			tempClauseAppearance[lit][2+tempClauseAppearance[lit][0]] = -1;
			#ifdef COLLINF_SLS
			if (tempClauseAppearance[lit][0] > maxNumClauseAppearance)
				maxNumClauseAppearance = tempClauseAppearance[lit][0];
			#endif
		}
		//We insert the clause into the unsat clauses, if necessary.
		if (numTrue[i] == 0){
			unsatClauses[numUnsatClauses] = i;
			whereUnsat[i] = numUnsatClauses;
			numUnsatClauses++;
		}
	}
	free(tempClauseLiterals);

	//Now that we know the maximum clause size we can allocate:
	prob = malloc(sizeof(float)*(maxClauseSize));

	//We now initialize the clauseAppearance arrays such that we know what literal appears in what clause.
	clauseAppearance = malloc(sizeof(int*)*(2*numVars+1));
	clauseAppearance += numVars;
	for (i = -numVars; i < numVars+1; i++){
		clauseAppearance[i] = malloc(sizeof(int)*(tempClauseAppearance[i][0]+1));
		for (j = 0; j < tempClauseAppearance[i][0]; j++){
			clauseAppearance[i][j] = tempClauseAppearance[i][2+j];
		}
		clauseAppearance[i][tempClauseAppearance[i][0]] = -1;
		free(tempClauseAppearance[i]);
	}
	tempClauseAppearance -= numVars;
	free(tempClauseAppearance);

	//Then we fill up the partners array such that we know what variable has what partner.
	int* tempStamps = malloc(sizeof(int)*(numVars+1));
	for (i = 1; i < numVars+1; ++i){tempStamps[i] = 0;}
	partners = malloc(sizeof(int*)*(numVars+1));

	for (i = 1; i < numVars+1; i++){
		//The tempPartners arrays are also allocated way too big. No variable will have all other variables as
		//a partner, but it is the worst case.
		partners[i]		= malloc(sizeof(int)*(3));
		partners[i][0]	= 0;
		partners[i][1]	= 1;
		partners[i][2]	= 0;
	}

	for (var = 1; var < numVars+1; ++var){
		for (cls = clauseAppearance[var]; *cls != -1; ++cls){
			#ifdef PREPROCESSING
			if (isIgnoredClause[*cls]) continue;
			#endif
			for (arrPtr = clauseLiterals[*cls]; *arrPtr != 0; ++arrPtr){
				if (tempStamps[abs(*arrPtr)] != var){
					if (partners[var][0] == partners[var][1]-1){
						++partners[var][1];
						partners[var] = realloc(partners[var],sizeof(int)*(partners[var][1]+2));
						//printf("%i:%i-%i:%p\n", var,partners[var][0], partners[var][1],partners[var]);fflush(stdout);
					}
					partners[var][partners[var][0]+2] = abs(*arrPtr);
					++partners[var][0];
					partners[var][partners[var][0]+2] = 0;
					tempStamps[abs(*arrPtr)] = var;
				}
			}
		}
		for (cls = clauseAppearance[-var]; *cls != -1; ++cls){
			#ifdef PREPROCESSING
			if (isIgnoredClause[*cls]) continue;
			#endif
			for (arrPtr = clauseLiterals[*cls]; *arrPtr != 0; ++arrPtr){
				if (tempStamps[abs(*arrPtr)] != var){
					if (partners[var][0] == partners[var][1]-1){
						++partners[var][1];
						partners[var] = realloc(partners[var],sizeof(int)*(partners[var][1]+2));
					}
					partners[var][partners[var][0]+2] = abs(*arrPtr);
					++partners[var][0];
					partners[var][partners[var][0]+2] = 0;
					tempStamps[abs(*arrPtr)] = var;
				}
			}
		}
	}
	free(tempStamps);

	#ifdef LONGHEADER
	printf("done.\n");fflush(stdout);
	#endif
}

#ifdef DISPOSE
//If disposing of memory is enabled, we have sls_dispose, that frees all the memory allocated in global.h using
//the allocate primary and secondary methods.
void sls_dispose(){
	register int i;
	#ifdef LONGHEADER
	printf("c\tDisposing SLS memory... ");fflush(stdout);
	#endif

	#ifdef COLLINF_SLS
	free(variables);
	#endif

	free(unsatClauses);
	free(largeWeightClauses);
	free(decVars);

	//VARIABLE SPECIFIC ARRAYS
	free(isDecVars);
	free(assignment);
	free(lastFlipped);
	clauseAppearance -= numVars;	//We shift the array pointer back to the beginning.
	for (i = 0; i < 2*numVars+1; i++){
		free(clauseAppearance[i]);
	}
	free(clauseAppearance);
	for (i = 1; i < numVars+1; i++){
		free(partners[i]);
	}
	free(partners);
	free(score);
	free(prob);

	//CLAUSE SPECIFIC ARRAYS
	free(clauseSize);
	free(numTrue);
	free(trueVar);
	free(weight);
	free(whereUnsat);

	#ifdef HYBRID
		#ifndef UNITWALK
			for (i = numOriginalClauses; i < numCDCLClauses+1; i++){
				free(clauseLiterals[i]);
			}
		#endif
		#ifdef DISTRIBUTIONCAUCHY
			if (maxClauseSize == 3 && numVars >= 20000){
				free(CAUCHY_TABLE);
				free(CAUCHY_COOLDOWNS);
			}
		#endif
	#endif
	free(clauseLiterals);
	free(clauses);

	#ifdef LONGHEADER
	printf("done.\n");fflush(stdout);
	#endif
}
#endif

//This method adapts all the sparrow parameters and all the variable selection heuristics to the formula at hand.
void adaptToInstance(){
	#ifdef LONGHEADER
	printf("c Adapting to instance...\n");
	#endif
	//We adapt the sparrow scheme and enable or disable weighting depending on the type of instance.
	//Weighting is only enabled for random 2 and 3-SAT. The sparrow tables get used depending on the size of
	//the clauses.
	//Furthermore, if HYBRID is enabled, we decide what variable selection strategy is used in the CDCL:
	//	- For random (HIHEURISTIC enabled), we use cdcl_decisionStack_pickLiteralToSatisfy_HIheuristic().
	//	- For crafted/application (VSIDS enabled), we use cdcl_decisionStack_pickLiteralToSatisfy_VSIDS().
	//	- Otherwise, we use the cdcl_decisionStack_pickLiteralToSatisfy_simple().
	//Lets check if the formula is random.
	looksrandom = isFormulaRandom();
	#ifdef WEIGHTING
	checkClauseWeights = &checkClauseWeightsNull;//Initially, we assume no weighting.
	#endif
	//Standard aging values. The smaller age measure, the more the age will weight during sparrow calculations.
	ageMeasure 		= 100000000000000000000.0f;
	ageIgnore 		= 0.1*(float)numVars;
	//Handle weighting and set the lookup table scores for the sparrow scheme. Also adapt the ageMeasure and
	//ageIgnore. They will later be used to override the PS_TABLE contents such that we do not have to do
	//all the multiplications in the pickVar() method.
	if (looksrandom){
		#ifdef LONGHEADER
		printf("c\tThe instance looks like random %i-SAT. ", maxClauseSize);
		#endif
		//Depending on the size of the clauses, we will used different PS_TABLE entries.
		if (maxClauseSize == 2){
			#ifdef WEIGHTING
				#ifdef LONGHEADER
				printf("Clause weighting enabled.\n");
				#endif
				checkClauseWeights = &checkClauseWeightsLinear;//Enable weighting for random 2-SAT.
				weightStepping = (unsigned char)1;
				SP = 0.347f;
			#else
				#ifdef LONGHEADER
				printf("Clause weighting disabled.\n");
				#endif
			#endif
			PS_TABLE = (float*)PS_3SAT;
			ageMeasure *= 0.005;
		} else if (maxClauseSize == 3){
			#ifdef WEIGHTING
				#ifdef LONGHEADER
				printf("Clause weighting enabled.\n");
				#endif
				checkClauseWeights = &checkClauseWeightsLinear;//Enable weighting for random 3-SAT.
				weightStepping = ((unsigned char)1);
				SP = 0.347f;
			#else
				#ifdef LONGHEADER
				printf("Clause weighting disabled.\n");
				#endif
			#endif
			PS_TABLE = (float*)PS_3SAT;
			ageMeasure *= 0.005;
		} else if (maxClauseSize == 4){
			#ifdef WEIGHTING
				#ifdef LONGHEADER
				printf("Clause weighting enabled.\n");
				#endif
				checkClauseWeights = &checkClauseWeightsLinear;//Enable weighting for random 4-SAT.
				weightStepping = (unsigned char)2;
				SP = 0.79f;
			#else
				#ifdef LONGHEADER
				printf("Clause weighting disabled.\n");
				#endif
			#endif
			PS_TABLE = (float*)PS_4SAT;
			ageMeasure *= 0.0035;
		} else if (maxClauseSize == 5){
			#ifdef WEIGHTING
				#ifdef LONGHEADER
				printf("Clause weighting enabled.\n");
				#endif
				checkClauseWeights = &checkClauseWeightsLinear;//Enable weighting for random 5-SAT.
				weightStepping = (unsigned char)2;
				SP = 0.79f;
			#else
				#ifdef LONGHEADER
				printf("Clause weighting disabled.\n");
				#endif
			#endif
			PS_TABLE = (float*)PS_5SAT;
			ageMeasure *= 0.0023;
		} else if (maxClauseSize == 6){
			#ifdef WEIGHTING
				#ifdef LONGHEADER
				printf("Clause weighting enabled.\n");
				#endif
				checkClauseWeights = &checkClauseWeightsLinear;//Enable weighting for random 3-SAT.
				weightStepping = (unsigned char)3;
				SP = 0.919f;
			#else
				#ifdef LONGHEADER
				printf("Clause weighting disabled.\n");
				#endif
			#endif
			PS_TABLE = (float*)PS_6SAT;
			ageMeasure *= 0.0021;
		} else {
			//We use the lookup table of 7-SAT for any k-SAT formula with k > 6.
			#ifdef WEIGHTING
				#ifdef LONGHEADER
				printf("Clause weighting enabled.\n");
				#endif
				checkClauseWeights = &checkClauseWeightsLinear;//Enable weighting for random 3-SAT.
				weightStepping = (unsigned char)4;
				SP = 0.919f;
			#else
				#ifdef LONGHEADER
				printf("Clause weighting disabled.\n");
				#endif
			#endif
			PS_TABLE = (float*)PS_7SAT;
			ageMeasure *= 0.002;
		}
	} else {
		//For an application formula, we will use the 7-SAT table and no clause weighting.
		//checkClauseWeights() will stay on checkClauseWeightsNull().
		#ifdef LONGHEADER
		printf("c\tThe instance does not look random. Clause weighting disabled.\n");
		#endif
		PS_TABLE = (float*)PS_7SAT;
		ageMeasure *= 0.002;
	}

	//Here, we multiply the PS_TABLE value with the value we calculated for the weight of the age.
	//This will later relieve us of multiplying this every time we pick a variable randomly. See pickVar().
	int i;
	for (i = 0; i < numClauses; i++){weight[i] = (unsigned char)weightStepping;}//Init clause weights.
	for (i = 0; i < 10; i++){PS_TABLE[i] *= ageMeasure;}

	#ifdef LONGHEADER
	printf("c\tSparrow scheme parameters:\n");
	printf("c\t\tSparrow p_a measure: %f\n", ageMeasure);
	printf("c\t\tSparrow p_a ignore: %f\n", ageIgnore);
	printf("c\t\tSparrow p_s base values:\n");
	for (i = 0; i < 11; i++){
		if (i == 0){
			printf("c\t\t>=   0:%25.1f\n",ageMeasure);
		} else if (i < 10){
			printf("c\t\t%6.i:%25.1f\n",-i,PS_TABLE[i]);
		} else {
			printf("c\t\t<= -10:%25.1f\n",PS_TABLE[0]);
		}
	}
	#endif

	//Finally, we adapt the heuristics and call schemes used in the SLS/CDCL if the solver runs in hybrid mode.
	#ifdef HYBRID
		//First we adapt the variable selection scheme and additionally, we disable CDCL calling and enable it only for 3-SAT.
		callCDCL = &callCDCL_null;
		if (looksrandom){
			#ifdef HIHEURISTIC
			heuristic = HEURHI;
			#else
				#ifdef VSIDSHEURISTIC
					heuristic = HEURVSIDS;
				#else
					#ifdef AGEHEURISTIC
						heuristic = HEURAGE;
					#else
						#ifdef RANDOMHEURISTIC
							heuristic = HEURRAND;
						#else
							heuristic = HEURSIMPLE;
						#endif
					#endif
				#endif
			#endif
		} else {
			#ifdef VSIDSHEURISTIC
			heuristic = HEURVSIDS;
			#else
				#ifdef AGEHEURISTIC
					heuristic = HEURAGE;
				#else
					heuristic = HEURSIMPLE;
				#endif
			#endif
		}
		//Second we adapt the learning scheme.
		#ifndef UNITWALK
			#ifdef LEARNUIP
			cdcl_conflictAnalysis_learn = &cdcl_conflictAnalysis_learnUIP;
			#else
			cdcl_conflictAnalysis_learn = &cdcl_conflictAnalysis_learnSimple;
			#endif
		#endif
		//Third we adapt the calling scheme of the CDCL.
		if (maxClauseSize == 3 && numVars >= 20000){
			#ifdef MINIMACALLING
				#ifdef LONGHEADER
				printf("c\tLOCALMIN CDCL calling scheme is in use... ");
				#endif
				callCDCL = &callCDCL_localMin;
				//We adapt the cool-down calculations for the local minimum calling scheme here.
				#ifdef DISTRIBUTIONCAUCHY
					CAUCHY_TABSIZE = 2000;
					CAUCHY_OFFSET_FRACTION = (double) 0.7407407;
					CAUCHY_GAMMA = (double) 15.0;
					CAUCHY_FLIPINCREASE = (int)((2.7f*(float)numVars)/(float)100);
					CAUCHY_OFFSET = (int)(CAUCHY_OFFSET_FRACTION*CAUCHY_TABSIZE);
					CAUCHY_COOLDOWNS = malloc(sizeof(unsigned int)*(CAUCHY_TABSIZE+1));
					CAUCHY_TABLE = malloc(sizeof(double)*(CAUCHY_TABSIZE+1));
					#ifdef LONGHEADER
					printf("using Cauchy distributed cool-down periods. z ~ C(%i,%f,%f,%i,%i)\n",
							CAUCHY_TABSIZE, CAUCHY_OFFSET_FRACTION, CAUCHY_GAMMA, CAUCHY_FLIPINCREASE, CAUCHY_OFFSET);
					#endif
					cooldownLength = 2*numVars;
					distribution_createCauchyTable();
					distribution = &distribution_cauchy;
				#endif
			#endif
		} else {
			#ifdef LONGHEADER
			printf("c\tCDCL is not being called. Formula is too small.\n");
			#endif
		}
	#endif

	#ifdef TABULIST
	//Last but not least we adapt the TABU list length.
	//TABU = tabulistlength;
	if (maxClauseSize <= 3){
		TABU = (unsigned int) 3;
	} else if (maxClauseSize == 4){
		TABU = (unsigned int) 9;
	} else if (maxClauseSize == 5){
		TABU = (unsigned int) 7;
	} else if (maxClauseSize == 6){
		TABU = (unsigned int) 6;
	} else {
		TABU = (unsigned int) 4;
	}
	#ifdef LONGHEADER
	printf("c\tTABU list length is: %i.\n",TABU);
	#endif
	#endif
	#ifdef WEIGHTING
	#ifdef LONGHEADER
	printf("c\tweightStepping is: %i.\nc\tSP is: %f.\n",weightStepping,SP);
	#endif
	#endif
	#ifdef LONGHEADER
	printf("c done.\nc\n");fflush(stdout);
	#endif
}

//This method performs all the loading operations.
void loadFormula(){
	int i,chr, chr2, lit, numReadLits;
	char txt[100];

	chr = '#';
	while (chr != 'p') {
		while ((chr = fgetc(input)) == 'c') {
			while ((chr2 = fgetc(input)) != EOF && chr2 != '\n');
		}
	}
	ungetc(chr, input);
	if (fscanf(input, "p %s %i %i", txt, &numVars, &numClauses) != 3) {
		fprintf(stderr,"Error while reading the p-line.\n");
		printf("c e Error while reading the p-line.\n");
		exit(-1);
	}
	if (strcmp("cnf", txt) != 0 ) {
		fprintf(stderr, "Error while checking if problem file is >cnf<.\n");
		printf("c e Error while checking if problem file is >cnf<.\n");
		exit(-1);
	}

	//Here we allocate the primary memory along with some temporary memory.
	allocateAndInitializePrimary();
	#ifdef PREPROCESSING
	//If preprocessing is enabled, we initialize the preprocessor here.
	preprocess_allocateAndIntialize();
	#endif

	for (i = 0; i < numClauses; i++) {
		tempClauseLiterals[i] = malloc(sizeof(int)*MAXCLAUSESIZE);//Allocate temporary way too large.
		tempClauseLiterals[i][0] = 0; //Terminate.
		numReadLits = 0;
		lit = 0;
		do {
			if (numReadLits > MAXCLAUSESIZE) {
				fprintf(stderr, "e The input clause %i is too long; longer than %i.\n",i, MAXCLAUSESIZE);
				printf("c e The input clause %i is too long; longer than %i.\n",i, MAXCLAUSESIZE);
				exit(-1);
			}
			if (fscanf(input, "%i ", &lit) != 1) {
				fprintf(stderr, "There was an error reading a literal in clause %i. Bad input file?\n",i);
				printf("c e There was an error reading a literal in clause %i. Bad input file?\n",i);
				exit(-1);
			}
			if (lit != 0) {
				tempClauseLiterals[i][clauseSize[i]] = lit;
				tempClauseLiterals[i][++clauseSize[i]] = 0;
				if (tempClauseAppearance[lit][0] >= tempClauseAppearance[lit][1]-1){
					//We must increase the memory ready to store clause numbers in tempClauseAppearance[lit].
					tempClauseAppearance[lit][1] *= 2;
					tempClauseAppearance[lit] = realloc(tempClauseAppearance[lit], sizeof(int)*(tempClauseAppearance[lit][1]+2));
				}
				tempClauseAppearance[lit][2+tempClauseAppearance[lit][0]] = i;
				++tempClauseAppearance[lit][0];
				tempClauseAppearance[lit][2+tempClauseAppearance[lit][0]] = -1;
				numReadLits++;
				#ifdef COLLINF_SLS
				if (tempClauseAppearance[lit][0] > maxNumClauseAppearance)
					maxNumClauseAppearance = tempClauseAppearance[lit][0];
				#endif
			}
		} while (lit != 0);
		//Reallocate the temporary clause literals array such that it fits its size + 1 (+1 for termination).
		tempClauseLiterals[i] = realloc(tempClauseLiterals[i], sizeof(int)*(clauseSize[i]+1));
		if (clauseSize[i] < minClauseSize) minClauseSize = clauseSize[i];
		if (clauseSize[i] > maxClauseSize) maxClauseSize = clauseSize[i];
		#ifdef PREPROCESSING
		#ifdef UNITPROP
		if (clauseSize[i] == 1 && !preproc_isInUnitPropBuffer[abs(tempClauseLiterals[i][0])]){
			//We have found a unit clause. We add it to the unitPropBuffer.
			preproc_unitPropBuffer[preproc_unitPropBufferLast++] = tempClauseLiterals[i][0];
			preproc_isInUnitPropBuffer[abs(tempClauseLiterals[i][0])] = 1;
		}
		#endif
		#endif
	}
	//After having loaded all the formula information in the temporary memory, we will use it to adapt to the instance.
	adaptToInstance();

	#ifdef PREPROCESSING
	//If preprocessing is enabled, we will perform preprocessing on the temporary arrays now.
	preprocess();
	#endif

	allocateAndInitializeSecondary();

	#ifdef HYBRID
	cdcl_allocateAndInitialize();
	#endif

	fclose(input);
}

//The main call for the solver.
int main(int argc, char* argv[]){
	printHeader();

	#ifdef LONGHEADER
	printf("c The starting time in seconds is: %f\n",((float)(clock())/((float)CLOCKS_PER_SEC)));
	#endif

	printf("c INITIALIZING...\n");
	readParameters(argc, argv);
	loadFormula();
	#ifdef LONGHEADER
	printFormulaStats();
	#endif
	calculateInitialScoresAndDecVars();

	#ifdef LONGHEADER
	printf("c Time to initialize data structures and perform preprocessing: %f\nc\n",
			((float)clock())/((float)CLOCKS_PER_SEC));fflush(stdout);
	#endif

	#ifdef VERBOSE_SLS
	printVariables();
	printClauses();
	printUnsatClauses();
	printLargeWeightClauses();
	printVariableScores();
	printDecVars();
	printCurrentAssignment();fflush(stdout);
	#endif

	if (returnValue == UNKNOWN){
		#ifndef SILENT
		printf("c SEARCHING...\nc\n");
		fflush(stdout);
		#endif
		sls();
	}

	if (returnValue == UNKNOWN){
		printf("s UNKNOWN\n");
		fflush(stdout);
	} else if (returnValue == UNSAT){
		printf("s UNSATISFIABLE\n");
		fflush(stdout);
	} else {
		#ifdef VERIFICATION_SLS
		verification_sls_verifySolution();
		#endif
		printSolution();
		fflush(stdout);
	}

	#ifdef LONGHEADER
		printStats();
	#endif

	#ifdef DISPOSE
		#ifdef LONGHEADER
		printf("c\nc Disposing memory...\n");
		#endif
		sls_dispose();
		#ifdef HYBRID
		cdcl_dispose();
		#endif
		#ifdef PREPROCESSING
		preprocess_dispose();
		#endif
		#ifdef LONGHEADER
		printf("c All memory disposed.\n");
		printf("c Verily, this vichyssoise of verbiage veers most verbose.\n");
		#endif
	#endif

	return returnValue;
}
