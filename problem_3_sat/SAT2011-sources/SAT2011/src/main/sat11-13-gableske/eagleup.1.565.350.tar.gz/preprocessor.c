/*
 * preprocessor.c
 *
 *  Created on: 10.09.2010
 *      Author: Oliver Gableske
 *  	Content: This file contains all methods to perform preprocessing.
 *
 *  BE ADVISED: PREPROCESSING ONLY WORKS ON THE TEMPORARY TWO DIMENSIONAL ARRAYS:
 *  	-tempClauseLiterals
 *  	-tempClauseAppearance
 *  SO PREPROCESSING MUST BE DONE BEFORE METHOD allocateAndInitializeSecondary() IS CALLED IN global.c
 */


#include "preprocessor.h"

#ifdef PREPROCESSING
//In case a clause is set to be ignored (for example because it contains a pure literal), then this method will
//perform all operations to make the clause ignored.
void preprocess_makeClauseIgnored(int cNum){
	register int i,lit;
	if (isIgnoredClause[cNum]) return;
	isIgnoredClause[cNum] = 1;
	//Remove the clause from any appearance list.
	for (i = 0; (lit = tempClauseLiterals[cNum][i]) != 0; ++i){
		preprocess_removeFromAppearanceList(lit,cNum);
	}
	if (cNum < numOriginalClauses) {
		//We use this to see if the formula is already satisfied.
		++preproc_numIgnoredOriginalCls;
		if (preproc_numIgnoredOriginalCls == numOriginalClauses){
			returnValue = SAT;
		}
	}
}

//This method will remove the clause with number cNum from the appearance list of literal lit.
void preprocess_removeFromAppearanceList(int lit, int cNum){
	//This will remove the clause with number cNum from the tempClauseAppearance list of lit.
	//It will also update the numClauseAppearance.
	register int i;
	for (i = 0; i < tempClauseAppearance[lit][0]; ++i){
		if (tempClauseAppearance[lit][2+i] == cNum) {
			--tempClauseAppearance[lit][0];
			tempClauseAppearance[lit][2+i] = tempClauseAppearance[lit][2+tempClauseAppearance[lit][0]];
			tempClauseAppearance[lit][2+tempClauseAppearance[lit][0]] = -1;
			break;
		}
	}
}

//This method will remove a literal from a clause.
void preprocess_removeLiteralFromClause(int toRemove, int cNum){
	//This will remove literal toRemove from the clause cNum.
	register int j,lit;
	for (j = 0; (lit = tempClauseLiterals[cNum][j]) != 0; ++j){
		if (lit == toRemove){
			tempClauseLiterals[cNum][j] = tempClauseLiterals[cNum][--clauseSize[cNum]];
			tempClauseLiterals[cNum][clauseSize[cNum]] = 0;
			preprocess_removeFromAppearanceList(lit,cNum);
			if (clauseSize[cNum] == 0){
				//We have shrunk a clause to size 0. The formula must be unsatisfiable.
				returnValue = UNSAT;
				break;
			}
			#ifdef UNITPROP
			else if (clauseSize[cNum] == 1 && !preproc_isInUnitPropBuffer[abs(tempClauseLiterals[cNum][0])]){
				//We have shruk a clause to size 1. It is unit now and needs to be processed by unit propagation.
				preproc_unitPropBuffer[preproc_unitPropBufferLast % numVars] = tempClauseLiterals[cNum][0];
				preproc_isInUnitPropBuffer[abs(tempClauseLiterals[cNum][0])] = 1;
				++preproc_unitPropBufferLast;
			}
			#endif
			break;
		}
	}
}

//This method will make an assignment. It is made forever, since the variable will, after this is done, occur
//in no more clauses of the formula. This also means that some satisfied clauses are getting ignored and some
//clauses are reduced in size.
void preprocess_enforceAssignment(int var, int assi){
	register int i,cNum,toEnforce = 0;
	//We want to set the variable var to the given assignment assi. Therefore, we have to make the assignment,
	//and then we have to make the clauses in which the literals of var become true ignored. And we have to
	//shrink all clauses in which the literals of var become false.
	if (assi == 0){
		assignment[var] = 0;
		toEnforce = -var;	//The negative one becomes true.
	} else {
		assignment[var] = 1;
		toEnforce = var;	//The positive one becomes true.
	}
	#ifdef VERBOSE_PREPROC
	printf("c\t\t\tEnforcing the assignment of %i to %i.\n", var, assignment[var]);
	printf("c\t\t\tIgnoring clauses with literal becoming true: ");
	#endif
	//We have set the assignment of the variable. We must now mark all clauses it appears in satisfied as
	//being ignored.
	for (i = 0; i < tempClauseAppearance[toEnforce][0]; ++i){
		cNum = tempClauseAppearance[toEnforce][2+i];
		#ifdef VERBOSE_PREPROC
		printf("%i ", cNum);
		#endif
		preprocess_makeClauseIgnored(cNum);
		--i;//Since the previous step removes the current position in the array.
	}
	toEnforce = -toEnforce;
	#ifdef VERBOSE_PREPROC
	printf("\n");
	printf("c\t\t\tShrinking clauses with literal becoming false: ");
	#endif
	//We must now shrink all clauses that the literal appears in unsatisfied.
	for (i = 0; i < tempClauseAppearance[toEnforce][0]; ++i){
		cNum = tempClauseAppearance[toEnforce][2+i];
		#ifdef VERBOSE_PREPROC
		printf("%i ", cNum);
		#endif
		//Find the literal, replace it with the last one and terminate clause anew.
		preprocess_removeLiteralFromClause(toEnforce,cNum);
		--i;//Since the previous step removes the current position in the array.
	}
	#ifdef VERBOSE_PREPROC
	printf("\n");
	#endif
}

#ifdef UNITPROP
//In case unit propagation is enabled, we will do this here.
void preprocess_unitPropagation(){
	register int lit;
	#ifdef VERBOSE_PREPROC
	printf("c\tPerforming unit propagation...\n");
	#endif
	while(preproc_unitPropBufferPos < preproc_unitPropBufferLast && returnValue == UNKNOWN){
		lit = preproc_unitPropBuffer[preproc_unitPropBufferPos % numVars];
		#ifdef VERBOSE_PREPROC
		printf("c\t\t\tUnit propagation on literal %i.\n",lit);
		#endif
		if (lit > 0){
			//We must assign the corresponding variable to 1.
			preprocess_enforceAssignment(abs(lit),1);
		} else {
			//We must assign it to 0.
			preprocess_enforceAssignment(abs(lit), 0);
		}
		//Additional changes might have occurred. Reset the preprocessing flag:
		preproc_repeat = 1;
		++preproc_unitPropBufferPos;
		#ifdef COLLINF_PREP
		preproc_unitProps++;
		#endif
		preproc_isInUnitPropBuffer[abs(lit)] = 0;//We just handled unit propagation on this variable.
	}
}
#endif

#ifdef PURELIT
//In case pure literal elimination is enabled, we will do this here.
void preprocess_pureLiterals(){
	register int pureVar;
	#ifdef VERBOSE_PREPROC
	printf("c\tChecking for pure literals...\n");
	#endif
	for (pureVar = 1; pureVar < numVars+1; ++pureVar){
		if (!tempClauseAppearance[pureVar][0] || !tempClauseAppearance[-pureVar][0]){
			if (!tempClauseAppearance[pureVar][0] && !tempClauseAppearance[-pureVar][0]){
				//The variable does not occur in the formula at all. No changes necessary.
				continue;
			}
			#ifdef VERBOSE_PREPROC
			printf("c\t\tVariable %i is pure.\n",pureVar);
			#endif
			if (!tempClauseAppearance[pureVar][0]){//The negative literal is pure.
				#ifdef COLLINF_PREP
				preproc_pureLitsIgnoredCls += tempClauseAppearance[-pureVar][0];
				#endif
				preprocess_enforceAssignment(pureVar, 0);
			} else if (!tempClauseAppearance[-pureVar][0]){//The positive literal is pure.
				#ifdef COLLINF_PREP
				preproc_pureLitsIgnoredCls += tempClauseAppearance[pureVar][0];
				#endif
				preprocess_enforceAssignment(pureVar, 1);
			}
			preproc_repeat = 1;
			#ifdef COLLINF_PREP
			preproc_pureLits++;
			#endif
		}
	}
}
#endif

//This method performs preprocessing for random instances.
void preprocess_random(){
	//Preprocessing loop for random instances.
	while(preproc_repeat && returnValue == UNKNOWN){
		preproc_repeat = 0;//Reset the flag.
		#ifdef LONGHEADER
		#ifdef VERBOSE_PREPROC
		printf("c   PREPROCESSING ROUND %i\n",preprocess_round++);
		#endif
		#endif

		#ifdef PURELIT
		if (returnValue == UNKNOWN) preprocess_pureLiterals();
		#endif
	}
}

//This method performs preprocessing for application instances.
void preprocess_application(){
	//Preprocessing loop for application instances.
	while(preproc_repeat && returnValue == UNKNOWN){
		preproc_repeat = 0;//Reset the flag.
		#ifdef LONGHEADER
		#ifdef VERBOSE_PREPROC
		printf("c   PREPROCESSING ROUND %i\n",preprocess_round++);
		#endif
		#endif

		#ifdef UNITPROP
		if (returnValue == UNKNOWN)	preprocess_unitPropagation();
		#endif

		#ifdef PURELIT
		if (returnValue == UNKNOWN) preprocess_pureLiterals();
		#endif

		#ifdef HBCE
		if (returnValue == UNKNOWN) preprocess_hbce();
		#endif
	}
}

//This method is used for allocating and initializing the preprocessor related data-structures.
void preprocess_allocateAndIntialize(){
	int i;
	#ifdef LONGHEADER
	printf("c Allocating preprocessor memory... "); fflush(stdout);
	#endif
	//If preprocessing is enabled, we use this array to skip certain clauses. They will still appear in the
	//final formula, but they will not add anything to the partners or clauseAppearance arrays of the variables.
	//Basically, we pretend those clauses are not there. See allocateAndInitializeSecondary() for more details.
	isIgnoredClause			= malloc(sizeof(unsigned char)*numClauses);
	for (i = 0; i < numClauses; ++i){
		isIgnoredClause[i]	= 0;//Initially, all clauses are not ignored.
	}
	preproc_numIgnoredOriginalCls = 0;//Initially, all clauses are not ignored.

	#ifdef UNITPROP
	//If unit propagation is enabled, we use this buffer to store clause-numbers of unit clauses. They will later
	//be handled by unit propagation in the preprocessor.
	preproc_isInUnitPropBuffer	= malloc(sizeof(unsigned char)*(numVars+1));
	for (i = 1; i < numVars+1; ++i){
		preproc_isInUnitPropBuffer[i] = 0;
	}
	preproc_unitPropBuffer 		= malloc(sizeof(int)*numVars);
	preproc_unitPropBufferLast 	= 0;
	preproc_unitPropBufferPos 	= 0;
	#endif

	#ifdef HBCE
	//In case we want to perform hidden literal addition.
	#endif

	#ifdef COLLINF_PREP
	//Also some additional information might be collected about preprocessing if it is enabled.
	preproc_pureLits			= 0;
	preproc_pureLitsIgnoredCls  = 0;
	preproc_unitProps			= 0;
	#endif

	#ifdef VERBOSE_PREPROC
	preprocess_round			= 0;
	#endif

	#ifdef LONGHEADER
	printf("done.\n"); fflush(stdout);
	#endif
}

void preprocess_dispose(){
	#ifdef LONGHEADER
	printf("c\tDisposing Preprocessor memory... ");fflush(stdout);
	#endif

	free(isIgnoredClause);
	#ifdef UNITPROP
	free(preproc_isInUnitPropBuffer);
	free(preproc_unitPropBuffer);
	#endif

	#ifdef LONGHEADER
	printf("done.\n");fflush(stdout);
	#endif
}

//This is the main method for the preprocessor.
void preprocess(){
	//Launch the preprocessor for the instance in question.
	preproc_repeat = 1;//Set the flag.
	if (looksrandom){
		//The instance seems random, we use simple preprocessing.
		#ifdef LONGHEADER
		#ifdef VERBOSE_PREPROC
		printf("c Performing preprocessing for random instance... \n");
		#else
		printf("c Performing preprocessing for random instance... ");
		#endif
		#endif
		preprocess_random();
	} else {
		//The instance does not seem to be random, we use more sophisticated preprocessing.
		#ifdef LONGHEADER
		#ifdef VERBOSE_PREPROC
		printf("c Performing preprocessing for application instance... \n");
		#else
		printf("c Performing preprocessing for application instance... ");
		#endif
		#endif
		preprocess_application();
	}
	//Finally output the stuff the preprocessor wants to tell us.
	#ifdef LONGHEADER
		#ifdef VERBOSE_PREPROC
		printf("c done with preprocessing. Preprocessor says: ");
		#else
		printf("done with preprocessing. Preprocessor says: ");
		#endif
		if (returnValue == UNKNOWN){
			printf("UNKNOWN.\nc\n");
		} else if (returnValue == SAT){
			printf("SATISFIABLE.\nc\n");
		} else if (returnValue == UNSAT){
			printf("UNSATISFIABLE.\nc\n");
		}
	#endif /* LONGHEADER */
}

#endif /* PREPROCESSING */
