/*
 * verification_sls.h
 *
 *  Created on: 23.10.2010
 *      Author: Oliver Gableske
 *	   Content: This file contains all declarations to perform verifications for the SLS component.
 */

#ifndef VERIFICATION_SLS_H_
#define VERIFICATION_SLS_H_
#include "global.h"

#ifdef VERIFICATION_SLS
//FORWARD METHOD DECLARATIONS
void verification_sls_verifySolution();
#endif /* VERIFICATION_SLS */

#endif /* VERIFICATION_SLS_H_ */
