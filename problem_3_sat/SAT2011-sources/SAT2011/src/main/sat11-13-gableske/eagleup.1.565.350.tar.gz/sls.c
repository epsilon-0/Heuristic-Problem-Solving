/*
 * sls.c
 *
 *  Created on: 04.08.2010
 *      Author: Oliver Gableske
 *  	Content: This file contains all the methods for the SLS component of the solver.
 */

#include "sls.h"

#ifdef PREPROCESSING
#include "preprocessor.h"
#endif

#ifdef HYBRID
#include "cdcl.h"
#endif

#ifdef HYBRID
//This method makes no calls to the CDCL at all.
void callCDCL_null(){}

#ifdef MINIMACALLING
#ifdef DISTRIBUTIONCAUCHY
double distribution_pow(double n, int exp){
	int i = 0;
	double res = 1.0f;
	while (i < exp){
		res = res * n;
		++i;
	}
	return res;
}

double distribution_atan(double x){
	double result = 0.0;
	double pi = 3.141592653589793238462643383279502;

	if (x < -1.0){
		result = -pi/2 - (x/(distribution_pow(x,2)+0.28f));
	} else if (x > 1.0){
		result = pi/2 - x/(distribution_pow(x,2) + 0.28f);
	} else {
		result = x/(1.0f+0.28f*distribution_pow(x,2));
	}

	return result;
}

void distribution_createCauchyTable(){
	int i,j;
	double pi = 3.141592653589793238462643383279502;
	int x;
	for (x = 0; x < CAUCHY_TABSIZE; ++x){
		CAUCHY_TABLE[x] = 1.0f/pi * distribution_atan((x-CAUCHY_OFFSET)/CAUCHY_GAMMA)+0.5;
	}
	for (x = 0; x < CAUCHY_TABSIZE; ++x){
		if (x <= CAUCHY_OFFSET){
			CAUCHY_TABLE[x] = CAUCHY_TABLE[x] + CAUCHY_TABLE[x]*((x-((double)CAUCHY_OFFSET))/(double)(CAUCHY_OFFSET));
		} else {
			CAUCHY_TABLE[x] = CAUCHY_TABLE[x] + (1-CAUCHY_TABLE[x])*((x-((double)CAUCHY_OFFSET))/(double)(CAUCHY_TABSIZE-CAUCHY_OFFSET));
		}
	}
	CAUCHY_TABLE[CAUCHY_TABSIZE] = 1.0f;
	double cooldownPos,cooldownLastpos = 0;
	double cauchyVal;
	CAUCHY_COOLDOWNS[0] = 0;
	for (i = 0; i < CAUCHY_TABSIZE+1; ++i){
		cauchyVal = CAUCHY_TABLE[i];
		cooldownPos = (int)(cauchyVal*(double)CAUCHY_TABSIZE);
		for (j = cooldownLastpos+1; j < cooldownPos+1; ++j){
			CAUCHY_COOLDOWNS[j] = (unsigned int)(((float)(CAUCHY_FLIPINCREASE * i)) * (100.0f/(float)CAUCHY_TABSIZE));
		}
		cooldownLastpos = cooldownPos;
	}
}

void distribution_cauchy(){
	float ra = OORANDMAX*rand();
	int i = (int)(ra*((float)CAUCHY_TABSIZE));
	cooldownLength = CAUCHY_COOLDOWNS[i];
}
#endif

//This method calls the CDCL in a local minimum, i.e. when there are no decreasing variables.
void callCDCL_localMin(){
	if (numDecVars > 0 || flips-cdcl_lastCall < cooldownLength) return;

	#ifdef TIMING
	cdcl_callStarttime = (float) clock();
	#endif

	#ifdef VERBOSE_SLS
	printf("c CDCL call...\n");fflush(stdout);
	#endif

	returnValue = cdcl();

	#ifdef TIMING
	cdcl_callEndtime = (float) clock();
	cdcl_runtime += (cdcl_callEndtime-cdcl_callStarttime)/(float)CLOCKS_PER_SEC;
	#endif

	//Adapt cool-down length interval for next call.
	distribution();
}
#endif

#ifdef VSIDS_INCREASEINFLIPS
//This method increases the VSIDS scores of a variable in every flip.
inline void sls_updateVSIDSScores(){
	vsidsScore[chosenVar] += bump_factor_flips;
}
#endif
#endif /* HYBRID */

//This method calculates the initial variables scores and decides what variables are decreasing the number of
//unsatisfied clauses when flipped.
void calculateInitialScoresAndDecVars(){
	register int i,j,var;
	#ifdef LONGHEADER
	printf("c Calculating initial scores of the variables... ");
	#endif
	//Initially, all clauses have weight 1. No need to touch the clause weights in the following calculation.
	for (i = 0; i < numClauses; i++){
		#ifdef PREPROCESSING
		if (isIgnoredClause[i]) continue; //An ignored clause cannot add to the scores.
		#endif
		if (numTrue[i] > 1){//numTrue > 1!
			//For a clause with more than 1 true literal, no single variable can
			//change the state of the clause. Therefore, it cannot add to the
			//scores of any variable.
			continue;
		}
		//There will be score updates.
		if (numTrue[i] == 1){//numTrue == 1!
			//Exactly one literal in this clause is true. The corresponding variable
			//can change its state when it is flipped. Therefore we must decrease the
			//score for this corresponding variable.
			score[trueVar[i]] -= weightStepping;
		} else { //numTrue == 0!
			//None of the contained literals will satisfies the clause. A flip to
			//any of the variables will therefore satisfy it. All of the variables
			//will have their score improved.
			for (j = 0; (var = abs(clauseLiterals[i][j])) > 0; j++){
				score[var] += weightStepping;
			}
		}
	}

	for (i = 1; i < numVars+1; i++){
		if (score[i] > 0){
			decVars[numDecVars] = i;
			numDecVars++;
			isDecVars[i] = 1;
			#ifdef COLLINF_SLS
			variables[i].lastMarkedAt = 0;
			#endif
		} else {
			isDecVars[i] = 0;
		}
	}
	#ifdef LONGHEADER
	printf("%i have positive score.\nc\n", numDecVars);
	#endif
}

#ifdef WEIGHTING
//A dummy method facilitating no clause weight updates. The method pointer of checkClauseWeights will point to
//this method if clause weighting is enabled using the flag WEIGHTING but the solver decided to not use clause
//weights. See adaptToInstance() in global.c.
void checkClauseWeightsNull(){}

//This method performs clause weighting updates based on PAWS (pure additive weighting scheme).
void checkClauseWeightsLinear(){
	register int i,var,cNum;
	int* ptrInCls;
	#ifdef COLLINF_SLS
	numCheckClauseWeight++;
	#endif
	if (OORANDMAX*rand() < SP){ //Smoothing of clause weights.
		#ifdef VERBOSE_SLS
		printf("c The smoothing random value was %.3f < %.3f!\nc\n",ra,SP);
		printf("c Smoothing clause weights of the clauses:\n");
		#endif
		for (i=0; i < numLargeWeightClauses; i++){
			cNum = largeWeightClauses[i];
			if (numTrue[cNum] > 0){
				#ifdef VERBOSE_SLS
				printf("c\tClause %i, new weight %i-1: \t",largeWeightClauses[i],weight[largeWeightClauses[i]]);
				#endif
				if ((weight[cNum] -= weightStepping) == weightStepping){
					#ifdef VERBOSE_SLS
					printf("Removing clause %i(%i). ",largeWeightClauses[i],weight[largeWeightClauses[i]]);
					#endif
					largeWeightClauses[i] = largeWeightClauses[--numLargeWeightClauses];
					--i;
				}
				#ifdef VERBOSE_SLS
				else {
					printf("Adding %i(%i). ",cNum,weight[cNum]);
				}
				#endif
				if (numTrue[cNum] == 1){//Only one true literal is found.
					//This trueVar must get its score INCREASED because its penalty becomes smaller by 1!
					var = trueVar[cNum];
					score[var] += weightStepping;
					#ifdef VERBOSE_SLS
					printf("Has %i true literals. Increasing the scores of(to): %i(%i) ",
							numTrue[cNum], var, score[var]);
					#endif
					if ((score[var] > 0)
							&& (isDecVars[var] == 0)
							&& (lastFlipped[var] < flips - 1)){
						decVars[numDecVars++] = var;
						isDecVars[var] = 1;
						#ifdef COLLINF_SLS
						addDecrease++;
						variables[var].lastMarkedAt = flips;
						#endif
					}
				}
				#ifdef VERBOSE_SLS
				else {
				   printf("Has %i true literals. No score update necessary. ",numTrue[cNum]);
				}
				printf("\n");
				#endif
			}
			#ifdef VERBOSE_SLS
			else {
				printf("c\t Clause %i, keeps its weight since it is still unsatisfied. ",largeWeightClauses[i]);
				printf("Adding clause %i(%i).\n",largeWeightClauses[i],weight[largeWeightClauses[i]]);
			}
			#endif
		}
		#ifdef COLLINF_SLS
		numWeightDecrease++;
		#endif
		#ifdef VERBOSE_SLS
		printf("c\nc\n");
		#endif
	} else { //Increasing of clause weights.
		#ifdef VERBOSE_SLS
		printf("c The smoothing random value was %.3f >= %.3f.\nc\n",ra,SP);
		printf("c Increasing the clause weights of clauses:\n");
		#endif
		for (i = 0; i < numUnsatClauses; i++){
			cNum = unsatClauses[i];
			weight[cNum] += weightStepping;
			#ifdef COLLINF_SLS
			if (weight[unsatClauses[i]] > maxClauseWeight){
				maxClauseWeight = weight[cNum];
			}
			#endif
			#ifdef VERBOSE_SLS
			printf("c\t%i\t(to weight %i)\t changing scores: ",cNum,weight[cNum]);
			#endif
			for (ptrInCls = clauseLiterals[cNum]; (var = abs(*ptrInCls)) > 0; ptrInCls++){
				score[var] += weightStepping;
				#ifdef VERBOSE_SLS
				printf("%i+ to %i, ", var, score[var]);
				#endif
				if ((score[var] > 0)
						&& (isDecVars[var] == 0)
						&& (lastFlipped[var] < flips - 1)){
					decVars[numDecVars++] = var;
					isDecVars[var] = 1;
					#ifdef COLLINF_SLS
					variables[var].lastMarkedAt = flips;
					addIncrease++;
					#endif
				}
			}
			#ifdef VERBOSE_SLS
			printf("\nc");
			#endif
			if (weight[cNum] == 2*weightStepping){
				//This clause is newly having a large weight.
				largeWeightClauses[numLargeWeightClauses++] = cNum;
			}
		}
		#ifdef COLLINF_SLS
		numWeightIncrease++;
		#endif
		#ifdef VERBOSE_SLS
		printf("\n");
		#endif
	}
}
#endif /* WEIGHTING */

//This method picks a new variable for flipping.
void pickVar(){
	register int i, var, cNum,*ptr;
	register float age,r;
	register float totalP = 0.0;
	register char bestScore = -127;
	register unsigned bestLastFlipped = flips;
	//Picking a variable works in three phases:
	//1. We try to pick a variable with positive score.
	//2. If no such variable exists, we perform the Sparrow-like variable selection,
	//	 by picking an unsatisfied clause at random and for this clause, calculate the P values
	//	 and pick the variable according to the probability distribution given by the P values.
	//3. Return the chosen variable.
	#ifdef VERBOSE_SLS
	printf("c Picking variable...\n");
	#endif
	chosenVar = 0;
	//1. Pick variable to flip using SCORES
	#ifdef VERBOSE_SLS
	printf("c By scores...\n");
	#endif
	for (i = 0; i < numDecVars; ++i){
		var = decVars[i];
		#ifdef COLLINF_SLS
			if (score[var] > maxVariableScore) maxVariableScore = score[var];
			if (score[var] < minVariableScore) minVariableScore = score[var];
		#endif
		if (score[var] < weightStepping){
			#ifdef VERBOSE_SLS
			printf("c\tIGNORING VAR: %i, score: %i, lastFlipped:%u\n",
					var,score[var], lastFlipped[var]);
			#endif
			isDecVars[var] = 0;
			decVars[i] = decVars[--numDecVars];
			--i;
			#ifdef COLLINF_SLS
			if (flips - variables[var].lastMarkedAt > variables[var].longestMarkingDistance){
				variables[var].longestMarkingDistance = flips - variables[var].lastMarkedAt;
				variables[var].longestMarkingDistEnd = flips;
			}
			#endif
		} else {
			if (score[var] > bestScore
					#ifdef TABULIST
					&& (flips < TABU || lastFlipped[var] < flips+1-TABU)
					#endif
			){
				chosenVar = var;
				bestScore = score[var];
				bestLastFlipped = lastFlipped[var];
				#ifdef VERBOSE_SLS
				printf("c\tCHOSEN VAR: %i, score: %i, lastFlipped:%u\n",
					chosenVar,score[chosenVar], lastFlipped[chosenVar]);
				#endif
			} else if (bestScore == score[var]){
				if (lastFlipped[var] < bestLastFlipped){
					chosenVar = var;
					bestLastFlipped = lastFlipped[var];
				}
			}
			#ifdef VERBOSE_SLS
			else {
				printf("c\tSKIPPED VAR:%i, score: %i, lastFlipped:%u"
						#ifdef TABULIST
						", isTabu:%i"
						#endif
						"\n",
					var,score[var], lastFlipped[var]
						#ifdef TABULIST
					    ,(flips >= TABU && lastFlipped[var] >= flips+1-TABU)?1:0
						#endif
					);
			}
			#endif
		}
	}
	//End pick variable to flip using SCORES

	if (chosenVar != 0){
		//The scores did help. A variable with positive score exists and was chosen!
		#ifdef VERBOSE_SLS
		printf("c Variable picked by positive score: %i\nc\n",chosenVar);
		#endif
		#ifdef COLLINF_SLS
		isRandomFlip = 0;
		#endif
		return;
	}

	//2. Pick variable to flip using Sparrow probability distribution.
	#ifdef VERBOSE_SLS
	printf("c No candidate variable with positive score was found.\n");
	printf("c Picking a random clause to satisfy.\n");
	#endif
	#ifdef COLLINF_SLS
	isRandomFlip = 1;
	#endif
	cNum = unsatClauses[rand()%numUnsatClauses];
	//With the Sparrow scheme from Adrian Balint and Andreas Froehlich, the original parameters are as follows:
	//C1 = 2.0; C2 = 4.0; C3 = 100000; This stuff is however implemented extra tight. So you wont be able to
	//see the actual sparrow scheme in the code. The comments give you a hint on what is done exactly.
	//After heavy tuning, the parameters got adapted as you can see in global.c (top for the PS_TABLE) and
	//the age. C3 is no constant in this solver, it depends on the instance size.

	#ifdef VERBOSE_SLS
	printf("c The clause picked randomly is: %i\n",cNum);
	#endif
	for (i = 0; (var = abs(clauseLiterals[cNum][i])) > 0; ++i){
		age = (float)(flips-lastFlipped[var]);
		//We first calculate the p_s(var) value. All the following p_s values are already multiplied with
		//ageMeasure. This saves us the necessity for a mulitplication later on.
		if (score[var] <= -10) {
			//Too small values for score lead to zero probability anyway. We cutoff at -10!
			//The following line is equal to: prob[var] = pow(C1,(double)-10);
			prob[i] = PS_TABLE[0];
		} else if (score[var] < 0){
			//This is the score range that we are interested in.
			//The following line is equal to: prob[var] = pow(C1,(double)score[var]);
			prob[i] = PS_TABLE[abs(score[var])];
		} else {
			//A variable with 0 or positive score will receive the constant 1.0 p_s probability here.
			//This is because a variable with positive score would have been in decVars, but the fact
			//that we are in this method right now means the decVars set is empty. This then means
			//that all variables with positive score are "blocked" because of the g2wsat scheme.
			prob[i] = ageMeasure;
		}
		//Second we calculate the p_a(var) value. prob[i] already contains the ageMeasure.
		if (age > ageIgnore){
			//Age seems to be big enough to have an impact.
			age = age*age;
			age = age*age;
			prob[i] += age;
		}
		totalP += prob[i];

		#ifdef VERBOSE_SLS
		printf("c\tVariable:%i\t(score: %i\tage: %7.u)\tp_%i:\t%f\n",
				abs(clauseLiterals[cNum][i]),score[abs(clauseLiterals[cNum][i])],
				flips-lastFlipped[abs(clauseLiterals[cNum][i])],abs(clauseLiterals[cNum][i]),prob[i]);
		#endif
	}
	#ifdef VERBOSE_SLS
	printf("c\ttotalP:%.10f\n",totalP);
	#endif
	//Now, based on the p values of the clause cNum variables, pick one to flip.
	//Pick a random number between 0 and 1.
	r = (OORANDMAX*rand())*totalP;
	#ifdef VERBOSE_SLS
	printf("c\tr: %.10f\n",r);
	#endif

	//We sum up the probabilities of the variables in the clause until the sum is >= r. The variable for
	//which this happens is the one we pick. If this does not happen (number crunching problem) we pick the
	//last variable in the array.
	i = 0;
	for (ptr = clauseLiterals[cNum]; *ptr != 0; ++ptr){
		totalP -= prob[i++];
		chosenVar = abs(*ptr);
		if (totalP <= r){
			#ifdef VERBOSE_SLS
			printf("c\t\ttotalP = totalP - p_%i:\t%.10f <= r. Done.\n",abs(clauseLiterals[cNum][i-1]),totalP);
			#endif
			break;
		}
		#ifdef VERBOSE_SLS
		else {
			printf("c\t\ttotalP = totalP - p_%i:\t%.10f\n",abs(clauseLiterals[cNum][i-1]),totalP);
		}
		#endif
	}
	//End pick variable to flip using Sparrow probability distribution.
	//Finally, if weighting is enabled, update the clause weights after this random variable choice.
	#ifdef WEIGHTING
	checkClauseWeights();
	#endif
	#ifdef VERBOSE_SLS
	printf("c Variable picked by probability distribution: %i\nc\n", chosenVar);
	#endif
}

//This method performs a variable flip.
void flipVar(){
	register int cNum,toEnforce,var,lit,*ptr,*ptrInCls;
	//We want to flip the assignment of the selected variable.
	//Tasks to perform:
	//1. Flip the assignment of the variable, increase flips and update variable.lastFlipped.
	//	 Furthermore, we mark all partner variables that have a positive score.
	//2. For all clauses in which the chosenVar is in (distinct between the clauses it appears in with
	//   positive and with negative sign):
	//	a.update numtrueVars, trueVar
	//	b.update the scores for the variables in the clause
	//  c.if clause is unsatisfied, put it in the unsatClauses array
	//  d.if clause becomes satisfied, remove it from the unsatClauses array
	//4.Check all partners again and those, that have a positive score BUT NO mark are added to decVars
	#ifdef COLLINF_SLS
	if (lastVar == chosenVar){
		variables[chosenVar].numBackToBackFlips++;
		if (isRandomFlip) {
			variables[chosenVar].numBackToBackRand++;
		}
		doubleFlips++;
	}
	lastVar = chosenVar;
	if (isRandomFlip){
		numRandomFlip++;
	}
	variables[chosenVar].numFlipped++;
	#endif

	//1.
	#ifdef VERBOSE_SLS
	printf("c FLIP NUMBER: %u, Flipping variable: %i\n",flips, chosenVar);
	#endif

	if (assignment[chosenVar]){
		toEnforce = -chosenVar;//The clauses that contain -chosenVar may become sat.
	} else {
		toEnforce = chosenVar;//The clauses that contain chosenVar may become unsatisfied.
	}

	flips++;
	lastFlipped[chosenVar] = flips;
	assignment[chosenVar] = 1 - assignment[chosenVar];

	#ifdef VERBOSE_SLS
	printf("c Changing variable %i assignment to %i\n",chosenVar, assignment[chosenVar]);
	printf("c Marking variables with positive score before flip: ");
	#endif
	for (ptr = partners[chosenVar]+2; (var = *ptr) > 0; ++ptr){
				isDecVars[var] = (score[var] > 0);
				#ifdef VERBOSE_SLS
				printf("%i:%i ", var,(score[var] > 0));
				#endif
	}
	#ifdef VERBOSE_SLS
	printf("\n");
	#endif

	//2.
	#ifdef VERBOSE_SLS
	printf("c Checking clauses for flip of %i:\n",chosenVar);
	#endif
	//First check all clauses where the chosenVar becomes true.
	for (ptr = clauseAppearance[toEnforce]; (cNum = *ptr) > -1; ++ptr){
		#ifdef VERBOSE_SLS
		printf("c\tClause %i(%i):\t", cNum,weight[cNum]);
		printf("gains true literal, numTrue: %i+1<%i>.\tChanging scores: ",
				numTrue[cNum], trueVar[cNum]);
		#endif
		#ifdef COLLINF_SLS
		clauseStateChangesTotal++;
		#endif
		if (++numTrue[cNum] < 2){//Must be one then.
			//Before, the clause had no true literals. All its variables had a make score through it.
			//The make score will now be removed. Furthermore, the chosenVar gets a brake penalty for
			//this clause. The chosenVar is the new trueVar in the clause.
			//This clause is removed from the unsatClauses array.
			trueVar[cNum] = chosenVar;
			score[chosenVar] -= weight[cNum]; //Brake penalty.
			#ifdef VERBOSE_SLS
			printf("(replacing trueVar with %i) ", trueVar[cNum]);
			printf("%i- to %i, ", chosenVar, score[chosenVar]);
			#endif
			for (ptrInCls = clauseLiterals[cNum]; (var = abs(*ptrInCls)) > 0; ptrInCls++){
				//Reduce scores for variables, they all can not make the clause anymore.
				score[var] -= weight[cNum];
				#ifdef VERBOSE_SLS
				printf("%i- to %i, ",var, score[var]);
				#endif
			}
			unsatClauses[whereUnsat[cNum]] = unsatClauses[--numUnsatClauses];
			whereUnsat[unsatClauses[whereUnsat[cNum]]] = whereUnsat[cNum];
			#ifdef COLLINF_SLS
			litTrueOne++;
			#endif
			#ifdef VERBOSE_SLS
			printf("SAT ");
			#endif
		} else if (numTrue[cNum] < 3){//Must be two then.
			//The chosenVar newly adds a true literal to the clause. The old true literal stays true.
			//The old true literal is relieved of its penalty because it cannot brake the clause anymore.
			score[trueVar[cNum]] += weight[cNum];//Remove penalty.
			#ifdef VERBOSE_SLS
			printf("%i+ to %i, ", trueVar[cNum], score[trueVar[cNum]]);
			#endif
			#ifdef COLLINF_SLS
			litTrueTwo++;
			#endif
		}//else more than two true literals in the clause. Nothing to do.
		#ifdef COLLINF_SLS
		else {
			litTrueMore++;
		}
		#endif
		//Clause handling complete.
		#ifdef VERBOSE_SLS
		printf("\n");
		#endif
	}
	//First check all clauses where the chosenVar becomes false.
	toEnforce = -toEnforce;
	for (ptr = clauseAppearance[toEnforce]; (cNum = *ptr) > -1; ++ptr){
		//Checking all its clauses where the variable occurs in with POSITIVE sign.
		#ifdef VERBOSE_SLS
		printf("c\tClause %i(%i):\t", cNum,weight[cNum]);
		printf("loses true literal, numTrue: %i-1<%i>.\tChanging scores: ",
				numTrue[cNum], trueVar[cNum]);
		#endif
		#ifdef COLLINF_SLS
		clauseStateChangesTotal++;
		#endif
		if (--numTrue[cNum] < 1){//Must be zero then
			//The chosenVar was the last true literal, we just destroyed it.
			//The chosenVar had a penalty for this clause because it made it true on its own. We remove
			//the penalty. Furthermore, all variables in the clause get their score increased.
			//We add this clause to the unsatClauses arary.
			score[chosenVar] += weight[cNum];//Remove brake penalty.
			#ifdef VERBOSE_SLS
			printf("%i+ to %i, ", chosenVar, score[chosenVar]);
			#endif
			for (ptrInCls = clauseLiterals[cNum]; (var = abs(*ptrInCls)) > 0; ptrInCls++){
				//Increase scores for variables, they all can make the clause anymore.
				score[var] += weight[cNum];
				#ifdef VERBOSE_SLS
				printf("%i+ to %i, ",var, score[var]);
				#endif
			}
			whereUnsat[cNum] = numUnsatClauses;
			unsatClauses[numUnsatClauses++] = cNum;
			#ifdef COLLINF_SLS
			litFalseZero++;
			#endif
			#ifdef VERBOSE_SLS
			printf("UNSAT ");
			#endif
		} else if (numTrue[cNum] < 2){//Must be one then.
			//Here we destroyed one of the true literals in the clause. We cannot guarantee that the
			//last true literal in this clause is up to date, so we check it.
			//Furthermore, the new trueVar gets a penalty because it can now brake the clause.
			for (ptrInCls = clauseLiterals[cNum]; (lit = *ptrInCls) != 0; ++ptrInCls){
				if ((lit>0) == (assignment[abs(lit)])){
					//Here we have found the one true literal of the clause.
					trueVar[cNum] = abs(lit);
					score[abs(lit)] -= weight[cNum];//Add penalty.
					#ifdef VERBOSE_SLS
					printf("(replacing trueVar with %i) ", trueVar[cNum]);
					#endif
					break;
				}
			}
			#ifdef COLLINF_SLS
			trueVarMiss++;
			litFalseOne++;
			#endif
			#ifdef VERBOSE_SLS
			printf("%i- to %i ", trueVar[cNum], score[trueVar[cNum]]);
			#endif
		}
		#ifdef COLLINF_SLS
		else {
			litFalseMore++;
		}
		#endif

		//Clause handling complete.
		#ifdef VERBOSE_SLS
		printf("\n");
		#endif
	}

	#ifdef VERBOSE_SLS
	printf("c Updating decVars with partners (+ = yes, / = ignored): ");
	#endif
	for (ptr = partners[chosenVar]+2; (var = *ptr) > 0 ; ++ptr){
		#ifdef VERBOSE_SLS
		printf("%i(%i)", var, score[var]);
		#endif
		  if (!isDecVars[var]
		        && score[var] > 0){
			  decVars[numDecVars++] = var;
			#ifdef COLLINF_SLS
			  variables[var].lastMarkedAt = flips;
			#endif
			#ifdef VERBOSE_SLS
			printf("+ ");
			#endif
		}
		#ifdef VERBOSE_SLS
		printf("/ ");
		#endif
	}
	#ifdef VERBOSE_SLS
	printf(" done.\n");
	#endif
}

//This method contains the main loop for the SLS solver.
void sls(){
	returnValue = UNKNOWN;
	while(1){
		if (numUnsatClauses == 0){
			//All clauses satisfied by current assignment.
			returnValue = SAT;
			return;
		}
		#ifdef COLLINF_SLS
		if (numUnsatClauses == 1) numOfLocalMinima++;
		#endif

		#ifdef TIMING
		//If TIMING flag is active, the solver will check every TIMECHECKINTERVAL many flips if
		//the time in seconds maxTime is used up. If so, we have to stop.
		if (flips % TIMECHECKINTERVAL == 0 && maxTime > 0){//Respect timing?
			if(((float)(clock())/((float)CLOCKS_PER_SEC)) > (float)maxTime){//Time to stop?
				returnValue = UNKNOWN;
				printf("c Timeout.\n");
				break;
			}
		}
		#endif

		pickVar();
		flipVar();

		#ifdef HYBRID
			callCDCL();
			if (returnValue == SAT || returnValue == UNSAT){
				return;
			}
			#ifdef VSIDS_INCREASEINFLIPS
				if (heuristic == HEURVSIDS){
					sls_updateVSIDSScores();
				}
			#endif
		#endif

		#ifdef VERBOSE_SLS
		printClauses();
		printVariableScores();
		printUnsatClauses();
		printLargeWeightClauses();
		printDecVars();
		#endif
	}
}
