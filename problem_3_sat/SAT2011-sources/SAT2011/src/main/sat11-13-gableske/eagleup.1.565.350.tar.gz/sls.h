/*
 * sls.h
 *
 *  Created on: 04.08.2010
 *      Author: Oliver Gableske
 *  	Content: This file contains all definitions and declarations for the SLS component.
 */

#ifndef SLSDRMP_H_
#define SLSDRMP_H_

#include "global.h"

//FOR COLLECTING ADDITIONAL INFORMATION
#ifdef COLLINF_SLS		//Additional information about clauses being affected by a flip is stored
struct variable {					//A struct representing a variable to collect additional information.
	int numFlipped;					//The number of flips this variable received.
	int numBackToBackFlips;			//The number of back to back flips for this variable.
	int numBackToBackRand;			//The number of back to back flips in random flips.
	int longestMarkingDistance;		//How long was this variable being marked most in a row?
	int lastMarkedAt;				//The flip this variable was last marked at.
	int longestMarkingDistEnd;		//At what flip did this distance end?
};
struct variable* variables;			//The array for additional variable informations.
int litTrueOne;						//The literal became true by the flip. Clause has one true literal.
int litTrueTwo;						//The literal became true by the flip. Clause has two literals.
int litTrueMore;					//The literal became true by the flip. Clause has more than two true.
int litFalseZero;					//The literal became false by the flip. The clause has no true literals.
int litFalseOne;					//The literal became false by the flip. The clause has one true literal.
int litFalseMore;					//The literal became false by the flip. The clause has two true literals.
int trueVarMiss;					//A new trueVar for a clause had to be searched.
int clauseStateChangesTotal;		//How often did some clause change its number of true literals.
int maxClauseWeight;				//The maximum clause weight ever occurring.
int maxVariableScore;				//The largest variable score ever encountered.
int minVariableScore;				//The smallest variable score ever encountered.
int addIncrease;					//How often a variable was inserted in decVar while clause weight increase
int addDecrease;					//How often a variable was inserted in decVar while clause weight decrease
int doubleFlips;					//The number of times a variable was flipped twice.
int numRandomFlip;					//The number of random (Sparrow-like) flips.
int lastVar;						//The last variable that was flipped.
int numWeightDecrease;				//The number of times the clause weights got smoothed.
int numWeightIncrease;				//The number of times the clause weights got increased.
int numCheckClauseWeight;			//How often the clause weights were checked.
int numOfLocalMinima;				//The number of assignments found that left only one clause unsatisfied.
int maxNumClauseAppearance;			//The maximum number of clauses a single literal appeared in.
char isRandomFlip;					//Specifies whether the variable was picked randomly or by greedily.
#endif

//FORWARD DECLARATIONS
#ifdef HYBRID
void (*callCDCL)();
void callCDCL_null();

#ifdef MINIMACALLING
unsigned int cooldownLength;

#ifdef DISTRIBUTIONCAUCHY
unsigned int* CAUCHY_COOLDOWNS;
double* CAUCHY_TABLE;
double CAUCHY_GAMMA;
double CAUCHY_OFFSET_FRACTION;
int CAUCHY_OFFSET;
int CAUCHY_TABSIZE;
int CAUCHY_FLIPINCREASE;
double distribution_pow(double, int);
void distribution_createCauchyTable();
double distribution_atan(double);
void distribution_cauchy();
#endif

void (*distribution)();
void callCDCL_localMin();
#endif

#ifdef VSIDS_INCREASEINFLIPS
inline void sls_updateVSIDSScores();
#endif
#endif /* HYBRID */

void calculateInitialScoresAndDecVars();
void (*checkClauseWeights)();
void checkClauseWeightsNull();
void checkClauseWeightsLinear();
void pickVar();
void flipVar();
void sls();
#endif /* SLSDRMP_H_ */
