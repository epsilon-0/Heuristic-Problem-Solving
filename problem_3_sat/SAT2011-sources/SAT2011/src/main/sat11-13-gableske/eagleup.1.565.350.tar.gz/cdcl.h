/*
 * cdcl.h
 *
 *  Created on: 28.09.2010
 *      Author: Oliver Gableske
 *  	Content: This file contains all definitions and declarations for the CDCL component.
 */

#ifndef CDCL_H_
#define CDCL_H_

#include "global.h"
#ifdef PREPROCESSING
#include "preprocessor.h"
#endif
#ifdef TRANSFERASSIGNMENTCHANGES
#include "sls.h"
#endif
#ifdef HYBRID
//GLOBAL CONSTANTS
enum {
	#ifdef HIHEURISTIC
	HIDEPTH = 5,				//The number of levels in the HI-Heuristic that will be computed.
	#endif
	MAXINITDECLEVELS = 10,		//The initial size (number of levels) of the decision stack.
	MAXINITELEMENTS = 1,		//The number of elements that you initially allocate the memory for in a stack.
	HEURSIMPLE = 100,			//The simple strategy for decision variable selection is in use.
	HEURHI = 101,				//The HI heuristic is in use for selecting decision variables.
	HEURVSIDS = 102,			//The VSIDS heuristic is in use for selecting decision variables.
	HEURAGE = 103,				//The AGE heuristic is in use for selecting decision variables.
	HEURRAND = 104, 			//The RANDOM variable ordering heuristic is in use for selecting decision variables.
	CONFLICT = 3				//The status of the CDCL search if a conflict is found.
};

//GENERAL
int heuristic;					//Tells you what variable selection heuristic is in use.
int cdcl_lubyUnit;				//The base value for the LUBY series calculation.
unsigned int cdcl_callNumber;	//The number of times the CDCL was called.
unsigned int cdcl_lastCall;		//The flip at which the CDCL has been called last.
int maxNumberOfConflicts;		//The maximum number of conflict the CDCL is allowed to run into before returning.
int numberOfConflicts;			//The number of encountered conflicts in the current call (not the total).
int numCDCLClauses;				//The total amount of clauses found in the clause literals array. The clauses that
								//are visible for the SLS are found in the same array, but only up to numClauses.
								//It always holds that numOriginalClauses <= numClauses <= numCDCLClauses.
unsigned char cdcl_returnValue; //The return value of the CDCL component.
#ifdef TIMING
float cdcl_callStarttime;		//Start time of a CDCL call.
float cdcl_callEndtime;			//End time of a CDCL call.
float cdcl_runtime;				//Total sum of all times of CDCL calls.
#endif
//VARIABLE RELATED
int decisionLiteral;			//The literal that is supposed to be satisfied in making the new decision.
unsigned char* tvalue;			//The currently overridden reference point. tvalue[7] = 2 means not overridden.
								//In this case the variable 7 is still assigned to assignment[7].
int** watches1;					//Tells you what clauses are watched by the specific literal as the first watched
								//literal. First element in this array tells you how many the literal watches.
								//Second element tells you how much memory was allocated to hold elements.
								//Must be terminated with -1.
int* watches1pos;				//At what position is the clause found in watches1 array of the watching literal.
								//This info is given without the offset of +2. So if you want to find the clause
								//in watches1 you calculate: watches1[lit][2+watches1pos[clause]] == clause.
int** watches2;					//Tells you what clauses are watched by the specific literal as the second watched
								//literal. First element in this array tells you how many the literal watches.
								//Second element tells you how much memory was allocated to hold elements.
								//Must be terminated with -1.
int* watches2pos;				//At what position is the clause found in watches2 array of the watching literal.
								//This info is given without the offset of +2. So if you want to find the clause
								//in watches2 you calculate: watches2[lit][2+watches2pos[clause]] == clause.

//CLAUSE RELATED
int* watchedLiteral1;			//The first watched literal for a clause.
int* watchedLiteral2;			//The second watched literal for a clause.
int conflictClause;				//The clause a conflict was discovered on.

//DECISION STACK RELATED
int currentDecLevel;					//The current decision level the CDCL is working on.
int maxDecLevel;						//The number of decision levels we have memory allocated for in
										//decisionStack. In the beginning this is MAXINITDECLEVELS, meaning that
										//only cdcl_decisionStack_*[0 to MAXINITDECLEVELS-1] exist.
int** cdcl_decisionStack_assignments;	//Assignments made in the decision level. First element is the number of
										//made assignments. Second element tells you for how many elements in total
										//we have the memory allocated. Last element is 0.

//UNITPROP RELATED
int* cdcl_unitPropBuffer;				//A variable ring-buffer containing literals of unit clauses.
int cdcl_unitPropLastAdded;				//The variable that was last added to the unit propagation buffer.
int* cdcl_reasonPropBuffer;				//For every unit propagation, we store the clause that is its reason.
int* cdcl_unitPropBufferLast;			//The last position in the ring buffer as a pointer.
int* cdcl_unitPropBufferMax;			//The maximum offset for the unit propagation buffer.
int* cdcl_unitPropBufferPos;			//The current position for the unit clause buffer as a pointer.
int* cdcl_reasonPropBufferPos;			//The pointer to the current position of the unit propagation but in the
										//reason buffer. This gives the reason for the current propagation.
int* cdcl_reasonPropBufferLast;			//The pointer to the last position in the reason propagation buffer.
int* cdcl_reason;						//The reason-clause why a variable was finally assigned. -1 means decision.
int* cdcl_assignmentLevel;				//In what level was a variable assigned.

//CONFLICT ANALYSIS RELATED
#ifndef UNITWALK
int cdcl_learnedConflictClauseSize;		//The size of the learned conflict clause.
int cdcl_learnedConflictClauseAssLit;	//The asserting literal of the newly learned conflict clause. It will also
										//serve as first watcher of the newly learned clause.
int cdcl_learnedConflictClauseWatcher2;	//The literal serving as second watcher. Usually the one assigned in the
										//back-jump target level.
int cdcl_backjumpTargetLevel;			//While learning a clause we determine what level we must back-jump to.
#endif

//PICKING OF DECISION VARIABLE RELATED
int* variable_rank;				//A pointer to the currently used ranking array.
int* variable_order;			//A pointer to the currently used order array.
int* orderPtr;					//A pointer pointing in the variables array ordered by their score.

struct scoredvar {				//A holder structure for some data, later used to calculate the variable_order and rank:
	int var;					//A variable number.
	float totalScore;			//The total score for variable.
};
struct scoredvar* hVar;

#ifdef HIHEURISTIC
int* variable_rank_hi;			//The rank of the variable according to the HI-heuristic.
int* variable_order_hi;			//The order of the variables. Highest ranked first according to the HI-heuristic.
float* s;						//The s values for the HI-heuristic.
float** lScore;					//The literal scores coded as lScore[i][lit].
float* lScore_size;				//The not-normalized scores for a specific clause size.
#endif

#ifdef VSIDSHEURISTIC
int* variable_rank_vsids;		//The rank of the variables according to the VSIDS heuristic.
int* variable_order_vsids;		//The order of the variables. Highest/Lowest/Toggle first according to VSIDS and flags.
float* vsidsScore;				//An array containing the basic scores of the variables.
#endif

#ifdef AGEHEURISTIC
int* variable_rank_age;			//The rank of the variables according to their latest flip.
int* variable_order_age;		//The order of the variables. Oldest variable first.
#endif

#ifdef RANDOMHEURISTIC
int* variable_rank_random;		//The rank of the variables according to a random sorting.
int* variable_order_random;		//The order of the variables. A random variable first.
#endif

#ifndef HIHEURISTIC
#ifndef VSIDSHEURISTIC
#ifndef AGEHEURISTIC
#ifndef RANDOMHEURISTIC
int* variable_order_simple;
int* variable_rank_simple;
#endif
#endif
#endif
#endif

//CONFLICT ANALYSIS RELATED
#ifndef UNITWALK
#ifdef LEARNUIP
int* cdcl_UIPReplacementBuffer;		//The replacement buffer for creating a learned clause.
unsigned char* cdcl_UIPAdded;		//Whether a variable was added to replacement buffer.
#endif
#endif /* UNITWALK */

//FOR COLLECTING ADDITIONAL INFORMATION
#ifdef COLLINF_CDCL
unsigned int cdcl_callDistances;
unsigned int cdcl_necNumUnsatClsIncreases;
unsigned int cdcl_necNumUnsatClsDecreases;
unsigned int cdcl_maxNecNumUnsatCls;
unsigned int cdcl_numberOfDecisions;
unsigned int cdcl_numberOfBackjumps;
unsigned int cdcl_numBackjumpsLastCall;
unsigned int cdcl_numPropsBasedOnLearnedLastCall;
unsigned int cdcl_numPropsBasedOnLearned;
unsigned int cdcl_numUnitPropBufferIncreases;
#ifdef TRANSFERASSIGNMENTCHANGES
unsigned int cdcl_numTransferredAssignmnetChanges;
#endif
int* cdcl_learnedClausesOfLength;
#endif

//GLOBAL FORWARD DECLARATIONS
////HELPHERS
#ifdef VERBOSE_CDCL
void cdcl_printClauseInline(int);
void cdcl_printVariables();
void cdcl_printClauses();
void cdcl_printDecisionStack();
void cdcl_printPropagationBuffers();
#endif
char cdcl_isPowerOfTwoOrZero(const unsigned int);
inline int cdcl_fastLog2(unsigned int);
int cdcl_getLuby(const unsigned int);
inline void cdcl_transferSolutionToSLS();
inline unsigned char cdcl_getVariableAssignment(const int);
inline void cdcl_addToUnitPropBuffer(const int,const int);
int cdcl_compareScoredVar_totalscore_max(const void*, const void*);
int cdcl_compareScoredVar_totalscore_min(const void*, const void*);
#ifdef TRANSFERASSIGNMENTCHANGES
inline void cdcl_transferAssignmentChangesToSLS();
#endif

////WATCHED LITERAL RELATED
inline void cdcl_watcher_checkMemoryForWatcher1(const int);
inline void cdcl_watcher_checkMemoryForWatcher2(const int);
inline void cdcl_watcher_findNewFirst(const int);
inline void cdcl_watcher_findNewSecond(const int);
inline void cdcl_watcher_replaceFirst(const int, const int, const int);
inline void cdcl_watcher_replaceSecond(const int, const int, const int);

////DECISION STACK RELATED
inline void cdcl_decisionStack_addVariableAssignment(const int, const int, const int);
inline int cdcl_decisionStack_getVariableAssignment(const int, const int);
inline void cdcl_decisionStack_increaseDecisionLevel();
void cdcl_decisionStack_backjump(int);

////PICKING OF DECISION VARIABLE RELATED
#ifdef HIHEURISTIC
void cdcl_hiHeuristic();
#endif
#ifdef VSIDS_INCREASEINCONFLICT
inline void cdcl_updateVSIDSScores();
#endif
void cdcl_pickLiteralToSatisfy();

////CONFLICT ANALYSIS RELATED
#ifndef UNITWALK
#ifdef LEARNUIP
void cdcl_conflictAnalysis_learnUIP();
#endif
void cdcl_conflictAnalysis_learnSimple();
void (*cdcl_conflictAnalysis_learn)();
void cdcl_conflictAnalysis_insertNewClause();
#endif /* UNITWALK */

////GENERAL
void cdcl_allocateAndInitialize();
void cdcl_dispose();
void cdcl_initCall();
void cdcl_propagateAssignments();
int cdcl();
#endif /* HYBRID */
#endif /* CDCL_H_ */
