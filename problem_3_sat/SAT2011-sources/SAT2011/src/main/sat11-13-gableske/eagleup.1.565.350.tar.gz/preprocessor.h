/*
 * preprocessor.h
 *
 *  Created on: 10.09.2010
 *      Author: Oliver Gableske
 *  	Content: This file contains all definitions and declarations for the preprocessor.
 */

#ifndef PREPROCESSOR_H_
#define PREPROCESSOR_H_

#include "global.h"

#ifdef PREPROCESSING
//GENERAL PREPROCESSOR STUFF
int preproc_repeat;							//If changes happened during preprocessing, we must repeat preprocessing.
unsigned char* isIgnoredClause;				//isIgnoredClause[i] tells you that clause i is ignored.
int preproc_numIgnoredOriginalCls;			//The number of original clauses that we already ignore. If this equals the
											//the number of original clauses, we are done and the formula is satisfiable.

#ifdef VERBOSE_PREPROC
int preprocess_round;						//How many rounds the preprocessor performed.
#endif

//UNITPROP RELATED
#ifdef UNITPROP
int* preproc_unitPropBuffer;				//A variable ring-buffer containing literals of unit clauses.
unsigned char* preproc_isInUnitPropBuffer;	//States whether a specific variable is already marked for unit prop.
unsigned int preproc_unitPropBufferLast;	//The last position in the ring buffer.
unsigned int preproc_unitPropBufferPos;		//The current position for the unit clause buffer.
#endif

//COLLECTING OF INFORMATION RELATED
#ifdef COLLINF_PREP
int preproc_unitProps;						//The number of performed unit propagations.
int preproc_pureLits;						//The number of pure literals found in preprocessing.
int preproc_pureLitsIgnoredCls;				//The number of clauses being ignored for containing a pure literal.
#endif

//FORWARD DECLARATIONS OF PREPROCESSOR
void preprocess_makeClauseIgnored(int);
void preprocess_removeLiteralFromClause(int,int);
void preprocess_removeFromAppearanceList(int,int);
void preprocess_enforceAssignment(int, int);
void preprocess_random();
void preprocess_application();
void preprocess_allocateAndIntialize();
void preprocess_dispose();
void preprocess();
#ifdef UNITPROP
void preprocess_unitPropagation();
#endif
#ifdef PURELIT
void preprocess_pureLiterals();
#endif
#ifdef HBCE
void preprocess_hbce();
#endif
#endif /* PREPROCESSING */
#endif /* PREPROCESSOR_H_ */
