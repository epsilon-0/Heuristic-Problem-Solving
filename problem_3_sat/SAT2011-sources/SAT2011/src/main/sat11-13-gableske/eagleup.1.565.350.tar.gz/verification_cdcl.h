/*
 * verification_cdcl.h
 *
 *  Created on: 23.10.2010
 *      Author: Oliver Gableske
 *	   Content: This file contains all declarations to perform verifications for the CDCL component.
 *
 */

#ifndef VERIFICATION_CDCL_H_
#define VERIFICATION_CDCL_H_

#include "global.h"

#ifdef HYBRID
#ifdef VERIFICATION_CDCL

#ifndef VERBOSE_CDCL
void cdcl_printClauseInline(int);
#endif /* VERBOSE_CDCL */
int verification_cdcl_countNumberOfSatsifyingLiterals(int);
int verification_cdcl_countNumberOfUnassignedVaribales(int);
void verification_cdcl_verifyInitCall();
void verification_cdcl_verifyMemoryAllocation();
void verification_cdcl_learnedClauseHasFirstWatcher();
void verification_cdcl_learnedClauseHasSecondWatcher();
void verification_cdcl_clauseHasOldFirstWatcher(int);
void verification_cdcl_clauseHasOldScondWatcher(int);
void verification_cdcl_verifyFirstWatcherReplacement_primary(int,int,int);
void verification_cdcl_verifyFirstWatcherReplacement_secondary(int,int,int);
void verification_cdcl_verifySecondWatcherReplacement_primary(int,int,int);
void verification_cdcl_verifySecondWatcherReplacement_secondary(int,int,int);
void verification_cdcl_verifyWatcher1Adaption_case1(int);
void verification_cdcl_verifyWatcher1Adaption_case2(int);
void verification_cdcl_verifyWatcher1Adaption_case3(int);
void verification_cdcl_verifyWatcher1Adaption_case4(int);
void verification_cdcl_verifyWatcher2Adaption_case0(int);
void verification_cdcl_verifyWatcher2Adaption_case1(int);
void verification_cdcl_verifyWatcher2Adaption_case2(int);
void verification_cdcl_verifyWatcher2Adaption_case3(int);
void verification_cdcl_verifyWatcher2Adaption_case4(int);
void verification_cdcl_verifyLearnedClauseIsUnit();
void verification_cdcl_verifyVariableStates();
void verification_cdcl_verifyClauseStates();
#endif /* VERIFICATION_CDCL */
#endif /* HYBRID */

#endif /* VERIFICATION_CDCL_H_ */
