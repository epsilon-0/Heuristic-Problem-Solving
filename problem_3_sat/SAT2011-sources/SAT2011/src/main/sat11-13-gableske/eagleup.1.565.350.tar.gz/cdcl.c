/*
 * cdcl.c
 *
 *  Created on: 28.09.2010
 *     Authors: Oliver Gableske, Julian Rueth
 *     Content: This file contains all methods of the CDCL component.
 */

#include "cdcl.h"
#ifdef HYBRID
//////////////////////////////////////////////////HELPERS

#ifdef VERBOSE_CDCL
//This method outputs all the variables of the formula as it is known to the CDCL. Information provided is
//what clauses a literal watches as second or first watcher.
void cdcl_printVariables(){
	register int i,j,cNum;
	printf("c The clauses a literal watches as first watcher:\n");
	for (i = 1; i < numVars+1; i++){
		printf("c [%i\t]\t%i:",i, watches1[i][0]);
		for (j=2; (cNum = watches1[i][j]) > -1; j++){
			printf("%i ",cNum);
		}
		printf("\nc [%i\t]\t%i:",-i, watches1[-i][0]);
		for (j=2; (cNum = watches1[-i][j]) > -1; j++){
			printf("%i ",cNum);
		}
		printf("\n");
	}
	printf("c\n");
	printf("c The clauses a literal watches as second watcher:\n");
	for (i = 1; i < numVars+1; i++){
		printf("c [%i\t]\t%i:",i, watches2[i][0]);
		for (j=2; (cNum = watches2[i][j]) > -1; j++){
			printf("%i ",cNum);
		}
		printf("\nc [%i\t]\t%i:",-i, watches2[-i][0]);
		for (j=2; (cNum = watches2[-i][j]) > -1; j++){
			printf("%i ",cNum);
		}
		printf("\n");
	}
	printf("c\n");
}

//To print out a clause in-line with clause specific information like the watchers.
void cdcl_printClauseInline(int cNum){
	register int i;
	printf("[%6.1i|%6.1i|%6.1i] ",
			cNum,watchedLiteral1[cNum],watchedLiteral2[cNum]);fflush(stdout);
	for (i = 0; clauseLiterals[cNum][i] != 0; ++i){
		printf("%6.1i(pval:%i,tval:%i)", clauseLiterals[cNum][i],
				assignment[abs(clauseLiterals[cNum][i])], tvalue[abs(clauseLiterals[cNum][i])]);
		fflush(stdout);
	}
}

//To print out all clauses of the formula as it is know to the CDCL.
void cdcl_printClauses(){
	register int i;
	printf("c The %i clauses:\n", numCDCLClauses);
	for (i = 0; i < numCDCLClauses; i++){
		printf("c ");cdcl_printClauseInline(i);printf("\n");
	}
}

//This method is used to print out the current decision stack.
void cdcl_printDecisionStack(){
	register int i,j,lit;
	printf("c The decision stack is:\n");fflush(stdout);
	for (i = 0; i < currentDecLevel+1; i++){
		printf("c\tLevel %i:\nc\t\tAssignments: ",i);fflush(stdout);
		j=0;
		while ((lit = cdcl_decisionStack_getVariableAssignment(i,j)) != 0){
			printf("%i ", lit);fflush(stdout);
			j++;
		}
		printf("\n");
	}
	printf("c\n");
	fflush(stdout);
}

//To print out the unit propagation buffer (along with the reasons for such propagations).
void cdcl_printPropagationBuffers(){
	int *ptrUnit, *ptrReason;
	ptrUnit = cdcl_unitPropBuffer;
	ptrReason = cdcl_reasonPropBuffer;
	printf("c The unit propagation buffer is:\t");
	while (ptrUnit < cdcl_unitPropBufferLast){
		printf("%6.1i ", *ptrUnit);
		ptrUnit++;
	}
	printf("\nc The reason propagation buffer is:\t");
	while (ptrReason < cdcl_reasonPropBufferLast){
		printf("%6.1i ", *ptrReason);
		ptrReason++;
	}
	printf("\nc The size of the buffers are: %i\n", cdcl_unitPropBufferMax-cdcl_unitPropBuffer);
	printf("c The current position in the buffers: unit %i, reason %i\n",
			cdcl_unitPropBufferPos-cdcl_unitPropBuffer, cdcl_reasonPropBufferPos-cdcl_reasonPropBuffer);
}
#endif /* VERBOSE_CDCL */

//This method checks if a given unsigned integer is zero or a power of 2.
char cdcl_isPowerOfTwoOrZero(const unsigned int x){
	return !(x & (x - 1));
}

//This method is used to calculate the logarithm of base 2 of an unsigned integer.
inline int cdcl_fastLog2(unsigned int x){
    __asm__ ("bsr %%eax,%%eax": "=a"(x): "a"(x));
    return x;
}

//This method will caluculate the i-th element of the Luby-series.
int cdcl_getLuby(const unsigned int i){
	if (i<=1) return cdcl_lubyUnit;
	if (cdcl_isPowerOfTwoOrZero(i+1))
		return ((i+1)>>1)*cdcl_lubyUnit;
	else
		return cdcl_getLuby(i-(1<<cdcl_fastLog2(i+1))+1);
}

//This method is used to transfer a solution found by the CDCL over to the SLS solver such that it can stop
//searching and output the solution.
inline void cdcl_transferSolutionToSLS(){
	int i;
	#ifdef LONGHEADER
		int numDifferred = 0;
		printf("c Transferring found solution to SLS. ");
	#endif
	for (i = 1; i < numVars+1; i++){
		if (tvalue[i] != 2 && (tvalue[i] != assignment[i])) {//We only override variable assignments that did change.
			#ifdef LONGHEADER
				++numDifferred;
			#endif
			assignment[i] = tvalue[i];
		}
	}
	#ifdef LONGHEADER
		printf("%i assignments where changed by the CDCL.\n", numDifferred);
	#endif
	solutionFoundBy = SOL_CDCL;
}

//This method is used to check on the current assignment for variable var. Therefore we first check the temporary
//assignment and if the variable is temporarily assigned, we return this assignment. If the variable is yet
//unassigned, we return the assignment of the reference point.
inline unsigned char cdcl_getVariableAssignment(const int var){
	if (tvalue[var] != 2) return tvalue[var];
	return assignment[var];
}

//This method is used to insert a literal to the unit propagation buffer along with the clause number that is the
//reason for this propagation.
inline void cdcl_addToUnitPropBuffer(const int theLit, const int reason){
	//If we added the literal lately, we do not add it again. Makes no sense.
	if (cdcl_unitPropLastAdded == theLit) return;

	//We check if the unit propagation buffer is still large enough.
	if (cdcl_unitPropBufferLast == cdcl_unitPropBufferMax-1){
		//It is not. We double its size.
		#ifdef VERBOSE_CDCL
			printf("c Increasing unit prop buffer size.\n");
			cdcl_printPropagationBuffers();
		#endif
		int oldSize = cdcl_unitPropBufferMax-cdcl_unitPropBuffer;
		int unitPosOffset = cdcl_unitPropBufferPos - cdcl_unitPropBuffer;
		int unitLastOffset = cdcl_unitPropBufferLast - cdcl_unitPropBuffer;
		int reasonPosOffset = cdcl_reasonPropBufferPos - cdcl_reasonPropBuffer;
		int reasonLastOffset = cdcl_reasonPropBufferLast - cdcl_reasonPropBuffer;
		cdcl_unitPropBuffer = realloc(cdcl_unitPropBuffer, sizeof(int)*2*oldSize);
		cdcl_reasonPropBuffer = realloc(cdcl_reasonPropBuffer, sizeof(int)*2*oldSize);
		cdcl_unitPropBufferPos = cdcl_unitPropBuffer+unitPosOffset;
		cdcl_unitPropBufferLast = cdcl_unitPropBuffer+unitLastOffset;
		cdcl_unitPropBufferMax = cdcl_unitPropBuffer+2*oldSize;
		cdcl_reasonPropBufferPos = cdcl_reasonPropBuffer+reasonPosOffset;
		cdcl_reasonPropBufferLast = cdcl_reasonPropBuffer+reasonLastOffset;
		#ifdef VERBOSE_CDCL
			printf("c done. Result of increase:\n");
			cdcl_printPropagationBuffers();
		#endif
		#ifdef COLLINF_CDCL
			++cdcl_numUnitPropBufferIncreases;
		#endif
	}
	cdcl_unitPropLastAdded = theLit;
	*cdcl_unitPropBufferLast = theLit;
	*cdcl_reasonPropBufferLast = reason;
	++cdcl_unitPropBufferLast;
	++cdcl_reasonPropBufferLast;
}

//This method is a comparator used in qsort() to sort the variables according to their score to determine the variable
//rank and order for selecting decision variables. Highest scored variable is ranked best.
int cdcl_compareScoredVar_totalscore_max(const void * a, const void * b){
	if (((float)(*(struct scoredvar *)b).totalScore) -
			((float)((*(struct scoredvar *)a).totalScore)) < 0){
		return -1;
	} else {
		return 1;
	}
}

//This method is a comparator used in qsort() to sort the variables according to their score to determine the variable
//rank and order for selecting decision variables. Lowest scored variable is ranked best.
int cdcl_compareScoredVar_totalscore_min(const void * a, const void * b){
	if (((float)(*(struct scoredvar *)b).totalScore) -
			((float)((*(struct scoredvar *)a).totalScore)) > 0){
		return -1;
	} else {
		return 1;
	}
}

#ifdef TRANSFERASSIGNMENTCHANGES
int cdcl_flipVar(int chosenVar){
	register int cNum,toEnforce,*ptr,diff=0;

	if (assignment[chosenVar]){
		toEnforce = -chosenVar;
	} else {
		toEnforce = chosenVar;
	}

	assignment[chosenVar] = 1 - assignment[chosenVar];

	for (ptr = clauseAppearance[toEnforce]; (cNum = *ptr) > -1; ++ptr){
		if (numTrue[cNum]+1 < 2){
			--diff;
		}
	}
	toEnforce = -toEnforce;
	for (ptr = clauseAppearance[toEnforce]; (cNum = *ptr) > -1; ++ptr){
		if (numTrue[cNum]-1 < 1){
			++diff;
		}
	}

	assignment[chosenVar] = 1 - assignment[chosenVar];

	return diff;
}
//This method is used to transfer over specific assignment changes made by the CDCL to the SLS.
void cdcl_transferAssignmentChangesToSLS(){
	register int level,pos,var;
	for (level = 0; level < currentDecLevel+1; ++level){
		pos = 0;
		while (++pos < cdcl_decisionStack_assignments[level][0]) {
			var = abs(cdcl_decisionStack_getVariableAssignment(level,pos));
			if (assignment[var] != tvalue[var]){
				pickVar();
				chosenVar = var;
				flipVar();
				#ifdef COLLINF_CDCL
				++cdcl_numTransferredAssignmnetChanges;
				#endif
			}
		}
	}
}
#endif

//////////////////////////////////////////////////WATCHED LITERALS RELATED

//This method checks if enough memory is available such that lit can serve as first watcher for an additional
//clause.
inline void cdcl_watcher_checkMemoryForWatcher1(const int lit){
	if (watches1[lit][0] >= watches1[lit][1]-1){
		watches1[lit][1] *= 2;
		watches1[lit] = realloc(watches1[lit],sizeof(int)*(watches1[lit][1]+2));
	}
	#ifdef VERIFICATION_CDCL
		//We assert here that all the memory was allocated without error.
		verification_cdcl_verifyMemoryAllocation();
	#endif
}

//This method checks if enough memory is available such that lit can serve as second watcher for an additional
//clause.
inline void cdcl_watcher_checkMemoryForWatcher2(const int lit){
	if (watches2[lit][0] >= watches2[lit][1]-1){
		watches2[lit][1] *= 2;
		watches2[lit] = realloc(watches2[lit],sizeof(int)*(watches2[lit][1]+2));
	}
	#ifdef VERIFICATION_CDCL
		//We assert here that all the memory was allocated without error.
		verification_cdcl_verifyMemoryAllocation();
	#endif
}

//This method tries to find a new first watcher for a given clause.
inline void cdcl_watcher_findNewFirst(const int cNum){
	int *lit;
	//In this method, we try to find a new literal that can act as first watcher. This method will also take care
	//in replacing the old first watcher if and only if it finds a new first watcher.
	#ifdef VERIFICATION_CDCL
		//We assert here that the clause cNum indeed has a first watcher and that its watches list contains cNum.
		verification_cdcl_clauseHasOldFirstWatcher(cNum);
	#endif
	for (lit = clauseLiterals[cNum]; *lit != 0; ++lit){
		if (*lit != watchedLiteral2[cNum]){
			//We have found a literal that is not already acting as second watcher.
			if (tvalue[abs(*lit)] == 2 || ((tvalue[abs(*lit)] > 0) == (*lit > 0))){
				//*lit is now a literal that can serve as new first watcher. We exit the for-loop.
				break;
			}
		}
	}
	//Here *lit is either 0, in case no new first watcher could be found, or *lit != 0 in which case we replace
	//the old first watcher with the new one.
	if (*lit != 0){
		//We have found a literal in *lit that can act as new first watcher. We replace the old first watcher.
		cdcl_watcher_replaceFirst(cNum,watchedLiteral1[cNum],*lit);
	}
}

//This method tries to find a new second watcher for a given clause.
inline void cdcl_watcher_findNewSecond(const int cNum){
	int *lit;
	//In this method, we try to find a new literal that can act as second watcher. This method will also take care
	//in replacing the old second watcher if and only if it finds a new second watcher.
	#ifdef VERIFICATION_CDCL
		//We assert here that the clause cNum indeed has a second watcher and that its watches list has size > 0.
		verification_cdcl_clauseHasOldScondWatcher(cNum);
	#endif
	for (lit = clauseLiterals[cNum]; *lit != 0; ++lit){
		if (*lit != watchedLiteral1[cNum]){
			//We have found a literal that is not already acting as second watcher.
			if (tvalue[abs(*lit)] == 2 || ((tvalue[abs(*lit)] > 0) == (*lit > 0))){
				//*lit is now a literal that can serve as new second watcher. We exit the for-loop.
				break;
			}
		}
	}
	//Here *lit is either 0, in case no new second watcher could be found, or *lit != 0 in which case we replace
	//the old second watcher with the new one.
	if (*lit != 0){
		//We have found a literal in *lit that can act as new first watcher. We replace the old first watcher.
		cdcl_watcher_replaceSecond(cNum,watchedLiteral2[cNum],*lit);
	}
}

//This method replaces the first watcher of a clause with a new one.
inline void cdcl_watcher_replaceFirst(const int cNum, const int oldLit, const int newLit){
	//In this method we will replace the first watcher oldLit for cNum with newLit. To do so, we have to remove
	//cNum from watches1 by overriding it with the last element in watches1 for oldLit. Then we have to update the
	//watches1pos for the clause newly in this position. Then we have to add cNum in the watches1 for newLit and
	//update the watches1pos of cNum to the position it got added.
	#ifdef VERIFICATION_CDCL
		verification_cdcl_verifyFirstWatcherReplacement_primary(cNum, oldLit, newLit);
	#endif
	//First, remove cNum from watches1[oldLit] by overriding it with the last element of this array.
	--watches1[oldLit][0];
	watches1[oldLit][2+watches1pos[cNum]] = watches1[oldLit][2+watches1[oldLit][0]];
	watches1[oldLit][2+watches1[oldLit][0]] = -1;//Terminate the array anew.
	//Then update the watches1pos for the clause newly at the watches1pos[cNum] position.
	if (watches1[oldLit][2+watches1pos[cNum]] > -1){
		//We override the just shifted clauses position if and only if there was indeed a shift,i.e.
		//the removed element was not in the last position.
		watches1pos[watches1[oldLit][2+watches1pos[cNum]]] = watches1pos[cNum];
	}
	//We now have to insert cNum in the watches1 for newLit.
	cdcl_watcher_checkMemoryForWatcher1(newLit);
	watches1[newLit][2+watches1[newLit][0]] = cNum;
	//Update the new position in the watches array for cNum.
	watches1pos[cNum] = watches1[newLit][0];
	//Terminate the watches array anew.
	++watches1[newLit][0];
	watches1[newLit][2+watches1[newLit][0]] = -1;
	//After all this we have to finally assign the watched literal to make the clause aware of its new buddy.
	watchedLiteral1[cNum] = newLit;
	#ifdef VERIFICATION_CDCL
		verification_cdcl_verifyFirstWatcherReplacement_secondary(cNum, oldLit, newLit);
	#endif
}

//This method replaces the second watcher of a clause with a new one.
inline void cdcl_watcher_replaceSecond(const int cNum, const int oldLit, const int newLit){
	//In this method we will replace the second watcher oldLit for cNum with newLit. To do so, we have to remove
	//cNum from watches2 by overriding it with the last element in watches2 for oldLit. Then we have to update the
	//watches2pos for the clause newly in this position. Then we have to add cNum in the watches2 for newLit and
	//update the watches2pos of cNum to the position it got added.
	#ifdef VERIFICATION_CDCL
		verification_cdcl_verifySecondWatcherReplacement_primary(cNum, oldLit, newLit);
	#endif
	//First, remove cNum from watches2[oldLit] by overriding it with the last element of this array.
	--watches2[oldLit][0];
	watches2[oldLit][2+watches2pos[cNum]] = watches2[oldLit][2+watches2[oldLit][0]];
	watches2[oldLit][2+watches2[oldLit][0]] = -1;//Terminate the array anew.
	//Then update the watches2pos for the clause newly at the watches2pos[cNum] position.
	if (watches2[oldLit][2+watches2pos[cNum]] > -1){
		//We override the just shifted clauses position if and only if there was indeed a shift,i.e.
		//the removed element was not in the last position.
		watches2pos[watches2[oldLit][2+watches2pos[cNum]]] = watches2pos[cNum];
	}
	//We now have to insert cNum in the watches2 for newLit.
	cdcl_watcher_checkMemoryForWatcher2(newLit);
	watches2[newLit][2+watches2[newLit][0]] = cNum;
	//Update the new position in the watches array for cNum.
	watches2pos[cNum] = watches2[newLit][0];
	//Terminate the watches array anew.
	++watches2[newLit][0];
	watches2[newLit][2+watches2[newLit][0]] = -1;
	//After all this we have to finally assign the watched literal to make the clause aware of its new buddy.
	watchedLiteral2[cNum] = newLit;
	#ifdef VERIFICATION_CDCL
		verification_cdcl_verifySecondWatcherReplacement_secondary(cNum, oldLit, newLit);
	#endif
}

//////////////////////////////////////////////DECISION STACK RELATED

//This method adds a variable assignment to the decision stack at the given level and stores the reason for this.
inline void cdcl_decisionStack_addVariableAssignment(const int level, const int lit, const int reason){
	#ifdef VERBOSE_CDCL
		printf("c Adding literal %i to decision stack level %i.\n",lit, level);
	#endif
	if (cdcl_decisionStack_assignments[level][0]+1 == cdcl_decisionStack_assignments[level][1]){
		//If we need more memory to store additional assignments in this level, we have to allocate
		//it here. We double the memory we have.
		cdcl_decisionStack_assignments[level][1] *= 2;
		cdcl_decisionStack_assignments[level] = realloc(
				cdcl_decisionStack_assignments[level],
				sizeof(int)*(cdcl_decisionStack_assignments[level][1]+2));
	}
	cdcl_decisionStack_assignments[level][2+cdcl_decisionStack_assignments[level][0]] = lit;
	++cdcl_decisionStack_assignments[level][0];
	cdcl_decisionStack_assignments[level][2+cdcl_decisionStack_assignments[level][0]] = 0;
	cdcl_assignmentLevel[abs(lit)] = level;	//Remember that this variable was assigned in level.
	cdcl_reason[abs(lit)] = reason; //Remember the reason for this assignment.
}

//This method returns the varibale assignment on the given decision level and position.
inline int cdcl_decisionStack_getVariableAssignment(const int level, const int assiNum){
	return 	cdcl_decisionStack_assignments[level][2+assiNum];
}

//This method increases the current decision level. It will also allocate additional memory if necessary.
inline void cdcl_decisionStack_increaseDecisionLevel(){
	currentDecLevel++;
	#ifdef VERBOSE_CDCL
		printf("c Increasing the current decision level to: %i.\n",currentDecLevel);
	#endif
	if (currentDecLevel == maxDecLevel){
		//We must allocate additional memory for this decision level.
		maxDecLevel++;
		cdcl_decisionStack_assignments = realloc(cdcl_decisionStack_assignments, sizeof(int*)*maxDecLevel);
		cdcl_decisionStack_assignments[currentDecLevel] = malloc(sizeof(int)*3);

		//If and only if this decision level was created freshly we have to initialize the memory storage
		//information. If a level was created before, than the memory information is already up to date.
		cdcl_decisionStack_assignments[currentDecLevel][1] = 1;
	}
	//We initialize the decision level here.
	cdcl_decisionStack_assignments[currentDecLevel][0] = 0;
	cdcl_decisionStack_assignments[currentDecLevel][2] = 0;
	#ifdef VERIFICATION_CDCL
		//We assert here that all the memory was allocated without error.
		verification_cdcl_verifyMemoryAllocation();
	#endif
}

//This method performs a back-jump to the given target level.
void cdcl_decisionStack_backjump(int targetLevel){
	register int level,pos;
	//We will now unassign everything in tvalue that is found up to (excluding) decision level targetLevel.
	#ifdef VERBOSE_CDCL
		printf("c Back-jumping from level %i to level %i.\n",currentDecLevel, targetLevel);fflush(stdout);
	#endif
	for (level = currentDecLevel; level > targetLevel; --level){
		pos = cdcl_decisionStack_assignments[level][0];
		#ifdef VERBOSE_CDCL
			printf("c\tLevel %i, unassigning %i variables: ",level,pos);fflush(stdout);
		#endif
		while (--pos > -1) {
			#ifdef VERBOSE_CDCL
				printf("%i ", cdcl_decisionStack_getVariableAssignment(level,pos));fflush(stdout);
			#endif
			tvalue[abs(cdcl_decisionStack_getVariableAssignment(level,pos))] = 2;
		}
	#ifdef VERBOSE_CDCL
		printf("\n");fflush(stdout);
	#endif
	}
	currentDecLevel = targetLevel;
	#ifdef VERBOSE_CDCL
		printf("c Back-jumping done.\n"); fflush(stdout);
	#endif
	#ifdef COLLINF_CDCL
		++cdcl_numBackjumpsLastCall;
	#endif
}

///////////////////////////////////PICKING OF DECISION LITERAL

#ifdef HIHEURISTIC
//This method computes the HI-scores for all the variables. HIDEPTH defines to what level we calculate the scores.
void cdcl_hiHeuristic(){
	register int i_it = 1,r,*clsPtr,lit,*inClsPtr,cNum;
	int j,w,sign,clsSize;
	float helperA,helperB;//Helpers for manually calculating the power.

	//We will now calculate h_i, starting with i = 1 upwards to the given i.
	//FYI: lScore[i][j] = h_i(x_j). Do not confuse this with lScore_size[j].
	while (i_it <= HIDEPTH){
		//Calculate s_i-1. We will need s[i_it-1] for the normalization later.
		//Lucky us, the only thing we need is lScore[i_it-1] for this, we already have that.
		s[i_it-1] = 0.0;
		for (r = 1; r < numVars+1; ++r){
			s[i_it-1] += lScore[i_it-1][r] + lScore[i_it-1][-r];
		}
		s[i_it-1] = (((float)1)/((float)(2*numVars))) * s[i_it-1];
		//Based on the new s_i-1 and the lScores[i_it-1], we can calculate the lScores[i_it]; the real h_i values.
		for (r = 1; r < numVars+1; ++r){//For each variable.
			for (sign = -1; sign < 2; sign = sign+2){//For both literals.
				for (j = 0; j < maxClauseSize+1; ++j){//Initialize the clause scores to 0 here.
					lScore_size[j] = 0.0;//We just start to work on literal sign*r.
				}
				//We calculate the inner sum of the heuristic. I.e. for all clauses that contain literal sign*r.
				for (clsPtr = clauseAppearance[sign*r]; (cNum = *clsPtr) > -1; ++clsPtr){
					//Now for that clause, we calculate the innermost product of the heuristic.
					float clsResult = 1.0;
					clsSize = 0;
					for (inClsPtr = clauseLiterals[cNum]; (lit = *inClsPtr) != 0; ++inClsPtr){
						++clsSize;
						if (lit == sign*r) continue;//Ignore sign*r in the clause.
						clsResult *= lScore[i_it-1][-lit];
					}
					//We add the score result for one clause to the specific scores of clauses with the same
					//length. We need to distinct here because of the different normalizations you do for the
					//different clause lengths.
					lScore_size[clsSize] += clsResult;
				}
				//lScore_size[j] contain the scores for all clauses of size j, that contained sign*r. We now
				//normalize all those scores according to the heuristic, and add it to the final score for sign*r.
				for (j = 1; j < maxClauseSize+1; ++j){
					if (lScore_size[j] > 0){
						//We now normalize, the normalization factor in the heuristic: k^(k-j) / s[i_it-1]^(j-1)
						helperA = 1.0;
						for (w = 0; w < maxClauseSize-j; ++w){helperA *= maxClauseSize;}//Means helperA = k^(k-j).
						helperB = 1.0;
						for (w = 0; w < j-1; ++w){helperB *= s[i_it-1];}//Means helperB = s[i_it-1]^(j-1).
						lScore_size[j] *= (helperA / helperB);
					}
					//The normalized score is added to the score of sign*r. This is the outer sum in the heuristic.
					lScore[i_it][sign*r] += lScore_size[j];
				}
				//We have now finished the calculations for one literal of r, i.e. sign*r.
			}
		}
		//We have finished the calculations for all variables r in this iteration, i.e. one "i" in the heuristic.
		++i_it;
	}
	//We finished the calculations for all iterations of h_i.
}
#endif /* HIHEURISTIC */

#ifdef VSIDS_INCREASEINCONFLICT
inline void cdcl_updateVSIDSScores(){
	//We now increase the basic VSIDS scores of all variables from the conflicting clause.
	int* inClsPtr;
	for (inClsPtr = clauseLiterals[conflictClause]; *inClsPtr != 0; ++inClsPtr){
		vsidsScore[abs(*inClsPtr)] += bump_factor_conflict;
	}
}
#endif

//This method is used to pick a variable according to their rank. Highest ranked first.
void cdcl_pickLiteralToSatisfy(){
	decisionLiteral = 0;
	orderPtr = variable_order+1;
	while ((orderPtr - (variable_order+1) < numVars)){
		if (tvalue[*orderPtr] == 2){
			if (assignment[*orderPtr] == 0){
				decisionLiteral = -(*orderPtr);
				cdcl_addToUnitPropBuffer(decisionLiteral,-1);
				return;
			} else {
				decisionLiteral = *orderPtr;
				cdcl_addToUnitPropBuffer(decisionLiteral,-1);
				return;
			}
		}
		++orderPtr;
	}
}


/////////////////////////////////////CONFLICT ANALYSIS
#ifndef UNITWALK
#ifdef LEARNUIP
//This method performs learning based on the first UIP learning scheme.
void cdcl_conflictAnalysis_learnUIP(){
	register int level,pos,*inClsPtr,*repPtrPos,*repPtrLast,conflictVar;
	#ifdef FIRSTUIP
		int lastLevelReplaced = 0;
	#endif
	#ifdef VERBOSE_CDCL
		printf("c UIP learning.\n");fflush(stdout);
	#endif

	//First we mark all variables as not added in the learned clause.
	#ifdef VERBOSE_CDCL
		printf("c\tUnmarking the variables: ");
	#endif
	for (level = currentDecLevel; level > -1; --level){
		pos = cdcl_decisionStack_assignments[level][0]-1;
		while (pos > -1){
			cdcl_UIPAdded[abs(cdcl_decisionStack_getVariableAssignment(level,pos--))] = 0;
			#ifdef VERBOSE_CDCL
				printf("%i ",cdcl_decisionStack_getVariableAssignment(level,pos));
			#endif
		}
	}
	//Then we add the conflict variable.
	conflictVar=abs(cdcl_decisionStack_getVariableAssignment(currentDecLevel,cdcl_decisionStack_assignments[currentDecLevel][0]-1));
	repPtrPos = cdcl_UIPReplacementBuffer;		//Initialize the current position in the replacement buffer.
	repPtrLast = cdcl_UIPReplacementBuffer;	//Initialize the last position in the replacement buffer.
	cdcl_UIPAdded[abs(conflictVar)] = 1;	//Mark the conflict variable as added to the clause.

	#ifdef VERBOSE_CDCL
		printf("\nc\tThe conflict variable is: %i\n", conflictVar);
		printf("c\tInitializing replacement queue: ");fflush(stdout);
	#endif
	//Then we add all the literals from the conflict clause (omitting the one resulting in the conflict).
	for (inClsPtr = clauseLiterals[conflictClause]; *inClsPtr != 0 ; ++inClsPtr){
		if (cdcl_UIPAdded[abs(*inClsPtr)] == 0 && abs(*inClsPtr) != conflictVar){
			//We have found a literal in the conflict clause that we must add to the replacement buffer.
			#ifdef VERBOSE_CDCL
				printf("%i ", *inClsPtr);fflush(stdout);
			#endif
			*repPtrLast = *inClsPtr;				//Add it.
			cdcl_UIPAdded[abs(*inClsPtr)] = 1;		//Mark as added.
			repPtrLast++;							//Increase the last buffer position.
		}
	}
	#ifdef VERBOSE_CDCL
		printf("| ");fflush(stdout);
	#endif
	//Then we add all the literals from the reason clause of the conflict (ignoring the conflict literal).
	for (inClsPtr = clauseLiterals[cdcl_reason[conflictVar]]; *inClsPtr != 0 ; ++inClsPtr){
		if (cdcl_UIPAdded[abs(*inClsPtr)] == 0 && abs(*inClsPtr) != conflictVar){
			//We have found a literal in the last reason clause that we must add to the replacement buffer.
			#ifdef VERBOSE_CDCL
				printf("%i ", *inClsPtr);
			#endif
			*repPtrLast = *inClsPtr;				//Add it.
			cdcl_UIPAdded[abs(*inClsPtr)] = 1;		//Mark as added.
			repPtrLast++;							//Increase the last buffer position.
		}
	}
	#ifdef VERBOSE_CDCL
		printf("\n");
		printf("c\tStarting replacement process.\n");fflush(stdout);
	#endif

	while (repPtrPos < repPtrLast){
		//While there are still variables to replace...
		//We check if the current variable in the replacement buffer is subject to replacements. This is the case
		//if this variable is no decision.
		if (cdcl_reason[abs(*repPtrPos)] == -1
			#ifdef FIRSTUIP
				|| cdcl_assignmentLevel[abs(*repPtrPos)] < currentDecLevel
			#endif
				){
			//We move on, ignoring this decision variable. It cannot be replaced and must stay in the buffer.
			#ifdef VERBOSE_CDCL
				printf("c\t\tReplacing %i\t(reason %i\t) by... SKIPPING\n", *repPtrPos, cdcl_reason[abs(*repPtrPos)]);
				fflush(stdout);
			#endif
			repPtrPos++;
			continue;
		}
		if (cdcl_assignmentLevel[abs(*repPtrPos)] == 0){
			//This variable was assigned because of a unit propagation in level zero. Such a variable must
			//not be part of a learned clause because an immediate resolution could remove it.
			*repPtrPos = 0;	//Make the variable disappear from the buffer.
			repPtrPos++;	//Continue with next element in buffer.
			continue;
		}
		#ifdef VERBOSE_CDCL
			printf("c\t\tReplacing %i\t(reason %i\t) by... ", *repPtrPos, cdcl_reason[abs(*repPtrPos)]);fflush(stdout);
		#endif
		//At this point we do know, that the variable is getting replaced. By what is still to be determined, but
		//the variable itself must not appear in the buffer afterwards. We will now check into the reason for
		//the current variable assignment and replace the current variable assignment with all not yet added
		//literals from the reason clause.
		for (inClsPtr = clauseLiterals[cdcl_reason[abs(*repPtrPos)]]; *inClsPtr != 0 ; ++inClsPtr){
			if (cdcl_UIPAdded[abs(*inClsPtr)] == 0){
				//We have found a literal in the reason clause that we must add to the replacement buffer.
				#ifdef VERBOSE_CDCL
					printf("%i ", *inClsPtr);fflush(stdout);
				#endif
				*repPtrLast = *inClsPtr;				//Add it.
				cdcl_UIPAdded[abs(*inClsPtr)] = 1;		//Mark as added.
				repPtrLast++;							//Increase the last buffer position.
			}
		}
		#ifdef VERBOSE_CDCL
			printf("\n");fflush(stdout);
		#endif
		#ifdef FIRSTUIP
			++lastLevelReplaced;
			if (lastLevelReplaced == cdcl_decisionStack_assignments[currentDecLevel][0]-1){
				break;
			}
		#endif
		*repPtrPos = 0;	//Make the replaced variable disappear from the buffer.
		repPtrPos++;	//Continue with next element in buffer.
	}
	#ifdef VERBOSE_CDCL
		printf("c\tdone.\n");fflush(stdout);
	#endif
	//At this point, no more replacements can be made. From what remains in the buffer, we will learn an asserting
	//clause by collecting everything in the buffer up to *repPtrLast that is not zero.
	//We also compute the asserting level: it is the second highest assignment level of all the variables.
	//The highest one is the one of the asserted literal. We do not care for the level of the asserted literal,
	//but we need to know what the asserted literal is.
	cdcl_learnedConflictClauseSize = 0;
	repPtrPos = cdcl_UIPReplacementBuffer;
	cdcl_learnedConflictClauseAssLit = 0;
	cdcl_learnedConflictClauseWatcher2 = 0;
	cdcl_backjumpTargetLevel = -1;//The level we want to back-jump to. Will be the second highest decision level.
	level = 0;//Now the highest found decision level for any of the literals in the learned clause. Is the level
	//of the asserting literal.
	#ifdef VERBOSE_CDCL
	printf("c\tStarting the collecting phase. The learned clause contains:\n");fflush(stdout);
	#endif
	while (repPtrPos < repPtrLast){
		if (*repPtrPos != 0) {
			clauseLiterals[numCDCLClauses][cdcl_learnedConflictClauseSize++] = *repPtrPos;	//Add the survivor.
			clauseLiterals[numCDCLClauses][cdcl_learnedConflictClauseSize] = 0;				//Terminate the clause.
			#ifdef VERBOSE_CDCL
				printf("c\t\t%i(%i) ",*repPtrPos, cdcl_assignmentLevel[abs(*repPtrPos)]);fflush(stdout);
			#endif
			if (cdcl_assignmentLevel[abs(*repPtrPos)] > level){
				//If *repPtrPos has the largest decision level ever seen it must be our new asserting literal.
				cdcl_backjumpTargetLevel = level;
				level = cdcl_assignmentLevel[abs(*repPtrPos)];
				//Obviously, having a new asserting literal also means having a new second watcher.
				cdcl_learnedConflictClauseWatcher2 = cdcl_learnedConflictClauseAssLit;
				cdcl_learnedConflictClauseAssLit = *repPtrPos;
				#ifdef VERBOSE_CDCL
					printf("is new asserting literal");fflush(stdout);
				#endif
			} else if (cdcl_assignmentLevel[abs(*repPtrPos)] > cdcl_backjumpTargetLevel) {
				//If it is not the largest decision level but larger than the current target level,
				//we make it our new target level.
				cdcl_backjumpTargetLevel = cdcl_assignmentLevel[abs(*repPtrPos)];
				//It also gives us what the second watcher is.
				cdcl_learnedConflictClauseWatcher2 = *repPtrPos;
				#ifdef VERBOSE_CDCL
					printf("gives new back-jump target level/new second watcher");fflush(stdout);
				#endif
			}
			#ifdef VERBOSE_CDCL
				printf("\n");fflush(stdout);
			#endif
		}
		repPtrPos++;
	}
	#ifdef VERBOSE_CDCL
		printf("c\tdone.\n");
		printf("c\tComputed asserting literal is %i.\n", cdcl_learnedConflictClauseAssLit);
		printf("c\tComputed second watcher is: %i.\n", cdcl_learnedConflictClauseWatcher2);
		printf("c\tComputed back-jumping level is %i.\n", cdcl_backjumpTargetLevel);
		printf("c HI-UIP learning done.\n");fflush(stdout);
	#endif
}
#endif

//This is a fall-back method used to learn a new clause. It will simply take all the decisions on the decision
//stack, invert their signs and add them into a clause.
void cdcl_conflictAnalysis_learnSimple(){
	//Extremely simple learning scheme:
	//We simply learn a clause with all the decisions made so far in a clause but the decisions inverted.
	//This method must also compute the back-jump target level. This level is the decision level of an included
	//decision variable that has the largest level. In this case, i.e. the simple learning, this is always
	//current decision level -1. The learned clause will be unit in the back-jump level. The literal that is
	//to be propagated by the unit propagation is the last one we added in the clause.
	#ifdef VERBOSE_CDCL
		printf("c Analyzing conflict...\n");fflush(stdout);
	#endif
	register int i,pos,lit;
	pos = 0;
	for (i = 0; i < currentDecLevel+1; ++i){
		if ((lit = cdcl_decisionStack_getVariableAssignment(i,0)) != 0){
			clauseLiterals[numCDCLClauses][pos++] = -lit;
		}
	}
	clauseLiterals[numCDCLClauses][pos] = 0; //Terminate after all literals where learned.
	cdcl_learnedConflictClauseSize = pos;//We use this size +1 to allocate memory later.
	cdcl_backjumpTargetLevel = currentDecLevel-1; //This is where we want to back-jump in the simple scheme.
	cdcl_learnedConflictClauseAssLit = clauseLiterals[numCDCLClauses][pos-1];//Last decision is getting asserted.
	if (pos > 1) {
		cdcl_learnedConflictClauseWatcher2 = clauseLiterals[numCDCLClauses][pos-2];//Second watcher on back-jump level.
	} else {
		cdcl_learnedConflictClauseWatcher2 = 0;
	}
	#ifdef VERBOSE_CDCL
		int j;
		printf("c Learned new clause: [%i] ", numCDCLClauses);
		for (j = 0; j < pos; j++) printf("%i ", clauseLiterals[numCDCLClauses][j]);
		printf("has size: %i, currentDecisionLevel: %i, back-jump to: %i, forced unit propagation on: %i\n",
				cdcl_learnedConflictClauseSize, currentDecLevel, cdcl_backjumpTargetLevel,
				cdcl_learnedConflictClauseAssLit);
		fflush(stdout);
	#endif
}

//This method will insert the newly learned clause into the formula. It is independent of the learning scheme used.
void cdcl_conflictAnalysis_insertNewClause(){
	//Independently of the learning scheme, we can add the newly learned clause here.
	#ifdef VERBOSE_CDCL
		printf("c Adding newly learned clause...\n"); fflush(stdout);
	#endif
	#ifdef COLLINF_CDCL
		cdcl_learnedClausesOfLength[cdcl_learnedConflictClauseSize]++;
	#endif

	//A clause always has two watched literals. We therefore must increase the corresponding arrays here.
	watchedLiteral1 = realloc(watchedLiteral1, sizeof(int)*(numCDCLClauses+1));
	watchedLiteral2 = realloc(watchedLiteral2, sizeof(int)*(numCDCLClauses+1));
	watches1pos = realloc(watches1pos, sizeof(int)*(numCDCLClauses+1));
	watches2pos = realloc(watches2pos, sizeof(int)*(numCDCLClauses+1));
	#ifdef VERIFICATION_CDCL
		//We assert here that reallocation of all the memory worked out as intended.
		verification_cdcl_verifyMemoryAllocation();
	#endif

	//We can now transfer the literals of the learned clause over to clauseLiterals.
	#ifdef VERBOSE_CDCL
		printf("c\tResizing learned clause... "); fflush(stdout);
	#endif
	clauseLiterals[numCDCLClauses] =
		realloc(clauseLiterals[numCDCLClauses], sizeof(int)*(cdcl_learnedConflictClauseSize+1));
	#ifdef VERBOSE_CDCL
		printf("resizing done.\n"); fflush(stdout);
	#endif
	//We update the watched variables now. First the first watcher will always be the asserting literal.
	cdcl_watcher_checkMemoryForWatcher1(cdcl_learnedConflictClauseAssLit);
	watches1pos[numCDCLClauses] = watches1[cdcl_learnedConflictClauseAssLit][0];
	watches1[cdcl_learnedConflictClauseAssLit][2+watches1[cdcl_learnedConflictClauseAssLit][0]] = numCDCLClauses;
	++watches1[cdcl_learnedConflictClauseAssLit][0];
	watches1[cdcl_learnedConflictClauseAssLit][2+watches1[cdcl_learnedConflictClauseAssLit][0]] = -1;
	watchedLiteral1[numCDCLClauses] = cdcl_learnedConflictClauseAssLit;
	watchedLiteral2[numCDCLClauses] = 0;
	#ifdef VERIFICATION_CDCL
		verification_cdcl_learnedClauseHasFirstWatcher();
	#endif
	if (cdcl_learnedConflictClauseWatcher2 != 0){
		//If the learning scheme decided on a second watcher, we will use it here.
		cdcl_watcher_checkMemoryForWatcher2(cdcl_learnedConflictClauseWatcher2);
		watchedLiteral2[numCDCLClauses] = cdcl_learnedConflictClauseWatcher2;
		watches2pos[numCDCLClauses] = watches2[cdcl_learnedConflictClauseWatcher2][0];
		watches2[cdcl_learnedConflictClauseWatcher2]
		         [2+watches2[cdcl_learnedConflictClauseWatcher2][0]] = numCDCLClauses;
		++watches2[cdcl_learnedConflictClauseWatcher2][0];
		watches2[cdcl_learnedConflictClauseWatcher2][2+watches2[cdcl_learnedConflictClauseWatcher2][0]] = -1;
		#ifdef VERIFICATION_CDCL
			//Here we do assert, that searching for a new second watcher was indeed successful.
			verification_cdcl_learnedClauseHasSecondWatcher();
		#endif
	}
	#ifdef VERIFICATION_CDCL
		else {
			//Else a unit clause has no second watcher and we keep it at 0.
			verification_cdcl_verifyLearnedClauseIsUnit();
		}
	#endif
	//Since we only learn asserting clauses which become unit in the decision level we will back-jump to, we can
	//add the asserting literal of the clause to the unit propagation buffer right away to make the solver
	//propagate the new knowledge. The reason for this is of course the newly added asserting clause.
	cdcl_addToUnitPropBuffer(cdcl_learnedConflictClauseAssLit,numCDCLClauses);
	#ifdef VERBOSE_CDCL
		printf("c\tNewly learned conflict clause of size %i is ", cdcl_learnedConflictClauseSize);
		cdcl_printClauseInline(numCDCLClauses);printf("\n");
		printf("c\tThe assignment levels of the watched literals are: %i, %i\n",
				cdcl_assignmentLevel[abs(watchedLiteral1[numCDCLClauses])],
				cdcl_assignmentLevel[abs(watchedLiteral2[numCDCLClauses])]);
		printf("c\tAdding asserting literal to unit prop buffer: %i\n",cdcl_learnedConflictClauseAssLit);
		fflush(stdout);
	#endif
	//Finally, we increase the count of clauses at the CDCLs disposal.
	++numCDCLClauses;
	//We append the placeholder for a new clause that can be learned.
	clauseLiterals = realloc(clauseLiterals, sizeof(int*)*(numCDCLClauses+1));
	clauseLiterals[numCDCLClauses] = malloc(sizeof(int)*(numVars+1));
	clauseLiterals[numCDCLClauses][0] = 0;
}
#endif /* UNITWALK */

////////////////////////////////////////////////////GENERAL

//This method is called once during the start of the solver and handles the initialization of the CDCL.
void cdcl_allocateAndInitialize(){
	register int i,cNum,lit;
	#ifdef LONGHEADER
		printf("c Allocating CDCL memory...\n");fflush(stdout);
	#endif

	//GENERAL
	cdcl_lubyUnit				= 5;			//TODO: Needs better adaption.
	currentDecLevel				= 0;			//We start in decision level 0.
	cdcl_callNumber				= 0;			//Initially, no calls have been made.
	maxNumberOfConflicts 		= 1;			//Initially, the maximum number of conflicts is 1 (is overridden).
	numberOfConflicts			= 0;			//The discovered number of conflicts.
	numCDCLClauses				= numClauses;	//Initially, we have all the clauses of the formula.
	#ifdef TIMING
		cdcl_callStarttime 			= 0.0f;
		cdcl_callEndtime 			= 0.0f;
		cdcl_runtime 				= 0.0f;
	#endif

	//VARIABLE SPECIFIC ARRAYS
	tvalue = malloc(sizeof(unsigned char)*(numVars+1));
	for (i = 0; i < numVars+1;++i){tvalue[i] = 2;}

	//CDCL UNIT PROPAGATION RELATED
	cdcl_unitPropBuffer 		= malloc(sizeof(int)*(numVars));
	cdcl_reasonPropBuffer		= malloc(sizeof(int)*(numVars));
	cdcl_unitPropBufferPos 		= cdcl_unitPropBuffer;
	cdcl_unitPropBufferLast		= cdcl_unitPropBuffer;
	cdcl_unitPropBufferMax		= cdcl_unitPropBuffer + numVars;
	cdcl_reasonPropBufferPos	= cdcl_reasonPropBuffer;
	cdcl_reasonPropBufferLast 	= cdcl_reasonPropBuffer;
	cdcl_reason					= malloc(sizeof(int) * (numVars+1));
	cdcl_assignmentLevel		= malloc(sizeof(int) * (numVars+1));

	//DECISION STACK RELATED
	maxDecLevel = MAXINITDECLEVELS;
	cdcl_decisionStack_assignments 	= malloc(sizeof(int*)*MAXINITDECLEVELS);
	for (i = 0; i < MAXINITDECLEVELS; i++){
		cdcl_decisionStack_assignments[i] = malloc(sizeof(int)*(2+MAXINITELEMENTS));
		cdcl_decisionStack_assignments[i][0] = 0;				//No elements stored in the beginning.
		cdcl_decisionStack_assignments[i][1] = MAXINITELEMENTS;	//For how many elements did we allocate memory.
		cdcl_decisionStack_assignments[i][2] = 0;				//Terminate.
	}

	//WATCHED LITERALS RELATED
	//We must initialize the watched literal lists. Each clause has two.
	//We also initialize the watches list, that tells you what clause a variable currently watches.
	watches1 				= malloc(sizeof(int*)*(2*numVars+1));
	watches1 				+= numVars;
	for (i = -numVars; i < numVars+1; ++i){
		watches1[i] = malloc(sizeof(int)*(MAXINITELEMENTS+2));
		watches1[i][0] = 0;
		watches1[i][1] = MAXINITELEMENTS;
		watches1[i][2] = -1;
	}
	watches2 				= malloc(sizeof(int*)*(2*numVars+1));
	watches2 				+= numVars;
	for (i = -numVars; i < numVars+1; ++i){
		watches2[i] = malloc(sizeof(int)*(MAXINITELEMENTS+2));
		watches2[i][0] = 0;
		watches2[i][1] = MAXINITELEMENTS;
		watches2[i][2] = -1;
	}

	watchedLiteral1 		= malloc(sizeof(int)*numClauses);
	watchedLiteral2 		= malloc(sizeof(int)*numClauses);

	watches1pos				= malloc(sizeof(int)*numClauses);
	watches2pos				= malloc(sizeof(int)*numClauses);

	//Hint: When searching for watched literals, we can take any literal at this point, because none of them
	//has a tvalue != 2. Basically you can say that all variables are unassigned and therefore can all serve as
	//watchers.
	//Find watched literals for clauses. Clauses that are set to be ignored must be ignored here.
	for (cNum = 0; cNum < numCDCLClauses; cNum++){
		#ifdef PREPROCESSING
		if (cNum < numClauses && isIgnoredClause[cNum]) {
			//Only clauses the SLS knows can be ignored.
			watchedLiteral1[cNum] = 0;
			watchedLiteral2[cNum] = 0;
			watches1pos[cNum] = -1;
			watches2pos[cNum] = -1;
			continue; //Skip this if ignored.
		}
		#endif
		lit = clauseLiterals[cNum][0];
		cdcl_watcher_checkMemoryForWatcher1(lit);
		//Set the first watched literal of this clause.
		watches1[lit][2+watches1[lit][0]] = cNum;
		watches1pos[cNum] = watches1[lit][0];
		++watches1[lit][0];
		watches1[lit][2+watches1[lit][0]] = -1;
		watchedLiteral1[cNum] = lit;
		//Here we additionally set the second watched literal for the clause. Obviously, it should be something
		//else than the first watched literal. We must respect UNIT CLAUSES.
		if (clauseLiterals[cNum][1] == 0){
			//It is a unit clause. No second watched literal is possible.
			watchedLiteral2[cNum] = 0;
			watches2pos[cNum] = -1;
			//Since it is a unit clause, we add it to the unit propagation buffer in decision level 0.
			cdcl_addToUnitPropBuffer(clauseLiterals[cNum][0],cNum);
		} else {
			//We need to find another literal in the clause that is not yet the first watching literal.
			lit = clauseLiterals[cNum][1];
			cdcl_watcher_checkMemoryForWatcher2(lit);
			//Set the second watched literal of this clause to be the one literal we just checked.
			watches2[lit][2+watches2[lit][0]] = cNum;
			watches2pos[cNum] = watches2[lit][0];
			++watches2[lit][0];
			watches2[lit][2+watches2[lit][0]] = -1;
			watchedLiteral2[cNum] = lit;
		}
	}

	//DECISION VARIABLE SELECTION RELATED
	hVar = malloc(sizeof(struct scoredvar)*(numVars));

	#ifdef HIHEURISTIC
	//If the HIheuristic is in use, we initialize its stuff.
	if (heuristic == HEURHI){
		variable_rank_hi = malloc(sizeof(int)*(numVars+1));
		variable_order_hi = malloc(sizeof(int)*(numVars+1));
		int j;
		#ifdef LONGHEADER
			printf("c\tUsing HI-heuristic for variable selection.\n");
		#endif
		lScore_size = malloc(sizeof(float)*(maxClauseSize+1));
		s = malloc(sizeof(float)*(HIDEPTH+1));	//The s_i values for the hi-heuristic.
		for (i = 0; i < HIDEPTH+1; ++i){
			s[i] = 0.0;							//Initialized to 0.0.
		}
		lScore = malloc(sizeof(float*) * (HIDEPTH+1));	//The values of the h_i heuristic in iteration i.
		for (i = 0; i < HIDEPTH+1; ++i){
			lScore[i] = malloc(sizeof(float) * (2*numVars+1));
			if (i == 0){
				//In the first level, the literals have all score 1.0
				for (j = 0; j < 2*numVars+1; ++j){
					lScore[i][j] = 1.0;
				}
			} else {
				//In all higher levels, their score value is initialized to 0.
				for (j = 0; j < 2*numVars+1; ++j){
					lScore[i][j] = 0.0;
				}
			}
			lScore[i] += numVars;//Shift the pointer to the array center.
		}
		cdcl_hiHeuristic();
		for (i = 1; i < numVars+1; ++i){
			hVar[i-1].var = i;
			hVar[i-1].totalScore = lScore[HIDEPTH][i]*lScore[HIDEPTH][-i];
		}
		//We sort the variables according to their HI-scores.
		qsort(hVar,numVars,sizeof(struct scoredvar),cdcl_compareScoredVar_totalscore_max);
		for (i = 0; i < numVars; ++i){
			variable_rank_hi[hVar[i].var] = i+1;
			variable_order_hi[i+1] = hVar[i].var;
		}
		variable_rank = variable_rank_hi;
		variable_order = variable_order_hi;
	}
	#endif

	#ifdef VSIDSHEURISTIC
	//If the VSIDS heuristic is in use, we initialize its stuff.
	if (heuristic == HEURVSIDS){
		variable_rank_vsids = malloc(sizeof(int)*(numVars+1));
		variable_order_vsids = malloc(sizeof(int)*(numVars+1));
		#ifdef LONGHEADER
		printf("c\tUsing VSIDS-heuristic for variables selection.\n");
		#endif
		#ifdef VSIDS_INCREASEINCONFLICT
			bump_factor_conflict = 1.0;
			#ifdef LONGHEADER
				printf("c\tBump factor for conflict bump is %f.\n",bump_factor_conflict);
			#endif
		#endif
		#ifdef VSIDS_INCREASEINFLIPS
			bump_factor_flips = 1.0;
			#ifdef LONGHEADER
				printf("c\tBump factor for flip bump is %f.\n",bump_factor_flips);
			#endif
		#endif
		//Here we prepare the VSIDS heuristic score arrays.
		vsidsScore = malloc(sizeof(float)*(numVars+1));
		for (i = 0; i < numVars+1; ++i){
			vsidsScore[i] = 1.0;//In the beginning, all variables are equally important.
		}
		variable_rank = variable_rank_vsids;
		variable_order = variable_order_vsids;
	}
	#endif

	#ifdef AGEHEURISTIC
	if (heuristic == HEURAGE){
		variable_rank_age = malloc(sizeof(int)*(numVars+1));
		variable_order_age = malloc(sizeof(int)*(numVars+1));
		#ifdef LONGHEADER
			printf("c\tUsing AGE-heuristic for variable selection. ");
			#ifdef AGEYOUNG
				printf("Youngest variable first.\n");
			#else
				printf("Oldest variable first.\n");
			#endif
		#endif
		variable_rank = variable_rank_age;
		variable_order = variable_order_age;
	}
	#endif

	#ifdef RANDOMHEURISTIC
	if (heuristic == HEURRAND){
		variable_rank_random  = malloc(sizeof(int)*(numVars+1));
		variable_order_random  = malloc(sizeof(int)*(numVars+1));
		#ifdef LONGHEADER
			printf("c\tUsing RANDOM-heuristic for variable selection. ");
		#endif
		variable_rank = variable_rank_random;
		variable_order = variable_order_random;
	}
	#endif

	#ifndef HIHEURISTIC
	#ifndef VSIDSHEURISTIC
	#ifndef AGEHEURISTIC
	#ifndef RANDOMHEURISTIC
	if (heuristic == HEURSIMPLE){
		#ifdef LONGHEADER
			printf("c\tUsing simple variable selection heuristic.\n");
		#endif
		variable_rank_simple = malloc(sizeof(int)*(numVars+1));
		variable_order_simple = malloc(sizeof(int)*(numVars+1));
		//In case there must be something done for the simple selection scheme, we can do it here.
		//We use the number of literal occurrences multiplied to get scores for the variables to sort them.
		for (i = 0; i < numVars; ++i){
			hVar[i].var = i+1;
			hVar[i].totalScore = clauseAppearance[i+1][0] * clauseAppearance[-(i+1)][0];
		}
		qsort(hVar,numVars,sizeof(struct scoredvar),cdcl_compareScoredVar_totalscore_max);
		for (i = 0; i < numVars; ++i){
			variable_rank_simple[hVar[i].var] = i+1;
			variable_order_simple[i+1] = hVar[i].var;
		}
		variable_rank = variable_rank_simple;
		variable_order = variable_order_simple;
	}
	#endif
	#endif
	#endif
	#endif

	//CONFLICT ANALYSIS RELATED
	#ifndef UNITWALK
		//A learned clause could, in theory, contain a literal from every variable. Thats why the learned clause array
		//is initialized that big in the following. We simply add the "placeholder" for a new clause at the end of the
		//clause literals array.
		clauseLiterals = realloc(clauseLiterals, sizeof(int*)*(numCDCLClauses+1));
		clauseLiterals[numCDCLClauses] = malloc(sizeof(int)*(numVars+1));
		clauseLiterals[numCDCLClauses][0] = 0;
		cdcl_backjumpTargetLevel 		= 0;

		printf("c\tCDCL operates in standard mode.\n");

		#ifdef LEARNUIP
			#ifdef LONGHEADER
			printf("c\tUIP conflict analysis is in use. ");
			#ifdef FIRSTUIP
			printf("Search for first UIP.\n");
			#else
			printf("Search for last UIP.\n");
			#endif
			#endif
			cdcl_UIPAdded = malloc(sizeof(unsigned char)*(numVars+1));
			cdcl_UIPReplacementBuffer = malloc(sizeof(int)*(numVars+1));
		#else
			#ifdef LONGHEADER
			printf("c\tSimple conflict analysis is in use.\n");
			#endif
		#endif
	#else
		#ifdef LONGHEADER
		printf("c\tCDCL operates in UNITWALK-mode. Conflict analysis is disabled.\n");
		#endif
	#endif /* UNITWALK */

	//COLLECT INFORMATION RELATED
	#ifdef COLLINF_CDCL
		cdcl_learnedClausesOfLength	= malloc(sizeof(int)*numVars);
		for (i=0; i < numVars; i++){cdcl_learnedClausesOfLength[i] = 0;}
		cdcl_lastCall 							= 0;	cdcl_necNumUnsatClsIncreases	= 0;
		cdcl_callDistances 						= 0;	cdcl_necNumUnsatClsDecreases	= 0;
		cdcl_numberOfBackjumps					= 0;	cdcl_numUnitPropBufferIncreases	= 0;
		cdcl_numberOfDecisions					= 0;	cdcl_numPropsBasedOnLearned		= 0;
		cdcl_numPropsBasedOnLearnedLastCall		= 0;	cdcl_numBackjumpsLastCall		= 0;
		#ifdef SIMPLECALLING
		cdcl_maxNecNumUnsatCls			= necNumberOfUnsatCls;
		#endif
		#ifdef TRANSFERASSIGNMENTCHANGES
			cdcl_numTransferredAssignmnetChanges 	= 0;
		#endif
	#endif

	#ifdef VERIFICATION_CDCL
		verification_cdcl_verifyMemoryAllocation();
	#endif
	#ifdef LONGHEADER
		printf("c done.\n");fflush(stdout);
	#endif
}

#ifdef DISPOSE
//This method will take care of disposing all the allocated memory for the CDCL.
void cdcl_dispose(){
	register int i;
	#ifdef LONGHEADER
		printf("c\tDisposing CDCL memory... ");fflush(stdout);
	#endif

	//VARIABLE SPECIFIC ARRAYS
	free(tvalue);

	//WATCHED LITERALS RELATED
	for (i = -numVars; i < numVars+1; ++i){free(watches1[i]);}
	watches1 -= numVars;
	free(watches1);
	for (i = -numVars; i < numVars+1; ++i){free(watches2[i]);}
	watches2 -= numVars;
	free(watches2);

	free(watchedLiteral1);
	free(watchedLiteral2);

	free(watches1pos);
	free(watches2pos);

	//UNIT PROPAGATION RELATED
	free(cdcl_unitPropBuffer);
	free(cdcl_reasonPropBuffer);
	free(cdcl_reason);
	free(cdcl_assignmentLevel);

	//DECISION STACK RELATED
	for (i = 0; i < maxDecLevel; i++){free(cdcl_decisionStack_assignments[i]);}
	free(cdcl_decisionStack_assignments);

	//PICKING OF DECISION VARIABLE RELATED
	free(hVar);

	#ifdef HIHEURISTIC
	if (heuristic == HEURHI){
		free(variable_rank_hi);
		free(variable_order_hi);

		free(s);
		for (i = 0; i < HIDEPTH+1; ++i){lScore[i] -= numVars;free(lScore[i]);}
		free(lScore);
		free(lScore_size);
	}
	#endif

	#ifdef VSIDSHEURISTIC
	if (heuristic == HEURVSIDS){
		free(variable_rank_vsids);
		free(variable_order_vsids);
		free(vsidsScore);
	}
	#endif

	#ifdef AGEHEURISTIC
	if (heuristic == HEURAGE){
		free(variable_rank_age);
		free(variable_order_age);
	}
	#endif

	#ifdef RANDOMHEURISTIC
	if (heuristic == HEURRAND){
		free(variable_rank_random);
		free(variable_order_random);
	}
	#endif

	#ifndef HIHEURISTIC
	#ifndef VSIDSHEURISTIC
	#ifndef AGEHEURISTIC
	#ifndef RANDOMHEURISTIC
	if (heuristic == HEURSIMPLE){
		free(variable_order_simple);
		free(variable_rank_simple);
	}
	#endif
	#endif
	#endif
	#endif
	//CONFLICT ANALYSIS RELATED
	#ifndef UNITWALK
		#ifdef LEARNUIP
			//If first UIP is in use, we dispose its stuff used for learning.
			free(cdcl_UIPReplacementBuffer);
			free(cdcl_UIPAdded);
		#endif
	#endif

	//COLLECTING INFORMATION RELATED
	#ifdef COLLINF_CDCL
		free(cdcl_learnedClausesOfLength);
	#endif
	#ifdef LONGHEADER
		printf("done.\n");fflush(stdout);
	#endif
}
#endif

//This method will initialize a call to the CDCL.
void cdcl_initCall(){
	//All actions that need to be performed ahead of the CDCL call are done here.
	#ifdef VERBOSE_CDCL
	printf("c Initializing CDCL call... ");fflush(stdout);
	#endif

	++cdcl_callNumber;
	cdcl_returnValue 				= UNKNOWN;
	currentDecLevel 				= 0;
	numberOfConflicts 				= 0;
	cdcl_unitPropLastAdded 			= 0;
	cdcl_unitPropBufferLast 		= cdcl_unitPropBuffer;
	cdcl_unitPropBufferPos  		= cdcl_unitPropBuffer;
	cdcl_reasonPropBufferPos		= cdcl_reasonPropBuffer;
	cdcl_reasonPropBufferLast		= cdcl_reasonPropBuffer;

	#ifndef UNITWALK
		#ifdef USELUBYSERIES
		maxNumberOfConflicts 			= cdcl_getLuby(cdcl_callNumber);
		#else
		maxNumberOfConflicts			= cdcl_lubyUnit;
		#endif
		#ifdef VERBOSE_CDCL
		printf("%i conflicts must be found (CDCL standard mode)...\n",maxNumberOfConflicts);
		#endif
	#else
		maxNumberOfConflicts				= 1;
		#ifdef VERBOSE_CDCL
		printf("%i conflicts must be found (CDCL unit walk mode)...\n",maxNumberOfConflicts);
		#endif
	#endif


	#ifdef VSIDSHEURISTIC
	//If the VSIDS heuristic is in use, we use the basic VSIDS scores to compute a variable sort.
	if (heuristic == HEURVSIDS){
		int j;
		for (j = 0; j < numVars; ++j){
			hVar[j].var = j+1;
			hVar[j].totalScore = vsidsScore[j+1];
		}
		#ifdef VSIDSMAX
		//We sort the variable such that those with higher score appear first.
		qsort(hVar,numVars,sizeof(struct scoredvar),cdcl_compareScoredVar_totalscore_max);
		#else
		//We sort the variables such that those with lower score appear first.
		qsort(hVar,numVars,sizeof(struct scoredvar),cdcl_compareScoredVar_totalscore_min);
		#endif
		for (j = 0; j < numVars; ++j){
			variable_rank_vsids[hVar[j].var] = j+1;
			variable_order_vsids[j+1] = hVar[j].var;
		}
	}
	#endif

	#ifdef AGEHEURISTIC
	if (heuristic == HEURAGE){
		int i;
		for (i = 0; i < numVars; ++i){
			hVar[i].var = i+1;
			hVar[i].totalScore = lastFlipped[i+1];
		}
		#ifdef AGEYOUNG
			qsort(hVar,numVars,sizeof(struct scoredvar),cdcl_compareScoredVar_totalscore_max);
		#else
			qsort(hVar,numVars,sizeof(struct scoredvar),cdcl_compareScoredVar_totalscore_min);
		#endif
		for (i = 0; i < numVars; ++i){
			variable_rank_age[hVar[i].var] = i+1;
			variable_order_age[i+1] = hVar[i].var;
		}
	}
	#endif

	#ifdef RANDOMHEURISTIC
	if (heuristic == HEURRAND){
		int z, c = clock();
		for (z = 0; z < numVars; ++z){
			hVar[z].var = z+1;
			hVar[z].totalScore = (c*(z+clauseAppearance[(c+z)%numVars][0]))%(numVars+1);
		}
		qsort(hVar,numVars,sizeof(struct scoredvar),cdcl_compareScoredVar_totalscore_max);
		for (z = 0; z < numVars; ++z){
			variable_rank_random[hVar[z].var] = z+1;
			variable_order_random[z+1] = hVar[z].var;
		}
	}
	#endif

	#ifdef COLLINF_CDCL
	cdcl_numBackjumpsLastCall = 0;
	cdcl_numPropsBasedOnLearnedLastCall = 0;
	#endif

	#ifdef VERBOSE_CDCL
	printf("c done initializing call.\n");fflush(stdout);
	#endif
}

//This method will propagate all the assignments found on the propagation buffer. It will also initialize the
//update of the watched literals. It detects conflicts.
void cdcl_propagateAssignments(){
	register int toEnforce,cNum,*arrPtr;
	for (	//In this for loop, we have no initial condition.
			;
			//We keep propagating until everything is propagated.
			cdcl_unitPropBufferPos != cdcl_unitPropBufferLast;
			//For the next run of the for-loop, we increase the unit prop buffer and reason prop buffer pointers.
			cdcl_unitPropBufferPos++, cdcl_reasonPropBufferPos++
		){
		#ifdef VERBOSE_CDCL
		cdcl_printPropagationBuffers();
		#endif
		//If a variable from the propagation buffer is already assigned (can happen because multiple clauses
		//could imply a variable multiple times and then it is found multiple times here), we simply continue with
		//the next variable, because for the current one, nothing has to be done.
		if (tvalue[abs(*cdcl_unitPropBufferPos)] != 2) {
			#ifdef VERBOSE_CDCL
			printf("c Skipping because variable %i is already assigned.\n", *cdcl_unitPropBufferPos);
			#endif
			continue;
		}
		#ifdef VERBOSE_CDCL
		printf("c Assigning variable: %i = %i because of ",
				*cdcl_unitPropBufferPos, (*cdcl_unitPropBufferPos > 0) ? 1 : 0);
		if (*cdcl_reasonPropBufferPos > -1){
			printf("reason ");cdcl_printClauseInline(*cdcl_reasonPropBufferPos); printf("\n");fflush(stdout);
		} else {
			printf("a decision.\n");fflush(stdout);
		}
		#endif
		//First we make the assignment.
		tvalue[abs(*cdcl_unitPropBufferPos)] = (*cdcl_unitPropBufferPos > 0) ? 1 : 0;
		cdcl_decisionStack_addVariableAssignment(currentDecLevel,
				*cdcl_unitPropBufferPos,*cdcl_reasonPropBufferPos);

		#ifdef COLLINF_CDCL
		if (*cdcl_reasonPropBufferPos >= numOriginalClauses) {
			++cdcl_numPropsBasedOnLearned;
			++cdcl_numPropsBasedOnLearnedLastCall;
		}
		#endif
		//Here we have a literal *cdcl_unitPropBufferPos that is not yet assigned but unit propagation demands it
		//getting assigned. Making a literal true demands for no further actions in CDCL, so we only have to
		//check the negative literal. We call this literal with opposite sign toEnforce.
		toEnforce = -(*cdcl_unitPropBufferPos);

		//The following things are to be done:
		//	Find a new watched literal for all clauses having toEnforce as first watcher.
		//	Find a new watched literal for all clauses having toEnforce as second watcher.
		//	Find new responsible literals for all clauses where toEnforce is a responsible literal.
		//In order to perform these tasks, we keep close to the proposal of Stephan Kottlers paper "Decision
		//Making with Reference Points".

		//CHECK CLAUSES WHERE TOENFORCE IS FIRST WATCHER
		#ifdef VERBOSE_CDCL
		printf("c Handling the watches1 array.\nc Checking: ");fflush(stdout);
		for (arrPtr = watches1[toEnforce]+2; *arrPtr != -1; arrPtr++){
			printf("%i ", *arrPtr);
		}
		printf("\n");fflush(stdout);
		#endif
		for (arrPtr = watches1[toEnforce]+2; (cNum = *arrPtr) != -1; ++arrPtr){
			//Here *cNum is a clause having toEnforce as first watcher. We try to replace it.
			#ifdef VERBOSE_CDCL
			printf("c Clause ");cdcl_printClauseInline(cNum);fflush(stdout);
			#endif
			cdcl_watcher_findNewFirst(cNum);
			//The above call will replace the first watcher if possible. If it does not succeed in doing so,
			//nothing changes for the first watcher of *cNum.
			if (watchedLiteral1[cNum] == toEnforce){
				//We where unsuccessful in replacing the first watcher. This can have two reasons.
				if (clauseLiterals[cNum][1] == 0){
					//First, cNum is a unit clause and just got its one literal made false. This is a conflict.
					#ifdef VERIFICATION_CDCL
					verification_cdcl_verifyWatcher1Adaption_case1(cNum);
					#endif
					#ifdef VERBOSE_CDCL
					printf(" is a UNIT CONFLICT(#%i).\n",numberOfConflicts);fflush(stdout);
					#endif
					conflictClause = cNum;		//Set the conflict clause.
					cdcl_returnValue = CONFLICT;//Signal that a conflict was discovered.
					break;						//We can stop maintaining the arrays. We must back-jump anyway.
				} else {
					//Second, cNum is not a unit clause but we could not find a new first watcher because there
					//is no literal in the clause yet unassigned. The second watcher must either be making the
					//clause or, must be used for unit propagation, or we found a conflict.
					if (tvalue[abs(watchedLiteral2[cNum])] == 2){
						//Can be used for unit propagation.
						#ifdef VERIFICATION_CDCL
						verification_cdcl_verifyWatcher1Adaption_case2(cNum);
						#endif
						#ifdef VERBOSE_CDCL
						printf(" is unit in watcher 2. Add literal %i to propagation buffer with reason %i.\n",
								watchedLiteral2[cNum], cNum);fflush(stdout);
						#endif
						cdcl_addToUnitPropBuffer(watchedLiteral2[cNum],cNum);
					} else if ((tvalue[abs(watchedLiteral2[cNum])] > 0) != (watchedLiteral2[cNum] > 0)){
						//Is a conflict.
						#ifdef VERIFICATION_CDCL
						verification_cdcl_verifyWatcher1Adaption_case3(cNum);
						#endif
						#ifdef VERBOSE_CDCL
						printf(" is a CONFLICT(#%i).\n",numberOfConflicts);fflush(stdout);
						#endif
						conflictClause = cNum;		//Set the conflict clause.
						cdcl_returnValue = CONFLICT;//Signal that a conflict was discovered.
						break;						//We can stop maintaining the arrays. We must back-jump anyway.
					} else {
						//Is satisfied.
						#ifdef VERIFICATION_CDCL
						verification_cdcl_verifyWatcher1Adaption_case4(cNum);
						#endif
						#ifdef VERBOSE_CDCL
						printf(" is satisfied by second watcher.\n");fflush(stdout);
						#endif
					}
				}
			} else {
				//We succeeded in replacing the first watcher.
				//The replacement of the first watcher caused the watches1 array to change. A not yet checked
				//clause is found at the current position cNum in this array. We therefore undo the increment
				//of cNum here so we do not miss the clause that newly appeared at the position cNum.
				#ifdef VERBOSE_CDCL
				printf(" got watcher 1 replaced.\n");fflush(stdout);
				#endif
				--arrPtr;
			}
			#ifdef VERBOSE_CDCL
			printf("c Clause ");cdcl_printClauseInline(cNum);printf(" was updated successfully.\n");fflush(stdout);
			#endif
		}
		//We have now maintained all the clauses where toEnforce was the first watcher. If this resulted in a
		//conflict, we can abort the propagations here.
		if (cdcl_returnValue == CONFLICT) break; //This terminates the outer for loop.
		//From this position on, we do know that replacing the first watchers was successful. We can now check out
		//the second watchers in an almost similar for-loop.
		#ifdef VERBOSE_CDCL
		printf("c Handling the watches2 array.\nc Checking: ");
		for (arrPtr = watches2[toEnforce]+2; *arrPtr != -1; arrPtr++){
			printf("%i ", *arrPtr);
		}
		printf("\n");fflush(stdout);
		#endif
		for (arrPtr = watches2[toEnforce]+2; (cNum = *arrPtr) != -1; ++arrPtr){
			//If cNum is a unit clause, replacing the second watcher is useless since the clause cannot have a
			//second watcher. We assert this here.
			#ifdef VERIFICATION_CDCL
			verification_cdcl_verifyWatcher2Adaption_case0(cNum);
			#endif
			//Here cNum is a clause having toEnforce as second watcher. We try to replace it.
			#ifdef VERBOSE_CDCL
			printf("c Clause ");cdcl_printClauseInline(cNum);fflush(stdout);
			#endif
			cdcl_watcher_findNewSecond(cNum);
			//The above call will replace the second watcher if possible. If it does not succeed in doing so,
			//nothing changes for the second watcher of cNum.
			if (watchedLiteral2[cNum] == toEnforce){
				//We where unsuccessful in replacing the second watcher. This can have two reasons.
				if (clauseLiterals[cNum][1] == 0){
					//First, cNum is a unit clause and just got its one literal made false. This is a conflict.
					#ifdef VERIFICATION_CDCL
					verification_cdcl_verifyWatcher2Adaption_case1(cNum);
					#endif
					#ifdef VERBOSE_CDCL
					printf(" is a CONFLICT(#%i).\n",numberOfConflicts);fflush(stdout);
					#endif
					conflictClause = cNum;			//Set the conflict clause.
					cdcl_returnValue = CONFLICT;	//Signal that a conflict was discovered.
					break;							//We can stop maintaining the arrays. We must back-jump anyway.
				} else {
					//Second, cNum is not a unit clause but we could not find a new second watcher because there
					//is no literal in the clause yet unassigned. The first watcher must either be making the
					//clause or, must be used for unit propagation, or we found a conflict.
					if (tvalue[abs(watchedLiteral1[cNum])] == 2){
						//Can be used for unit propagation.
						#ifdef VERIFICATION_CDCL
						verification_cdcl_verifyWatcher2Adaption_case2(cNum);
						#endif
						#ifdef VERBOSE_CDCL
						printf(" is unit in watcher 1. Add literal %i to propagation buffer with reason %i.\n",
								watchedLiteral1[cNum], cNum);fflush(stdout);
						#endif
						cdcl_addToUnitPropBuffer(watchedLiteral1[cNum],cNum);
					} else if ((tvalue[abs(watchedLiteral1[cNum])] > 0) != (watchedLiteral1[cNum] > 0)){
						//Is a conflict.
						#ifdef VERIFICATION_CDCL
						verification_cdcl_verifyWatcher2Adaption_case3(cNum);
						#endif
						#ifdef VERBOSE_CDCL
						printf(" is a CONFLICT(#%i).\n",numberOfConflicts);fflush(stdout);
						#endif
						conflictClause = cNum;		//Set the conflict clause.
						cdcl_returnValue = CONFLICT;//Signal that a conflict was discovered.
						break;						//We can stop maintaining the arrays. We must back-jump anyway.
					} else {
						//Is satisfied.
						#ifdef VERIFICATION_CDCL
						verification_cdcl_verifyWatcher2Adaption_case4(cNum);
						#endif
						#ifdef VERBOSE_CDCL
						printf(" is satisfied by first watcher.\n");fflush(stdout);
						#endif
					}
				}
			} else {
				//We succeeded in replacing the second watcher.
				//The replacement of the second watcher caused the watches2 array to change. A not yet checked
				//clause is found at the current position cNum in this array. We therefore undo the increment
				//of cNum here so we do not miss the clause that newly appeared at the position cNum.
				#ifdef VERBOSE_CDCL
				printf(" got watcher 2 replaced.\n");fflush(stdout);
				#endif
				--arrPtr;
			}
			#ifdef VERBOSE_CDCL
			printf("c Clause ");cdcl_printClauseInline(cNum);printf(" was updated successfully.\n");fflush(stdout);
			#endif
		}
		//We have now maintained all the clauses where toEnforce was the second watcher. If this resulted in a
		//conflict, we can abort the propagations here.
		if (cdcl_returnValue == CONFLICT) break; //This terminates the outer for loop.

	}

	#ifdef VERBOSE_CDCL
	printf("c Done assigning variables.\n");fflush(stdout);
	#endif
}

int cdcl(){
	#ifdef VERBOSE_CDCL
	printf("c Calling CDCL on flip %i, call number %i...\n", flips,cdcl_callNumber+1);
	#endif

	#ifdef COLLINF_CDCL
	cdcl_callDistances += (flips - cdcl_lastCall);
	#endif

	cdcl_initCall();

	#ifdef VERBOSE_CDCL
	cdcl_printVariables();
	cdcl_printClauses();
	#endif

	#ifdef VERIFICATION_CDCL
	verification_cdcl_verifyInitCall();
	verification_cdcl_verifyMemoryAllocation();
	#endif

	#ifndef UNITWALK
	while (numberOfConflicts < maxNumberOfConflicts || currentDecLevel == 0){
	#else
	while (numberOfConflicts < maxNumberOfConflicts){
	#endif
		//Propagate any buffered decision (either by unit clauses, decision variables, or asserting literals).
		#ifdef VERIFICATION_CDCL
		verification_cdcl_verifyVariableStates();
		verification_cdcl_verifyClauseStates();
		#endif
		cdcl_returnValue = UNKNOWN;
		cdcl_propagateAssignments();

		//We start at the beginning of the unit propagation buffer for every decision and conflict analysis.
		cdcl_unitPropBufferPos 		= cdcl_unitPropBuffer;
		cdcl_unitPropBufferLast 	= cdcl_unitPropBuffer;
		cdcl_reasonPropBufferPos 	= cdcl_reasonPropBuffer;
		cdcl_reasonPropBufferLast	= cdcl_reasonPropBuffer;

		#ifdef VERBOSE_CDCL
		cdcl_printDecisionStack();
		#endif

		if (cdcl_returnValue == UNKNOWN){
			//No conflict was discovered. We must make a decision.
			#ifdef VERBOSE_CDCL
			printf("c CDCL DECISION HANDLING.\n");fflush(stdout);
			#endif
			//First we increase the decision level.
			cdcl_decisionStack_increaseDecisionLevel();
			//Then we find a literal we want to satisfy. Depending on the flags and heuristic used, we point to
			//a different method here:
			//	- Flag HIHEURISTIC enables cdcl_decisionStack_pickLiteralToSatisfy_HIheuristic(),
			//	- Flag VSIDSHEURISTIC enables cdcl_decisionStack_pickLiteralToSatisfy_VSIDSheuristic().
			//	  Which of the above is used depends on the instance and the adaptToInstance() in global.c.
			//	- Otherwise the fall-back method cdcl_decisionStack_pickLiteralToSatisfy_simple() is used.
			cdcl_pickLiteralToSatisfy();
			if (decisionLiteral == 0){
				//None found. This means there is no more variable left to assign. All assigned without a conflict means:
				cdcl_returnValue = SAT;
				//Transfer over the found solution from tvalue to the assignment array of the SLS component.
				cdcl_transferSolutionToSLS();
				break;
			}
			#ifdef VERBOSE_CDCL
			printf("c decisionLiteral: %i, rank: %i\n", decisionLiteral, variable_rank[abs(decisionLiteral)]);
			#endif
			#ifdef COLLINF_CDCL
			++cdcl_numberOfDecisions;
			#endif
		} else {
			#ifdef VERBOSE_CDCL
			printf("c CDCL CONFLICT HANDLING.\n");fflush(stdout);
			printf("c The conflict clause is %i.\n", conflictClause);
			#endif
			if (currentDecLevel == 0){
				//A conflict in decision level zero means we cannot satisfy this formula.
				solutionFoundBy = SOL_CDCL;
				cdcl_returnValue = UNSAT;
				#ifdef COLLINF_CDCL
				++cdcl_learnedClausesOfLength[0];
				#endif
				#ifdef VERBOSE_CDCL
				printf("c Decision level is 0. Formula is unsatisfiable.\n");fflush(stdout);
				#endif
				break;
			}
			#ifndef UNITWALK
				cdcl_conflictAnalysis_learn();
				cdcl_conflictAnalysis_insertNewClause();
				cdcl_decisionStack_backjump(cdcl_backjumpTargetLevel);
			#endif
			#ifdef VSIDS_INCREASEINCONFLICT
				if (heuristic == HEURVSIDS) cdcl_updateVSIDSScores();
			#endif
			#ifdef COLLINF_CDCL
				++cdcl_numberOfBackjumps;
			#endif
			++numberOfConflicts;
		}
	}

	#ifdef TRANSFERASSIGNMENTCHANGES
	if (cdcl_returnValue == UNKNOWN || cdcl_returnValue == CONFLICT) cdcl_transferAssignmentChangesToSLS();
	#endif

	//Back-jumping to level 0 means assign everything in tvalue to "2" to prepare the next call, but leave all
	//assignments made because of unit clauses alone. These stay for the next call to be already assigned.
	if (cdcl_returnValue == UNKNOWN || cdcl_returnValue == CONFLICT) cdcl_decisionStack_backjump(0);

	#ifdef VERBOSE_CDCL
	if (cdcl_returnValue == SAT){
		printf("c CDCL call done. Return value is: SAT.\n");
	} else if (cdcl_returnValue == UNSAT){
		printf("c CDCL call done. Return value is: UNSAT.\n");
	} else if (cdcl_returnValue == CONFLICT){
		printf("c CDCL call done. Return value is: CONFLICT.\n");
	} else {
		printf("c CDCL call done. Return value is: UNKNOWN.\n");
	}
	#endif
	cdcl_lastCall = flips;
	return cdcl_returnValue;
}

//This is the main method for the CDCL solver.
#endif /* HYBRID */
