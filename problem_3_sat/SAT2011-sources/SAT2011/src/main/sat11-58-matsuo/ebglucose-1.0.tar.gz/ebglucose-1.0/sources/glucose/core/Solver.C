/****************************************************************************************[Solver.C]
MiniSat -- Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#include "Solver.h"
#include "Sort.h"
#include <cmath>
#include "constants.h"

// Agressive deletion as described for Glucose version 1.1  -BM
#define GLUCOSE1_1AGG

/*
 * Bi-asserting clause variation options.  -BM
 */
//#define BAC_ONLY_MERGE_ON_DLVL
//#define BAC_GLUCOSE1_1AGG
//#define BAC_FURTHERBACK
// Bump unlearnt lits after learning bi-asserting clause.
#define BAC_BUMP 0
// Bump unlearnt lits twice after learning bi-asserting clause.
#define BAC_DOUBLEBUMP 0
// Bump the later-propagated literal after a learning bi-asserting clause.
#define BAC_BUMPLIT2 0
// Assume the negation of the first-propagated bi-asserting literal (bad idea).
#define BAC_ASSUMENEGEARLY 0
#define BAC_ASSUME_EMP 0

double  nof_learnts;
//=================================================================================================
// Constructor/Destructor:
int nbclausesbeforereduce = NBCLAUSESBEFOREREDUCE;



static inline void removeW(vec<Watched> &ws,Clause *c) {
  int j = 0;
  for (; j < ws.size() && ws[j].wcl != c; j++);
  assert(j < ws.size());
  for (; j < ws.size()-1; j++) ws[j] = ws[j+1];
  ws.pop();
  
}

static inline void removeBin(vec<Binaire> &ws,Clause *c) {
  int j = 0;
  for (; j < ws.size() && ws[j].clause != c; j++);
  assert(j < ws.size());
  for (; j < ws.size()-1; j++) ws[j] = ws[j+1];
  ws.pop();
  
}


Solver::Solver() :

    // Parameters: (formerly in 'SearchParams')
    var_decay(1 / 0.95), clause_decay(1 / 0.999), random_var_freq(0.02)
  , restart_first(100), restart_inc(1.5), learntsize_factor((double)1/(double)3), learntsize_inc(1)

    // More parameters:
    //
  , expensive_ccmin  (true)
  , polarity_mode    (polarity_user)
  , verbosity        (0)

    // Statistics: (formerly in 'SolverStats')
    // 
    , nbDL2(0),nbBin(0),nbUn(0)
    , nbReduceDB(0), starts(0)
    , decisions(0), rnd_decisions(0), propagations(0), conflicts(0)
#ifdef BACSTATCOLLECTION
    , stat_max_measure(1500), bac_propagations(0), resd_clauses(0), resd_bac(0)
#endif
  , clauses_literals(0), learnts_literals(0), max_literals(0), tot_literals(0)

  , ok               (true)
  , cla_inc          (1)
  , var_inc          (1)
#ifdef LINEARREGRESSION
   , lin_x(0), lin_y(0), sum_x(0), sum_y(0), prod_xy(0)
#endif
  , qhead            (0)
  , simpDB_assigns   (-1)
  , simpDB_props     (0)
  , order_heap       (VarOrderLt(activity))
  , random_seed      (91648253)
  , progress_estimate(0)
  , remove_satisfied (true)
{MYFLAG = 0;
#ifdef BACSTATCOLLECTION
//bac_prop_lbd_c = vec<uint64_t> ();
//bac_prop_len_c = vec<uint64_t> ();
//bac_res_lbd_c = vec<uint64_t> ();
//bac_res_len_c = vec<uint64_t> ();
//fuip_prop_lbd_c = vec<uint64_t> ();
//fuip_prop_len_c = vec<uint64_t> ();
//fuip_res_lbd_c = vec<uint64_t> ();
//fuip_res_len_c = vec<uint64_t> ();
bac_prop_lbd_c.growTo(stat_max_measure, 0);
bac_prop_len_c.growTo(stat_max_measure, 0);
bac_res_lbd_c.growTo(stat_max_measure, 0);
bac_res_len_c.growTo(stat_max_measure, 0);
fuip_prop_lbd_c.growTo(stat_max_measure, 0);
fuip_prop_len_c.growTo(stat_max_measure, 0);
fuip_res_lbd_c.growTo(stat_max_measure, 0);
fuip_res_len_c.growTo(stat_max_measure, 0);
#endif
}


Solver::~Solver()
{
    for (int i = 0; i < learnts.size(); i++) free(learnts[i]);
    for (int i = 0; i < clauses.size(); i++) free(clauses[i]);
}


//=================================================================================================
// Minor methods:


// Creates a new SAT variable in the solver. If 'decision_var' is cleared, variable will not be
// used as a decision variable (NOTE! This has effects on the meaning of a SATISFIABLE result).
//
Var Solver::newVar(bool sign, bool dvar)
{
    int v = nVars();
    watches   .push();          // (list for positive literal)
    watches   .push();          // (list for negative literal)
    watchesBin   .push();          // (list for negative literal)
    watchesBin   .push();          // (list for negative literal)
    reason    .push(NULL);
    assigns   .push(toInt(l_Undef));
    level     .push(-1);
    activity  .push(0);
    seen      .push(0);
    permDiff  .push(0);
	
    polarity    .push((char)sign);
    decision_var.push((char)dvar);

    insertVarOrder(v);
    return v;
}


bool Solver::addClause(vec<Lit>& ps)
{
    assert(decisionLevel() == 0);

    if (!ok)
        return false;
    else{
        // Check if clause is satisfied and remove false/duplicate literals:
        sort(ps);
        Lit p; int i, j;
        for (i = j = 0, p = lit_Undef; i < ps.size(); i++)
            if (value(ps[i]) == l_True || ps[i] == ~p)
                return true;
            else if (value(ps[i]) != l_False && ps[i] != p)
                ps[j++] = p = ps[i];
        ps.shrink(i - j);
    }

    if (ps.size() == 0)
        return ok = false;
    else if (ps.size() == 1){
        assert(value(ps[0]) == l_Undef);
        uncheckedEnqueue(ps[0]);
        return ok = (propagate() == NULL);
    }else{
        Clause* c = Clause_new(ps, false);
        clauses.push(c);
        attachClause(*c);
    }

    return true;
}


void Solver::attachClause(Clause& c) {
    assert(c.size() > 1);
    if(c.size()==2) {
      watchesBin[toInt(~c[0])].push();
      watchesBin[toInt(~c[1])].push();
      watchesBin[toInt(~c[0])].last().clause = &c;
      watchesBin[toInt(~c[0])].last().implied = c[1];
      watchesBin[toInt(~c[1])].last().clause = &c;
      watchesBin[toInt(~c[1])].last().implied = c[0];
      
    } else {
      watches[toInt(~c[0])].push();
      watches[toInt(~c[1])].push();
      watches[toInt(~c[0])].last().wcl = &c;
      watches[toInt(~c[0])].last().blocked = c[c.size()/2];
      watches[toInt(~c[1])].last().wcl = &c;
      watches[toInt(~c[1])].last().blocked = c[c.size()/2];
    }
    if (c.learnt()) learnts_literals += c.size();
    else            clauses_literals += c.size(); 
}

void Solver::detachClause(Clause& c) {
    assert(c.size() > 1);
    //    assert(find(watches[toInt(~c[0])], &c));
    //assert(find(watches[toInt(~c[1])], &c));

    if(c.size()==2) {
      removeBin(watchesBin[toInt(~c[0])],&c);
      removeBin(watchesBin[toInt(~c[1])],&c);
    } else {
      removeW(watches[toInt(~c[0])], &c);
      removeW(watches[toInt(~c[1])], &c); 
    }
    if (c.learnt()) learnts_literals -= c.size();
    else            clauses_literals -= c.size(); }


void Solver::removeClause(Clause& c) {
    detachClause(c);
    free(&c); }


bool Solver::satisfied(const Clause& c) const {
    for (int i = 0; i < c.size(); i++)
        if (value(c[i]) == l_True)
            return true;
    return false; }


// Revert to the state at given level (keeping all assignment at 'level' but not beyond).
//
void Solver::cancelUntil(int level) {
  if (decisionLevel() > level){
    for (int c = trail.size()-1; c >= trail_lim[level]; c--){
      Var     x  = var(trail[c]);
      assigns[x] = toInt(l_Undef);
      insertVarOrder(x); }
    qhead = trail_lim[level];
    trail.shrink(trail.size() - trail_lim[level]);
    trail_lim.shrink(trail_lim.size() - level);
  }
}


//=================================================================================================
// Major methods:


Lit Solver::pickBranchLit(int polarity_mode, double random_var_freq)
{
    Var next = var_Undef;

    // Random decision:
    if ((drand(random_seed) < random_var_freq) && !order_heap.empty()){
      
      next = order_heap[irand(random_seed,order_heap.size())];
      if (toLbool(assigns[next]) == l_Undef && decision_var[next])
	rnd_decisions++; }
    
    // Activity based decision:
    while (next == var_Undef || toLbool(assigns[next]) != l_Undef || !decision_var[next])
      if (order_heap.empty()){
            next = var_Undef;
            break;
        }else
            next = order_heap.removeMin();

    bool sign = false;
    switch (polarity_mode){
    case polarity_true:  sign = false; break;
    case polarity_false: sign = true;  break;
    case polarity_user:  if(next!=var_Undef) sign = polarity[next]; break;
    case polarity_rnd:   sign = irand(random_seed, 2); break;
    default: assert(false); }

    return next == var_Undef ? lit_Undef : Lit(next, sign);
}


/*_________________________________________________________________________________________________
|
|  analyze : (confl : Clause*) (out_learnt : vec<Lit>&) (out_btlevel : int&)  ->  [void]
|  
|  Description:
|    Analyze conflict and produce a reason clause.
|  
|    Pre-conditions:
|      * 'out_learnt' is assumed to be cleared.
|      * Current decision level must be greater than root level.
|  
|    Post-conditions:
|      * 'out_learnt[0]' is the asserting literal at level 'out_btlevel'.
|  
|  Effect:
|    Will undo part of the trail, upto but not beyond the assumption of the current decision level.
|________________________________________________________________________________________________@*/
void Solver::analyze(Clause* confl, vec<Lit>& out_learnt, int& out_btlevel,int &nbl,int &mer, bool &out_isbac, Lit& bac_emp)
{
    int pathC = 0;
    Lit p     = lit_Undef;

	
    out_learnt.push();      // (leave room for the asserting literal)
    int index   = trail.size() - 1;
    out_btlevel = 0;

    bool out_isempowering = false;  // Flag for finding 1-emp clauses.   BM
#ifdef BAC_ONLY_MERGE_ON_DLVL
    bool p_isempowering = false;
#endif
    bac_emp = lit_Undef;
    int bac_btlevel = -1;
    bool bac_nopathinc = false;
    Lit bac_lit1, bac_lit2;
    int bac_lit1_index = -1;
    int bac_edge = -1;
    out_isbac = false;
    do{
        assert(confl != NULL);          // (otherwise should be UIP)
        Clause& c = *confl;

#ifdef BACSTATCOLLECTION
        if (c.isLearnt()) {
            bool reason_isbac = c.isBiAsserting();
            ++resd_clauses;
            if (reason_isbac) ++resd_bac;

            int reason_lbd = c.activity();
            if (reason_lbd < stat_max_measure) {
                if (reason_isbac) bac_res_lbd_c[reason_lbd]++;
                else fuip_res_lbd_c[reason_lbd]++;
            }

            int reason_length = c.size();
            if (reason_length < stat_max_measure) {
                if (reason_isbac) bac_res_len_c[reason_length]++;
                else fuip_res_len_c[reason_length]++;
            }
        }
#endif
      
        // The first one has to be SAT
        if( p != lit_Undef && c.size()==2 && value(c[0])==l_False) {
	        assert(value(c[1])==l_True);
	        Lit tmp = c[0];
	        c[0] =  c[1], c[1] = tmp;
        }

        if (c.learnt())
	        claBumpActivity(c);
      
        for (int j = (p == lit_Undef) ? 0 : 1; j < c.size(); j++){
	        Lit q = c[j];
	
            if (!seen[var(q)] && level[var(q)] > 0){
	      
                varBumpActivity(var(q));

#ifdef BAC_ONLY_MERGE_ON_DLVL
                seen[var(q)] = p_isempowering ? 2 : 1;
#else
                seen[var(q)] = 1;
#endif
                if (level[var(q)] >= decisionLevel()){
                    pathC++;
                    if (bac_nopathinc) bac_nopathinc=false;
#ifdef UPDATEVARACTIVITY
		            if((reason[var(q)]!=NULL)  && (reason[var(q)]->learnt())) 
		                lastDecisionLevel.push(q);
#endif
		        }
                else{
                    out_learnt.push(q);
                    if (level[var(q)] > out_btlevel)
                        out_btlevel = level[var(q)];
                }
            }
#ifdef BAC_ONLY_MERGE_ON_DLVL
            else if (seen[var(q)] && level[var(q)] >= decisionLevel()) { // Check for a merge on the highest level.   -BM
                seen[var(q)] = 2;
                out_isempowering = true;
            }
#else
            else if (seen[var(q)]) { // Check for a merge on the highest level.   -BM
                out_isempowering = true;
            }
#endif
        }

        // Select next clause to look at:
        if (bac_nopathinc) { // skip retracing the trail if we know we can.
            p = bac_lit1;
            index = bac_lit1_index;
        }
        else {
            while (!seen[var(trail[index--])]);
            p = trail[index+1];
        }
#ifdef BAC_ONLY_MERGE_ON_DLVL
        p_isempowering = (seen[var(trail[index+1])] == 2);
#endif
        confl = reason[var(p)];
        seen[var(p)] = 0;
        pathC--;

        // Check for the first BAC.   BM
        if ( bac_btlevel == -1 && pathC == 1 && out_isempowering) {
            // Like FUIP, the F1BAC is the best BAC (lowest btlevel).
            bac_btlevel = out_btlevel;
            bac_lit1_index = index;
            while (!seen[var(trail[bac_lit1_index--])]);
                bac_lit1 = trail[bac_lit1_index + 1];
                bac_lit2 = p;
#ifdef BAC_ONLY_MERGE_ON_DLVL
                bac_emp = (seen[var(bac_lit1)] == 2) ? bac_lit1 : bac_lit2;
#else
                bac_emp = bac_lit1;
#endif
            bac_nopathinc = true;
            bac_edge = out_learnt.size(); // highest index in the BAC.
        }

    }while (pathC > 0);
#ifdef BAC_FURTHERBACK
    // This seemed to lower performance in all scenarios.
    if (bac_btlevel > out_btlevel - 3 || bac_btlevel == -1) { // BAC should not be learnt.
#else
    if (bac_btlevel > out_btlevel - 2 || bac_btlevel == -1) { // BAC should not be learnt.
#endif
        out_learnt[0] = ~p;
    }
    else {
        // The F1BAC if it is good enough to recreate.   BM
        /*
        * printf("Learnt F1BAC clause with btlevel %d (FUIP %d)\n", bac_btlevel, out_btlevel);
        * printf("    BA lits = (%s%d, %d) (%s%d, %d)\n",
        *         sign(bac_lit1) ? "" : "-", var(bac_lit1), level[var(bac_lit1)],
        *         sign(bac_lit2) ? "" : "-", var(bac_lit2), level[var(bac_lit2)]);
        * printf("    Length: %d\n", bac_nblearntlit + 2);
        */
        if (out_learnt.size() == 1) 
            out_learnt.growTo(2);
        else {
            for (int i = bac_edge; i < out_learnt.size(); i++) seen[var(out_learnt[i])] = 0;
            for (int i = bac_edge; i > 1; i--) out_learnt[i] = out_learnt[i-1];
            out_learnt.shrink(out_learnt.size() - bac_edge - 1);
        }

        out_learnt[0] = ~bac_lit1;
        out_learnt[1] = ~bac_lit2;
        out_btlevel = bac_btlevel;
        out_isbac = true;
        /*
        * for (int i = 0; i < out_learnt.size(); i++) {
        *     printf("(%s%d,%d)",
        *         value(sign(out_learnt[i])) == l_True ? "" : "-", var(out_learnt[i]), level[var(out_learnt[i])]);
        * }
        */
    }


	
    // Simplify conflict clause:
    //
    int i=0, j=0;
    int start_keep = 1 + (out_isbac ? 1 : 0);
    if (expensive_ccmin){
        uint32_t abstract_level = 0;
        for (i = start_keep; i < out_learnt.size(); i++)
	        abstract_level |= abstractLevel(var(out_learnt[i])); // (maintain an abstraction of levels involved in conflict)
      
        out_learnt.copyTo(analyze_toclear);
        for (i = j = start_keep; i < out_learnt.size(); i++)
	        if (reason[var(out_learnt[i])] == NULL || !litRedundant(out_learnt[i], abstract_level))
	            out_learnt[j++] = out_learnt[i];
    }else{
        out_learnt.copyTo(analyze_toclear);
        for (i = j = start_keep; i < out_learnt.size(); i++){
	        Clause& c = *reason[var(out_learnt[i])];
	        if(c.size()==2 && value(c[0])==l_False) {
	            assert(value(c[1])==l_True);
	            Lit tmp = c[0];
	            c[0] =  c[1], c[1] = tmp;
	        }
	
	        for (int k = start_keep; k < c.size(); k++)
	            if (!seen[var(c[k])] && level[var(c[k])] > 0){
	                out_learnt[j++] = out_learnt[i];
	                break;
                }
        }
    }
    max_literals += out_learnt.size();
    out_learnt.shrink(i - j);
    tot_literals += out_learnt.size();

    



    // Find correct backtrack level:
    //
    if (out_learnt.size() == 1)
        out_btlevel = 0;
    else if (out_isbac && out_learnt.size() == 2)  // BM
        out_btlevel = 0;
    else{
        int max_i = start_keep;
        for (int i = start_keep + 1; i < out_learnt.size(); i++)
            if (level[var(out_learnt[i])] > level[var(out_learnt[max_i])])
                max_i = i;
        Lit p                   = out_learnt[max_i];
        out_learnt[max_i]       = out_learnt[start_keep];
        out_learnt[start_keep]  = p;
        out_btlevel             = level[var(p)];
    }


    nbl = 0;mer = 0;
    MYFLAG++;
    for(int i=0;i<out_learnt.size();i++) {
      
        int l = level[var(out_learnt[i])];
        if (permDiff[l] != MYFLAG) {
		    permDiff[l] = MYFLAG;
		    nbl++;
		    mer +=nbPropagated(l);
        }
    }
    
	
#ifdef UPDATEVARACTIVITY
    if(lastDecisionLevel.size()>0) {
        for(int i = 0;i<lastDecisionLevel.size();i++) {
	        if(reason[var(lastDecisionLevel[i])]->activity()<nbl)
	            varBumpActivity(var(lastDecisionLevel[i]));
        }
        lastDecisionLevel.clear();
    } 
#endif	    
    



    for (int j = 0; j < analyze_toclear.size(); j++)
        seen[var(analyze_toclear[j])] = 0;    // ('seen[]' is now cleared)
}


// Check if 'p' can be removed. 'abstract_levels' is used to abort early if the algorithm is
// visiting literals at levels that cannot be removed later.
bool Solver::litRedundant(Lit p, uint32_t abstract_levels)
{
    analyze_stack.clear(); analyze_stack.push(p);
    int top = analyze_toclear.size();
    while (analyze_stack.size() > 0){
        assert(reason[var(analyze_stack.last())] != NULL);
        Clause& c = *reason[var(analyze_stack.last())]; analyze_stack.pop();
	if(c.size()==2 && value(c[0])==l_False) {
	  assert(value(c[1])==l_True);
	  Lit tmp = c[0];
	  c[0] =  c[1], c[1] = tmp;
	}
    
    
	for (int i = 1; i < c.size(); i++){
	  Lit p  = c[i];
	  if (!seen[var(p)] && level[var(p)] > 0){
	    if (reason[var(p)] != NULL && (abstractLevel(var(p)) & abstract_levels) != 0){
	      seen[var(p)] = 1;
	      analyze_stack.push(p);
	      analyze_toclear.push(p);
	    }else{
	      for (int j = top; j < analyze_toclear.size(); j++)
		seen[var(analyze_toclear[j])] = 0;
	      analyze_toclear.shrink(analyze_toclear.size() - top);
	      return false;
                }
	  }
        }
    }
    
    return true;
}


/*_________________________________________________________________________________________________
|
|  analyzeFinal : (p : Lit)  ->  [void]
|  
|  Description:
|    Specialized analysis procedure to express the final conflict in terms of assumptions.
|    Calculates the (possibly empty) set of assumptions that led to the assignment of 'p', and
|    stores the result in 'out_conflict'.
|________________________________________________________________________________________________@*/
void Solver::analyzeFinal(Lit p, vec<Lit>& out_conflict)
{
    out_conflict.clear();
    out_conflict.push(p);

    if (decisionLevel() == 0)
        return;

    seen[var(p)] = 1;

    for (int i = trail.size()-1; i >= trail_lim[0]; i--){
        Var x = var(trail[i]);
        if (seen[x]){
            if (reason[x] == NULL){
                assert(level[x] > 0);
                out_conflict.push(~trail[i]);
            }else{
                Clause& c = *reason[x];
                for (int j = 1; j < c.size(); j++)
                    if (level[var(c[j])] > 0)
                        seen[var(c[j])] = 1;
            }
            seen[x] = 0;
        }
    }

    seen[var(p)] = 0;
}


void Solver::uncheckedEnqueue(Lit p, Clause* from)
{

    assert(value(p) == l_Undef);
    assigns [var(p)] = toInt(lbool(!sign(p)));  // <<== abstract but not uttermost effecient
    level   [var(p)] = decisionLevel();
    reason  [var(p)] = from;
    polarity[var(p)] = sign(p);
    trail.push(p);
}


/*_________________________________________________________________________________________________
|
|  propagate : [void]  ->  [Clause*]
|  
|  Description:
|    Propagates all enqueued facts. If a conflict arises, the conflicting clause is returned,
|    otherwise NULL.
|  
|    Post-conditions:
|      * the propagation queue is empty, even if there was a conflict.
|________________________________________________________________________________________________@*/
Clause* Solver::propagate()
{
  Clause* confl     = NULL;
  int     num_props = 0;
#ifdef BACSTATCOLLECTION
  int     num_bac_props = 0;
#endif
  
  while (qhead < trail.size()){
    Lit            p   = trail[qhead++];     // 'p' is enqueued fact to propagate.
    vec<Watched>&  ws  = watches[toInt(p)];
    Watched         *i, *j, *end;
    num_props++;
#ifdef BACSTATCOLLECTION
    if (reason[var(p)] != NULL && reason[var(p)]->isLearnt() && reason[var(p)]->isBiAsserting())
        num_bac_props++;
#endif
    
    vec<Binaire> & wbin = watchesBin[toInt(p)];
    
    for(int k = 0;k<wbin.size();k++) {
      Lit imp = wbin[k].implied;
      if(value(imp) == l_False) {
	return wbin[k].clause;
      }
      
      if(value(imp) == l_Undef) {
	uncheckedEnqueue(imp,wbin[k].clause);
      }
    }
      

    for (i = j = (Watched*)ws, end = i + ws.size();  i != end;){
      if(value(i->blocked)==l_True) { // Clause is sat
	*j++ = *i++;
	continue;
      }
      Lit bl = i->blocked;
      Clause& c = *(i->wcl);
      i++;
      
      
      // Make sure the false literal is data[1]:
      Lit false_lit = ~p;
      if (c[0] == false_lit)
	c[0] = c[1], c[1] = false_lit;
      
      assert(c[1] == false_lit);
      
      // If 0th watch is true, then clause is already satisfied.
      Lit first = c[0];
      if (value(first) == l_True){
	j->wcl = &c;
	j->blocked = first;
	j++;
      }else{
	// Look for new watch:
	for (int k = 2; k < c.size(); k++)
	  if (value(c[k]) != l_False){
	    c[1] = c[k]; c[k] = false_lit;
	    watches[toInt(~c[1])].push();
	    watches[toInt(~c[1])].last().wcl = &c;
	    watches[toInt(~c[1])].last().blocked = c[0];
	    goto FoundWatch; }
	
	// Did not find watch -- clause is unit under assignment:
	j->wcl = &c;
	j->blocked = bl;
	j++;
	
	if (value(first) == l_False){
	  confl = &c;
	  qhead = trail.size();
	  // Copy the remaining watches:
	  while (i < end) 
	    *j++ = *i++;
	}else {
	  uncheckedEnqueue(first, &c);
	  
#ifdef DYNAMICNBLEVEL		    
	  if(c.learnt()  && c.activity()>2) { // GA
	    MYFLAG++;
	    int nblevels =0;
		      for(int i=0;i<c.size();i++) {
			int l = level[var(c[i])];
			if (permDiff[l] != MYFLAG) {
			  permDiff[l] = MYFLAG;
			  nblevels++;
			}
			
			
		      }
		      if(nblevels+1<c.activity()) {
			c.setActivity(nblevels);
		      } else {
		      }
		    }
#endif
	      }
            }
        FoundWatch:;
        }
        ws.shrink(i - j);
    }
    propagations += num_props;
    simpDB_props -= num_props;
#ifdef BACSTATCOLLECTION
    bac_propagations += num_bac_props;
#endif

    return confl;
}



/*_________________________________________________________________________________________________
|
|  reduceDB : ()  ->  [void]
|  
|  Description:
|    Remove half of the learnt clauses, minus the clauses locked by the current assignment. Locked
|    clauses are clauses that are reason to some assignment. Binary clauses are never removed.
|________________________________________________________________________________________________@*/
struct reduceDB_lt { 
  bool operator () (Clause* x, Clause* y) { 
#ifdef GLUCOSE1_1AGG
    return x->activity() > y->activity() ? 1
        : x->activity() < y->activity() ? 0
#ifdef BAC_GLUCOSE1_1AGG
        // This seems to hurt performance in all scenarios.
        : (x->isBiAsserting() && !y->isBiAsserting()) ? 1
#endif // end BAC_GLUCOSE1_1AGG
        : x->oldActivity() < y->oldActivity();  
#else
    return 
        // First criteria 
        (x->size()> 2 && y->size()==2) ? 1
        : (y->size()>2 && x->size()==2) ? 0
        : (x->size()==2 && y->size()==2) ? 0
    
        // Second one
        : (x->activity()> y->activity()) ? 1
        : (x->activity()< y->activity()) ? 0
        //: x->oldActivity() < y->oldActivity();
        : x->size() < y->size();
#endif
  }};




void Solver::reduceDB()
{
  int     i, j;
  
	
    nbReduceDB++;
    sort(learnts, reduceDB_lt());
    
    for (i = j = 0; i < learnts.size() / RATIOREMOVECLAUSES; i++){
        if (learnts[i]->size() > 2 && !locked(*learnts[i]) && learnts[i]->activity()>2){
            removeClause(*learnts[i]);
        }
        else
	        learnts[j++] = learnts[i];
    }
    for (; i < learnts.size(); i++){
        learnts[j++] = learnts[i];
    }
    learnts.shrink(i - j);
    nof_learnts   *= learntsize_inc;
}


void Solver::removeSatisfied(vec<Clause*>& cs)
{
    int i,j;
    for (i = j = 0; i < cs.size(); i++){
        if (satisfied(*cs[i]))
            removeClause(*cs[i]);
        else
            cs[j++] = cs[i];
    }
    cs.shrink(i - j);
}


/*_________________________________________________________________________________________________
|
|  simplify : [void]  ->  [bool]
|  
|  Description:
|    Simplify the clause database according to the current top-level assigment. Currently, the only
|    thing done here is the removal of satisfied clauses, but more things can be put here.
|________________________________________________________________________________________________@*/
bool Solver::simplify()
{
    assert(decisionLevel() == 0);

    if (!ok || propagate() != NULL)
        return ok = false;

    if (nAssigns() == simpDB_assigns || (simpDB_props > 0))
        return true;

    // Remove satisfied clauses:
    removeSatisfied(learnts);
    if (remove_satisfied)        // Can be turned off.
        removeSatisfied(clauses);

    // Remove fixed variables from the variable heap:
    order_heap.filter(VarFilter(*this));

    simpDB_assigns = nAssigns();
    simpDB_props   = clauses_literals + learnts_literals;   // (shouldn't depend on stats really, but it will do for now)

    return true;
}


/*_________________________________________________________________________________________________
|
|  search : (nof_conflicts : int) (nof_learnts : int) (params : const SearchParams&)  ->  [lbool]
|  
|  Description:
|    Search for a model the specified number of conflicts, keeping the number of learnt clauses
|    below the provided limit. NOTE! Use negative value for 'nof_conflicts' or 'nof_learnts' to
|    indicate infinity.
|  
|  Output:
|    'l_True' if a partial assigment that is consistent with respect to the clauseset is found. If
|    all variables are decision variables, this means that the clause set is satisfiable. 'l_False'
|    if the clause set is unsatisfiable. 'l_Undef' if the bound on number of conflicts is reached.

|________________________________________________________________________________________________@*/

static long curRestart = 1,cons=0,conf4Stats=0;

lbool Solver::search(int nof_conflicts, int nof_learnts)
{
    assert(ok);
    int         backtrack_level;
    int         conflictsC = 0;
    vec<Lit>    learnt_clause;
    bool        learnt_isbac;
    Lit         bac_emp_lit;
    int nblevels=0,nbCC=0,merged=0;
    starts++;
    bool first = true;

    for (;;){

        Clause* confl = propagate();
        if (confl != NULL){
            // CONFLICT
	        conflicts++; conflictsC++;cons++;nbCC++;
            if (decisionLevel() == 0) return l_False;

            first = false;

            learnt_clause.clear();
            analyze(confl, learnt_clause, backtrack_level,nblevels,merged,learnt_isbac, bac_emp_lit);


	        conf4Stats++;
	        nbDecisionLevelHistory.push(nblevels);
	        totalSumOfDecisionLevel += nblevels;
	    
	        cancelUntil(backtrack_level);
	        assert(value(learnt_clause[0]) == l_Undef);
	    
	        if (learnt_clause.size() == 1){
	            uncheckedEnqueue(learnt_clause[0]);
	            nbUn++;
            }else{
	            Clause* c = Clause_new(learnt_clause, true);
	            learnts.push(c);
                c->setIsBiAsserting(learnt_isbac); // BM
	            c->setActivity(nblevels); // LS
	            if(nblevels<=2) nbDL2++;
	            if(c->size()==2) nbBin++;
	            attachClause(*c);
	            claBumpActivity(*c);
                /*
                * printf("Learnt %s (%s) with Size %d, LBD %d, nblevels %d\n",
                *         c->isBiAsserting() ? "F1BAC" : "FUIP",
                *         learnt_isbac ? "F1BAC" : "FUIP",
                *         c->size(), c->activity(), nblevels);
                */
                if (learnt_isbac) { // Don't enqueue propagation for BAC clauses.  BM
                    /*
                    * for (int i = 0; i < c->size(); i++) {
                    *     printf("(%s%d,%d)",
                    *         value(sign((*c)[i])) == l_True ? "" : "-", var((*c)[i]), level[var((*c)[i])]);
                    * } printf("\n");
                    */
#if(BAC_BUMP || BAC_DOUBLEBUMP)
                    varBumpActivity(var(learnt_clause[0]));
#endif
#if(BAC_DOUBLEBUMP)
                    varBumpActivity(var(learnt_clause[0]));
#endif
#if(BAC_BUMP || BAC_DOUBLEBUMP)
                    varBumpActivity(var(learnt_clause[1]));
#endif
#if(BAC_DOUBLEBUMP)
                    varBumpActivity(var(learnt_clause[1]));
#endif
#if(BAC_BUMPLIT2)
                    varBumpActivity(var(learnt_clause[1]));
#endif
#if(BAC_ASSUMENEGEARLY)
                    newDecisionLevel();
                    uncheckedEnqueue(~learnt_clause[0]);
#endif
#if(BAC_ASSUME_EMP)
                    newDecisionLevel();
                    uncheckedEnqueue(bac_emp_lit);
#endif
                } 
                else {
	                uncheckedEnqueue(learnt_clause[0], c);
                }
                
            }
	        varDecayActivity();
	        claDecayActivity();
        }else{
	        if (
	                ( nbDecisionLevelHistory.isvalid() 
                        && ((nbDecisionLevelHistory.getavg()*0.7)
                            > (totalSumOfDecisionLevel / conf4Stats)))) {
	            nbDecisionLevelHistory.fastclear();
	            progress_estimate = progressEstimate();
	            cancelUntil(0);
	            return l_Undef;
            }


            // Simplify the set of problem clauses:
            if (decisionLevel() == 0 && !simplify())
                return l_False;
	    //

            Lit next = lit_Undef;


	        if(cons-curRestart* nbclausesbeforereduce>=0) {
		        curRestart = (conflicts/ nbclausesbeforereduce)+1;
		        reduceDB();
		        nbclausesbeforereduce += 500;
	        }


            if (next == lit_Undef){
                // New variable decision:
                decisions++;
                next = pickBranchLit(polarity_mode, random_var_freq);

                if (next == lit_Undef)
                    // Model found:
                    return l_True;
            }

            // Increase decision level and enqueue 'next'
            assert(value(next) == l_Undef);
            newDecisionLevel();
            uncheckedEnqueue(next);
        }
    }
}


double Solver::progressEstimate() const
{
    double  progress = 0;
    double  F = 1.0 / nVars();

    for (int i = 0; i <= decisionLevel(); i++){
        int beg = i == 0 ? 0 : trail_lim[i - 1];
        int end = i == decisionLevel() ? trail.size() : trail_lim[i];
        progress += pow(F, i) * (end - beg);
    }

    return progress / nVars();
}


bool Solver::solve(const vec<Lit>& assumps)
{
    model.clear();
    conflict.clear();

    nbDecisionLevelHistory.initSize(100);
    totalSumOfDecisionLevel = 0;
    
    if (!ok) return false;
    
    assumps.copyTo(assumptions);

    double nof_conflicts = restart_first;
    nof_learnts   = nClauses() * learntsize_factor;

    if(nof_learnts <nbclausesbeforereduce) {
      nbclausesbeforereduce = (nof_learnts/2 < 5000) ? 5000 : nof_learnts/2;
    }
    lbool   status        = l_Undef;

    if (verbosity >= 1){
        reportf("============================[ Search Statistics ]==============================\n");
        reportf("| Conflicts |          ORIGINAL         |          LEARNT          | Progress |\n");
        reportf("|           |    Vars  Clauses Literals |    Limit  Clauses Lit/Cl |          |\n");
        reportf("===============================================================================\n");
    }

    // Search:
    while (status == l_Undef){
        if (verbosity >= 1)
            reportf("| %9d | %7d %8d %8d | %8d %8d %6.0f | %6.3f %% |\n", (int)conflicts, order_heap.size(), nClauses(), (int)clauses_literals, (int)nof_learnts, nLearnts(), (double)learnts_literals/nLearnts(), progress_estimate*100), fflush(stdout);
        status = search((int)nof_conflicts, (int)nof_learnts);
        nof_conflicts *= restart_inc;
 //LS mis dans reduceDB lui meme       nof_learnts   *= learntsize_inc;
	
	
    }

    if (verbosity >= 1)
        reportf("===============================================================================\n");


    if (status == l_True){
        // Extend & copy model:
        model.growTo(nVars());
        for (int i = 0; i < nVars(); i++) model[i] = value(i);
#ifndef NDEBUG
        verifyModel();
#endif
    }else{
        assert(status == l_False);
        if (conflict.size() == 0)
            ok = false;
    }
#ifdef LS_STATS_NBBUMP
	for(int i=0;i<learnts.size();i++)
		printf("## %d %d %d\n",learnts[i]->size(),learnts[i]->activity(),(unsigned int)learnts[i]->nbBump());
#endif
    cancelUntil(0);
    return status == l_True;
}

//=================================================================================================
// Debug methods:


void Solver::verifyModel()
{
    bool failed = false;
    for (int i = 0; i < clauses.size(); i++){
        assert(clauses[i]->mark() == 0);
        Clause& c = *clauses[i];
        for (int j = 0; j < c.size(); j++)
            if (modelValue(c[j]) == l_True)
                goto next;

        reportf("unsatisfied clause: ");
        printClause(*clauses[i]);
        reportf("\n");
        failed = true;
    next:;
    }

    assert(!failed);

    reportf("Verified %d original clauses.\n", clauses.size());
}


void Solver::checkLiteralCount()
{
    // Check that sizes are calculated correctly:
    int cnt = 0;
    for (int i = 0; i < clauses.size(); i++)
        if (clauses[i]->mark() == 0)
            cnt += clauses[i]->size();

    if ((int)clauses_literals != cnt){
        fprintf(stderr, "literal count: %d, real value = %d\n", (int)clauses_literals, cnt);
        assert((int)clauses_literals == cnt);
    }
}

