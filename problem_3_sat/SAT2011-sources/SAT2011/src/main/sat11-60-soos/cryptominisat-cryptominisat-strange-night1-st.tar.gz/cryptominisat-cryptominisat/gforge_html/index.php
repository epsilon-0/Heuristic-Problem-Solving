<?php

   header( 'Location: http://www.msoos.org/wordpress/?page_id=99' ) ;

?>
