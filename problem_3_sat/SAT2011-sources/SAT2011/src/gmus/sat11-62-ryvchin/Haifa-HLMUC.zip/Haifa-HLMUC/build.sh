#!/bin/sh
export MROOT=<Change to location of the folder>
echo $MROOT
cd simp
gmake clean
gmake rs
cp minisat_static ../hhlmuc
